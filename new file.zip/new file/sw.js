self.addEventListener('install', (event) => {
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(clients.claim());
});

// 🔥 PUSH EVENT: Background me notification ko pakad kar screen par dikhana 🔥
self.addEventListener('push', function(event) {
    console.log('[Service Worker] Push Received.');
    
    let pushData = {};
    if (event.data) {
        try {
            pushData = event.data.json();
        } catch (e) {
            pushData = { title: "SCPK CRM Alert", message: event.data.text() };
        }
    }

    const title = pushData.title || "SCPK CRM";
    const options = {
        body: pushData.message || "You have a new update in CRM.",
        icon: '/favicon.png', // Android pop-up icon ke liye
        badge: '/favicon.png', // Android status bar chhote icon ke liye
        vibrate: [200, 100, 200, 100, 200], // Phone screen on/vibrate karne ke liye
        requireInteraction: true, // Jab tak click na ho notification screen par rahega
        data: {
            url: pushData.url || '/' // Click hone par kahan jana hai
        }
    };

    event.waitUntil(
        self.registration.showNotification(title, options)
    );
});

// 🔥 CLICK EVENT: Click karne par sahi CRM page (Lead Profile/Dashboard) kholna 🔥
self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    
    // Check url inside notification data, fallback to '/'
    const targetUrl = event.notification.data && event.notification.data.url ? event.notification.data.url : '/';

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
            // Agar CRM ka tab pehle se khula hai toh sirf usko focus karo
            for (const client of clientList) {
                if (client.url.includes(targetUrl) && 'focus' in client) {
                    return client.focus();
                }
            }
            // Agar CRM ka tab band hai toh naya window kholo
            if (clients.openWindow) {
                return clients.openWindow(targetUrl);
            }
        })
    );
});