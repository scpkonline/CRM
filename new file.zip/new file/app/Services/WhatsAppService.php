<?php
namespace Services;

class WhatsAppService {
    
    private $apiUrl;
    private $token;

    public function __construct() {
        $this->apiUrl = 'https://graph.facebook.com/v19.0/' . WA_PHONE_NUMBER_ID . '/messages';
        $this->token = WA_ACCESS_TOKEN;
    }

    public function sendTextMessage($recipientPhone, $messageText, $replyToMessageId = null) {
        $data = [
            'messaging_product' => 'whatsapp', 
            'recipient_type' => 'individual', 
            'to' => $recipientPhone, 
            'type' => 'text',
            'text' => ['preview_url' => false, 'body' => $messageText]
        ];
        
        if (!empty($replyToMessageId)) {
            $data['context'] = ['message_id' => $replyToMessageId];
        }
        
        return $this->sendRequest($data);
    }

    public function sendImageMessage($recipientPhone, $imageUrl, $caption = '', $replyToMessageId = null) {
        $data = [
            'messaging_product' => 'whatsapp', 
            'recipient_type' => 'individual', 
            'to' => $recipientPhone, 
            'type' => 'image',
            'image' => ['link' => $imageUrl]
        ];
        
        if (!empty($caption)) {
            $data['image']['caption'] = $caption;
        }
        
        if (!empty($replyToMessageId)) {
            $data['context'] = ['message_id' => $replyToMessageId];
        }
        
        return $this->sendRequest($data);
    }

    public function sendVideoMessage($recipientPhone, $videoUrl, $caption = '', $replyToMessageId = null) {
        $data = [
            'messaging_product' => 'whatsapp', 
            'recipient_type' => 'individual', 
            'to' => $recipientPhone, 
            'type' => 'video',
            'video' => ['link' => $videoUrl]
        ];
        
        if (!empty($caption)) {
            $data['video']['caption'] = $caption;
        }
        
        if (!empty($replyToMessageId)) {
            $data['context'] = ['message_id' => $replyToMessageId];
        }
        
        return $this->sendRequest($data);
    }

    public function sendAudioMessage($recipientPhone, $audioUrl, $replyToMessageId = null) {
        $data = [
            'messaging_product' => 'whatsapp', 
            'recipient_type' => 'individual', 
            'to' => $recipientPhone, 
            'type' => 'audio',
            'audio' => ['link' => $audioUrl]
        ];
        
        if (!empty($replyToMessageId)) {
            $data['context'] = ['message_id' => $replyToMessageId];
        }
        
        return $this->sendRequest($data);
    }

    public function sendDocumentMessage($recipientPhone, $docUrl, $filename = 'Document', $replyToMessageId = null) {
        $data = [
            'messaging_product' => 'whatsapp', 
            'recipient_type' => 'individual', 
            'to' => $recipientPhone, 
            'type' => 'document',
            'document' => ['link' => $docUrl, 'filename' => $filename]
        ];
        
        if (!empty($replyToMessageId)) {
            $data['context'] = ['message_id' => $replyToMessageId];
        }
        
        return $this->sendRequest($data);
    }

    public function sendTemplateMessage($recipientPhone, $templateName, $language = 'en') {
        $data = [
            'messaging_product' => 'whatsapp', 
            'recipient_type' => 'individual', 
            'to' => $recipientPhone, 
            'type' => 'template',
            'template' => [
                'name' => $templateName,
                'language' => ['code' => $language]
            ]
        ];
        return $this->sendRequest($data);
    }

    public function downloadMedia($mediaId) {
        $ch = curl_init('https://graph.facebook.com/v19.0/' . $mediaId);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $this->token]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // NAYA: Security on
        $res = curl_exec($ch);
        curl_close($ch);
        
        $mediaData = json_decode($res, true);
        if (!isset($mediaData['url'])) return null;
        
        $ch2 = curl_init($mediaData['url']);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $this->token]);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch2, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, true); // NAYA: Security on
        $binary = curl_exec($ch2);
        curl_close($ch2);
        
        return [
            'data' => $binary,
            'mime_type' => $mediaData['mime_type'] ?? 'image/jpeg'
        ];
    }

    private function sendRequest($data) {
        $ch = curl_init($this->apiUrl);
        $payload = json_encode($data);
        
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // NAYA: SSL Hamesha On rakhein
        curl_setopt($ch, CURLOPT_TIMEOUT, 15); // NAYA: Agar Meta server down ho toh CRM stuck na ho
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return ['status' => $httpCode, 'response' => json_decode($response, true)];
    }
}
?>