<?php
namespace Core;

class NotificationHelper {
    
    /**
     * Send Real-time notification to user (Stored in MySQL)
     */
    public static function sendToUser($userId, $title, $message, $url = '') {
        if (empty($userId) || empty($title)) {
            return false;
        }
        
        if (empty($url)) {
            $url = defined('BASE_URL') ? BASE_URL . 'assignments' : '/';
        }

        try {
            $pdo = Database::getInstance();
            $stmt = $pdo->prepare("INSERT INTO user_notifications (user_id, title, message, url, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())");
            return $stmt->execute([$userId, $title, $message, $url]);
        } catch (\Exception $e) {
            error_log("Notification Error: " . $e->getMessage());
            return false;
        }
    }
}