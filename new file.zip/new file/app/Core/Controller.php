<?php
namespace Core;

class Controller {
    // Helper function to load views safely
    protected function view($view, $data = []) {
        extract($data);
        $viewFile = APP_DIR . 'Views/' . $view . '.php';
        
        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            die("View does not exist: " . $view);
        }
    }
}
?>