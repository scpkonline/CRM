<?php
namespace Core;
use PDO;
use PDOException;

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => true, // NAYA: Connection fast karne ke liye
            ];
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            // Use UTC for MySQL timestamp storage/read consistency.
            // Reset each connection, including reused persistent PDO sessions.
            // Display timezone will be controlled by Preferences in later stages.
            $this->pdo->exec("SET time_zone = '+00:00'");
        } catch (PDOException $e) {
            // Error details chhupane ke liye taaki database structure leak na ho
            die("Database Connection Failed. Please try again later.");
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance->pdo;
    }
}
?>