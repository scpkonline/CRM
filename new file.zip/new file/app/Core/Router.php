<?php
namespace Core;

/**
 * Compatible with the CRM's original URL routing behavior.
 * Security: rejects calls to protected/private/inherited controller methods.
 * Requires login for ordinary CRM routes; keeps integration webhooks public.
 * Uses PHP 7-compatible functions (no str_contains/str_starts_with).
 */
class Router {
    protected $controller = 'HomeController';
    protected $method = 'index';
    protected $params = [];

    private const IDLE_TIMEOUT = 7200;

    public function dispatch($url) {
        $url = $this->parseUrl($url);

        // Preserve the exact controller filename mapping used by original CRM.
        if (isset($url[0]) && is_string($url[0])) {
            $segment = $url[0];
            if (preg_match('/\A[A-Za-z][A-Za-z0-9_]*\z/D', $segment)) {
                $candidate = ucwords($segment) . 'Controller';
                if (is_file(APP_DIR . 'Controllers/' . $candidate . '.php')) {
                    $this->controller = $candidate;
                    unset($url[0]);
                }
            }
        }

        $controllerClass = '\\Controllers\\' . $this->controller;
        if (!class_exists($controllerClass)) {
            $this->notFound();
        }

        // Never dispatch inherited Controller helpers / magic / private methods.
        // For unknown methods, preserve the original 'index' fallback, but do NOT
        // accidentally use request arguments to invoke index via unknown method.
        if (isset($url[1]) && is_string($url[1])) {
            $requestedMethod = $url[1];
            if (preg_match('/\A[A-Za-z][A-Za-z0-9_]*\z/D', $requestedMethod)
                && $this->isSafeAction($controllerClass, $requestedMethod)) {
                $this->method = $requestedMethod;
                unset($url[1]);
            } else {
                $this->notFound();
            }
        }

        if (!$this->isSafeAction($controllerClass, $this->method)) {
            $this->notFound();
        }

        $this->authorize($this->controller, $this->method);

        $this->controller = new $controllerClass();
        $this->params = $url ? array_values($url) : [];
        call_user_func_array([$this->controller, $this->method], $this->params);
    }

    private function isSafeAction($controllerClass, $method) {
        if (!is_string($method) || $method === '' || $method[0] === '_') return false;
        if (!method_exists($controllerClass, $method)) return false;
        $reflection = new \ReflectionMethod($controllerClass, $method);
        return $reflection->isPublic()
            && !$reflection->isStatic()
            && $reflection->getDeclaringClass()->getName() === ltrim($controllerClass, '\\');
    }

    private function authorize($controller, $method) {
        // External webhook endpoints must remain accessible until Stage 3
        // installs Meta signature validation.
        $public =
            ($controller === 'HomeController' && $method === 'index') ||
            ($controller === 'AuthController' && in_array($method, ['index', 'login', 'forgot_password', 'reset_password'], true)) ||
            ($controller === 'WebhookController' && in_array($method, ['whatsapp', 'website_leads'], true)) ||
            ($controller === 'BotController' && $method === 'whatsapp');

        if ($public) return;

        if (empty($_SESSION['user_id'])) {
            $this->unauthorized();
        }

        // Keep existing logged-in sessions compatible with this staged rollout:
        // an activity marker exists only after new AuthController login.
        if (isset($_SESSION['crm_last_activity'])) {
            if (time() - (int)$_SESSION['crm_last_activity'] > self::IDLE_TIMEOUT) {
                $_SESSION = [];
                $this->unauthorized();
            }
        }
        $_SESSION['crm_last_activity'] = time();
    }

    private function unauthorized() {
        $accept = strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
        $contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
        if (strpos($accept, 'application/json') !== false
            || strpos($contentType, 'application/json') !== false) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['status' => 'error', 'message' => 'Authentication required']);
        } else {
            header('Location: ' . BASE_URL . 'auth');
        }
        exit;
    }

    private function notFound() {
        http_response_code(404);
        echo 'Not Found';
        exit;
    }

    private function parseUrl($url) {
        if (is_string($url) && $url !== '') {
            return explode('/', filter_var(rtrim($url, '/'), FILTER_SANITIZE_URL));
        }
        return [];
    }
}
?>
