<?php
declare(strict_types=1);

namespace Core;

use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;
use PDO;
use PDOException;

/**
 * Central CRM timezone helper.
 *
 * Storage policy:
 * - MySQL connection and database timestamps use UTC.
 * - One company-level display timezone is selected in Preferences.
 * - Display conversion never modifies existing database records.
 *
 * IMPORTANT: The companion crm_timezone_settings table and the Preferences
 * controller integration are installed in Stage 2. Adding this class alone
 * will not change the CRM's existing behavior.
 */
final class Timezone
{
    private const DEFAULT_TIMEZONE = 'Asia/Kolkata';

    private const ALLOWED_TIMEZONES = [
        'Asia/Kolkata',
        'UTC',
    ];

    /** Get the allowed display timezone choices. */
    public static function choices(): array
    {
        return self::ALLOWED_TIMEZONES;
    }

    /** Validate a timezone chosen in Settings > Preferences. */
    public static function validate(string $timezone): string
    {
        if (!in_array($timezone, self::ALLOWED_TIMEZONES, true)) {
            throw new InvalidArgumentException('Unsupported CRM timezone.');
        }

        return $timezone;
    }

    /**
     * Read the company-wide timezone preference.
     * Before Stage 2 creates the settings table, use Asia/Kolkata safely.
     */
    public static function get(PDO $pdo, int $companyId = 1): string
    {
        try {
            $stmt = $pdo->prepare(
                'SELECT timezone FROM crm_timezone_settings WHERE company_id = ? LIMIT 1'
            );
            $stmt->execute([$companyId]);
            $value = $stmt->fetchColumn();

            if (is_string($value) && in_array($value, self::ALLOWED_TIMEZONES, true)) {
                return $value;
            }
        } catch (PDOException $e) {
            // The table may not exist until the Preferences migration is applied.
            // Leave existing CRM behavior untouched during staged installation.
        }

        return self::DEFAULT_TIMEZONE;
    }

    /** Save the company-wide timezone (requires the Stage 2 settings table). */
    public static function save(PDO $pdo, int $companyId, string $timezone): void
    {
        $timezone = self::validate($timezone);
        $stmt = $pdo->prepare(
            'INSERT INTO crm_timezone_settings (company_id, timezone) VALUES (?, ?) '
            . 'ON DUPLICATE KEY UPDATE timezone = VALUES(timezone)'
        );
        $stmt->execute([$companyId, $timezone]);
    }

    /** Interpret an unqualified database timestamp as UTC and show selected time. */
    public static function formatUtc(
        ?string $utcTimestamp,
        string $timezone,
        string $format = 'd M Y, h:i A'
    ): string {
        if ($utcTimestamp === null || trim($utcTimestamp) === '') {
            return '-';
        }

        self::validate($timezone);
        $source = new DateTimeImmutable($utcTimestamp, new DateTimeZone('UTC'));
        return $source->setTimezone(new DateTimeZone($timezone))->format($format);
    }

    /** Convert a UTC value to a DateTimeImmutable in the selected timezone. */
    public static function fromUtc(string $utcTimestamp, string $timezone): DateTimeImmutable
    {
        self::validate($timezone);
        return (new DateTimeImmutable($utcTimestamp, new DateTimeZone('UTC')))
            ->setTimezone(new DateTimeZone($timezone));
    }

    /** Convert a locally entered reminder/filter time back to UTC for storage. */
    public static function toUtc(
        string $localTimestamp,
        string $timezone,
        string $format = 'Y-m-d H:i:s'
    ): string {
        self::validate($timezone);
        return (new DateTimeImmutable($localTimestamp, new DateTimeZone($timezone)))
            ->setTimezone(new DateTimeZone('UTC'))
            ->format($format);
    }
}
