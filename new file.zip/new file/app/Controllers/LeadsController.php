<?php 
namespace Controllers; 
use Core\Controller; 
use Core\Database;

class LeadsController extends Controller {
    // Date-only UI filters use the company calendar day; DB timestamps remain UTC.
    private function utcFilterBoundary($value, $timezone, $endExclusive = false) {
        if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value)) return null;
        $local = \DateTimeImmutable::createFromFormat('!Y-m-d', $value, new \DateTimeZone($timezone));
        if (!$local || $local->format('Y-m-d') !== $value) return null;
        if ($endExclusive) $local = $local->modify('+1 day');
        return \Core\Timezone::toUtc($local->format('Y-m-d') . ' 00:00:00', $timezone);
    }

          
    
    public function index() {          
        if (!isset($_SESSION['user_id'])) {              
            header('Location: ' . BASE_URL . 'auth');              
            exit;          
        }          
        
        $company_id = $_SESSION['company_id'] ?? 1;
        $user_id = $_SESSION['user_id'];
        $role = isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES';
        
        $pdo = Database::getInstance();
        $displayTimezone = \Core\Timezone::get($pdo, (int)$company_id);
        $todayLocal = (new \DateTimeImmutable('now', new \DateTimeZone($displayTimezone)))->format('Y-m-d');

        $queryString = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
        if ($queryString) {
            parse_str($queryString, $customGet);
            $_GET = array_merge($_GET, $customGet);
        }

        // --- 🔥 SERVER-SIDE FILTERS & SEARCH LOGIC 🔥 ---
        $where_clauses = ["company_id = :company_id"];
        $params = [':company_id' => $company_id];

        if ($role !== 'ADMIN') {
            $where_clauses[] = "(assigned_to IS NULL OR assigned_to = 0 OR assigned_to = :user_id)";
            $params[':user_id'] = $user_id;
        }

        // Smart Search Logic
        if (!empty($_GET['search']) && trim($_GET['search']) !== '') {
            $searchTerm = trim($_GET['search']);
            
            $searchClause = "(
                full_name LIKE :search1 
                OR company_name LIKE :search2 
                OR email LIKE :search3 
                OR city LIKE :search4 
                OR phone_number LIKE :search5 
                OR whatsapp_number LIKE :search6 
                OR tags LIKE :search7
                OR products_of_interest LIKE :search8";
            
            $params[':search1'] = '%' . $searchTerm . '%';
            $params[':search2'] = '%' . $searchTerm . '%';
            $params[':search3'] = '%' . $searchTerm . '%';
            $params[':search4'] = '%' . $searchTerm . '%';
            $params[':search5'] = '%' . $searchTerm . '%';
            $params[':search6'] = '%' . $searchTerm . '%';
            $params[':search7'] = '%' . $searchTerm . '%';
            $params[':search8'] = '%' . $searchTerm . '%';

            if (preg_match('/^[0-9\+\-\s]+$/', $searchTerm)) {
                $cleanNum = preg_replace('/[^0-9]/', '', $searchTerm);
                if (strlen($cleanNum) > 10 && substr($cleanNum, 0, 2) == '91') {
                    $cleanNum = substr($cleanNum, 2);
                }
                
                if(!empty($cleanNum)) {
                    $searchClause .= " OR phone_number LIKE :cleanNum1 OR whatsapp_number LIKE :cleanNum2";
                    $params[':cleanNum1'] = '%' . $cleanNum . '%';
                    $params[':cleanNum2'] = '%' . $cleanNum . '%';
                }
            }
            
            $searchId = 0;
            if (preg_match('/^#?LD-([0-9]+)$/i', $searchTerm, $matches)) {
                $searchId = (int)$matches[1];
            } elseif (preg_match('/^[0-9]+$/', $searchTerm)) {
                $searchId = (int)$searchTerm;
            }

            if ($searchId > 0) {
                $searchClause .= " OR id = :searchId";
                $params[':searchId'] = $searchId;
            }
            
            $searchClause .= ")";
            $where_clauses[] = $searchClause;
        }

        // 🔥 FIXED: Default to 'new' leads if status is not provided 🔥
        $status_filter = $_GET['status'] ?? 'new';
        $_GET['status'] = $status_filter; // View ke liye set kar diya

        if ($status_filter !== 'all') {
            if ($status_filter === 'new') {
                $where_clauses[] = "(lead_stage = 'new' OR lead_stage = 'New' OR lead_stage IS NULL OR lead_stage = '')";
            } elseif ($status_filter === 'pipeline') {
                $where_clauses[] = "LOWER(lead_stage) IN ('qualified', 'catalog sharing', 'follow up', 'negotiation', 'sold')";
            } elseif ($status_filter === 'unqualified') {
                $where_clauses[] = "LOWER(lead_stage) LIKE '%unqualified%'";
            } elseif ($status_filter === 'catalog_sharing') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'catalog sharing'";
            } elseif ($status_filter === 'follow_up') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'follow up'";
            } elseif ($status_filter === 'negotiation') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'negotiation'";
            } elseif ($status_filter === 'sold') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'sold'";
            }
        }

        if (!empty($_GET['source'])) {
            $where_clauses[] = "lead_source = :source";
            $params[':source'] = $_GET['source'];
        }

        if (!empty($_GET['temp'])) {
            $where_clauses[] = "temperature = :temp";
            $params[':temp'] = $_GET['temp'];
        }

        if (!empty($_GET['agent'])) {
            $where_clauses[] = "assigned_to = :agent_id";
            $params[':agent_id'] = $_GET['agent'];
        }

        if (!empty($_GET['tag'])) {
            $where_clauses[] = "tags LIKE :tag_param";
            $params[':tag_param'] = '%' . trim($_GET['tag']) . '%';
        }

        if (!empty($_GET['start_date'])) {
            $utcStart = $this->utcFilterBoundary($_GET['start_date'], $displayTimezone);
            if ($utcStart === null) $where_clauses[] = '1 = 0';
            else { $where_clauses[] = 'created_at >= :start_date'; $params[':start_date'] = $utcStart; }
        }

        if (!empty($_GET['end_date'])) {
            $utcEnd = $this->utcFilterBoundary($_GET['end_date'], $displayTimezone, true);
            if ($utcEnd === null) $where_clauses[] = '1 = 0';
            else { $where_clauses[] = 'created_at < :end_date'; $params[':end_date'] = $utcEnd; }
        }

        $where_sql = implode(' AND ', $where_clauses);

        // --- 🔥 PAGINATION LOGIC 🔥 ---
        $countStmt = $pdo->prepare("SELECT COUNT(id) FROM leads WHERE $where_sql");
        $countStmt->execute($params);
        $total_leads = (int)$countStmt->fetchColumn();

        $limit = 50; 
        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;
        $total_pages = ceil($total_leads / $limit);
        if ($page > $total_pages && $total_pages > 0) $page = $total_pages;
        
        $offset = ($page - 1) * $limit;

        $stmt = $pdo->prepare("SELECT * FROM leads WHERE $where_sql ORDER BY created_at DESC LIMIT $limit OFFSET $offset");
        $stmt->execute($params);
        $leads = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        // Fetch Agents
        $agents = [];
        try { 
            $agents = $pdo->query("SELECT id, full_name as name FROM users ORDER BY full_name ASC")->fetchAll(\PDO::FETCH_ASSOC); 
        } catch (\Exception $e) {
            try { $agents = $pdo->query("SELECT id, name FROM users ORDER BY name ASC")->fetchAll(\PDO::FETCH_ASSOC); } catch (\Exception $e2) {}
        }

        // Fetch Tags for filter dropdown
        $tags = [];
        try {
            $tagsStmt = $pdo->query("SELECT name FROM crm_tags ORDER BY name ASC");
            $tags = $tagsStmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {}

        $data = [              
            'title' => 'Lead Management - SCPK CRM',              
            'user_name' => $_SESSION['name'],   
            'user_role' => $role,
            'leads' => $leads,
            'agents' => $agents,
            'tags' => $tags,
            'current_page' => $page,
            'total_pages' => $total_pages,
            'total_leads' => $total_leads,
            'filters' => $_GET,
            'displayTimezone' => $displayTimezone,
            'todayLocal' => $todayLocal
        ];                  
        $this->view('leads', $data);     
    }    

    /**
     * Download an Excel-compatible CSV of the current filtered leads.
     * If selected_ids[] is posted, download only checked rows (within filters).
     * Access restricted to ADMIN, as in leads.php's Export CSV button.
     */
    public function export_csv() {
        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role'] ?? '') !== 'ADMIN') {
            http_response_code(403);
            exit('Unauthorized');
        }

        $company_id = $_SESSION['company_id'] ?? 1;
        $pdo = Database::getInstance();
        $displayTimezone = \Core\Timezone::get($pdo, (int)$company_id);
        $input = ($_SERVER['REQUEST_METHOD'] === 'POST') ? $_POST : $_GET;

        // Match the index() page's company, search, stage and advanced filters.
        $where_clauses = ['company_id = :company_id'];
        $params = [':company_id' => $company_id];

        $searchTerm = trim(is_string($input['search'] ?? null) ? $input['search'] : '');
        if ($searchTerm !== '') {
            $searchClause = "(full_name LIKE :search1
                OR company_name LIKE :search2
                OR email LIKE :search3
                OR city LIKE :search4
                OR phone_number LIKE :search5
                OR whatsapp_number LIKE :search6
                OR tags LIKE :search7
                OR products_of_interest LIKE :search8";
            for ($i = 1; $i <= 8; $i++) {
                $params[":search$i"] = '%' . $searchTerm . '%';
            }

            if (preg_match('/^[0-9\+\-\s]+$/', $searchTerm)) {
                $cleanNum = preg_replace('/[^0-9]/', '', $searchTerm);
                if (strlen($cleanNum) > 10 && substr($cleanNum, 0, 2) == '91') {
                    $cleanNum = substr($cleanNum, 2);
                }
                if ($cleanNum !== '') {
                    $searchClause .= ' OR phone_number LIKE :cleanNum1 OR whatsapp_number LIKE :cleanNum2';
                    $params[':cleanNum1'] = '%' . $cleanNum . '%';
                    $params[':cleanNum2'] = '%' . $cleanNum . '%';
                }
            }

            $searchId = 0;
            if (preg_match('/^#?LD-([0-9]+)$/i', $searchTerm, $matches)) {
                $searchId = (int) $matches[1];
            } elseif (preg_match('/^[0-9]+$/', $searchTerm)) {
                $searchId = (int) $searchTerm;
            }
            if ($searchId > 0) {
                $searchClause .= ' OR id = :searchId';
                $params[':searchId'] = $searchId;
            }
            $where_clauses[] = $searchClause . ')';
        }

        $status_filter = is_string($input['status'] ?? null) ? $input['status'] : 'new';
        if ($status_filter !== 'all') {
            if ($status_filter === 'new') {
                $where_clauses[] = "(lead_stage = 'new' OR lead_stage = 'New' OR lead_stage IS NULL OR lead_stage = '')";
            } elseif ($status_filter === 'pipeline') {
                $where_clauses[] = "LOWER(lead_stage) IN ('qualified', 'catalog sharing', 'follow up', 'negotiation', 'sold')";
            } elseif ($status_filter === 'unqualified') {
                $where_clauses[] = "LOWER(lead_stage) LIKE '%unqualified%'";
            } elseif ($status_filter === 'catalog_sharing') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'catalog sharing'";
            } elseif ($status_filter === 'follow_up') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'follow up'";
            } elseif ($status_filter === 'negotiation') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'negotiation'";
            } elseif ($status_filter === 'sold') {
                $where_clauses[] = "LOWER(TRIM(lead_stage)) = 'sold'";
            }
        }

        foreach (['source' => 'lead_source', 'temp' => 'temperature', 'agent' => 'assigned_to'] as $key => $column) {
            if (isset($input[$key]) && is_string($input[$key]) && $input[$key] !== '') {
                $where_clauses[] = "$column = :$key";
                $params[":$key"] = $input[$key];
            }
        }
        if (isset($input['tag']) && is_string($input['tag']) && trim($input['tag']) !== '') {
            $where_clauses[] = 'tags LIKE :tag_param';
            $params[':tag_param'] = '%' . trim($input['tag']) . '%';
        }
        if (!empty($input['start_date'])) {
            $utcStart = $this->utcFilterBoundary($input['start_date'], $displayTimezone);
            if ($utcStart === null) $where_clauses[] = '1 = 0';
            else { $where_clauses[] = 'created_at >= :start_date'; $params[':start_date'] = $utcStart; }
        }
        if (!empty($input['end_date'])) {
            $utcEnd = $this->utcFilterBoundary($input['end_date'], $displayTimezone, true);
            if ($utcEnd === null) $where_clauses[] = '1 = 0';
            else { $where_clauses[] = 'created_at < :end_date'; $params[':end_date'] = $utcEnd; }
        }

        // Checkbox selection: only export these lead IDs, scoped to the company and filters.
        if (isset($input['selected_ids'])) {
            $postedIds = is_array($input['selected_ids']) ? $input['selected_ids'] : [];
            $selectedIds = array_values(array_unique(array_filter(
                array_map('intval', $postedIds),
                static function ($id) { return $id > 0; }
            )));
            if (count($selectedIds) === 0) {
                http_response_code(400);
                exit('No valid leads selected');
            }
            $idPlaceholders = [];
            foreach ($selectedIds as $index => $id) {
                $key = ':selected_id_' . $index;
                $idPlaceholders[] = $key;
                $params[$key] = $id;
            }
            $where_clauses[] = 'id IN (' . implode(', ', $idPlaceholders) . ')';
        }

        $where_sql = implode(' AND ', $where_clauses);
        $stmt = $pdo->prepare("SELECT * FROM leads WHERE $where_sql ORDER BY created_at DESC");
        $stmt->execute($params);

        // Resolve the same agent names used by the existing leads page.
        $agentNames = [];
        try {
            $users = $pdo->query('SELECT id, full_name AS name FROM users')->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            try {
                $users = $pdo->query('SELECT id, name FROM users')->fetchAll(\PDO::FETCH_ASSOC);
            } catch (\Exception $e2) {
                $users = [];
            }
        }
        foreach ($users as $agent) {
            $agentNames[(int) $agent['id']] = $agent['name'];
        }

        $filename = 'crm_leads_' . date('Y-m-d_H-i-s') . '.csv';
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');

        $output = fopen('php://output', 'w');
        fwrite($output, "\xEF\xBB\xBF"); // UTF-8 BOM for Excel and Hindi text.
        fputcsv($output, [
            'Lead ID', 'Full Name', 'Phone Number', 'WhatsApp Number',
            'Email', 'Company Name', 'Source', 'City', 'State', 'Postal Code',
            'Country', 'Product Interest', 'Assigned To', 'Lead Status',
            'Temperature', 'Tags', 'Date Created'
        ], ',', '"', '');

        // Prevent spreadsheet formulas being executed if a lead supplied hostile input.
        $safeCsvCell = static function ($value) {
            $value = (string) ($value ?? '');
            return preg_match('/^[\x00-\x20]*[=+\-@]/', $value) ? "'" . $value : $value;
        };

        while ($lead = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $assignedId = (int) ($lead['assigned_to'] ?? 0);
            $assignedName = $assignedId ? ($agentNames[$assignedId] ?? (string) $assignedId) : 'Unassigned';
            $row = [
                'LD-' . str_pad((string) $lead['id'], 4, '0', STR_PAD_LEFT),
                $lead['full_name'] ?? '',
                $lead['phone_number'] ?? '',
                $lead['whatsapp_number'] ?? '',
                $lead['email'] ?? '',
                $lead['company_name'] ?? '',
                $lead['lead_source'] ?? '',
                $lead['city'] ?? '',
                $lead['state'] ?? '',
                $lead['postal_code'] ?? '',
                $lead['country'] ?? '',
                $lead['products_of_interest'] ?? '',
                $assignedName,
                $lead['lead_stage'] ?? '',
                $lead['temperature'] ?? '',
                $lead['tags'] ?? '',
                !empty($lead['created_at']) ? \Core\Timezone::formatUtc($lead['created_at'], $displayTimezone, 'Y-m-d H:i:s') : ''
            ];
            fputcsv($output, array_map($safeCsvCell, $row), ',', '"', '');
        }
        fclose($output);
        exit;
    }

    public function add() {
        if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_URL . 'auth'); exit; }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pdo = \Core\Database::getInstance();
            $company_id = $_SESSION['company_id'] ?? 1;

            $full_name = filter_var(trim($_POST['full_name'] ?? ''), FILTER_SANITIZE_STRING);
            $phone_number = filter_var(trim($_POST['phone_number'] ?? ''), FILTER_SANITIZE_STRING);
            $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
            $company_name = filter_var(trim($_POST['company_name'] ?? ''), FILTER_SANITIZE_STRING);

            $city = filter_var(trim($_POST['city'] ?? ''), FILTER_SANITIZE_STRING);
            $state = filter_var(trim($_POST['state'] ?? ''), FILTER_SANITIZE_STRING);
            $postal_code = filter_var(trim($_POST['postal_code'] ?? ''), FILTER_SANITIZE_STRING);
            $country = filter_var(trim($_POST['country'] ?? 'India'), FILTER_SANITIZE_STRING);
            $based_in = filter_var(trim($_POST['based_in'] ?? 'Domestic'), FILTER_SANITIZE_STRING);

            $products_of_interest = filter_var(trim($_POST['products_of_interest'] ?? ''), FILTER_SANITIZE_STRING);

            try {
                $stmt = $pdo->prepare("
                    INSERT INTO leads (
                        company_id, full_name, phone_number, email, company_name, 
                        city, state, postal_code, country, based_in, 
                        products_of_interest, lead_source, lead_stage
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Manual', 'new')
                ");
                
                $stmt->execute([
                    $company_id, $full_name, $phone_number, $email, $company_name, 
                    $city, $state, $postal_code, $country, $based_in, 
                    $products_of_interest
                ]);
                
                $lead_id = $pdo->lastInsertId();
                if($lead_id) {
                    try {
                        $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Created', 'Lead created manually', ?)")
                            ->execute([$lead_id, $_SESSION['name']]);
                    } catch (\Exception $e) {}
                }

                header('Location: ' . BASE_URL . 'leads');
                exit;

            } catch (\Exception $e) {
                header('Location: ' . BASE_URL . 'leads');
                exit;
            }
        }
    }

    public function assign_lead() {
        if (!isset($_SESSION['user_id'])) exit;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            if ($lead_id = $input['lead_id'] ?? null) {
                $agent_id = !empty($input['agent_id']) ? $input['agent_id'] : null;
                $pdo = Database::getInstance();
                $pdo->prepare("UPDATE leads SET assigned_to = ? WHERE id = ?")->execute([$agent_id, $lead_id]);
                
                $agentName = "Unassigned";
                if ($agent_id) {
                    try {
                        $agentName = $pdo->query("SELECT full_name FROM users WHERE id = $agent_id")->fetchColumn();
                    } catch (\Exception $e) {
                        try { $agentName = $pdo->query("SELECT name FROM users WHERE id = $agent_id")->fetchColumn(); } catch (\Exception $e2) {}
                    }
                }
                try {
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Assigned', ?, ?)")
                        ->execute([$lead_id, "Lead manually assigned to: " . $agentName, $_SESSION['name']]);
                } catch (\Exception $e) {}
                echo json_encode(['status' => 'success']);
            }
            exit;
        }
    }

    public function mark_qualified() {
        if (!isset($_SESSION['user_id'])) exit;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            if ($lead_id = $input['lead_id'] ?? null) {
                $pdo = Database::getInstance();
                $pdo->prepare("UPDATE leads SET lead_stage = 'Qualified' WHERE id = ?")->execute([$lead_id]);
                try {
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Status', 'Marked as Qualified', ?)")->execute([$lead_id, $_SESSION['name']]);
                } catch (\Exception $e) {}
                echo json_encode(['status' => 'success']);
            }
            exit;
        }
    }

    public function mark_unqualified() {
        if (!isset($_SESSION['user_id'])) exit;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            if ($lead_id = $input['lead_id'] ?? null) {
                $pdo = Database::getInstance();
                $pdo->prepare("UPDATE leads SET lead_stage = 'Unqualified' WHERE id = ?")->execute([$lead_id]);
                try {
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Status', 'Marked as Unqualified', ?)")->execute([$lead_id, $_SESSION['name']]);
                } catch (\Exception $e) {}
                echo json_encode(['status' => 'success']);
            }
            exit;
        }
    }

    public function delete_bulk() {
        header('Content-Type: application/json');

        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role']) !== 'ADMIN') {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized access. Only Admins can delete leads.']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $lead_ids = $data['lead_ids'] ?? [];

        if (empty($lead_ids) || !is_array($lead_ids)) {
            echo json_encode(['status' => 'error', 'message' => 'No leads selected for deletion.']);
            exit;
        }

        try {
            $pdo = Database::getInstance();
            $clean_ids = array_map('intval', $lead_ids);
            $placeholders = rtrim(str_repeat('?,', count($clean_ids)), ',');

            $stmt = $pdo->prepare("DELETE FROM leads WHERE id IN ($placeholders)");
            $stmt->execute($clean_ids);

            echo json_encode(['status' => 'success', 'message' => count($clean_ids) . ' leads deleted successfully.']);
        } catch (\Exception $e) {
            echo json_encode(['status' => 'error', 'message' => 'Database Error: ' . $e->getMessage()]);
        }
        exit;
    }
} 
?>