<?php
namespace Controllers;
use Core\Controller;
use Core\Database;

class AuthController extends Controller {
    // Session-local throttle: immediate protection. A shared IP/account rate limiter
    // should be added later for distributed attacks.
    private const MAX_LOGIN_ATTEMPTS = 8;
    private const LOGIN_BLOCK_SECONDS = 900;

    private function loginBlocked(): bool {
        $blockedUntil = (int)($_SESSION['crm_login_blocked_until'] ?? 0);
        if ($blockedUntil > time()) return true;
        if ($blockedUntil > 0) {
            unset($_SESSION['crm_login_blocked_until'], $_SESSION['crm_login_attempts']);
        }
        return false;
    }

    private function loginFailed(): void {
        $attempts = (int)($_SESSION['crm_login_attempts'] ?? 0) + 1;
        $_SESSION['crm_login_attempts'] = $attempts;
        if ($attempts >= self::MAX_LOGIN_ATTEMPTS) {
            $_SESSION['crm_login_blocked_until'] = time() + self::LOGIN_BLOCK_SECONDS;
        }
    }

    private function loginViewError(): void {
        $this->view('login', [
            'title' => 'Login - LeadFlow CRM',
            'error' => 'Invalid credentials or too many attempts. Please try again later.'
        ]);
    }

    
    // Show the login page
    public function index() {
        // If already logged in, send them to the dashboard
        if (!empty($_SESSION['user_id']) && (int)($_SESSION['company_id'] ?? 0) > 0) {
            header('Location: ' . BASE_URL . 'dashboard');
            exit;
        }
        // Stale sessions missing company identity must not cause redirect loops.
        if (!empty($_SESSION['user_id']) && (int)($_SESSION['company_id'] ?? 0) < 1) {
            $_SESSION = [];
        }
        $this->view('login', ['title' => 'Login - LeadFlow CRM']);
    }

    // Process the login form
    public function login() {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            header('Location: ' . BASE_URL . 'auth');
            exit;
        }
        if ($this->loginBlocked()) {
            http_response_code(429);
            $this->loginViewError();
            return;
        }
        $email = filter_var(trim((string)($_POST['email'] ?? '')), FILTER_VALIDATE_EMAIL);
        $password = (string)($_POST['password'] ?? '');
        if (!$email || $password === '' || strlen($password) > 4096) {
            $this->loginFailed();
            $this->loginViewError();
            return;
        }

        $pdo = Database::getInstance();
        $stmt = $pdo->prepare("SELECT id, company_id, full_name, password_hash, role FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, (string)$user['password_hash']) && (int)$user['company_id'] > 0) {
            // Prevent session fixation and cross-account session residue.
            session_regenerate_id(true);
            $_SESSION = [];
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['company_id'] = (int)$user['company_id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['full_name'];
            $_SESSION['crm_last_activity'] = time();
            $_SESSION['crm_authenticated_at'] = time();
            header('Location: ' . BASE_URL . 'dashboard');
            exit;
        }

        $this->loginFailed();
        $this->loginViewError();
    }

    // Securely log out
    public function logout() {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 3600,
                'path' => $params['path'] ?: '/',
                'domain' => $params['domain'],
                'secure' => (bool)$params['secure'],
                'httponly' => true,
                'samesite' => $params['samesite'] ?: 'Lax'
            ]);
        }
        session_destroy();
        header('Location: ' . BASE_URL . 'auth');
        exit;
    }
    // ==========================================
    // 1. FORGOT PASSWORD (SEND EMAIL)
    // ==========================================
    public function forgot_password() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = filter_var(trim((string)($_POST['email'] ?? '')), FILTER_VALIDATE_EMAIL);
            
            if (!$email) {
                $this->view('login', ['title' => 'Login - SCPK CRM',
                    'success' => 'If your email exists in our system, a password reset link has been sent to it.']);
                return;
            }
            // Prevent accidental repeated mail requests from this session.
            if ((int)($_SESSION['crm_last_reset_request'] ?? 0) > time() - 60) {
                $this->view('login', ['title' => 'Login - SCPK CRM',
                    'success' => 'If your email exists in our system, a password reset link has been sent to it.']);
                return;
            }
            $_SESSION['crm_last_reset_request'] = time();
            $pdo = Database::getInstance();
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            // Security Best Practice: Hamesha success dikhao taaki hackers email guess na kar sakein
            $success_msg = 'If your email exists in our system, a password reset link has been sent to it.';

            if ($user) {
                // Generate a secure 32-character token
                $token = bin2hex(random_bytes(32));
                // Set Expiry to 1 Hour from now
                $expiry = date('Y-m-d H:i:s', time() + 3600); 

                // Save token in DB
                $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expiry = ? WHERE id = ?");
                $stmt->execute([$token, $expiry, $user['id']]);

                // Create Reset Link
                $resetLink = BASE_URL . "auth/reset_password?token=" . $token;

                // Send Email using PHP's default mail function
                $subject = "Password Reset Request - SCPK CRM";
                $message = "Hello,\n\nWe received a request to reset your SCPK CRM password.\n\nClick the link below to set a new password:\n" . $resetLink . "\n\nThis link is valid for 1 hour.\nIf you didn't request this, please ignore this email.\n\nThanks,\nSCPK CRM System";
                $host = parse_url(BASE_URL, PHP_URL_HOST) ?: 'localhost';
                $headers = "From: noreply@" . $host;
                
                @mail($email, $subject, $message, $headers);
            }

            $this->view('login', [
                'title' => 'Login - SCPK CRM',
                'success' => $success_msg
            ]);
        }
    }

    // ==========================================
    // 2. RESET PASSWORD (VERIFY TOKEN & SET NEW PASS)
    // ==========================================
    public function reset_password() {
        $token = $_GET['token'] ?? '';
        if (!is_string($token) || !preg_match('/\A[a-f0-9]{64}\z/D', $token)) {
            die("Invalid or missing token.");
        }

        $pdo = Database::getInstance();
        $current_time = date('Y-m-d H:i:s');
        
        // Check if token exists and is not expired
        $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_expiry >= ?");
        $stmt->execute([$token, $current_time]);
        $user = $stmt->fetch();

        if (!$user) {
            die("This password reset link is invalid or has expired. Please request a new one.");
        }

        // If user submitted the new password
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $new_password = (string)($_POST['password'] ?? '');
            if (strlen($new_password) < 6 || strlen($new_password) > 4096) {
                http_response_code(422);
                $this->view('reset_password', [
                    'title' => 'Set New Password - SCPK CRM',
                    'token' => $token,
                    'error' => 'Please use a password of at least 6 characters.'
                ]);
                return;
            }
            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

            // Update password and erase the token from DB
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, reset_token = NULL, reset_expiry = NULL WHERE id = ?");
            $stmt->execute([$password_hash, $user['id']]);

            $this->view('login', [
                'title' => 'Login - SCPK CRM',
                'success' => 'Your password has been successfully reset! You can now log in.'
            ]);
            exit;
        }

        // Show the Reset Password View
        $this->view('reset_password', ['title' => 'Set New Password - SCPK CRM', 'token' => $token]);
    }
    
}
?>