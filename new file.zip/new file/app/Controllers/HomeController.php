<?php 
namespace Controllers; 
use Core\Controller; 

class HomeController extends Controller {          
    
    public function index() {         
        // Check if the user is already logged in
        if (isset($_SESSION['user_id'])) {             
            // If logged in, send them straight to the Dashboard
            header('Location: ' . BASE_URL . 'dashboard');             
            exit;         
        } else {
            // If NOT logged in, redirect them to the Login page
            header('Location: ' . BASE_URL . 'auth');             
            exit; 
        }
    }      
}
?>