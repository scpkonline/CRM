<?php 
namespace Controllers; 
use Core\Controller; 
use Models\Lead; 
use Core\Database;

class LeadprofileController extends Controller {          
    
    public function index($lead_id = null) {          
        if (!isset($_SESSION['user_id']) || !$lead_id) {              
            header('Location: ' . BASE_URL . 'leads');              
            exit;          
        }          
        
        $pdo = Database::getInstance();
        // Stage 7: read company timezone; do not change UTC DB storage.
        $crmTimezone = \Core\Timezone::get($pdo, (int)($_SESSION['company_id'] ?? 1));
        $leadModel = new Lead();          
        $lead = $leadModel->getLeadById($_SESSION['company_id'], $lead_id);          
        if (!$lead) die("Lead not found.");          

        try {
            $adStmt = $pdo->prepare("SELECT meta_ad_name FROM leads WHERE id = ?");
            $adStmt->execute([$lead_id]);
            $adData = $adStmt->fetch(\PDO::FETCH_ASSOC);
            if ($adData && !empty($adData['meta_ad_name'])) {
                $lead['meta_ad_name'] = $adData['meta_ad_name'];
            }
        } catch (\Exception $e) {}

        $timeline = [];
        try {
            $notesStmt = $pdo->prepare("SELECT * FROM lead_notes WHERE lead_id = ? ORDER BY created_at DESC");
            $notesStmt->execute([$lead_id]);
            $timeline = $notesStmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {}

        try {
            $stmt = $pdo->prepare("SELECT id as conversation_id FROM wa_conversations WHERE lead_id = ? AND company_id = ? ORDER BY last_message_at DESC, id DESC LIMIT 1");
            $stmt->execute([$lead_id, (int)$_SESSION['company_id']]);
            $convo = $stmt->fetch();
            $lead['conversation_id'] = $convo ? $convo['conversation_id'] : null;
        } catch (\Exception $e) {}

        $agents = [];
        try { 
            $agents = $pdo->query("SELECT id, full_name as name FROM users ORDER BY full_name ASC")->fetchAll(\PDO::FETCH_ASSOC); 
        } catch (\Exception $e) {
            try { $agents = $pdo->query("SELECT id, name FROM users ORDER BY name ASC")->fetchAll(\PDO::FETCH_ASSOC); } catch (\Exception $e2) {}
        }

        $all_unique_tags = [];
        try {
            $tagStmt = $pdo->query("SELECT name FROM crm_tags ORDER BY name ASC");
            $all_unique_tags = $tagStmt->fetchAll(\PDO::FETCH_COLUMN);
        } catch (\Exception $e) {}

        if (empty($all_unique_tags)) {
            $all_tags_raw = $pdo->query("SELECT tags FROM leads WHERE company_id = {$_SESSION['company_id']} AND tags IS NOT NULL AND tags != ''")->fetchAll(\PDO::FETCH_COLUMN);
            foreach($all_tags_raw as $t_str) {
                $t_arr = explode(',', $t_str);
                foreach($t_arr as $t) {
                    $t = trim($t);
                    if(!empty($t) && !in_array($t, $all_unique_tags)) {
                        $all_unique_tags[] = $t;
                    }
                }
            }
            sort($all_unique_tags);
        }

        $data = [              
            'title' => $lead['full_name'] . ' - Profile',              
            'user_name' => $_SESSION['name'],              
            'lead' => $lead,
            'crm_timezone' => $crmTimezone,
            'timeline' => $timeline,
            'agents' => $agents,
            'all_company_tags' => $all_unique_tags
        ];                  
        
        $this->view('lead_profile', $data);      
    }

    // Lead Profile only: bounded chat history + incremental polling.
    // Does not modify WhatsApp sending, bot state or Inbox pagination.
    public function chat_history($lead_id = null) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, private');
        if ($_SERVER['REQUEST_METHOD'] !== 'GET' || empty($_SESSION['user_id']) ||
            empty($_SESSION['company_id']) || !ctype_digit((string)$lead_id) || (int)$lead_id <= 0) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'Not authorized']);
            return;
        }

        try {
            $pdo = Database::getInstance();
            $companyId = (int)$_SESSION['company_id'];
            $leadId = (int)$lead_id;
            $leadCheck = $pdo->prepare('SELECT 1 FROM leads WHERE id = ? AND company_id = ? LIMIT 1');
            $leadCheck->execute([$leadId, $companyId]);
            if (!$leadCheck->fetchColumn()) {
                http_response_code(403);
                echo json_encode(['status' => 'error', 'message' => 'Lead unavailable']);
                return;
            }

            // A lead can have legacy duplicate conversation records. Merge their
            // message history for display, but keep the newest conversation for sends.
            $convStmt = $pdo->prepare('SELECT id FROM wa_conversations WHERE lead_id = ? AND company_id = ? ORDER BY last_message_at DESC, id DESC');
            $convStmt->execute([$leadId, $companyId]);
            $conversationIds = array_map('intval', $convStmt->fetchAll(\PDO::FETCH_COLUMN));
            $conversationId = $conversationIds ? $conversationIds[0] : 0;
            if (!$conversationId) {
                echo json_encode(['status' => 'success', 'conversation_id' => null,
                    'messages' => [], 'has_more' => false, 'last_customer_at' => null]);
                return;
            }
            // Release PHP session lock before database queries so other CRM tabs stay responsive.
            if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
            $conversationMarks = implode(',', array_fill(0, count($conversationIds), '?'));

            $before = filter_input(INPUT_GET, 'before', FILTER_VALIDATE_INT);
            $after = filter_input(INPUT_GET, 'after', FILTER_VALIDATE_INT);
            if ($before === false || $after === false || ($before && $after)) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'Invalid history cursor']);
                return;
            }
            $before = $before ? (int)$before : null;
            $after = $after ? (int)$after : null;
            // Preserve Inbox load_messages read/unread semantics when the profile is viewed.
            // Scrolling historical pages should not change unread counters repeatedly.
            if ($before === null) {
                try {
                    $pdo->prepare('UPDATE wa_conversations SET unread_count = 0 WHERE lead_id = ? AND company_id = ?')
                        ->execute([$leadId, $companyId]);
                    $pdo->prepare("UPDATE wa_messages SET is_read = 1, delivery_status = 'read'
                        WHERE conversation_id IN ({$conversationMarks}) AND sender_type = 'lead'
                          AND (is_read = 0 OR delivery_status != 'read')")
                        ->execute($conversationIds);
                } catch (\Exception $readError) {
                    // A read-receipt write failure must not prevent history viewing.
                }
            }
            $pageSize = 80;
            $where = 'm.conversation_id IN (' . $conversationMarks . ')';
            $params = $conversationIds;
            if ($before !== null) { $where .= ' AND m.id < ?'; $params[] = $before; }
            if ($after !== null) { $where .= ' AND m.id > ?'; $params[] = $after; }
            $ascending = $after !== null;
            $order = $ascending ? 'ASC' : 'DESC';
            // This endpoint reads only the requested page; Inbox's all-history query remains untouched.
            $columns = 'm.id, m.wa_message_id, m.sender_type, m.message_type, m.message_body, '
                . 'm.created_at, m.delivery_status, m.media_url, m.mime_type, m.is_internal';
            $query = "SELECT {$columns}, m.reply_to_wa_message_id FROM wa_messages m "
                . "WHERE {$where} ORDER BY m.id {$order} LIMIT " . ($pageSize + 1);
            try {
                $stmt = $pdo->prepare($query);
                $stmt->execute($params);
                $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            } catch (\PDOException $e) {
                // Compatibility with installations which have not yet added reply metadata.
                // Do not hide unrelated SQL failures.
                if (stripos($e->getMessage(), 'Unknown column') === false ||
                    stripos($e->getMessage(), 'reply_to_wa_message_id') === false) throw $e;
                $stmt = $pdo->prepare("SELECT {$columns} FROM wa_messages m WHERE {$where} ORDER BY m.id {$order} LIMIT " . ($pageSize + 1));
                $stmt->execute($params);
                $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            }
            $hasMore = count($rows) > $pageSize;
            if ($hasMore) $rows = array_slice($rows, 0, $pageSize);
            if (!$ascending) $rows = array_reverse($rows);

            // Fetch original quoted-message previews in one bounded query, if the reply column exists.
            $quotedIds = [];
            foreach ($rows as $row) {
                if (!empty($row['reply_to_wa_message_id'])) $quotedIds[] = $row['reply_to_wa_message_id'];
            }
            if ($quotedIds) {
                $quotedIds = array_values(array_unique($quotedIds));
                $marks = implode(',', array_fill(0, count($quotedIds), '?'));
                $quotedStmt = $pdo->prepare("SELECT id, wa_message_id, sender_type, message_type, message_body, media_url, mime_type "
                    . "FROM wa_messages WHERE conversation_id IN ({$conversationMarks}) AND wa_message_id IN ({$marks})");
                $quotedStmt->execute(array_merge($conversationIds, $quotedIds));
                $quotedMap = [];
                foreach ($quotedStmt->fetchAll(\PDO::FETCH_ASSOC) as $quoted) {
                    $quotedMap[$quoted['wa_message_id']] = $quoted;
                }
                foreach ($rows as &$row) {
                    if (!empty($row['reply_to_wa_message_id']) && isset($quotedMap[$row['reply_to_wa_message_id']])) {
                        $row['quoted_reference'] = $quotedMap[$row['reply_to_wa_message_id']];
                    }
                }
                unset($row);
            }
            // Identify the actual FIRST inbound message across all legacy conversations.
            // Used only to attach the original Meta ad creative to the correct bubble.
            // Fetch only for the first history page; later poll/older pages reuse it client-side.
            $firstCustomerMessageId = null;
            if ($before === null && $after === null) {
                $firstStmt = $pdo->prepare("SELECT id FROM wa_messages WHERE conversation_id IN ({$conversationMarks}) AND sender_type = 'lead' ORDER BY id ASC LIMIT 1");
                $firstStmt->execute($conversationIds);
                $firstCustomerMessageId = $firstStmt->fetchColumn() ?: null;
            }

            $lastCustStmt = $pdo->prepare("SELECT created_at FROM wa_messages WHERE conversation_id IN ({$conversationMarks}) AND sender_type = 'lead' ORDER BY id DESC LIMIT 1");
            $lastCustStmt->execute($conversationIds);
            $lastCustomerAt = $lastCustStmt->fetchColumn() ?: null;
            echo json_encode(['status' => 'success', 'conversation_id' => $conversationId,
                'messages' => $rows, 'has_more' => $hasMore, 'last_customer_at' => $lastCustomerAt,
                'first_customer_message_id' => $firstCustomerMessageId]);
        } catch (\Throwable $e) {
            error_log('Lead profile paged chat error: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Unable to load chat history']);
        }
    }

    // ==========================================
    // 🔥 NEW: UPDATE LEAD STAGE FROM PROFILE 🔥
    // ==========================================
    public function update_stage() {
        if (!isset($_SESSION['user_id'])) exit;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);

            $lead_id = $input['lead_id'] ?? null;
            $stage = $input['stage'] ?? null;
            $sale_amount = $input['sale_amount'] ?? null;
            $sale_date = $input['sale_date'] ?? null;

            if ($lead_id && $stage) {
                try {
                    $pdo = Database::getInstance();

                    if ($stage === 'Sold' && $sale_amount !== null) {
                        $pdo->prepare("UPDATE leads SET lead_stage = ?, sale_amount = ?, sale_date = ? WHERE id = ?")
                            ->execute([$stage, $sale_amount, $sale_date, $lead_id]);

                        $companyToday = (new \DateTimeImmutable('now', new \DateTimeZone(\Core\Timezone::get($pdo, (int)($_SESSION['company_id'] ?? 1)))))->format('d M Y');
                        $note_text = "Lead Sold for ₹" . number_format((float)$sale_amount, 2) . " on " . $companyToday;
                        $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Status', ?, ?)")
                            ->execute([$lead_id, $note_text, $_SESSION['name']]);
                    } else {
                        $pdo->prepare("UPDATE leads SET lead_stage = ? WHERE id = ?")->execute([$stage, $lead_id]);

                        $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Status', ?, ?)")
                            ->execute([$lead_id, "Stage changed to: " . $stage, $_SESSION['name']]);
                    }

                    echo json_encode(['status' => 'success']);
                } catch (\Exception $e) {
                    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Missing data']);
            }
            exit;
        }
    }

    // ==========================================
    // TASKS & REMINDERS BACKEND
    // ==========================================
    public function add_task() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            $lead_id = $input['lead_id'] ?? null;
            $title = trim($input['title'] ?? '');
            $due_date = $input['due_date'] ?? null;

            if ($lead_id && $title && $due_date) {
                try {
                    $pdo = Database::getInstance();
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO lead_tasks 
                        (lead_id, assigned_to, task_type, task_title, due_date, status, is_completed) 
                        VALUES (?, ?, 'general', ?, ?, 'pending', 0)
                    ");
                    $stmt->execute([$lead_id, $_SESSION['user_id'], $title, $due_date]);
                    
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Task', ?, ?)")
                        ->execute([$lead_id, "Reminder set for: " . date('d M Y, h:i A', strtotime($due_date)) . " - " . $title, $_SESSION['name']]);
                    
                    $notif_title = "🔔 Lead Reminder";
                    $notif_msg = "Task: " . $title;
                    $notif_url = BASE_URL . "leadprofile/index/" . $lead_id;
                    
                    try {
                        $pdo->prepare("
                            INSERT INTO user_notifications 
                            (user_id, title, message, url, reminder_time, is_read, created_at) 
                            VALUES (?, ?, ?, ?, ?, 0, NOW())
                        ")->execute([$_SESSION['user_id'], $notif_title, $notif_msg, $notif_url, $due_date]);
                    } catch (\Exception $e) {
                        error_log("Notification Insert Failed: " . $e->getMessage());
                    }

                    echo json_encode(['status' => 'success']);
                } catch (\Exception $e) {
                    echo json_encode(['status' => 'error', 'message' => 'DB Error: ' . $e->getMessage()]);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Please provide task description and time.']);
            }
            exit;
        }
    }

    public function get_tasks($lead_id) {
        header('Content-Type: application/json');
        try {
            $pdo = Database::getInstance();
            $stmt = $pdo->prepare("SELECT * FROM lead_tasks WHERE lead_id = ? AND status = 'pending' ORDER BY due_date ASC");
            $stmt->execute([$lead_id]);
            echo json_encode(['status' => 'success', 'data' => $stmt->fetchAll(\PDO::FETCH_ASSOC)]);
        } catch (\Exception $e) {
            echo json_encode(['status' => 'error', 'data' => []]);
        }
        exit;
    }

    public function complete_task() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            $task_id = $input['task_id'] ?? null;
            if ($task_id) {
                try {
                    Database::getInstance()->prepare("UPDATE lead_tasks SET status = 'completed', is_completed = 1 WHERE id = ?")->execute([$task_id]);
                    echo json_encode(['status' => 'success']);
                } catch (\Exception $e) {
                    echo json_encode(['status' => 'error']);
                }
            }
            exit;
        }
    }

    // ==========================================
    // EXISTING TAGS & MACROS BACKEND
    // ==========================================
    public function get_macros() {
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        $pdo = Database::getInstance();
        try {
            $stmt = $pdo->query("SELECT shortcut as cmd, message as text, media_url FROM agent_macros ORDER BY created_at DESC");
            echo json_encode(['status' => 'success', 'data' => $stmt->fetchAll(\PDO::FETCH_ASSOC)]);
        } catch (\Exception $e) {
            echo json_encode(['status' => 'error', 'data' => []]);
        }
        exit;
    }

    public function add_tag() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $lead_id = $input['lead_id'] ?? '';
            $new_tag = trim($input['tag'] ?? '');
            
            if (!empty($new_tag) && !empty($lead_id)) {
                $pdo = Database::getInstance();

                try {
                    $chk = $pdo->prepare("SELECT id FROM crm_tags WHERE name = ?");
                    $chk->execute([$new_tag]);
                    if (!$chk->fetch()) {
                        $pdo->prepare("INSERT INTO crm_tags (name, created_by) VALUES (?, ?)")->execute([$new_tag, $_SESSION['user_id']]);
                    }
                } catch (\Exception $e) {}

                $current_tags = $pdo->query("SELECT tags FROM leads WHERE id = $lead_id")->fetchColumn();
                $tags_array = $current_tags ? array_map('trim', explode(',', $current_tags)) : [];
                
                if (!in_array($new_tag, $tags_array)) {
                    $tags_array[] = $new_tag;
                    $pdo->prepare("UPDATE leads SET tags = ? WHERE id = ?")->execute([implode(',', $tags_array), $lead_id]);
                    try { $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Tag Added', ?, ?)")->execute([$lead_id, "Tag added: " . $new_tag, $_SESSION['name']]); } catch (\Exception $e) {}
                }
                echo json_encode(['status' => 'success']);
                exit;
            }
            echo json_encode(['status' => 'error']);
            exit;
        }
    }

    public function remove_tag() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $lead_id = $input['lead_id'] ?? '';
            $tag_to_remove = trim($input['tag'] ?? '');
            
            if (!empty($tag_to_remove) && !empty($lead_id)) {
                $pdo = Database::getInstance();
                $current_tags = $pdo->query("SELECT tags FROM leads WHERE id = $lead_id")->fetchColumn();
                $tags_array = $current_tags ? array_map('trim', explode(',', $current_tags)) : [];
                
                if (($key = array_search($tag_to_remove, $tags_array)) !== false) {
                    unset($tags_array[$key]);
                    $pdo->prepare("UPDATE leads SET tags = ? WHERE id = ?")->execute([implode(',', $tags_array), $lead_id]);
                    try { $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Tag Removed', ?, ?)")->execute([$lead_id, "Tag removed: " . $tag_to_remove, $_SESSION['name']]); } catch (\Exception $e) {}
                }
                echo json_encode(['status' => 'success']);
                exit;
            }
            echo json_encode(['status' => 'error']);
            exit;
        }
    }

    public function add_note() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $lead_id = $_POST['lead_id'];
            $note = trim($_POST['note']);
            if (!empty($note)) {
                try { Database::getInstance()->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Note', ?, ?)")->execute([$lead_id, $note, $_SESSION['name']]); } catch (\Exception $e) {}
            }
            header("Location: " . BASE_URL . "leadprofile/index/" . $lead_id);
            exit;
        }
    }
} 
?>