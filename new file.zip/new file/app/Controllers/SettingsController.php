<?php 
namespace Controllers; 
use Core\Controller; 
use Core\Database;
use Core\Timezone;

class SettingsController extends Controller {          
    
    public function index() {          
        header('Location: ' . BASE_URL . 'settings/profile');               
        exit;          
    }      

    public function profile() {
        if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_URL . 'auth'); exit; }          
        
        $pdo = Database::getInstance();
        $user_id = $_SESSION['user_id'];
        
        $user = [];
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {}

        $data = [              
            'title' => 'Settings & Profile - SCPK CRM',              
            'user_name' => $_SESSION['name'] ?? 'User',
            'user_role' => isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES',
            'user_data' => $user
        ];                  
        
        $this->view('settings_profile', $data);     
    }

    public function update_profile() {
        if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_URL . 'auth'); exit; }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pdo = Database::getInstance();
            $user_id = $_SESSION['user_id'];
            
            $full_name = filter_var($_POST['full_name'] ?? '', FILTER_SANITIZE_STRING);
            $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
            $phone = filter_var($_POST['phone'] ?? '', FILTER_SANITIZE_STRING);
            $password = $_POST['password'] ?? '';

            if (!empty($full_name) && !empty($email)) {
                $profile_image_path = null;
                if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                    $uploadDir = 'uploads/profiles/';
                    if (!is_dir($uploadDir)) { mkdir($uploadDir, 0777, true); }
                    
                    $ext = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
                    $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                    
                    if (in_array($ext, $allowed_types)) {
                        $fileName = 'user_' . $user_id . '_' . time() . '.' . $ext;
                        $targetFilePath = $uploadDir . $fileName;
                        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFilePath)) {
                            $profile_image_path = $targetFilePath;
                        }
                    }
                }
                
                try {
                    if ($profile_image_path) {
                        $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, profile_image = ? WHERE id = ?")
                            ->execute([$full_name, $email, $phone, $profile_image_path, $user_id]);
                    } else {
                        $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?")
                            ->execute([$full_name, $email, $phone, $user_id]);
                    }
                } catch (\Exception $e) {
                    try {
                        if ($profile_image_path) {
                            $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ?, profile_image = ? WHERE id = ?")->execute([$full_name, $email, $phone, $profile_image_path, $user_id]);
                        } else {
                            $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?")->execute([$full_name, $email, $phone, $user_id]);
                        }
                    } catch (\Exception $e2) {}
                }
                
                $_SESSION['name'] = $full_name;

                if (!empty($password)) {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    try {
                        $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([$hashed_password, $user_id]);
                    } catch (\Exception $e) {
                        try { $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hashed_password, $user_id]); } catch (\Exception $e2) {}
                    }
                }
                
                $_SESSION['success_msg'] = "Your profile has been updated successfully!";
            } else {
                $_SESSION['error_msg'] = "Name and Email are required fields.";
            }

            header('Location: ' . BASE_URL . 'settings/profile');
            exit;
        }
    }

    public function team() {          
        if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_URL . 'auth'); exit; }          
        
        $pdo = Database::getInstance();
        $company_id = $_SESSION['company_id'] ?? 1;
        $user_role = isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES';

        if ($user_role !== 'ADMIN') {
            header('Location: ' . BASE_URL . 'settings/profile');
            exit;
        }

        $stmt = $pdo->prepare("
            SELECT u.id, u.full_name as name, u.email, u.phone, u.role, 
                   u.is_auto_assign, u.daily_lead_limit, u.assign_weight, u.priority_level,
                   (SELECT COUNT(*) FROM leads WHERE assigned_to = u.id) as assigned_leads 
            FROM users u 
            WHERE u.company_id = ? 
            ORDER BY u.role ASC, u.full_name ASC
        ");
        $stmt->execute([$company_id]);
        $team = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $data = [              
            'title' => 'Team Settings - SCPK CRM',              
            'user_name' => $_SESSION['name'] ?? 'User',
            'user_role' => $user_role,
            'team' => $team
        ];                  
        
        $this->view('team', $data);     
    }      

    public function add_team() {
        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role']) !== 'ADMIN') { header('Location: ' . BASE_URL . 'settings/team'); exit; }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pdo = Database::getInstance();
            $company_id = $_SESSION['company_id'] ?? 1;
            $full_name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone'] ?? '');
            if ($phone === '') $phone = null; 
            
            $role = strtolower(trim($_POST['role'])); 
            $password_hash = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
            $permissions = ($role === 'admin') ? null : '["inbox","leads"]';

            try {
                $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $check->execute([$email]);
                
                if ($check->rowCount() > 0) {
                    $_SESSION['error_msg'] = "Error: This Email ID is already registered!";
                } else {
                    $stmt = $pdo->prepare("INSERT INTO users (company_id, full_name, email, phone, password_hash, role, permissions) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$company_id, $full_name, $email, $phone, $password_hash, $role, $permissions]);
                    $_SESSION['success_msg'] = "Team member added successfully!";
                }
                header('Location: ' . BASE_URL . 'settings/team');
                exit;

            } catch (\Exception $e) {
                die("Database Error while adding member: " . $e->getMessage());
            }
        }
    }

    public function edit_team() {
        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role']) !== 'ADMIN') { header('Location: ' . BASE_URL . 'settings/team'); exit; }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pdo = Database::getInstance();
            $id = $_POST['user_id'];
            $full_name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone'] ?? '');
            if ($phone === '') $phone = null; 
            
            $role = strtolower(trim($_POST['role']));

            try {
                if (!empty($_POST['password'])) {
                    $password_hash = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET full_name=?, email=?, phone=?, role=?, password_hash=? WHERE id=?");
                    $stmt->execute([$full_name, $email, $phone, $role, $password_hash, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET full_name=?, email=?, phone=?, role=? WHERE id=?");
                    $stmt->execute([$full_name, $email, $phone, $role, $id]);
                }

                $_SESSION['success_msg'] = "Team member updated successfully!";
                header('Location: ' . BASE_URL . 'settings/team');
                exit;

            } catch (\Exception $e) {
                die("Database Error while updating member: " . $e->getMessage());
            }
        }
    }

    public function update_routing() {
        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role']) !== 'ADMIN') { 
            header('Location: ' . BASE_URL . 'settings/team'); 
            exit; 
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pdo = Database::getInstance();
            $id = $_POST['user_id'];
            
            $is_auto_assign = isset($_POST['is_auto_assign']) ? 1 : 0;
            $daily_lead_limit = !empty($_POST['daily_limit']) ? (int)$_POST['daily_limit'] : 9999;
            
            $weight = 1;
            if (isset($_POST['assign_weight']) && (int)$_POST['assign_weight'] > 0) {
                $weight = (int)$_POST['assign_weight'];
            } elseif (isset($_POST['weight']) && (int)$_POST['weight'] > 0) {
                $weight = (int)$_POST['weight'];
            }
            
            $priority_level = isset($_POST['priority_level']) ? (int)$_POST['priority_level'] : 1;

            try {
                $stmt = $pdo->prepare("UPDATE users SET is_auto_assign = ?, daily_lead_limit = ?, assign_weight = ?, priority_level = ? WHERE id = ?");
                $stmt->execute([$is_auto_assign, $daily_lead_limit, $weight, $priority_level, $id]);
                
                $_SESSION['success_msg'] = "Lead Routing Rules updated successfully!";
            } catch (\Exception $e) {
                $_SESSION['error_msg'] = "DB Error: " . $e->getMessage();
            }
            
            header('Location: ' . BASE_URL . 'settings/team');
            exit;
        }
    }
    
    /** Private file: outside public_html. Never write credentials into config.php. */
    private function integrationsEnvPath() {
        return dirname(__DIR__, 3) . '/crm_private/.env';
    }

    /** Quote one INI value so punctuation in API tokens cannot create new keys. */
    private function quoteEnvValue($value) {
        return '"' . str_replace(['\\', '"'], ['\\\\', '\\"'], $value) . '"';
    }

    /**
     * Update selected keys only, retaining all other environment settings.
     * Lock, atomic rename, private permissions, and re-parse safeguard.
     */
    private function saveIntegrationEnv(array $changes) {
        $envPath = $this->integrationsEnvPath();
        $dir = dirname($envPath);
        if (!is_dir($dir) || is_link($dir) || !is_file($envPath) || is_link($envPath)
            || !is_readable($envPath) || !is_writable($envPath) || !is_writable($dir)) {
            throw new \RuntimeException('Private .env is not ready. Move the current .env to crm_private outside public_html, then retry.');
        }

        $lockPath = $dir . '/.env.lock';
        $lock = @fopen($lockPath, 'c');
        if (!$lock) {
            throw new \RuntimeException('Unable to secure the private configuration for writing.');
        }
        $tmp = null;
        try {
            if (!flock($lock, LOCK_EX)) {
                throw new \RuntimeException('Could not lock the private configuration.');
            }
            $content = @file_get_contents($envPath);
            if (!is_string($content)) {
                throw new \RuntimeException('Private configuration could not be read.');
            }

            foreach ($changes as $key => $value) {
                $line = $key . '=' . $this->quoteEnvValue($value);
                $pattern = '/^\\s*' . preg_quote($key, '/') . '\\s*=.*$/m';
                $matches = preg_match_all($pattern, $content);
                if ($matches === false || $matches > 1) {
                    throw new \RuntimeException('Duplicate or invalid configuration entries found; no changes were saved.');
                }
                if ($matches === 1) {
                    $content = preg_replace_callback($pattern, function () use ($line) {
                        return $line;
                    }, $content, 1);
                } else {
                    $content = rtrim($content, "\r\n") . "\n" . $line . "\n";
                }
            }

            $tmp = tempnam($dir, '.crm_env_');
            if ($tmp === false) {
                throw new \RuntimeException('Private configuration temporary file could not be created.');
            }
            @chmod($tmp, 0600);
            if (file_put_contents($tmp, $content, LOCK_EX) === false) {
                throw new \RuntimeException('Private configuration write failed.');
            }
            $parsed = @parse_ini_file($tmp);
            if (!is_array($parsed)) {
                throw new \RuntimeException('Generated configuration is invalid; the old file was preserved.');
            }
            foreach ($changes as $key => $value) {
                if (!array_key_exists($key, $parsed) || (string)$parsed[$key] !== $value) {
                    throw new \RuntimeException('Configuration validation failed; the old file was preserved.');
                }
            }
            if (!@rename($tmp, $envPath)) {
                throw new \RuntimeException('Private configuration could not be replaced safely.');
            }
            $tmp = null;
            @chmod($envPath, 0600);
        } finally {
            if ($tmp !== null && is_file($tmp)) @unlink($tmp);
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    public function integrations() {
        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role'] ?? '') !== 'ADMIN') {
            header('Location: ' . BASE_URL . 'settings/profile'); exit;
        }
        // Never cache pages showing configuration status.
        header('Cache-Control: no-store, private');
        if (empty($_SESSION['integrations_csrf'])) {
            $_SESSION['integrations_csrf'] = bin2hex(random_bytes(32));
        }
        $envPath = $this->integrationsEnvPath();
        $dir = dirname($envPath);
        $secureReady = is_dir($dir) && !is_link($dir) && is_file($envPath)
            && !is_link($envPath) && is_readable($envPath)
            && is_writable($envPath) && is_writable($dir);

        $data = [
            'title' => 'Integrations & API - SCPK CRM',
            'user_name' => $_SESSION['name'] ?? 'User',
            'user_role' => 'ADMIN',
            'integrations_csrf' => $_SESSION['integrations_csrf'],
            'secure_env_ready' => $secureReady,
            // IDs are not authentication secrets; only authenticated admins see these.
            'wa_app_id' => defined('WA_APP_ID') ? WA_APP_ID : '',
            'wa_phone_id' => defined('WA_PHONE_NUMBER_ID') ? WA_PHONE_NUMBER_ID : '',
            'wa_waba_id' => defined('WA_WABA_ID') ? WA_WABA_ID : '',
            'meta_ad_account_id' => defined('META_AD_ACCOUNT_ID') ? META_AD_ACCOUNT_ID : '',
            // Only booleans. Actual secrets MUST NOT be passed to a view.
            'wa_verify_token_configured' => defined('WA_VERIFY_TOKEN') && WA_VERIFY_TOKEN !== '',
            'wa_access_token_configured' => defined('WA_ACCESS_TOKEN') && WA_ACCESS_TOKEN !== ''
        ];
        $this->view('settings_integrations', $data);
    }

    public function update_integrations() {
        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role'] ?? '') !== 'ADMIN') {
            header('Location: ' . BASE_URL . 'settings/profile'); exit;
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405); exit;
        }
        $postedCsrf = $_POST['integrations_csrf'] ?? '';
        $savedCsrf = $_SESSION['integrations_csrf'] ?? '';
        if (!is_string($postedCsrf) || !is_string($savedCsrf)
            || $savedCsrf === '' || !hash_equals($savedCsrf, $postedCsrf)) {
            http_response_code(403);
            exit('Invalid request token. Reload the Integrations page.');
        }
        $fields = [
            'wa_app_id' => 'WA_APP_ID',
            'wa_phone_id' => 'WA_PHONE_NUMBER_ID',
            'wa_waba_id' => 'WA_WABA_ID',
            'wa_verify_token' => 'WA_VERIFY_TOKEN',
            'wa_access_token' => 'WA_ACCESS_TOKEN',
            'meta_ad_account_id' => 'META_AD_ACCOUNT_ID'
        ];
        $changes = [];
        foreach ($fields as $postField => $envKey) {
            $raw = $_POST[$postField] ?? '';
            if (!is_string($raw)) {
                $_SESSION['error_msg'] = 'Invalid integration setting supplied.';
                header('Location: ' . BASE_URL . 'settings/integrations'); exit;
            }
            $value = trim($raw);
            // Empty fields mean KEEP existing value, particularly sensitive tokens.
            if ($value === '') continue;
            if (strlen($value) > 4096 || preg_match('/[\\x00-\\x1F\\x7F]/', $value)) {
                $_SESSION['error_msg'] = 'Invalid integration setting length or characters.';
                header('Location: ' . BASE_URL . 'settings/integrations'); exit;
            }
            $changes[$envKey] = $value;
        }
        try {
            if (empty($changes)) {
                $_SESSION['success_msg'] = 'No changes submitted. Existing credentials preserved.';
            } else {
                $this->saveIntegrationEnv($changes);
                $_SESSION['success_msg'] = 'Settings saved to private .env. New values apply on the next request.';
            }
        } catch (\Throwable $e) {
            // Do not log submitted tokens, values, or contents.
            error_log('CRM private integration configuration update failed.');
            $_SESSION['error_msg'] = $e->getMessage();
        }
        header('Location: ' . BASE_URL . 'settings/integrations');
        exit;
    }

    public function notifications() {          
        if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_URL . 'auth'); exit; }          
        
        $data = [              
            'title' => 'Notifications - SCPK CRM',              
            'user_name' => $_SESSION['name'] ?? 'User',
            'user_role' => isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES'
        ];                  
        $this->view('settings_notifications', $data);     
    }

    public function update_notifications() {          
        if (!isset($_SESSION['user_id'])) { header('Location: ' . BASE_URL . 'auth'); exit; }          
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $notify_new_lead = isset($_POST['notify_new_lead']) ? '1' : '0';
            $notify_lead_reply = isset($_POST['notify_lead_reply']) ? '1' : '0';

            setcookie('notify_new_lead', $notify_new_lead, time() + (86400 * 365), "/");
            setcookie('notify_lead_reply', $notify_lead_reply, time() + (86400 * 365), "/");

            $_SESSION['success_msg'] = "Notification settings saved successfully!";
            header('Location: ' . BASE_URL . 'settings/notifications');
            exit;
        }
    }

    public function add_user_alert() {
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        
        $input = json_decode(file_get_contents('php://input'), true);
        $title = trim($input['title'] ?? 'Reminder');
        $message = trim($input['message'] ?? '');
        $url = trim($input['url'] ?? '');
        $reminder_time = trim($input['alert_time'] ?? null); 
        $user_id = $_SESSION['user_id'];

        if (!empty($message)) {
            try {
                $pdo = Database::getInstance();
                $pdo->exec("SET time_zone = '+05:30'");

                $stmt = $pdo->prepare("INSERT INTO user_notifications (user_id, title, message, url, reminder_time, is_read, created_at) VALUES (?, ?, ?, ?, ?, 0, NOW())");
                $stmt->execute([$user_id, $title, $message, $url, $reminder_time]);
                
                echo json_encode(['status' => 'success']);
            } catch (\Exception $e) {
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Empty message']);
        }
        exit;
    }

    public function get_user_alerts() {
        header('Content-Type: application/json');
        header('Cache-Control: no-cache, no-store, must-revalidate'); 

        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['notifications' => []]);
            exit;
        }

        $userId = (int)$_SESSION['user_id'];
        $lastId = isset($_GET['last_id']) ? (int)$_GET['last_id'] : 0;

        $pdo = Database::getInstance();
        
        try {
            $pdo->exec("SET time_zone = '+05:30'");

            if ($lastId === 0) {
                $stmtMax = $pdo->prepare("SELECT MAX(id) FROM user_notifications WHERE user_id = ?");
                $stmtMax->execute([$userId]);
                $maxId = (int)$stmtMax->fetchColumn() ?: 0;
                
                echo json_encode(['sync_id' => $maxId, 'notifications' => []]);
                exit;
            }

            $stmt = $pdo->prepare("
                SELECT id, title, message, url 
                FROM user_notifications 
                WHERE user_id = ? AND id > ? 
                AND (reminder_time IS NULL OR reminder_time <= NOW()) 
                ORDER BY id ASC
            ");
            $stmt->execute([$userId, $lastId]);
            $notifications = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            if (!empty($notifications)) {
                $ids = array_column($notifications, 'id');
                $inQuery = implode(',', array_map('intval', $ids));
                $pdo->query("UPDATE user_notifications SET is_read = 1 WHERE id IN ($inQuery)");
            }

            echo json_encode(['notifications' => $notifications]);
        } catch (\Exception $e) {
            echo json_encode(['notifications' => []]);
        }
        exit;
    }
    
    public function check_alerts() {
        if (!isset($_SESSION['user_id'])) { 
            echo json_encode(['status' => 'error']); exit; 
        }
        
        $pdo = Database::getInstance();
        $user_id = $_SESSION['user_id'];
        
        $last_check_timestamp = isset($_GET['last_check']) ? (int)$_GET['last_check'] : time() - 10;
        $last_check_date = date('Y-m-d H:i:s', $last_check_timestamp);

        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM leads WHERE assigned_to = ? AND created_at > ?");
            $stmt->execute([$user_id, $last_check_date]);
            $new_leads = (int)$stmt->fetchColumn();

            $stmt2 = $pdo->prepare("
                SELECT COUNT(m.id) FROM wa_messages m 
                JOIN wa_conversations c ON m.conversation_id = c.id 
                JOIN leads l ON c.lead_id = l.id 
                WHERE l.assigned_to = ? AND m.sender_type = 'lead' AND m.created_at > ?
            ");
            $stmt2->execute([$user_id, $last_check_date]);
            $new_msgs = (int)$stmt2->fetchColumn();

            echo json_encode([
                'status' => 'success',
                'new_leads' => $new_leads,
                'new_msgs' => $new_msgs,
                'server_time' => time()
            ]);
        } catch (\Exception $e) {
            echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
        }
        exit;
    }

    /**
     * Stage 4: one display timezone per company, selected by an ADMIN.
     * Keep PHP/MySQL at UTC; this preference does not rewrite stored timestamps.
     * This replaces only the previous cookie-only Preferences POST handler.
     */
    public function preferences() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . BASE_URL . 'auth');
            exit;
        }

        $pdo = Database::getInstance();
        $companyId = (int)($_SESSION['company_id'] ?? 1);
        if ($companyId < 1) {
            http_response_code(403);
            exit('Invalid company session. Please log in again.');
        }
        $userRole = strtoupper((string)($_SESSION['role'] ?? 'SALES'));
        $isAdmin = ($userRole === 'ADMIN');

        if (empty($_SESSION['preferences_csrf'])) {
            $_SESSION['preferences_csrf'] = bin2hex(random_bytes(32));
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $postedToken = $_POST['preferences_csrf'] ?? '';
            $savedToken = $_SESSION['preferences_csrf'];
            if (!is_string($postedToken) || !hash_equals($savedToken, $postedToken)) {
                http_response_code(403);
                exit('Invalid preferences request. Reload this page and retry.');
            }

            $theme = $_POST['theme'] ?? 'light';
            if (!is_string($theme) || !in_array($theme, ['light', 'dark'], true)) {
                $_SESSION['error_msg'] = 'Invalid theme selection.';
                header('Location: ' . BASE_URL . 'settings/preferences');
                exit;
            }

            try {
                if ($isAdmin) {
                    $postedTimezone = $_POST['timezone'] ?? '';
                    if (!is_string($postedTimezone)) {
                        throw new \InvalidArgumentException('Invalid timezone selection.');
                    }
                    // Whitelist supported timezones. Never accept browser cookie as source.
                    $timezone = Timezone::validate($postedTimezone);
                    Timezone::save($pdo, $companyId, $timezone);
                    $_SESSION['success_msg'] = 'Company timezone and your theme saved successfully.';
                } else {
                    // Sales users may change their own theme, not the company's clock.
                    if (isset($_POST['timezone'])) {
                        throw new \InvalidArgumentException('Only an administrator can change the company timezone.');
                    }
                    $_SESSION['success_msg'] = 'Your theme saved successfully. Company timezone is administrator-controlled.';
                }

                // Theme remains a per-browser preference; client JS reads this cookie.
                setcookie('theme', $theme, time() + (86400 * 30), '/');
            } catch (\InvalidArgumentException $e) {
                $_SESSION['error_msg'] = $e->getMessage();
            } catch (\Throwable $e) {
                error_log('CRM company timezone preference save failed.');
                $_SESSION['error_msg'] = 'Timezone could not be saved. Check the CRM timezone settings table.';
            }

            header('Location: ' . BASE_URL . 'settings/preferences');
            exit;
        }

        // Read fresh from the database so changes are shared across users/devices.
        $companyTimezone = Timezone::get($pdo, $companyId);
        $data = [
            'title' => 'Preferences - SCPK CRM',
            'user_name' => $_SESSION['name'] ?? 'User',
            'user_role' => $userRole,
            'preferences_timezone' => $companyTimezone,
            'preferences_csrf' => $_SESSION['preferences_csrf'],
            'can_change_timezone' => $isAdmin
        ];
        $this->view('settings_preferences', $data);
    }
}
?>