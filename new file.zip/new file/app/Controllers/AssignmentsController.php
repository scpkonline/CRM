<?php 
namespace Controllers; 
use Core\Controller; 
use Core\Database;

class AssignmentsController extends Controller {          
    
    private function ensure_schema() {
        $pdo = Database::getInstance();
        // Stage 7: read company timezone; do not change UTC DB storage.
        $crmTimezone = \Core\Timezone::get($pdo, (int)($_SESSION['company_id'] ?? 1));
        try {
            $pdo->exec("ALTER TABLE tasks MODIFY COLUMN status VARCHAR(50) DEFAULT 'Pending'");
        } catch (\Exception $e) {}
    }

    private function create_notification($userId, $title, $message, $url) {
        $pdo = Database::getInstance();

        // Prevent duplicate spam within last 5 seconds in database
        try {
            $stmtCheck = $pdo->prepare("SELECT id FROM user_notifications WHERE user_id = ? AND title = ? AND message = ? AND created_at >= (NOW() - INTERVAL 5 SECOND)");
            $stmtCheck->execute([$userId, $title, $message]);
            if ($stmtCheck->rowCount() > 0) {
                return; // Duplicate block (Stop double insertion)
            }
        } catch (\Exception $e) {}

        if (class_exists('\Core\NotificationHelper')) {
            try {
                \Core\NotificationHelper::sendToUser($userId, $title, $message, $url);
                return;
            } catch (\Exception $e) {}
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO user_notifications (user_id, title, message, url, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())");
            $stmt->execute([$userId, $title, $message, $url]);
        } catch (\Exception $e) {}
    }

    public function index() {          
        if (!isset($_SESSION['user_id'])) {              
            header('Location: ' . BASE_URL . 'auth');              
            exit;          
        }          
        
        $this->ensure_schema();
        $company_id = $_SESSION['company_id'] ?? 1;
        $user_id = $_SESSION['user_id'];
        $role = isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES';
        
        $pdo = Database::getInstance();

        if ($role === 'ADMIN') {
            $stmt = $pdo->prepare("
                SELECT t.*, u1.full_name as assignee_name, u2.full_name as assigner_name 
                FROM tasks t 
                LEFT JOIN users u1 ON t.assigned_to = u1.id 
                LEFT JOIN users u2 ON t.assigned_by = u2.id 
                WHERE t.company_id = ? 
                ORDER BY t.id DESC
            ");
            $stmt->execute([$company_id]);
        } else {
            $stmt = $pdo->prepare("
                SELECT t.*, u1.full_name as assignee_name, u2.full_name as assigner_name 
                FROM tasks t 
                LEFT JOIN users u1 ON t.assigned_to = u1.id 
                LEFT JOIN users u2 ON t.assigned_by = u2.id 
                WHERE t.company_id = ? AND t.assigned_to = ? 
                ORDER BY t.id DESC
            ");
            $stmt->execute([$company_id, $user_id]);
        }
        $tasks = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        $agents = [];
        if ($role === 'ADMIN') {
            try { 
                $agents = $pdo->query("SELECT id, full_name as name FROM users WHERE LOWER(role) = 'sales' ORDER BY full_name ASC")->fetchAll(\PDO::FETCH_ASSOC); 
            } catch (\Exception $e) {
                try { $agents = $pdo->query("SELECT id, name FROM users WHERE LOWER(role) = 'sales' ORDER BY name ASC")->fetchAll(\PDO::FETCH_ASSOC); } catch (\Exception $e2) {}
            }
        }

        $active_tab = $_GET['tab'] ?? 'tasks';

        $data = [              
            'title' => 'Team Assignments - SCPK CRM',              
            'user_name' => $_SESSION['name'],   
            'user_role' => $role,
            'tasks' => $tasks,
            'agents' => $agents,
            'active_tab' => $active_tab
        ];                  
        $this->view('assignments', $data);     
    }     

    public function add() {
        if (!isset($_SESSION['user_id']) || strtoupper($_SESSION['role']) !== 'ADMIN') { 
            header('Location: ' . BASE_URL . 'assignments?tab=tasks'); exit; 
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->ensure_schema();
            $pdo = Database::getInstance();
            $company_id = $_SESSION['company_id'] ?? 1;

            $title = filter_var(trim($_POST['title'] ?? ''), FILTER_SANITIZE_STRING);
            $description = filter_var(trim($_POST['description'] ?? ''), FILTER_SANITIZE_STRING);
            $assigned_target = trim($_POST['assigned_to'] ?? '');
            $priority = $_POST['priority'] ?? 'Medium';
            $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
            $assigned_by = $_SESSION['user_id'];

            if (!empty($title) && !empty($assigned_target)) {
                $targetUserIds = [];

                if ($assigned_target === 'all') {
                    $stmtAll = $pdo->prepare("SELECT id FROM users WHERE LOWER(role) = 'sales' AND company_id = ?");
                    $stmtAll->execute([$company_id]);
                    $targetUserIds = $stmtAll->fetchAll(\PDO::FETCH_COLUMN);
                } else {
                    $targetUserIds = [(int)$assigned_target];
                }

                $stmtInsert = $pdo->prepare("
                    INSERT INTO tasks (company_id, title, description, assigned_to, assigned_by, priority, status, due_date) 
                    VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?)
                ");

                foreach ($targetUserIds as $uId) {
                    if ($uId > 0 && $uId !== (int)$assigned_by) {
                        $stmtInsert->execute([$company_id, $title, $description, $uId, $assigned_by, $priority, $due_date]);

                        $this->create_notification(
                            $uId,
                            "📋 New Task Assigned!",
                            "Admin assigned you a task: " . $title,
                            BASE_URL . "assignments?tab=tasks"
                        );
                    }
                }
            }
            header('Location: ' . BASE_URL . 'assignments?tab=tasks');
            exit;
        }
    }

    public function request_approval() {
        if (!isset($_SESSION['user_id'])) { 
            header('Location: ' . BASE_URL . 'assignments?tab=approvals'); exit; 
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->ensure_schema();
            $pdo = Database::getInstance();
            $company_id = $_SESSION['company_id'] ?? 1;

            $subject = filter_var(trim($_POST['subject'] ?? ''), FILTER_SANITIZE_STRING);
            $party_name = filter_var(trim($_POST['party_name'] ?? ''), FILTER_SANITIZE_STRING);
            $description_text = filter_var(trim($_POST['description'] ?? ''), FILTER_SANITIZE_STRING);
            
            $final_description = "Party Name: " . $party_name . "\n\nReason:\n" . $description_text;
            $hidden_title = "APPROVAL_REQ: " . $subject;

            $assigned_to = $_SESSION['user_id']; 
            $assigned_by = $_SESSION['user_id']; 
            $priority = 'Medium';
            $due_date = (new \DateTimeImmutable('now', new \DateTimeZone(\Core\Timezone::get($pdo, (int)$company_id))))->format('Y-m-d'); 

            if (!empty($subject)) {
                $stmt = $pdo->prepare("
                    INSERT INTO tasks (company_id, title, description, assigned_to, assigned_by, priority, status, due_date) 
                    VALUES (?, ?, ?, ?, ?, ?, 'In Progress', ?)
                ");
                $stmt->execute([$company_id, $hidden_title, $final_description, $assigned_to, $assigned_by, $priority, $due_date]);
                $approvalId = $pdo->lastInsertId();

                $requesterName = $_SESSION['name'] ?? 'Sales Executive';
                $currentUserId = (int)$_SESSION['user_id'];
                
                try {
                    $stmtAdmin = $pdo->prepare("SELECT id FROM users WHERE LOWER(role) = 'admin' AND company_id = ?");
                    $stmtAdmin->execute([$company_id]);
                    $admins = $stmtAdmin->fetchAll(\PDO::FETCH_ASSOC);

                    foreach ($admins as $admin) {
                        if ((int)$admin['id'] === $currentUserId) continue;

                        $this->create_notification(
                            (int)$admin['id'],
                            "🔔 New Approval Request!",
                            $requesterName . " requested approval for: " . $subject . ($party_name ? " (Party: $party_name)" : ""),
                            BASE_URL . "assignments?tab=approvals&open_chat=" . $approvalId
                        );
                    }
                } catch (\Exception $e) {}
            }
            header('Location: ' . BASE_URL . 'assignments?tab=approvals');
            exit;
        }
    }

    public function update_status() {
        if (!isset($_SESSION['user_id'])) exit;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->ensure_schema();
            $input = json_decode(file_get_contents('php://input'), true);
            $task_id = (int)($input['task_id'] ?? 0);
            $status = trim($input['status'] ?? 'Pending');
            $completion_notes = isset($input['completion_notes']) ? filter_var(trim($input['completion_notes']), FILTER_SANITIZE_STRING) : null;
            
            if ($task_id) {
                $pdo = Database::getInstance();
                $role = strtoupper($_SESSION['role'] ?? 'SALES');

                $stmtTask = $pdo->prepare("SELECT * FROM tasks WHERE id = ?");
                $stmtTask->execute([$task_id]);
                $taskInfo = $stmtTask->fetch(\PDO::FETCH_ASSOC);

                if ($completion_notes !== null) {
                    if ($role === 'ADMIN') {
                        $stmt = $pdo->prepare("UPDATE tasks SET status = ?, completion_notes = ? WHERE id = ?");
                        $stmt->execute([$status, $completion_notes, $task_id]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE tasks SET status = ?, completion_notes = ? WHERE id = ? AND assigned_to = ?");
                        $stmt->execute([$status, $completion_notes, $task_id, $_SESSION['user_id']]);
                    }
                } else {
                    if ($role === 'ADMIN') {
                        $stmt = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?");
                        $stmt->execute([$status, $task_id]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ? AND assigned_to = ?");
                        $stmt->execute([$status, $task_id, $_SESSION['user_id']]);
                    }
                }

                if ($taskInfo && (int)$taskInfo['assigned_to'] !== (int)$_SESSION['user_id']) {
                    $cleanTitle = str_replace('APPROVAL_REQ:', '', $taskInfo['title']);
                    $statusLabel = ($status === 'Completed') ? 'Approved' : (($status === 'On Hold') ? 'On Hold' : 'Rejected');
                    
                    $this->create_notification(
                        (int)$taskInfo['assigned_to'],
                        "📢 Approval Status Update",
                        "Your request '{$cleanTitle}' has been marked as {$statusLabel}.",
                        BASE_URL . "assignments?tab=approvals&open_chat=" . $task_id
                    );
                }

                echo json_encode(['status' => 'success', 'new_status' => $status]);
            }
            exit;
        }
    }
    
    public function delete($id) {
        if (!isset($_SESSION['user_id'])) exit;
        
        $pdo = Database::getInstance();
        $role = strtoupper($_SESSION['role'] ?? 'SALES');

        $stmtCheck = $pdo->prepare("SELECT title FROM tasks WHERE id = ?");
        $stmtCheck->execute([$id]);
        $taskRow = $stmtCheck->fetch(\PDO::FETCH_ASSOC);
        $tab = ($taskRow && strpos($taskRow['title'], 'APPROVAL_REQ:') === 0) ? 'approvals' : 'tasks';

        if ($role === 'ADMIN') {
            $pdo->prepare("DELETE FROM tasks WHERE id = ?")->execute([$id]);
        } else {
            $pdo->prepare("DELETE FROM tasks WHERE id = ? AND assigned_to = ?")->execute([$id, $_SESSION['user_id']]);
        }
        
        header('Location: ' . BASE_URL . 'assignments?tab=' . $tab);
        exit;
    }

    private function check_chat_table() {
        $pdo = Database::getInstance();
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS task_internal_chats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                task_id INT NOT NULL,
                user_id INT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX (task_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }

    public function get_chat_messages() {
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');

        $taskId = (int)($_GET['task_id'] ?? 0);
        if (!$taskId) {
            echo json_encode(['status' => 'error', 'messages' => []]);
            exit;
        }

        $this->check_chat_table();
        $pdo = Database::getInstance();
        // Display only: internal approval/task chat timestamps are stored in UTC.
        $crmTimezone = \Core\Timezone::get($pdo, (int)($_SESSION['company_id'] ?? 1));

        $stmtTask = $pdo->prepare("SELECT t.*, u.full_name as requester_name FROM tasks t LEFT JOIN users u ON t.assigned_to = u.id WHERE t.id = ?");
        $stmtTask->execute([$taskId]);
        $task = $stmtTask->fetch(\PDO::FETCH_ASSOC);

        $taskDetails = null;
        if ($task) {
            $cleanTitle = trim(str_replace('APPROVAL_REQ:', '', $task['title']));
            $party = 'N/A';
            if (preg_match('/Party Name:\s*([^\n\r]+)/i', $task['description'], $matches)) {
                $party = trim($matches[1]);
            }

            $taskDetails = [
                'id' => $task['id'],
                'app_id' => '#APP-' . str_pad($task['id'], 4, '0', STR_PAD_LEFT),
                'title' => htmlspecialchars($cleanTitle),
                'party' => htmlspecialchars($party),
                'description' => htmlspecialchars($task['description']),
                'requester_name' => htmlspecialchars($task['requester_name'] ?? 'Executive'),
                'time' => \Core\Timezone::formatUtc($task['created_at'], $crmTimezone, 'd M, h:i A'),
                'status' => $task['status']
            ];
        }

        $stmt = $pdo->prepare("
            SELECT c.*, u.full_name as user_name 
            FROM task_internal_chats c 
            LEFT JOIN users u ON c.user_id = u.id 
            WHERE c.task_id = ? 
            ORDER BY c.created_at ASC
        ");
        $stmt->execute([$taskId]);
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $messages = [];
        foreach ($rows as $r) {
            $messages[] = [
                'id' => $r['id'],
                'user_id' => $r['user_id'],
                'user_name' => $r['user_name'] ?? 'User',
                'message' => htmlspecialchars($r['message']),
                'time' => \Core\Timezone::formatUtc($r['created_at'], $crmTimezone, 'h:i A')
            ];
        }

        echo json_encode([
            'status' => 'success', 
            'task_details' => $taskDetails,
            'messages' => $messages
        ]);
        exit;
    }

    public function send_chat_message() {
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');

        $input = json_decode(file_get_contents('php://input'), true);
        $taskId = (int)($input['task_id'] ?? 0);
        $message = trim($input['message'] ?? '');

        if (!$taskId || empty($message)) {
            echo json_encode(['status' => 'error', 'message' => 'Empty message']);
            exit;
        }

        $this->check_chat_table();
        $pdo = Database::getInstance();
        $currentUserId = (int)$_SESSION['user_id'];
        $senderName = $_SESSION['name'] ?? 'User';
        $companyId = $_SESSION['company_id'] ?? 1;

        $stmt = $pdo->prepare("INSERT INTO task_internal_chats (task_id, user_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$taskId, $currentUserId, $message]);

        $stmtTask = $pdo->prepare("SELECT * FROM tasks WHERE id = ?");
        $stmtTask->execute([$taskId]);
        $task = $stmtTask->fetch(\PDO::FETCH_ASSOC);

        if ($task) {
            $targetUsers = [];
            $requesterId = (int)$task['assigned_to'];
            $cleanTitle = str_replace('APPROVAL_REQ:', '', $task['title']);

            if ($currentUserId === $requesterId) {
                $stmtAdmin = $pdo->prepare("SELECT id FROM users WHERE LOWER(role) = 'admin' AND company_id = ? ORDER BY id ASC LIMIT 1");
                $stmtAdmin->execute([$companyId]);
                $singleAdminId = $stmtAdmin->fetchColumn();
                if ($singleAdminId && (int)$singleAdminId !== $currentUserId) {
                    $targetUsers[] = (int)$singleAdminId;
                }
            } else {
                if ($requesterId !== $currentUserId) {
                    $targetUsers[] = $requesterId;
                }
            }

            foreach (array_unique($targetUsers) as $targetId) {
                $this->create_notification(
                    $targetId,
                    "💬 Chat: " . $cleanTitle,
                    $senderName . ": " . (strlen($message) > 50 ? substr($message, 0, 50) . '...' : $message),
                    BASE_URL . "assignments?tab=approvals&open_chat=" . $taskId
                );
            }
        }

        echo json_encode(['status' => 'success']);
        exit;
    }
}
?>