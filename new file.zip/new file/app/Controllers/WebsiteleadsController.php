<?php 
namespace Controllers; 
use Core\Controller; 
use Core\Database;

class WebsiteleadsController extends Controller {
    // Date-only UI filters use the company calendar day; DB timestamps remain UTC.
    private function utcFilterBoundary($value, $timezone, $endExclusive = false) {
        if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value)) return null;
        $local = \DateTimeImmutable::createFromFormat('!Y-m-d', $value, new \DateTimeZone($timezone));
        if (!$local || $local->format('Y-m-d') !== $value) return null;
        if ($endExclusive) $local = $local->modify('+1 day');
        return \Core\Timezone::toUtc($local->format('Y-m-d') . ' 00:00:00', $timezone);
    }

          
    
    public function index() {         
        if (!isset($_SESSION['user_id'])) {             
            header('Location: ' . BASE_URL . 'auth');             
            exit;         
        }         

        $pdo = Database::getInstance();
        $company_id = $_SESSION['company_id'] ?? 1;
        $displayTimezone = \Core\Timezone::get($pdo, (int)$company_id);
        $todayLocal = (new \DateTimeImmutable('now', new \DateTimeZone($displayTimezone)))->format('Y-m-d');
        $user_id = $_SESSION['user_id'];
        
        $role = isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES';

        // URL parsing fix for filtering
        $queryString = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
        if ($queryString) {
            parse_str($queryString, $customGet);
            $_GET = array_merge($_GET, $customGet);
        }

        // --- 🔥 SERVER-SIDE FILTERS & SEARCH LOGIC 🔥 ---
        $where_clauses = ["company_id = :company_id", "lead_source = 'Website'"];
        $params = [':company_id' => $company_id];

        if ($role !== 'ADMIN') {
            $where_clauses[] = "(assigned_to IS NULL OR assigned_to = 0 OR assigned_to = :user_id)";
            $params[':user_id'] = $user_id;
        }

        // 🔥 BUG FIXED: Exact & Smart Search Logic 🔥
        if (!empty($_GET['search']) && trim($_GET['search']) !== '') {
            $searchTerm = trim($_GET['search']);
            
            $searchClause = "(
                full_name LIKE :search1 
                OR company_name LIKE :search2 
                OR email LIKE :search3 
                OR city LIKE :search4 
                OR phone_number LIKE :search5 
                OR whatsapp_number LIKE :search6 
                OR tags LIKE :search7
                OR products_of_interest LIKE :search8";
            
            $params[':search1'] = '%' . $searchTerm . '%';
            $params[':search2'] = '%' . $searchTerm . '%';
            $params[':search3'] = '%' . $searchTerm . '%';
            $params[':search4'] = '%' . $searchTerm . '%';
            $params[':search5'] = '%' . $searchTerm . '%';
            $params[':search6'] = '%' . $searchTerm . '%';
            $params[':search7'] = '%' . $searchTerm . '%';
            $params[':search8'] = '%' . $searchTerm . '%';

            // Smart Number Matching (ONLY run if user typed a pure phone number, not an email with numbers)
            if (preg_match('/^[0-9\+\-\s]+$/', $searchTerm)) {
                $cleanNum = preg_replace('/[^0-9]/', '', $searchTerm);
                if (strlen($cleanNum) > 10 && substr($cleanNum, 0, 2) == '91') {
                    $cleanNum = substr($cleanNum, 2);
                }
                
                if(!empty($cleanNum)) {
                    $searchClause .= " OR phone_number LIKE :cleanNum1 OR whatsapp_number LIKE :cleanNum2";
                    $params[':cleanNum1'] = '%' . $cleanNum . '%';
                    $params[':cleanNum2'] = '%' . $cleanNum . '%';
                }
            }
            
            // Exact ID matching (Only if user typed exactly a number or 'LD-123' format)
            $searchId = 0;
            if (preg_match('/^#?LD-([0-9]+)$/i', $searchTerm, $matches)) {
                $searchId = (int)$matches[1];
            } elseif (preg_match('/^[0-9]+$/', $searchTerm)) {
                $searchId = (int)$searchTerm;
            }

            if ($searchId > 0) {
                $searchClause .= " OR id = :searchId";
                $params[':searchId'] = $searchId;
            }
            
            $searchClause .= ")";
            $where_clauses[] = $searchClause;
        }

        if (!empty($_GET['status']) && $_GET['status'] !== 'all') {
            $st = $_GET['status'];
            if ($st === 'new') {
                $where_clauses[] = "(lead_stage = 'new' OR lead_stage = 'New' OR lead_stage IS NULL)";
            } elseif ($st === 'pipeline') {
                $where_clauses[] = "LOWER(lead_stage) IN ('qualified', 'catalog sharing', 'follow up', 'negotiation', 'sold')";
            } elseif ($st === 'unqualified') {
                $where_clauses[] = "LOWER(lead_stage) LIKE '%unqualified%'";
            }
        }

        if (!empty($_GET['temp'])) {
            $where_clauses[] = "temperature = :temp";
            $params[':temp'] = $_GET['temp'];
        }

        if (!empty($_GET['agent'])) {
            $where_clauses[] = "assigned_to = :agent_id";
            $params[':agent_id'] = $_GET['agent'];
        }

        if (!empty($_GET['tag'])) {
            $where_clauses[] = "tags LIKE :tag";
            $params[':tag'] = '%' . trim($_GET['tag']) . '%';
        }

        if (!empty($_GET['start_date'])) {
            $utcStart = $this->utcFilterBoundary($_GET['start_date'], $displayTimezone);
            if ($utcStart === null) $where_clauses[] = '1 = 0';
            else { $where_clauses[] = 'created_at >= :start_date'; $params[':start_date'] = $utcStart; }
        }

        if (!empty($_GET['end_date'])) {
            $utcEnd = $this->utcFilterBoundary($_GET['end_date'], $displayTimezone, true);
            if ($utcEnd === null) $where_clauses[] = '1 = 0';
            else { $where_clauses[] = 'created_at < :end_date'; $params[':end_date'] = $utcEnd; }
        }

        $where_sql = implode(' AND ', $where_clauses);

        // --- 🔥 PAGINATION LOGIC 🔥 ---
        $countStmt = $pdo->prepare("SELECT COUNT(id) FROM leads WHERE $where_sql");
        $countStmt->execute($params);
        $total_leads = (int)$countStmt->fetchColumn();

        $limit = 50; 
        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;
        $total_pages = ceil($total_leads / $limit);
        if ($page > $total_pages && $total_pages > 0) $page = $total_pages;
        
        $offset = ($page - 1) * $limit;

        $stmt = $pdo->prepare("SELECT * FROM leads WHERE $where_sql ORDER BY created_at DESC LIMIT $limit OFFSET $offset");
        $stmt->execute($params);
        $website_leads = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        // Fetch Agents
        $agents = [];
        if ($role === 'ADMIN') {
            try {
                $stmtAgents = $pdo->query("SELECT id, name FROM users ORDER BY name ASC");
                $agents = $stmtAgents->fetchAll(\PDO::FETCH_ASSOC);
            } catch (\Exception $e) {
                try {
                    $stmtAgents = $pdo->query("SELECT id, full_name as name FROM users ORDER BY full_name ASC");
                    $agents = $stmtAgents->fetchAll(\PDO::FETCH_ASSOC);
                } catch (\Exception $e2) {}
            }
        }

        // Fetch Tags
        $tags = [];
        try {
            $tagsStmt = $pdo->query("SELECT name FROM crm_tags ORDER BY name ASC");
            $tags = $tagsStmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {}
        
        $data = [             
            'title' => 'Website Leads - SCPK CRM',             
            'user_name' => $_SESSION['name'] ?? 'User',             
            'user_role' => $role,  
            'leads' => $website_leads,
            'agents' => $agents,
            'tags' => $tags,
            'current_page' => $page,
            'total_pages' => $total_pages,
            'total_leads' => $total_leads,
            'filters' => $_GET,
            'displayTimezone' => $displayTimezone,
            'todayLocal' => $todayLocal
        ];                 
        
        $this->view('website_leads', $data);     
    } 

    public function assign_lead() {
        if (!isset($_SESSION['user_id'])) exit;
        
        $role = isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES';
        
        if ($role !== 'ADMIN') {
            echo json_encode(['status' => 'error', 'message' => 'Only Admin can assign leads.']);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            
            $lead_id = $input['lead_id'] ?? null;
            $agent_id = $input['agent_id'] ?? null;
            
            if ($lead_id) {
                try {
                    $pdo = Database::getInstance();
                    $agent_id = !empty($agent_id) ? $agent_id : null;
                    $stmt = $pdo->prepare("UPDATE leads SET assigned_to = ? WHERE id = ?");
                    $stmt->execute([$agent_id, $lead_id]);
                    
                    echo json_encode(['status' => 'success']);
                } catch (\Exception $e) {
                    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
                }
            } else {
                echo json_encode(['status' => 'error']);
            }
            exit;
        }
    }
} 
?>