<?php
namespace Controllers;
use Core\Controller;
use Core\Database;

class WebhookController extends Controller {
    
    // ----------------------------------------------------
    // WHATSAPP LEADS WEBHOOK (Incoming Messages)
    // ----------------------------------------------------
    public function whatsapp() {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            if (isset($_GET['hub_mode']) && $_GET['hub_mode'] === 'subscribe') {
                if (isset($_GET['hub_verify_token']) && $_GET['hub_verify_token'] === WA_VERIFY_TOKEN) {
                    echo $_GET['hub_challenge'];
                    exit;
                }
            }
            http_response_code(403);
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);

            // Allow webhook processing to continue after the quick HTTP 200 response.
            ignore_user_abort(true);
            
            // Fast 200 OK (WhatsApp Retry Glitch Rokne Ke Liye)
            ob_start();
            http_response_code(200);
            echo "OK";
            header('Connection: close');
            header('Content-Length: ' . ob_get_length());
            ob_end_flush();
            @ob_flush();
            @flush();
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request(); 
            }

            try {
                $pdo = Database::getInstance();
                // Meta can include several entries, changes and messages in one POST.
                // Process EACH item independently: never silently discard photos [1..N].
                foreach (($data['entry'] ?? []) as $entry) {
                    foreach (($entry['changes'] ?? []) as $change) {
                        $value = $change['value'] ?? [];

                        foreach (($value['statuses'] ?? []) as $statusData) {
                            try {
                                $wa_message_id = $statusData['id'] ?? null;
                                $status = $statusData['status'] ?? null;
                                if (!$wa_message_id || !$status) continue;
                                $stmt = $pdo->prepare("UPDATE wa_messages SET delivery_status = ? WHERE wa_message_id = ?");
                                $stmt->execute([$status, $wa_message_id]);
                                if ($status === 'failed') {
                                    $waError = $statusData['errors'][0]['code'] ?? 'UNKNOWN';
                                    $this->botDebugLog('META_DELIVERY_FAILED',
                                        $statusData['recipient_id'] ?? '', 'code=' . (string)$waError);
                                }
                            } catch (\Throwable $e) {
                                $this->botDebugLog('STATUS_PROCESS_FAILED', '', 'code=' . $e->getCode());
                            }
                        }

                        $messages = $value['messages'] ?? [];
                        if (!is_array($messages)) continue;
                        if (count($messages) > 1) {
                            $this->botDebugLog('INBOUND_BATCH', '', 'count=' . count($messages));
                        }
                        foreach ($messages as $messageData) {
                            try {
                                if (!is_array($messageData)) continue;
                                $senderPhone = $messageData['from'] ?? '';
                                if (!$senderPhone) continue;
                                $contactData = $value['contacts'][0] ?? [];
                                // Match the sender to the right contact in a batch.
                                foreach (($value['contacts'] ?? []) as $candidate) {
                                    if (($candidate['wa_id'] ?? '') === $senderPhone) {
                                        $contactData = $candidate;
                                        break;
                                    }
                                }
                                $senderName = $contactData['profile']['name'] ?? 'WhatsApp User';
                                $wa_message_id = $messageData['id'] ?? null;
                                $msg_type = $messageData['type'] ?? 'text';
                                $messageText = '';
                                $media_id = null;
                                $replyToWaMessageId = isset($messageData['context']['id']) && is_string($messageData['context']['id'])
                                    ? substr($messageData['context']['id'], 0, 255) : null;

                                if ($msg_type === 'text') {
                                    $messageText = $messageData['text']['body'] ?? '';
                                } elseif (in_array($msg_type, ['image', 'video', 'document', 'audio'])) {
                                    $media_id = $messageData[$msg_type]['id'] ?? null;
                                    $messageText = $messageData[$msg_type]['caption'] ?? '';
                                } elseif ($msg_type === 'button' || $msg_type === 'interactive') {
                                    $messageText = $messageData['interactive']['button_reply']['title']
                                        ?? $messageData['button']['text'] ?? '[Interactive Response]';
                                } elseif ($msg_type === 'unsupported') {
                                    $messageText = "🚫 [Unsupported Message: View-Once image, Poll, or Reaction]";
                                } else {
                                    $messageText = "[$msg_type Received]";
                                }

                                $referral = $messageData['referral'] ?? null;
                                $this->processIncomingMessage($senderPhone, $senderName, $messageText,
                                    $msg_type, $wa_message_id, $media_id, $referral, $replyToWaMessageId);
                            } catch (\Throwable $e) {
                                // Failure processing one attachment must not drop the rest.
                                $this->botDebugLog('INBOUND_ITEM_FAILED',
                                    $messageData['from'] ?? '', 'code=' . $e->getCode());
                            }
                        }
                    }
                }
            } catch (\Throwable $e) {
                error_log("Webhook Error: " . $e->getMessage());
                $this->botDebugLog('WEBHOOK_FAILED', '', 'code=' . $e->getCode());
            }
        }
    }

    private function processIncomingMessage($phone, $name, $text, $msg_type = 'text', $wa_message_id = null, $media_id = null, $referral = null, $replyToWaMessageId = null) {
        // LOG ONLY: records processing without storing customer message content.
        $this->botDebugLog('INBOUND_RECEIVED', $phone, 'type=' . $msg_type);
        try {
            $pdo = Database::getInstance();
            $company_id = 1; 

            // Duplicate Message Lock
            if ($wa_message_id) {
                $checkMsg = $pdo->prepare("SELECT id FROM wa_messages WHERE wa_message_id = ?");
                $checkMsg->execute([$wa_message_id]);
                if ($checkMsg->fetch()) {
                    $this->botDebugLog('SKIP_ALREADY_SAVED', $phone);
                    return;
                }
                
                $lockFile = sys_get_temp_dir() . '/wa_' . md5($wa_message_id) . '.lock';
                if (file_exists($lockFile)) {
                    $this->botDebugLog('SKIP_LOCK_EXISTS', $phone);
                    return;
                }
                @file_put_contents($lockFile, 'locked');
            }

            // ==========================================
            // STRICTLY FAIL-SAFE META AD TRACKING
            // ==========================================
            $meta_ad_name = null;
            if ($referral && isset($referral['source_id'])) {
                try {
                    $ad_id = $referral['source_id'];
                    $adStmt = $pdo->prepare("SELECT ad_name FROM meta_ads WHERE ad_id = ?");
                    $adStmt->execute([$ad_id]);
                    $adRow = $adStmt->fetch();
                    $meta_ad_name = $adRow ? $adRow['ad_name'] : "Ad ID: " . $ad_id;
                } catch (\Exception $e) {}
            }

            $stmt = $pdo->prepare("SELECT id FROM leads WHERE whatsapp_number = ? AND company_id = ?");
            $stmt->execute([$phone, $company_id]);
            $lead = $stmt->fetch();

            if (!$lead) {
                // --- INSERT WHATSAPP LEAD ---
                $stmt = $pdo->prepare("INSERT INTO leads (company_id, full_name, whatsapp_number, lead_source, lead_status) VALUES (?, ?, ?, 'WhatsApp', 'new')");
                $stmt->execute([$company_id, $name, $phone]);
                $lead_id = $pdo->lastInsertId();
                
                // === BACKGROUND AUTO-ASSIGN RUN HOGA ===
                $this->autoAssignLeadAutomatically($lead_id, $pdo);

            } else {
                $lead_id = $lead['id'];
            }

            // Safely Save Meta Ad Name & Trigger Note
            if ($meta_ad_name) {
                try {
                    $pdo->query("SELECT meta_ad_name FROM leads LIMIT 1");
                } catch (\Exception $e) {
                    $pdo->exec("ALTER TABLE leads ADD COLUMN meta_ad_name VARCHAR(255) NULL DEFAULT NULL");
                }
                
                try {
                    $pdo->prepare("UPDATE leads SET meta_ad_name = ? WHERE id = ?")->execute([$meta_ad_name, $lead_id]);
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'System Event', ?, 'System')")
                        ->execute([$lead_id, "Lead arrived from Click-to-WhatsApp Ad: " . $meta_ad_name]); 
                } catch (\Exception $e) {}
            }

            $stmt = $pdo->prepare("SELECT id, unread_count FROM wa_conversations WHERE lead_id = ?");
            $stmt->execute([$lead_id]);
            $conversation = $stmt->fetch();

            if (!$conversation) {
                $stmt = $pdo->prepare("INSERT INTO wa_conversations (company_id, lead_id, unread_count) VALUES (?, ?, 1)");
                $stmt->execute([$company_id, $lead_id]);
                $conversation_id = $pdo->lastInsertId();
            } else {
                $conversation_id = $conversation['id'];
                $new_unread = $conversation['unread_count'] + 1;
                $pdo->prepare("UPDATE wa_conversations SET last_message_at = CURRENT_TIMESTAMP, unread_count = ? WHERE id = ?")->execute([$new_unread, $conversation_id]);
            }

            // ACTUAL IMAGE DOWNLOAD LOGIC
            $local_media_url = null;
            $mime_type = null;

            if ($media_id) {
                $waService = new \Services\WhatsAppService();
                $downloaded = $waService->downloadMedia($media_id);
                
                if ($downloaded && $downloaded['data']) {
                    $mime_type = $downloaded['mime_type'];
                    
                    $ext = 'bin'; 
                    if (strpos($mime_type, 'image/jpeg') !== false) $ext = 'jpg';
                    elseif (strpos($mime_type, 'image/png') !== false) $ext = 'png';
                    elseif (strpos($mime_type, 'video/mp4') !== false) $ext = 'mp4';
                    elseif (strpos($mime_type, 'audio/') !== false) $ext = 'ogg'; 
                    elseif (strpos($mime_type, 'pdf') !== false) $ext = 'pdf';
                    
                    $file_name = 'wa_' . $media_id . '_' . time() . '.' . $ext;
                    $upload_path = $_SERVER['DOCUMENT_ROOT'] . '/uploads/chat/';
                    if (!is_dir($upload_path)) mkdir($upload_path, 0777, true);
                    
                    file_put_contents($upload_path . $file_name, $downloaded['data']);
                    $local_media_url = rtrim(BASE_URL, '/') . '/uploads/chat/' . $file_name;
                }
            }

            $stmt = $pdo->prepare("
                INSERT INTO wa_messages (wa_message_id, conversation_id, sender_type, message_type, message_body, media_url, mime_type, delivery_status, reply_to_wa_message_id) 
                VALUES (?, ?, 'lead', ?, ?, ?, ?, 'delivered', ?)
            ");
            $stmt->execute([$wa_message_id, $conversation_id, $msg_type, $text, $local_media_url, $mime_type, $replyToWaMessageId]);
            $this->botDebugLog('INBOUND_DB_SAVED', $phone, 'type=' . $msg_type);
            
            // 🔥 TRIGGER CHATBOT FLOW 🔥
            if ($msg_type === 'text' || $msg_type === 'button' || $msg_type === 'interactive') {
                $this->triggerWhatsAppBot($phone, $name, $text, $conversation_id, $pdo, $wa_message_id, $replyToWaMessageId);
            }

        } catch (\Exception $e) {
            error_log("Database Error: " . $e->getMessage());
            $this->botDebugLog('INBOUND_PROCESS_FAILED', $phone, $e->getMessage());
        }
    }

    // ----------------------------------------------------
    // WEBSITE LEADS WEBHOOK (Pabbly/Google Sheets)
    // ----------------------------------------------------
    public function website_leads() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);

            if ($data) {
                try {
                    $pdo = \Core\Database::getInstance();
                    $company_id = 1;

                    $name = $data['name'] ?? 'Unknown Website Lead';
                    $company = $data['company'] ?? '';
                    $email = trim($data['email'] ?? '');
                    $phone = trim($data['phone'] ?? '');
                    $products = $data['products'] ?? '';
                    $city = $data['city'] ?? '';
                    $state = $data['state'] ?? '';
                    $postal = $data['postal'] ?? '';
                    $country = $data['country'] ?? '';
                    $based = $data['based'] ?? '';

                    $existing_lead = false;

                    if (!empty($phone)) {
                        $stmt = $pdo->prepare("SELECT id FROM leads WHERE whatsapp_number = ? OR phone_number = ?");
                        $stmt->execute([$phone, $phone]);
                        $existing_lead = $stmt->fetch();
                    } elseif (!empty($email)) {
                        $stmt = $pdo->prepare("SELECT id FROM leads WHERE email = ?");
                        $stmt->execute([$email]);
                        $existing_lead = $stmt->fetch();
                    }

                    if (!$existing_lead) {
                        $stmt = $pdo->prepare("
                            INSERT INTO leads (
                                company_id, full_name, phone_number, email, company_name, 
                                products_of_interest, city, state, postal_code, country, based_in, 
                                lead_source, lead_stage
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Website', 'new')
                        ");
                        $stmt->execute([
                            $company_id, $name, $phone, $email, $company, 
                            $products, $city, $state, $postal, $country, $based
                        ]);
                        $lead_id = $pdo->lastInsertId();
                        
                        $this->autoAssignLeadAutomatically($lead_id, $pdo);

                    } else {
                        $stmt = $pdo->prepare("
                            UPDATE leads SET 
                                full_name = ?, email = ?, company_name = ?, products_of_interest = ?, 
                                city = ?, state = ?, postal_code = ?, country = ?, based_in = ?,
                                lead_source = 'Website', 
                                lead_stage = 'new',
                                created_at = CURRENT_TIMESTAMP,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                        ");
                        $stmt->execute([
                            $name, $email, $company, $products, $city, $state, $postal, $country, $based, $existing_lead['id']
                        ]);

                        try {
                            $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'System Event', 'Customer re-submitted Website Form. Lead moved to Top.', 'System')")
                                ->execute([$existing_lead['id']]);
                        } catch (\Exception $e) {}
                    }

                    http_response_code(200);
                    echo json_encode(['status' => 'success', 'message' => 'Lead Captured Successfully']);
                    exit;

                } catch (\Exception $e) {
                    error_log("Website Webhook Error: " . $e->getMessage());
                    http_response_code(500);
                    exit;
                }
            }
        }
        http_response_code(400);
        exit;
    }   

    // =========================================================================
    // STRICT TOTAL-COUNT BASED RATIO & SEQUENCE AUTO-ASSIGN
    // =========================================================================
    private function autoAssignLeadAutomatically($lead_id, $pdo) {
        $today = date('Y-m-d');
        $company_id = 1;

        try {
            $desired_sequence = ['mukul', 'dolly', 'varsha', 'manisha', 'naaz', 'sakshi', 'mansi', 'zeba'];
            
            $stmt = $pdo->prepare("
                SELECT id, full_name as name, is_auto_assign, daily_lead_limit, assign_weight 
                FROM users 
                WHERE LOWER(role) = 'sales' AND company_id = ?
            ");
            $stmt->execute([$company_id]);
            $raw_users = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            if (empty($raw_users)) {
                return false;
            }

            $sales_agents = [];
            foreach ($desired_sequence as $seq_name) {
                foreach ($raw_users as $u) {
                    $agent_fname = strtolower(trim($u['name'] ?? $u['full_name'] ?? ''));
                    
                    if (strpos($agent_fname, $seq_name) !== false) {
                        $is_active = isset($u['is_auto_assign']) ? (int)$u['is_auto_assign'] : 1;
                        $limit = isset($u['daily_lead_limit']) ? max(1, (int)$u['daily_lead_limit']) : 9999;
                        $weight = isset($u['assign_weight']) ? max(1, (int)$u['assign_weight']) : 1;

                        if ($is_active === 1) {
                            $countStmt = $pdo->prepare("SELECT 
                                COUNT(id) as total_leads, 
                                COALESCE(SUM(CASE WHEN DATE(updated_at) = ? OR DATE(created_at) = ? THEN 1 ELSE 0 END), 0) as today_leads 
                                FROM leads WHERE assigned_to = ?");
                            $countStmt->execute([$today, $today, $u['id']]);
                            $counts = $countStmt->fetch(\PDO::FETCH_ASSOC);
                            
                            $total_assigned = (int)$counts['total_leads'];
                            $today_assigned = (int)$counts['today_leads'];
                            
                            if ($today_assigned < $limit) {
                                $sales_agents[] = [
                                    'id' => $u['id'],
                                    'name' => strtoupper($u['name'] ?? $u['full_name']),
                                    'limit' => $limit,
                                    'weight' => $weight,
                                    'today_count' => $today_assigned,
                                    'total_count' => $total_assigned
                                ];
                            }
                        }
                        break; 
                    }
                }
            }

            if (empty($sales_agents)) {
                return false; 
            }

            $total_agents = count($sales_agents);
            $agent_ids = array_column($sales_agents, 'id');
            $agent_list_str = implode(',', $agent_ids);

            $last_assigned_id = $pdo->query("SELECT assigned_to FROM leads WHERE company_id = $company_id AND assigned_to IN ($agent_list_str) ORDER BY id DESC LIMIT 1")->fetchColumn();
            
            $start_index = 0;
            if ($last_assigned_id) {
                foreach ($sales_agents as $index => $agent) {
                    if ($agent['id'] == $last_assigned_id) {
                        $start_index = ($index + 1) % $total_agents;
                        break;
                    }
                }
            }

            $current_index = $start_index;
            $selected_agent = null;
            $attempts = 0;
            $max_attempts = $total_agents * 2;

            while ($attempts < $max_attempts) {
                $agent = $sales_agents[$current_index];
                
                if ($agent['today_count'] < $agent['limit']) {
                    
                    if ($agent['weight'] > 1) {
                        $normal_total = 0;
                        $normal_count = 0;
                        foreach ($sales_agents as $sa) {
                            if ($sa['weight'] == 1) {
                                $normal_total += $sa['total_count'];
                                $normal_count++;
                            }
                        }

                        if ($normal_count > 0) {
                            $avg_normal = $normal_total / $normal_count;
                            $allowed_max = floor($avg_normal / $agent['weight']);

                            if ($agent['total_count'] >= $allowed_max && $avg_normal >= 1) {
                                $current_index = ($current_index + 1) % $total_agents;
                                $attempts++;
                                continue;
                            }
                        }
                    }

                    $selected_agent = $agent;
                    break;
                }
                
                $current_index = ($current_index + 1) % $total_agents;
                $attempts++;
            }

            if (!$selected_agent) {
                foreach ($sales_agents as $agent) {
                    if ($agent['today_count'] < $agent['limit']) {
                        $selected_agent = $agent;
                        break;
                    }
                }
            }

            if ($selected_agent) {
                $pdo->prepare("UPDATE leads SET assigned_to = ?, updated_at = NOW() WHERE id = ?")
                    ->execute([$selected_agent['id'], $lead_id]);

                try { 
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'System Event', ?, 'System')")
                        ->execute([$lead_id, "Lead Auto-Assigned with Strict Ratio to " . $selected_agent['name']]); 
                } catch (\Exception $e) {}

                return true;
            }

        } catch (\Exception $e) {
            error_log("Strict Ratio Assign Error: " . $e->getMessage());
        }

        return false;
    }

    // =========================================================================
    // 🤖 WHATSAPP AUTOMATED CHATBOT LOGIC (FAST + BUTTONS)
    // =========================================================================
    private function triggerWhatsAppBot($phone, $name, $messageText, $conversation_id, $pdo, $wa_message_id = null, $replyToWaMessageId = null) {
        $messageText = strtolower(trim($messageText));

        // Human takeover: an agent's latest real outbound message stops the bot.
        // ONLY a NEWER customer TEXT message exactly "menu" resumes it.
        // Use DB message IDs (insertion order) instead of an ever-present agent
        // record, so a previous takeover does not block "menu" forever.
        // Bot-generated [Bot] messages and internal notes are not takeovers.
        // Auto-assignment without a real agent message does not stop the bot.
        try {
            $takeoverStmt = $pdo->prepare("
                SELECT sender_type FROM wa_messages
                WHERE conversation_id = ?
                  AND (
                    (sender_type = 'agent'
                     AND (is_internal = 0 OR is_internal IS NULL)
                     AND (message_body IS NULL OR message_body NOT LIKE '[Bot]%'))
                    OR
                    (sender_type = 'lead'
                     AND message_type = 'text'
                     AND LOWER(TRIM(message_body)) = 'menu')
                  )
                ORDER BY id DESC LIMIT 1
            ");
            $takeoverStmt->execute([$conversation_id]);
            if ($takeoverStmt->fetchColumn() === 'agent') {
                $this->botDebugLog('BOT_STOP_AGENT_TAKEOVER', $phone);
                return; // Hi, old buttons, catalog, etc. cannot restart it.
            }
        } catch (\Throwable $e) {
            // Fail closed: never risk an automated reply when handover status
            // cannot be checked. Customer messages remain saved in CRM.
            $this->botDebugLog('BOT_TAKEOVER_CHECK_FAILED', $phone, 'code=' . $e->getCode());
            return;
        }

        $stateFile = __DIR__ . '/bot_states.json'; 
        $states = file_exists($stateFile) ? json_decode(file_get_contents($stateFile), true) : [];

        if (!isset($states[$phone])) {
            $states[$phone] = ['step' => 'START', 'data' => []];
        }

        $this->botDebugLog('BOT_STATE', $phone, 'step=' . ($states[$phone]['step'] ?? 'UNKNOWN'));

        // When the customer quotes an OLD bot menu, use that exact menu to
        // interpret numeric 1/2/3 rather than guessing from today's bot state.
        $quotedChoiceStep = null;
        if ($replyToWaMessageId && in_array($messageText, ['1', '2', '3'], true)) {
            try {
                $q = $pdo->prepare("SELECT message_body FROM wa_messages
                    WHERE wa_message_id = ? AND conversation_id = ? AND sender_type = 'agent'
                    LIMIT 1");
                $q->execute([$replyToWaMessageId, $conversation_id]);
                $original = (string)($q->fetchColumn() ?: '');
                if (strpos($original, '[Bot]') === 0) {
                    if (strpos($original, 'What is your target selling range?') !== false && $messageText !== '3') {
                        $quotedChoiceStep = 'ASK_RANGE';
                    } elseif (strpos($original, 'What are you looking for today?') !== false && $messageText !== '3') {
                        $quotedChoiceStep = 'PROCESS_PURPOSE';
                    } elseif (strpos($original, 'Would you like to schedule a Video Call') !== false) {
                        $quotedChoiceStep = 'ASK_PREFERENCE';
                    } elseif (strpos($original, 'When would you like to schedule the Video Call?') !== false) {
                        $quotedChoiceStep = 'SCHEDULE_VC';
                    }
                }
            } catch (\Throwable $e) {
                $this->botDebugLog('BOT_QUOTE_LOOKUP_FAILED', $phone);
            }
        }
        if ($quotedChoiceStep !== null) {
            $states[$phone]['step'] = $quotedChoiceStep;
            $this->botDebugLog('BOT_QUOTED_MENU', $phone, 'step=' . $quotedChoiceStep);
        }
        if ($states[$phone]['step'] === 'SCHEDULE_VC' &&
            in_array($messageText, ['video call', 'catalog images', 'scpk address'], true) &&
            ($messageText === 'scpk address' ||
             in_array((string)($states[$phone]['data']['range'] ?? ''), ['1000', '2000'], true))) {
            // Allow switching the preference even after starting video-call scheduling.
            $states[$phone]['step'] = 'ASK_PREFERENCE';
            $this->botDebugLog('BOT_PREFERENCE_SWITCH', $phone);
        }

        if ($states[$phone]['step'] === 'HUMAN_AGENT') {
            if ($messageText === 'menu') {
                $states[$phone]['step'] = 'START';
                $this->botDebugLog('BOT_MENU_RESUME', $phone);
            } elseif (in_array($messageText, ['personal use', 'retail', 'shop or boutique'], true)) {
                // Legacy button clicks still work without reopening arbitrary agent chats.
                $states[$phone]['step'] = 'PROCESS_PURPOSE';
                $this->botDebugLog('BOT_LEGACY_BUTTON_RESUME', $phone);
            } elseif (in_array($messageText, ['video call', 'catalog images', 'scpk address'], true) &&
                      ($messageText === 'scpk address' ||
                       in_array((string)($states[$phone]['data']['range'] ?? ''), ['1000', '2000'], true))) {
                // Explicit old WhatsApp button labels can still select the OTHER option.
                // Do not reinterpret plain numeric 1/2/3 here: these are ambiguous.
                $states[$phone]['step'] = 'ASK_PREFERENCE';
                $this->botDebugLog('BOT_PREFERENCE_RESUME', $phone);
            } else {
                $this->botDebugLog('BOT_STOP_HUMAN_AGENT', $phone);
                return; // Preserve normal agent handover for all other messages.
            }
        } else {
            $is_greeting = in_array($messageText, ['hi', 'hello', 'hey', 'menu']) || 
                           strpos($messageText, 'came across your ad') !== false || 
                           strpos($messageText, 'more info on this') !== false;

            if ($is_greeting) {
                // Greetings/menu restart at question #1 (Personal / Wholesale).
                $states[$phone]['step'] = 'START';
            }
        }

        $currentStep = $states[$phone]['step'];
        $replyText = "";
        $replyButtons = [];
        $catalogRangeToSend = null; // Single-file catalog sending; no worker or Cron.
        // Shared retail reply, used for legacy Personal Use selections and direct retail requests.
        // Keep the actual group URL clean (no trailing hidden whitespace).
        $retailReplyText = "Thank you! For personal use, please visit our website: https://www.scpkonline.com\n\nOr contact our retail team directly at: *9311771299*.\n\nJoin our Retail WhatsApp Group:\nhttps://chat.whatsapp.com/E45xhw1veqxEgL1noOloR1\n\nHave a great day!";

        switch ($currentStep) {
            case 'START':
            case 'ASK_LOCATION':
            case 'ASK_PURPOSE':
                // Question #1: no intro video, name, city, or company-name question.
                $replyText = "Welcome to SCPK!\n\nWhat are you looking for today?\n\nType *1* for Personal Use\nType *2* for Shop or Boutique (Wholesale)";
                $replyButtons = ["Personal Use", "Shop or Boutique"];
                $states[$phone]['step'] = 'PROCESS_PURPOSE';
                break;

            case 'ASK_REQUIREMENT':
                // Compatibility for chats left in the discontinued requirement step.
                // Do not treat their next numeric selection as a selling range.
                $replyText = "Welcome to SCPK!\n\nWhat are you looking for today?\n\nType *1* for Personal Use\nType *2* for Shop or Boutique (Wholesale)";
                $replyButtons = ["Personal Use", "Shop or Boutique"];
                $states[$phone]['step'] = 'PROCESS_PURPOSE';
                break;

            case 'PROCESS_PURPOSE':
                $is_personal = ($messageText === '1' || strpos($messageText, 'personal') !== false || strpos($messageText, 'retail') !== false);
                $is_wholesale = ($messageText === '2' || strpos($messageText, 'wholesale') !== false || strpos($messageText, 'shop') !== false || strpos($messageText, 'boutique') !== false || strpos($messageText, 'bulk') !== false);
                if ($is_personal) {
                    $replyText = $retailReplyText;
                    try {
                        $pdo->prepare("UPDATE leads SET products_of_interest = 'Retail / Personal Use' WHERE whatsapp_number = ? AND company_id = 1")
                            ->execute([$phone]);
                    } catch (\Throwable $e) {
                        $this->botDebugLog('BOT_RETAIL_SAVE_FAILED', $phone);
                    }
                    $states[$phone]['step'] = 'HUMAN_AGENT';
                } elseif ($is_wholesale) {
                    // Question #2: wholesale goes straight to price range.
                    // No shop/company name and no generic product requirement question.
                    try {
                        $pdo->prepare("UPDATE leads SET products_of_interest = 'Wholesale Bulk Orders' WHERE whatsapp_number = ? AND company_id = 1")
                            ->execute([$phone]);
                    } catch (\Throwable $e) {
                        $this->botDebugLog('BOT_WHOLESALE_SAVE_FAILED', $phone);
                    }
                    $replyText = "Thanks! What is your target selling range?\n\nType *1* for Under ₹1000\nType *2* for Under ₹2000";
                    $replyButtons = ["Under ₹1000", "Under ₹2000"];
                    $states[$phone]['step'] = 'ASK_RANGE';
                } else {
                    $replyText = "Please select an option:\n\nType *1* for Personal Use\nType *2* for Shop or Boutique (Wholesale)";
                    $replyButtons = ["Personal Use", "Shop or Boutique"];
                }
                break;

            case 'ASK_COMPANY':
                // A legacy saved state: redirect to the desired question #2.
                $replyText = "Thanks! What is your target selling range?\n\nType *1* for Under ₹1000\nType *2* for Under ₹2000";
                $replyButtons = ["Under ₹1000", "Under ₹2000"];
                $states[$phone]['step'] = 'ASK_RANGE';
                break;

            case 'ASK_RANGE':
                // Question #2. Here '1'/'2' mean prices, not Personal/Wholesale.
                // Explicit text 'Personal Use' still allows a customer to switch to retail.
                if (strpos($messageText, 'personal') !== false || strpos($messageText, 'retail') !== false) {
                    $replyText = $retailReplyText;
                    try { $pdo->prepare("UPDATE leads SET products_of_interest = 'Retail / Personal Use' WHERE whatsapp_number = ?")->execute([$phone]); } catch (\Exception $e) {}
                    $states[$phone]['step'] = 'HUMAN_AGENT';
                    break;
                }

                $is_1000 = ($messageText == '1' || strpos($messageText, '1000') !== false || strpos($messageText, 'one thousand') !== false || strpos($messageText, 'under 1000') !== false);
                $is_2000 = ($messageText == '2' || strpos($messageText, '2000') !== false || strpos($messageText, 'two thousand') !== false || strpos($messageText, 'under 2000') !== false);

                if ($is_1000) {
                    $states[$phone]['data']['range'] = '1000';
                } elseif ($is_2000) {
                    $states[$phone]['data']['range'] = '2000';
                } else {
                    $replyText = "Please select a range:\n\nType *1* for Under ₹1000\nType *2* for Under ₹2000";
                    $replyButtons = ["Under ₹1000", "Under ₹2000"];
                    break;
                }
                
                // Question #3: keep the exact Video Call / Catalog Images options.
                $replyText = "Would you like to schedule a Video Call, or should I send the catalog right now?\n\nType *1* for Video Call\nType *2* to See Catalog Images\nType *3* for SCPK Address";
                $replyButtons = ["Video Call", "Catalog Images", "SCPK Address"]; 
                $states[$phone]['step'] = 'ASK_PREFERENCE';
                break;
                
            case 'ASK_PREFERENCE':
                $is_video = ($messageText == '1' || strpos($messageText, 'video') !== false || strpos($messageText, 'call') !== false);
                $is_catalog = ($messageText == '2' || strpos($messageText, 'catalog') !== false || strpos($messageText, 'image') !== false || strpos($messageText, 'photo') !== false || strpos($messageText, 'see') !== false || strpos($messageText, 'design') !== false);
                $is_address = ($messageText === '3' || $messageText === 'scpk address');

                if ($is_address) {
                    $replyText = "SCPK\nShri Chand Pardeep Kumar Pvt Ltd\n1308 Katra Leshwan Chandni chowk delhi 110006\n\n📍Google location: https://g.page/SCPKPL";
                    $states[$phone]['step'] = 'HUMAN_AGENT';
                } elseif ($is_video) {
                    $replyText = "When would you like to schedule the Video Call?\n\nType *1* for Next 1 Hour\nType *2* for Next 3 Hours\nType *3* for Tomorrow";
                    $replyButtons = ["Next 1 Hour", "Next 3 Hours", "Tomorrow"]; 
                    $states[$phone]['step'] = 'SCHEDULE_VC';
                } elseif ($is_catalog) {
                    // No CLI worker / Cron dependency. Check actual images before acknowledging.
                    $rangeFolder = (string)($states[$phone]['data']['range'] ?? '');
                    $catalogFiles = $this->catalogEligibleFiles($rangeFolder);
                    if (!in_array($rangeFolder, ['1000', '2000'], true)) {
                        $replyText = "First please select your selling range:\n\nType *1* for Under ₹1000\nType *2* for Under ₹2000";
                        $replyButtons = ["Under ₹1000", "Under ₹2000"];
                        $states[$phone]['step'] = 'ASK_RANGE';
                    } elseif (!empty($catalogFiles) && defined('WA_ACCESS_TOKEN') && WA_ACCESS_TOKEN &&
                        defined('WA_PHONE_NUMBER_ID') && WA_PHONE_NUMBER_ID) {
                        $catalogRangeToSend = $rangeFolder;
                        $replyText = "Sending our latest collection... Please wait a moment.";
                        // Save handover BEFORE slow image sends; don't accidentally restart the bot.
                        $states[$phone]['step'] = 'HUMAN_AGENT';
                    } else {
                        $this->botDebugLog('CATALOG_NOT_READY', $phone, 'range=' . $rangeFolder);
                        $replyText = "Catalog images are not available right now. Please select Video Call, SCPK Address, or type menu to start again.";
                        $states[$phone]['step'] = 'ASK_PREFERENCE';
                        $replyButtons = ["Video Call", "Catalog Images", "SCPK Address"];
                    }
                } else {
                    $replyText = "Please select an option:\n\nType *1* for Video Call\nType *2* to See Catalog Images\nType *3* for SCPK Address";
                    $replyButtons = ["Video Call", "Catalog Images", "SCPK Address"];
                }
                break;

            case 'SCHEDULE_VC':
                $is_1hr = ($messageText == '1' || strpos($messageText, '1 hour') !== false || strpos($messageText, 'one hour') !== false);
                $is_3hr = ($messageText == '2' || strpos($messageText, '3 hour') !== false || strpos($messageText, 'three hour') !== false);
                $is_tmrw = ($messageText == '3' || strpos($messageText, 'tomorrow') !== false || strpos($messageText, 'next day') !== false || strpos($messageText, 'kal') !== false);
                if (!$is_1hr && !$is_3hr && !$is_tmrw) {
                    // An unrelated reply is not an implicit video-call booking.
                    $replyText = "Please choose a video-call time:\n\nType *1* for Next 1 Hour\nType *2* for Next 3 Hours\nType *3* for Tomorrow";
                    $replyButtons = ["Next 1 Hour", "Next 3 Hours", "Tomorrow"];
                    break;
                }

                $timePref = "soon";
                if ($is_1hr) $timePref = "in the next 1 hour";
                elseif ($is_3hr) $timePref = "in the next 3 hours";
                elseif ($is_tmrw) $timePref = "tomorrow";

                try {
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES ((SELECT id FROM leads WHERE whatsapp_number = ? LIMIT 1), 'System Event', ?, 'Bot')")
                        ->execute([$phone, "Customer requested Video Call: " . $timePref]);
                } catch (\Exception $e) {}

                $replyText = "Your video call request has been noted. An executive from SCPK will call you shortly to confirm the exact timing. Thank you!\n\nJoin our WhatsApp Channel for new wholesale designs and collection updates:\nhttps://whatsapp.com/channel/0029Vb6yeYB7oQhgyRNpz82C";
                $states[$phone]['step'] = 'HUMAN_AGENT';
                break;
        }

        file_put_contents($stateFile, json_encode($states, JSON_PRETTY_PRINT));
        $this->botDebugLog('BOT_NEXT_STATE', $phone, 'step=' . ($states[$phone]['step'] ?? 'UNKNOWN'));

        if (!empty($replyText)) {
            // The original flow saved AFTER the HTTP request. On some hosts PHP is
            // interrupted after WhatsApp has accepted the message but before INSERT.
            // Pre-save one visible, clearly unconfirmed CRM record first.
            $crmText = "[Bot] " . $replyText;
            if (!empty($replyButtons)) {
                $crmText .= "\n🔘 [" . implode("]  🔘 [", $replyButtons) . "]";
            }

            $pendingId = uniqid('bot_pending_', true);
            $pendingText = $crmText . "\n[WhatsApp status: awaiting API confirmation]";
            $preSaved = false;
            try {
                // 'sent' is an existing schema value; the message body explicitly
                // states that Meta has NOT yet confirmed acceptance or delivery.
                $stmt = $pdo->prepare("
                    INSERT INTO wa_messages
                        (wa_message_id, conversation_id, sender_type, message_type,
                         message_body, delivery_status, is_internal)
                    VALUES (?, ?, 'agent', 'text', ?, 'sent', 0)
                ");
                $stmt->execute([$pendingId, $conversation_id, $pendingText]);
                $preSaved = true;
                $this->botDebugLog('BOT_CRM_PRESAVED', $phone);
                try {
                    $pdo->prepare("UPDATE wa_conversations SET last_message_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([$conversation_id]);
                } catch (\Throwable $e) {
                    // The outgoing row is already saved; do not create a second row.
                    $this->botDebugLog('BOT_CHAT_TIMESTAMP_UPDATE_FAILED', $phone, 'code=' . $e->getCode());
                }
            } catch (\Throwable $e) {
                $this->botDebugLog('BOT_CRM_PRESAVE_FAILED', $phone, 'code=' . $e->getCode());
                // Preserve the old behavior if the pre-save fails: still try WhatsApp,
                // then fall back to an INSERT after the API returns.
            }

            $completed = false;
            register_shutdown_function(function () use (&$completed, $phone) {
                if (!$completed) {
                    $lastError = error_get_last();
                    $type = isset($lastError['type']) ? (int)$lastError['type'] : 0;
                    $this->botDebugLog('BOT_REQUEST_INTERRUPTED', $phone, 'php_error_type=' . $type);
                }
            });

            $kind = !empty($replyButtons) ? 'buttons' : 'text';
            $this->botDebugLog('META_SEND_BEGIN', $phone, 'type=' . $kind);
            $started = microtime(true);
            $apiResponse = null;
            try {
                if (!empty($replyButtons)) {
                    $apiResponse = $this->sendMetaApiInteractiveButtons($phone, $replyText, $replyButtons);
                } else {
                    $apiResponse = $this->sendMetaApiMessage($phone, $replyText);
                }
            } catch (\Throwable $e) {
                $this->botDebugLog('META_SEND_EXCEPTION', $phone, 'type=' . get_class($e));
            }
            $elapsedMs = (int)round((microtime(true) - $started) * 1000);
            $this->botDebugLog('META_SEND_RETURNED', $phone, 'type=' . $kind . ' ms=' . $elapsedMs);

            $acceptedId = is_array($apiResponse) ? ($apiResponse['messages'][0]['id'] ?? null) : null;
            if (is_string($acceptedId) && $acceptedId !== '') {
                $this->botDebugLog('META_ACCEPTED', $phone, 'type=' . $kind);
                $finalText = $crmText;
            } else {
                $code = is_array($apiResponse) ? ($apiResponse['error']['code'] ?? 'NO_MESSAGE_ID') : 'NO_RESPONSE';
                // Do not automatically retry a timeout: Meta may already have delivered
                // the message, and resending could duplicate it for the customer.
                $definiteReject = is_array($apiResponse) && isset($apiResponse['error']['http_status'])
                    && (int)$apiResponse['error']['http_status'] >= 400;
                $marker = $definiteReject
                    ? '[WhatsApp status: API rejected; not confirmed sent]'
                    : '[WhatsApp status: unconfirmed; check WhatsApp before resending]';
                $finalText = $crmText . "\n" . $marker;
                $this->botDebugLog('META_NOT_ACCEPTED', $phone, 'code=' . (string)$code);
            }

            if ($preSaved) {
                try {
                    if (is_string($acceptedId) && $acceptedId !== '') {
                        $stmt = $pdo->prepare("
                            UPDATE wa_messages SET wa_message_id = ?, message_body = ?
                            WHERE wa_message_id = ? AND conversation_id = ?
                        ");
                        $stmt->execute([$acceptedId, $finalText, $pendingId, $conversation_id]);
                    } else {
                        $stmt = $pdo->prepare("
                            UPDATE wa_messages SET message_body = ?
                            WHERE wa_message_id = ? AND conversation_id = ?
                        ");
                        $stmt->execute([$finalText, $pendingId, $conversation_id]);
                    }
                    $this->botDebugLog('BOT_CRM_FINALIZED', $phone, 'accepted=' . (!empty($acceptedId) ? 'yes' : 'no'));
                } catch (\Throwable $e) {
                    // The pre-saved row still exists, even if finalization fails.
                    $this->botDebugLog('BOT_CRM_FINALIZE_FAILED', $phone, 'code=' . $e->getCode());
                }
            } else {
                // Backward-compatible fallback: original INSERT-after-send approach.
                $fallbackId = !empty($acceptedId) ? $acceptedId : uniqid('bot_unconfirmed_', true);
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO wa_messages
                            (wa_message_id, conversation_id, sender_type, message_type,
                             message_body, delivery_status, is_internal)
                        VALUES (?, ?, 'agent', 'text', ?, 'sent', 0)
                    ");
                    $stmt->execute([$fallbackId, $conversation_id, $finalText]);
                    $pdo->prepare("UPDATE wa_conversations SET last_message_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([$conversation_id]);
                    $this->botDebugLog('BOT_CRM_FALLBACK_SAVED', $phone);
                } catch (\Throwable $e) {
                    $this->botDebugLog('BOT_CRM_SAVE_FAILED', $phone, 'code=' . $e->getCode());
                }
            }
            // Keep the shutdown diagnostic active until catalog sending finishes.
        }

        // AFTER acknowledging the customer: send catalog directly in this webhook's
        // PHP process. No second PHP worker, external queue or Cron is required.
        if ($catalogRangeToSend !== null) {
            $summary = $this->sendCatalogImagesDirect($phone, $catalogRangeToSend, $conversation_id, $pdo);
            $hasImages = $summary['accepted'] > 0;
            $endText = $hasImages
                ? "Here are our latest designs! Please let us know which ones you liked so our executive can assist you further."
                : "We could not send the catalog images right now. Our executive will help you shortly. You may type menu to try again.";
            if ($hasImages && ($summary['failed'] > 0 || $summary['skipped'] > 0)) {
                $endText .= "\nSome images could not be confirmed. Please ask our executive if a design is missing.";
            }
            $endText .= "\n\nJoin our WhatsApp Channel for new wholesale designs and collection updates:\nhttps://whatsapp.com/channel/0029Vb6yeYB7oQhgyRNpz82C";
            // Keep a safe gap after the last image before the final text.
            if ($summary['accepted'] > 0) usleep(6100000);
            $finalResponse = $this->sendMetaApiMessage($phone, $endText);
            $finalId = is_array($finalResponse) ? ($finalResponse['messages'][0]['id'] ?? null) : null;
            if (is_string($finalId) && $finalId !== '') {
                $this->catalogStoreSent($pdo, $conversation_id, $finalId, '[Bot] ' . $endText, null, null);
            } else {
                $this->botDebugLog('CATALOG_FINAL_UNCONFIRMED', $phone);
            }
        }
        if (isset($completed)) $completed = true;
    }

    private function sendMetaApiMessage($to, $text) {
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'text',
            'text' => ['body' => $text]
        ];
        return $this->sendMetaBotRequest($to, $data, 'text');
    }

    private function sendMetaApiInteractiveButtons($to, $text, $buttons) {
        $buttonArray = [];
        foreach ($buttons as $index => $btnText) {
            $buttonArray[] = [
                'type' => 'reply',
                'reply' => [
                    'id' => 'btn_' . time() . '_' . $index,
                    'title' => substr($btnText, 0, 20)
                ]
            ];
        }

        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'interactive',
            'interactive' => [
                'type' => 'button',
                'body' => ['text' => $text],
                'action' => ['buttons' => $buttonArray]
            ]
        ];
        return $this->sendMetaBotRequest($to, $data, 'buttons');
    }
    
    private function sendMetaApiVideoMessage($to, $videoUrl, $caption = '') {
    $token = defined('WA_ACCESS_TOKEN') ? WA_ACCESS_TOKEN : '';
    $phoneId = defined('WA_PHONE_NUMBER_ID') ? WA_PHONE_NUMBER_ID : '';

    if (!$token || !$phoneId) return null;

    $url = "https://graph.facebook.com/v17.0/{$phoneId}/messages";

    $data = [
        'messaging_product' => 'whatsapp',
        'to' => $to,
        'type' => 'video',
        'video' => [
            'link' => $videoUrl
        ]
    ];

    if (!empty($caption)) {
        $data['video']['caption'] = $caption;
    }

    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\nAuthorization: Bearer {$token}\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
            'timeout' => 12
        ]
    ];

    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);

    return $result ? json_decode($result, true) : null;
}

    // Shared transport only: preserve the existing Meta API payloads above.
    // Explicit time limits prevent the bot from hanging indefinitely on a slow API.
    private function sendMetaBotRequest($to, $data, $type) {
        $token = defined('WA_ACCESS_TOKEN') ? WA_ACCESS_TOKEN : '';
        $phoneId = defined('WA_PHONE_NUMBER_ID') ? WA_PHONE_NUMBER_ID : '';
        if (!$token || !$phoneId) {
            $this->botDebugLog('META_CONFIG_MISSING', $to);
            return ['error' => ['code' => 'CONFIG_MISSING', 'http_status' => 0]];
        }

        // Keep the originally configured Graph API version unchanged.
        // Graph v17.0 retired in 2025; v24.0 remains supported in 2026.
        $url = "https://graph.facebook.com/v24.0/{$phoneId}/messages";
        $payload = json_encode($data);
        if ($payload === false) {
            return ['error' => ['code' => 'JSON_ENCODE_FAILED', 'http_status' => 0]];
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch === false) {
                return ['error' => ['code' => 'CURL_INIT_FAILED', 'http_status' => 0]];
            }
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $payload,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $token,
                    'Content-Type: application/json'
                ],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_CONNECTTIMEOUT => 4,
                CURLOPT_TIMEOUT => 12
            ]);
            $body = curl_exec($ch);
            $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $errno = (int)curl_errno($ch);
            curl_close($ch);

            if ($body === false) {
                $this->botDebugLog('META_TRANSPORT_FAILED', $to,
                    'type=' . $type . ' curl_errno=' . $errno . ' http=' . $httpCode);
                return ['error' => ['code' => 'CURL_' . $errno, 'http_status' => $httpCode]];
            }
        } else {
            // Fallback for PHP installations without cURL.
            $context = stream_context_create(['http' => [
                'header' => "Content-type: application/json\r\nAuthorization: Bearer {$token}\r\n",
                'method' => 'POST',
                'content' => $payload,
                'timeout' => 12,
                'ignore_errors' => true
            ]]);
            $body = @file_get_contents($url, false, $context);
            $httpCode = 0;
            if (isset($http_response_header[0]) &&
                preg_match('/HTTP\/\S+\s+(\d{3})/', $http_response_header[0], $matches)) {
                $httpCode = (int)$matches[1];
            }
            if ($body === false) {
                $this->botDebugLog('META_TRANSPORT_FAILED', $to, 'type=' . $type . ' http=' . $httpCode);
                return ['error' => ['code' => 'STREAM_FAILED', 'http_status' => $httpCode]];
            }
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            $this->botDebugLog('META_BAD_JSON', $to, 'type=' . $type . ' http=' . $httpCode);
            return ['error' => ['code' => 'INVALID_RESPONSE', 'http_status' => $httpCode]];
        }
        if ($httpCode > 0 && ($httpCode < 200 || $httpCode >= 300)) {
            $errorCode = $decoded['error']['code'] ?? ('HTTP_' . $httpCode);
            $this->botDebugLog('META_HTTP_FAILED', $to,
                'type=' . $type . ' http=' . $httpCode . ' code=' . $errorCode);
            if (!isset($decoded['error']) || !is_array($decoded['error'])) {
                $decoded['error'] = ['code' => $errorCode];
            }
            $decoded['error']['http_status'] = $httpCode;
        }
        return $decoded;
    }

    // Read eligible catalog files from the selected price-range folder only.
    // No worker/Cron or database schema change is required.
    private function catalogEligibleFiles($range) {
        $range = (string)$range;
        if (!in_array($range, ['1000', '2000'], true)) return [];
        $root = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');
        if ($root === '') return [];
        $dir = $root . '/uploads/bot_catalogs/' . $range . '/';
        if (!is_dir($dir) || !is_readable($dir)) return [];
        $names = @scandir($dir);
        if (!is_array($names)) return [];
        $files = [];
        foreach ($names as $name) {
            if (!preg_match('/\.(?:jpe?g|png)$/i', $name)) continue;
            if ($name !== basename($name)) continue;
            if (is_file($dir . $name) && is_readable($dir . $name)) $files[] = $name;
        }
        sort($files, SORT_NATURAL | SORT_FLAG_CASE);
        return $files;
    }

    // Restored from the previously working catalog sender: send publicly hosted
    // image.link FIRST, rather than uploading every file to Meta before sending.
    // If Meta explicitly rejects the URL, upload that image and try its media ID.
    // Do NOT re-send on an unknown/timeout response (it might already be sent).
    // Only accepted WhatsApp message IDs are stored as sent in CRM.
    private function sendCatalogImagesDirect($phone, $range, $conversationId, $pdo) {
        $files = $this->catalogEligibleFiles($range);
        $summary = ['found' => count($files), 'accepted' => 0, 'failed' => 0, 'skipped' => 0];
        $this->botDebugLog('CATALOG_SCAN', $phone, 'range=' . $range . ' found=' . $summary['found']);
        if (!$files) return $summary;

        $root = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');
        if (function_exists('set_time_limit')) { @set_time_limit(180); }
        $startTime = microtime(true);
        $slowPacing = false;

        foreach ($files as $index => $filename) {
            // Keep time for the final customer-facing confirmation message.
            if (microtime(true) - $startTime > 145) {
                $summary['skipped'] += count($files) - $index;
                $this->botDebugLog('CATALOG_TIME_BUDGET', $phone,
                    'remaining=' . (count($files) - $index));
                break;
            }
            $localFile = $root . '/uploads/bot_catalogs/' . $range . '/' . $filename;
            $size = @filesize($localFile);
            if ($size === false || $size < 1 || $size > 5 * 1024 * 1024) {
                $summary['skipped']++;
                $this->botDebugLog('CATALOG_FILE_SKIPPED', $phone, 'reason=size');
                continue;
            }

            $publicUrl = rtrim(BASE_URL, '/') . '/uploads/bot_catalogs/' . $range . '/' . rawurlencode($filename);
            $mime = strtolower(pathinfo($filename, PATHINFO_EXTENSION)) === 'png' ? 'image/png' : 'image/jpeg';

            // The old working sender used this public image URL directly.
            $payload = [
                'messaging_product' => 'whatsapp',
                'to' => $phone,
                'type' => 'image',
                'image' => ['link' => $publicUrl]
            ];
            $this->botDebugLog('CATALOG_LINK_BEGIN', $phone, 'range=' . $range);
            $res = $this->sendMetaBotRequest($phone, $payload, 'image');
            $acceptedId = is_array($res) ? ($res['messages'][0]['id'] ?? null) : null;
            $code = is_array($res) ? (string)($res['error']['code'] ?? 'NO_MESSAGE_ID') : 'NO_RESPONSE';
            $status = is_array($res) ? (int)($res['error']['http_status'] ?? 0) : 0;

            // Rate-limit is a definite rejection; once observed, pace subsequent
            // images to avoid repeatedly hitting the same Meta recipient limit.
            if ((!is_string($acceptedId) || $acceptedId === '') &&
                $status >= 400 && in_array($code, ['131056', '130429'], true)) {
                $slowPacing = true;
                $this->botDebugLog('CATALOG_RATE_WAIT', $phone, 'code=' . $code);
                sleep(7);
                $res = $this->sendMetaBotRequest($phone, $payload, 'image');
                $acceptedId = is_array($res) ? ($res['messages'][0]['id'] ?? null) : null;
                $code = is_array($res) ? (string)($res['error']['code'] ?? 'NO_MESSAGE_ID') : 'NO_RESPONSE';
                $status = is_array($res) ? (int)($res['error']['http_status'] ?? 0) : 0;
            }

            // Upload fallback is safe ONLY after a definite non-rate-limit HTTP
            // rejection. On a timeout/ambiguous response do not send twice.
            if ((!is_string($acceptedId) || $acceptedId === '') && $status >= 400 &&
                !in_array($code, ['131056', '130429', '190'], true)) {
                $this->botDebugLog('CATALOG_LINK_REJECTED', $phone, 'code=' . $code);
                $mediaId = $this->catalogUploadMedia($localFile, $mime, $phone);
                if ($mediaId) {
                    $this->botDebugLog('CATALOG_MEDIA_FALLBACK', $phone);
                    $payload['image'] = ['id' => $mediaId];
                    $res = $this->sendMetaBotRequest($phone, $payload, 'image');
                    $acceptedId = is_array($res) ? ($res['messages'][0]['id'] ?? null) : null;
                    $code = is_array($res) ? (string)($res['error']['code'] ?? 'NO_MESSAGE_ID') : 'NO_RESPONSE';
                    $status = is_array($res) ? (int)($res['error']['http_status'] ?? 0) : 0;
                }
            }

            if (is_string($acceptedId) && $acceptedId !== '') {
                $summary['accepted']++;
                $this->catalogStoreSent($pdo, $conversationId, $acceptedId,
                    '[Bot] Catalog Image', $publicUrl, $mime);
                $this->botDebugLog('CATALOG_IMAGE_ACCEPTED', $phone);
            } else {
                $summary['failed']++;
                $this->botDebugLog('META_IMAGE_NOT_ACCEPTED', $phone,
                    'code=' . $code . ' http=' . $status);
            }

            // Previous working code used 300 ms, not 6.1 seconds BEFORE every
            // image. If recipient rate-limiting occurs, slow down adaptively.
            if ($index < count($files) - 1) {
                usleep($slowPacing ? 6100000 : 300000);
            }
        }

        $this->botDebugLog('CATALOG_DONE', $phone,
            'range=' . $range . ' found=' . $summary['found'] .
            ' accepted=' . $summary['accepted'] . ' failed=' . $summary['failed'] .
            ' skipped=' . $summary['skipped']);
        return $summary;
    }

    private function catalogUploadMedia($localFile, $mime, $phone) {
        if (!function_exists('curl_init') || !class_exists('CURLFile') ||
            !defined('WA_ACCESS_TOKEN') || !WA_ACCESS_TOKEN ||
            !defined('WA_PHONE_NUMBER_ID') || !WA_PHONE_NUMBER_ID) return null;
        $url = 'https://graph.facebook.com/v24.0/' . WA_PHONE_NUMBER_ID . '/media';
        $ch = curl_init($url);
        if (!$ch) return null;
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => [
                'messaging_product' => 'whatsapp',
                'type' => $mime,
                'file' => new \CURLFile($localFile, $mime, basename($localFile))
            ],
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . WA_ACCESS_TOKEN],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => 18
        ]);
        $raw = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $data = $raw !== false ? json_decode($raw, true) : null;
        if ($httpCode >= 200 && $httpCode < 300 &&
            is_array($data) && isset($data['id']) && is_string($data['id'])) {
            return $data['id'];
        }
        $code = is_array($data) ? ($data['error']['code'] ?? 'UPLOAD_HTTP_' . $httpCode)
            : 'UPLOAD_TRANSPORT_FAILED';
        $this->botDebugLog('CATALOG_UPLOAD_FAILED', $phone,
            'http=' . $httpCode . ' code=' . (string)$code);
        return null;
    }

    private function catalogStoreSent($pdo, $conversationId, $messageId, $text, $url, $mime) {
        try {
            $stmt = $pdo->prepare("INSERT INTO wa_messages
                (wa_message_id, conversation_id, sender_type, message_type,
                 message_body, media_url, mime_type, delivery_status, is_internal)
                 VALUES (?, ?, 'agent', ?, ?, ?, ?, 'sent', 0)");
            $stmt->execute([$messageId, $conversationId, $url ? 'image' : 'text', $text, $url, $mime]);
            $pdo->prepare('UPDATE wa_conversations SET last_message_at = CURRENT_TIMESTAMP WHERE id = ?')
                ->execute([$conversationId]);
        } catch (\Throwable $e) {
            // Meta may already have delivered it. Do not send again after DB error.
            $this->botDebugLog('BOT_CRM_IMAGE_SAVE_FAILED', '', 'code=' . $e->getCode());
        }
    }

    // LOGGING ONLY: this method does not modify bot states, leads, or sending logic.
    private function botDebugLog($event, $phone = '', $details = '') {
        try {
            // Web root: .../public_html; log folder: .../crm_private_logs
            $logDir = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'crm_private_logs';
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0700, true);
            }
            if (!is_dir($logDir) || !is_writable($logDir)) {
                return;
            }

            // Never record a full phone number, WhatsApp content, or API token.
            $digits = preg_replace('/\D+/', '', (string)$phone);
            $masked = $digits === '' ? 'system' : '***' . substr($digits, -4);
            $safeEvent = preg_replace('/[^A-Z0-9_]/i', '_', (string)$event);
            $safeDetails = str_replace(["\r", "\n"], ' ', (string)$details);
            // Keep Meta's numeric 6/7-digit error codes, but redact 8+ digit
            // numbers and other potentially identifying long numbers.
            $safeDetails = preg_replace('/\b\d{8,}\b|(?<!code=)\b\d{6,}\b/', '[redacted]', $safeDetails);
            $safeDetails = substr($safeDetails, 0, 240);

            $line = date('Y-m-d H:i:s') . ' | ' . $masked . ' | ' . $safeEvent
                  . ($safeDetails !== '' ? ' | ' . $safeDetails : '') . PHP_EOL;
            @file_put_contents($logDir . DIRECTORY_SEPARATOR . 'bot_debug.log', $line, FILE_APPEND | LOCK_EX);
        } catch (\Throwable $e) {
            // A logging failure must never affect CRM message processing.
        }
    }
}
?>