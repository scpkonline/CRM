<?php 
namespace Controllers; 
use Core\Controller; 
use Core\Database;

class TasksController extends Controller {          
    
    public function index() {         
        if (!isset($_SESSION['user_id'])) {             
            header('Location: ' . BASE_URL . 'auth');             
            exit;         
        }         

        $pdo = Database::getInstance();
        // Stage 7: read company timezone; do not change UTC DB storage.
        $crmTimezone = \Core\Timezone::get($pdo, (int)($_SESSION['company_id'] ?? 1));
        $company_id = $_SESSION['company_id'] ?? 1;
        $user_id = $_SESSION['user_id'];
        $role = isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES';

        $queryString = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
        if ($queryString) {
            parse_str($queryString, $customGet);
            $_GET = array_merge($_GET, $customGet);
        }

        // --- 🔥 SERVER-SIDE SMART SEARCH & FILTERS LOGIC 🔥 ---
        $where_clauses = ["l.company_id = :company_id"];
        $params = [':company_id' => $company_id];

        if ($role !== 'ADMIN') {
            $where_clauses[] = "(l.assigned_to IS NULL OR l.assigned_to = 0 OR l.assigned_to = :user_id)";
            $params[':user_id'] = $user_id;
        }

        if (!empty($_GET['search']) && trim($_GET['search']) !== '') {
            $searchTerm = trim($_GET['search']);
            
            $searchClause = "(
                l.full_name LIKE :search1 
                OR l.company_name LIKE :search2 
                OR l.email LIKE :search3 
                OR l.city LIKE :search4 
                OR l.phone_number LIKE :search5 
                OR l.whatsapp_number LIKE :search6 
                OR l.tags LIKE :search7
                OR l.products_of_interest LIKE :search8";
            
            $params[':search1'] = '%' . $searchTerm . '%';
            $params[':search2'] = '%' . $searchTerm . '%';
            $params[':search3'] = '%' . $searchTerm . '%';
            $params[':search4'] = '%' . $searchTerm . '%';
            $params[':search5'] = '%' . $searchTerm . '%';
            $params[':search6'] = '%' . $searchTerm . '%';
            $params[':search7'] = '%' . $searchTerm . '%';
            $params[':search8'] = '%' . $searchTerm . '%';

            if (preg_match('/^[0-9\+\-\s]+$/', $searchTerm)) {
                $cleanNum = preg_replace('/[^0-9]/', '', $searchTerm);
                if (strlen($cleanNum) > 10 && substr($cleanNum, 0, 2) == '91') {
                    $cleanNum = substr($cleanNum, 2);
                }
                
                if(!empty($cleanNum)) {
                    $searchClause .= " OR l.phone_number LIKE :cleanNum1 OR l.whatsapp_number LIKE :cleanNum2";
                    $params[':cleanNum1'] = '%' . $cleanNum . '%';
                    $params[':cleanNum2'] = '%' . $cleanNum . '%';
                }
            }
            
            $searchId = 0;
            if (preg_match('/^#?LD-([0-9]+)$/i', $searchTerm, $matches)) {
                $searchId = (int)$matches[1];
            } elseif (preg_match('/^[0-9]+$/', $searchTerm)) {
                $searchId = (int)$searchTerm;
            }

            if ($searchId > 0) {
                $searchClause .= " OR l.id = :searchId";
                $params[':searchId'] = $searchId;
            }
            
            $searchClause .= ")";
            $where_clauses[] = $searchClause;
        }

        if (!empty($_GET['source'])) {
            $where_clauses[] = "l.lead_source = :source";
            $params[':source'] = $_GET['source'];
        }

        if (!empty($_GET['temp'])) {
            $where_clauses[] = "l.temperature = :temp";
            $params[':temp'] = $_GET['temp'];
        }

        if (!empty($_GET['agent'])) {
            $where_clauses[] = "l.assigned_to = :agent_id";
            $params[':agent_id'] = $_GET['agent'];
        }

        if (!empty($_GET['tag'])) {
            $where_clauses[] = "l.tags LIKE :tag_param";
            $params[':tag_param'] = '%' . trim($_GET['tag']) . '%';
        }

        if (!empty($_GET['start_date'])) {
            $where_clauses[] = "l.created_at >= :start_date";
            $params[':start_date'] = \Core\Timezone::toUtc($_GET['start_date'] . ' 00:00:00', $crmTimezone);
        }

        if (!empty($_GET['end_date'])) {
            $where_clauses[] = "l.created_at < :end_date";
            $params[':end_date'] = \Core\Timezone::toUtc((new \DateTimeImmutable($_GET['end_date'], new \DateTimeZone($crmTimezone)))->modify('+1 day')->format('Y-m-d 00:00:00'), $crmTimezone);
        }

        $where_sql = implode(' AND ', $where_clauses);
        if (empty($where_sql)) $where_sql = "1=1";

        $is_unqualified_view = (!empty($_GET['status']) && $_GET['status'] === 'unqualified');

        // --- 🔥 ACCURATE TOTAL COUNTS FOR BADGES 🔥 ---
        $stageCounts = ['Catalog Sharing' => 0, 'Follow Up' => 0, 'Negotiation' => 0, 'Sold' => 0];
        
        try {
            $countGroupStmt = $pdo->prepare("SELECT lead_stage, COUNT(id) as c FROM leads l WHERE $where_sql GROUP BY lead_stage");
            $countGroupStmt->execute($params);
            $groupedCounts = $countGroupStmt->fetchAll(\PDO::FETCH_ASSOC);
            
            foreach($groupedCounts as $g) {
                $stage = trim($g['lead_stage'] ?? 'new');
                $c = (int)$g['c'];
                $is_unq_stage = (stripos($stage, 'unqualified') !== false);
                
                if ($is_unqualified_view) {
                    if ($stage === 'Unqualified-Catalog Sharing' || $stage === 'Unqualified') $stageCounts['Catalog Sharing'] += $c;
                    elseif ($stage === 'Unqualified-Follow Up') $stageCounts['Follow Up'] += $c;
                    elseif ($stage === 'Unqualified-Negotiation') $stageCounts['Negotiation'] += $c;
                    elseif ($stage === 'Unqualified-Sold') $stageCounts['Sold'] += $c;
                    elseif ($is_unq_stage) $stageCounts['Catalog Sharing'] += $c; 
                } else {
                    if ($is_unq_stage) continue;
                    
                    if ($stage === 'Qualified' || $stage === 'Catalog Sharing' || empty($stage) || $stage === 'new' || $stage === 'New') {
                        $stageCounts['Catalog Sharing'] += $c;
                    } elseif ($stage === 'Follow Up') {
                        $stageCounts['Follow Up'] += $c;
                    } elseif ($stage === 'Negotiation') {
                        $stageCounts['Negotiation'] += $c;
                    } elseif ($stage === 'Sold') {
                        $stageCounts['Sold'] += $c;
                    } else {
                        $stageCounts['Catalog Sharing'] += $c;
                    }
                }
            }
        } catch (\Exception $e) {}

        $stageCountsMap = [
            'cat' => $stageCounts['Catalog Sharing'],
            'fol' => $stageCounts['Follow Up'],
            'neg' => $stageCounts['Negotiation'],
            'sol' => $stageCounts['Sold']
        ];

        // --- 🔥 PER-COLUMN PAGINATION LOGIC 🔥 ---
        $limit = 30; // Load 30 cards per column page
        $pages = [
            'cat' => max(1, (int)($_GET['p_cat'] ?? 1)),
            'fol' => max(1, (int)($_GET['p_fol'] ?? 1)),
            'neg' => max(1, (int)($_GET['p_neg'] ?? 1)),
            'sol' => max(1, (int)($_GET['p_sol'] ?? 1))
        ];

        $columnsData = [
            'cat' => ['stage_sql' => "(l.lead_stage IN ('Qualified', 'Catalog Sharing', 'new', 'New') OR l.lead_stage IS NULL OR l.lead_stage = '')", 'unq_sql' => "l.lead_stage IN ('Unqualified-Catalog Sharing', 'Unqualified')"],
            'fol' => ['stage_sql' => "l.lead_stage = 'Follow Up'", 'unq_sql' => "l.lead_stage = 'Unqualified-Follow Up'"],
            'neg' => ['stage_sql' => "l.lead_stage = 'Negotiation'", 'unq_sql' => "l.lead_stage = 'Unqualified-Negotiation'"],
            'sol' => ['stage_sql' => "l.lead_stage = 'Sold'", 'unq_sql' => "l.lead_stage = 'Unqualified-Sold'"]
        ];

        $col_leads = ['cat' => [], 'fol' => [], 'neg' => [], 'sol' => []];
        $col_pages = ['cat' => 1, 'fol' => 1, 'neg' => 1, 'sol' => 1];

        foreach ($columnsData as $key => $sqlData) {
            $stage_cond = $is_unqualified_view ? $sqlData['unq_sql'] : $sqlData['stage_sql'];
            $full_where = $where_sql . " AND " . $stage_cond;
            $offset = ($pages[$key] - 1) * $limit;
            
            try {
                $stmt = $pdo->prepare("
                    SELECT l.*, 
                           (SELECT note_text FROM lead_notes ln WHERE ln.lead_id = l.id AND ln.note_type = 'Note' ORDER BY ln.created_at DESC LIMIT 1) as latest_note
                    FROM leads l 
                    WHERE $full_where 
                    ORDER BY l.updated_at DESC 
                    LIMIT $limit OFFSET $offset
                ");
                $stmt->execute($params);
                $col_leads[$key] = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            } catch (\Exception $e) {
                $col_leads[$key] = [];
            }

            $cCount = $stageCountsMap[$key] ?? 0;
            $col_pages[$key] = max(1, ceil($cCount / $limit));
        }

        $agents = [];
        try {
            $stmtAgents = $pdo->query("SELECT id, name FROM users ORDER BY name ASC");
            $agents = $stmtAgents->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            try {
                $stmtAgents = $pdo->query("SELECT id, full_name as name FROM users ORDER BY full_name ASC");
                $agents = $stmtAgents->fetchAll(\PDO::FETCH_ASSOC);
            } catch (\Exception $e2) {}
        }

        $tags = [];
        try {
            $tagsStmt = $pdo->query("SELECT name FROM crm_tags ORDER BY name ASC");
            $tags = $tagsStmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {}
        
        $data = [             
            'title' => 'Tasks & Follow-ups - SCPK CRM',             
            'user_name' => $_SESSION['name'] ?? 'User',             
            'user_role' => $role,
            'col_leads' => $col_leads,
            'col_pages' => $col_pages,
            'current_pages' => $pages,
            'agents' => $agents,
            'tags' => $tags,
            'stageCounts' => $stageCounts,
            'filters' => $_GET
        ];                 
        
        $this->view('tasks', $data);     
    } 

    public function update_stage() {
        if (!isset($_SESSION['user_id'])) exit;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            
            $lead_id = $input['lead_id'] ?? null;
            $stage = $input['stage'] ?? null;
            $sale_amount = $input['sale_amount'] ?? null;
            $sale_date = $input['sale_date'] ?? null;
            
            if ($lead_id && $stage) {
                try {
                    $pdo = Database::getInstance();
                    
                    if ($stage === 'Sold' && $sale_amount !== null && $sale_date !== null) {
                        $pdo->prepare("UPDATE leads SET lead_stage = ?, sale_amount = ?, sale_date = ? WHERE id = ?")
                            ->execute([$stage, $sale_amount, $sale_date, $lead_id]);
                        
                        $note_text = "Lead Sold for ₹" . number_format((float)$sale_amount, 2) . " on " . date('d M Y', strtotime($sale_date));
                        try {
                            $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'System', ?, ?)")
                                ->execute([$lead_id, $note_text, $_SESSION['name']]);
                        } catch (\Exception $e) {}
                    } else {
                        $pdo->prepare("UPDATE leads SET lead_stage = ? WHERE id = ?")->execute([$stage, $lead_id]);
                        try {
                            $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Pipeline', ?, ?)")
                                ->execute([$lead_id, "Moved to Pipeline Stage: " . $stage, $_SESSION['name']]);
                        } catch (\Exception $e) {}
                    }
                    echo json_encode(['status' => 'success']);
                } catch (\Exception $e) {
                    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
                }
            } else {
                echo json_encode(['status' => 'error']);
            }
            exit;
        }
    }
    
    public function update_temperature() {
        if (!isset($_SESSION['user_id'])) exit;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            
            $lead_id = $input['lead_id'] ?? null;
            $temperature = $input['temperature'] ?? '';

            if ($lead_id) {
                $pdo = \Core\Database::getInstance();
                $pdo->prepare("UPDATE leads SET temperature = ? WHERE id = ?")->execute([$temperature, $lead_id]);
                
                $tempText = empty($temperature) ? "Temperature cleared" : "Temperature set to: " . ucfirst($temperature);
                try {
                    $pdo->prepare("INSERT INTO lead_notes (lead_id, note_type, note_text, created_by) VALUES (?, 'Status', ?, ?)")
                        ->execute([$lead_id, $tempText, $_SESSION['name']]);
                } catch (\Exception $e) {}

                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Lead ID missing']);
            }
            exit;
        }
    }
} 
?>