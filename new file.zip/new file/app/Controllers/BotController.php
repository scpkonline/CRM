<?php 
namespace Controllers; 
use Core\Controller; 

class BotController extends Controller {

    // Webhook Receiver Function
    public function whatsapp() {
        
        // 1. META WEBHOOK VERIFICATION (Pehli baar connect karne ke liye)
        if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['hub_challenge'])) {
            echo $_GET['hub_challenge'];
            exit;
        }

        // 2. WHATSAPP SE AANE WALA MESSAGE READ KAREIN
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            http_response_code(200);
            exit;
        }

        $message = '';
        $phone = '';

        // Extract message and sender's phone number
        if (isset($input['entry'][0]['changes'][0]['value']['messages'][0])) {
            $msgObj = $input['entry'][0]['changes'][0]['value']['messages'][0];
            $phone = $msgObj['from']; // Customer ka WhatsApp number
            
            if (isset($msgObj['text']['body'])) {
                $message = strtolower(trim($msgObj['text']['body']));
            }
        }

        // Agar koi valid text message nahi hai, toh yahin rok do
        if (!$phone || !$message) {
            http_response_code(200);
            exit;
        }

        // 3. NO-DATABASE LOGIC (JSON File ka use karenge memory ke liye)
        // Note: Make sure is folder mein file read/write permission ho
        $stateFile = __DIR__ . '/bot_states.json'; 
        $states = file_exists($stateFile) ? json_decode(file_get_contents($stateFile), true) : [];

        // Agar naya customer hai, toh usko START step par rakhein
        if (!isset($states[$phone])) {
            $states[$phone] = ['step' => 'START', 'data' => []];
        }

        $currentStep = $states[$phone]['step'];
        $replyText = "";

        // 4. HARDCODED BOT FLOW (The Logic Engine)
        switch ($currentStep) {
            case 'START':
                $replyText = "Welcome to SCPK Online! To serve you better, please reply with your Full Name.";
                $states[$phone]['step'] = 'ASK_LOCATION';
                break;
                
            case 'ASK_LOCATION':
                $states[$phone]['data']['name'] = $message;
                $replyText = "Thank you, " . ucwords($message) . "! Where are you located? (e.g., Delhi, India)";
                $states[$phone]['step'] = 'ASK_INTEREST';
                break;
                
            case 'ASK_INTEREST':
                $states[$phone]['data']['location'] = $message;
                $replyText = "Great! What kind of products are you looking for today?\n\nType '1' for Retail Kurti Sets\nType '2' for Wholesale Bulk Orders\nType '3' to Talk to an Agent";
                $states[$phone]['step'] = 'PROCESS_INTEREST';
                break;
                
            case 'PROCESS_INTEREST':
                if ($message == '1') {
                    $replyText = "Here is our latest retail collection: https://www.scpkonline.com/retail\nLet us know if you need help finding a specific size!";
                    $states[$phone]['step'] = 'START'; // Flow khatam, restart ke liye set kar diya
                } elseif ($message == '2') {
                    $replyText = "For wholesale pricing, please share your Shop/Company Name.";
                    $states[$phone]['step'] = 'ASK_COMPANY';
                } elseif ($message == '3') {
                    $replyText = "Transferring you to a live agent. Please hold on. We will reply shortly.";
                    $states[$phone]['step'] = 'HUMAN_AGENT';
                } else {
                    $replyText = "Invalid option. Please type '1', '2', or '3'.";
                }
                break;
                
            case 'ASK_COMPANY':
                $states[$phone]['data']['company'] = $message;
                $replyText = "Thanks! Our B2B executive will contact you shortly regarding bulk pricing.";
                $states[$phone]['step'] = 'START'; // Reset
                break;
                
            case 'HUMAN_AGENT':
                // Bot yahan chup rahega aur koi auto-reply nahi karega, agent handle karega
                http_response_code(200);
                exit;
        }

        // Customer ki aage ki history JSON file mein save kar dein
        file_put_contents($stateFile, json_encode($states, JSON_PRETTY_PRINT));

        // 5. REPLY SEND KARNA WHATSAPP PAR
        if (!empty($replyText)) {
            $this->sendWhatsAppMessage($phone, $replyText);
        }

        // WhatsApp Meta API ko 200 OK bhejna zaroori hai, warna error aayega
        http_response_code(200);
        exit;
    }

    // Yeh function Meta ki API ko hit karke message send karta hai
    private function sendWhatsAppMessage($to, $text) {
        // Yeh Constants aapki config.php (ya SettingsController ki Integration tab) se aayenge
        $token = defined('WA_ACCESS_TOKEN') ? WA_ACCESS_TOKEN : '';
        $phoneId = defined('WA_PHONE_NUMBER_ID') ? WA_PHONE_NUMBER_ID : '';
        
        if (!$token || !$phoneId) return;

        $url = "https://graph.facebook.com/v17.0/{$phoneId}/messages";
        
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'text',
            'text' => ['body' => $text]
        ];

        $options = [
            'http' => [
                'header'  => "Content-type: application/json\r\nAuthorization: Bearer {$token}\r\n",
                'method'  => 'POST',
                'content' => json_encode($data)
            ]
        ];
        
        $context  = stream_context_create($options);
        @file_get_contents($url, false, $context);
    }
}
?>