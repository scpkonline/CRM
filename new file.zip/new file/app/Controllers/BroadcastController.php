<?php
namespace Controllers;
use Core\Controller;
use Core\Database;

/**
 * SCPK opt-in WhatsApp marketing broadcasts.
 * Deliberately separate from WebhookController and InboxController's chat rules.
 * Batches are explicitly started by an admin, with no background Cron.
 */
class BroadcastController extends Controller {
    private function authorize(): int {
        if (empty($_SESSION['user_id']) || (int)($_SESSION['company_id'] ?? 0) < 1) {
            $this->fail('Login required', 403);
        }
        $role = strtolower(trim((string)($_SESSION['role'] ?? '')));
        if (!in_array($role, ['admin', 'super_admin', 'superadmin', 'administrator', 'owner'], true)) {
            $this->fail('Broadcasts require a CRM administrator account', 403);
        }
        return (int)$_SESSION['company_id'];
    }
    private function fail(string $message, int $http = 400): void {
        http_response_code($http);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status'=>'error','message'=>$message]);
        exit;
    }
    private function json(): array {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: private, no-store');
        return [];
    }
    private function post(): array {
        $this->json();
        $expected = (string)($_SESSION['scpk_action_csrf'] ?? '');
        $provided = (string)($_SERVER['HTTP_X_SCPK_CSRF'] ?? '');
        if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
            $this->fail('Session action token missing; reload the CRM page', 403);
        }
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $this->fail('POST required', 405);
        $site = $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? '';
        if ($site) {
            $expected = parse_url(BASE_URL, PHP_URL_HOST);
            if (!$expected || strcasecmp((string)parse_url($site, PHP_URL_HOST), (string)$expected) !== 0) {
                $this->fail('Origin check failed', 403);
            }
        }
        $data = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($data)) $this->fail('Invalid JSON body');
        return $data;
    }
    private function db(): \PDO {
        try { return Database::getInstance(); }
        catch (\Throwable $e) { $this->fail('Database unavailable', 503); }
    }
    private function schemaNeeded(\Throwable $e): void {
        error_log('SCPK broadcast SQL error code: ' . $e->getCode());
        $this->fail('Broadcast tables unavailable. Install BROADCAST_SCHEMA.sql before using this tab.', 503);
    }
    private function number(string $text): string {
        return preg_replace('/\D+/', '', $text);
    }
    private function templates(): array {
        $waba = defined('WA_WABA_ID') ? (string)WA_WABA_ID : '';
        $token = defined('WA_ACCESS_TOKEN') ? (string)WA_ACCESS_TOKEN : '';
        if (!ctype_digit($waba) || !$token || !function_exists('curl_init')) $this->fail('Meta templates configuration missing', 503);
        $url = 'https://graph.facebook.com/v24.0/' . $waba . '/message_templates?fields=name,language,status,category,components,parameter_format&limit=100';
        $found = [];
        for ($page=0;$page<5;$page++) {
            $ch=curl_init($url);
            curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_SSL_VERIFYPEER=>true,
                CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>18,
                CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token]]);
            $body=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
            $data=is_string($body)?json_decode($body,true):null;
            if ($http!==200 || !is_array($data)) $this->fail('Could not verify approved Meta templates', 503);
            foreach (($data['data']??[]) as $t) $found[]=$t;
            $next=$data['paging']['next']??'';
            if (!$next || !preg_match('~^https://graph\.facebook\.com/v24\.0/~', (string)$next)) break;
            $url=$next;
        }
        return $found;
    }
    private function template(string $name,string $lang): array {
        if (!preg_match('/^[a-z0-9_]{1,512}$/',$name) || !preg_match('/^[a-zA-Z_]{2,16}$/',$lang)) $this->fail('Invalid template name/language');
        foreach ($this->templates() as $t) {
            if (($t['name']??'')!==$name || ($t['language']??'')!==$lang) continue;
            if (($t['status']??'')!=='APPROVED' || strtoupper((string)($t['category']??''))!=='MARKETING') {
                $this->fail('Broadcast requires an approved MARKETING template. Utility templates are not for promotional campaigns.');
            }
            // Initial safe broadcast engine supports static body, static buttons and one IMAGE/VIDEO header.
            $header='';
            foreach (($t['components']??[]) as $c) {
                $type=strtoupper((string)($c['type']??''));
                if ($type==='HEADER') {
                    $format=strtoupper((string)($c['format']??''));
                    if (!in_array($format,['TEXT','IMAGE','VIDEO'],true) ||
                        ($format==='TEXT' && preg_match('/\{\{/',(string)($c['text']??'')))) {
                        $this->fail('Broadcast does not support this dynamic/advanced template header yet. Send individually from WA Templates.');
                    }
                    if ($format==='IMAGE'||$format==='VIDEO') $header=strtolower($format);
                } elseif ($type==='BODY') {
                    if (preg_match('/\{\{/',(string)($c['text']??''))) $this->fail('Bulk sending of templates with dynamic body variables is disabled.');
                } elseif ($type==='BUTTONS') {
                    foreach (($c['buttons']??[]) as $b) {
                        $bt=strtoupper((string)($b['type']??''));
                        if (!in_array($bt,['URL','PHONE_NUMBER','QUICK_REPLY'],true) ||
                            ($bt==='URL' && preg_match('/\{\{/',(string)($b['url']??'')))) {
                            $this->fail('Bulk sending with dynamic/advanced buttons is disabled.');
                        }
                    }
                } elseif ($type!=='FOOTER') $this->fail('Advanced templates cannot be bulk sent from this version.');
            }
            $t['_header_media_kind']=$header;
            return $t;
        }
        $this->fail('Template not found in configured WABA');
    }
    private function media(int $company,string $id): ?array {
        if (!preg_match('/^[a-f0-9]{32}$/',$id)) return null;
        $dir=dirname(__DIR__,3).'/crm_private_template_media/company_'.$company;
        $meta=json_decode((string)@file_get_contents($dir.'/'.$id.'.json'),true);
        if (!is_array($meta)||($meta['id']??'')!==$id) return null;
        $mime=(string)($meta['mime']??'');
        if (!in_array($mime,['image/jpeg','image/png','video/mp4'],true)) return null;
        $ext=['image/jpeg'=>'jpg','image/png'=>'png','video/mp4'=>'mp4'][$mime];
        $path=$dir.'/'.$id.'.'.$ext;
        return is_file($path)&&is_readable($path)?['path'=>$path,'mime'=>$mime]:null;
    }
    private function uploadMeta(int $company,string $id,string $kind): string {
        $item=$this->media($company,$id);
        if (!$item || ($kind==='image' && strpos($item['mime'],'image/')!==0) ||
            ($kind==='video' && $item['mime']!=='video/mp4')) $this->fail('Selected campaign media missing or wrong type');
        $phone=defined('WA_PHONE_NUMBER_ID')?(string)WA_PHONE_NUMBER_ID:'';
        $token=defined('WA_ACCESS_TOKEN')?(string)WA_ACCESS_TOKEN:'';
        if (!ctype_digit($phone)||!$token||!function_exists('curl_init')||!class_exists('CURLFile')) $this->fail('Meta media upload unavailable');
        $ch=curl_init('https://graph.facebook.com/v24.0/'.$phone.'/media');
        curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>['messaging_product'=>'whatsapp',
            'type'=>$item['mime'],'file'=>new \CURLFile($item['path'],$item['mime'],basename($item['path']))],
            CURLOPT_RETURNTRANSFER=>true,CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>40,
            CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token]]);
        $body=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
        $meta=is_string($body)?json_decode($body,true):null;
        $id=is_array($meta)?(string)($meta['id']??''):'';
        if ($http<200||$http>=300||!preg_match('/^[0-9]{5,64}$/',$id)) $this->fail('Meta could not accept campaign media (HTTP '.$http.'). No messages sent.');
        return $id;
    }
    private function leadByNumber(\PDO $pdo,int $company,string $phone): ?array {
        $phone=$this->number($phone);
        if (strlen($phone)<10||strlen($phone)>15) return null;
        $local=substr($phone,-10);
        $variants=array_values(array_unique([$phone,$local,'+'.$phone]));
        $marks=implode(',',array_fill(0,count($variants),'?'));
        $sql="SELECT l.id AS lead_id,l.full_name,l.whatsapp_number,l.phone_number,c.id AS conversation_id
              FROM leads l JOIN wa_conversations c ON c.lead_id=l.id AND c.company_id=l.company_id
              WHERE l.company_id=? AND (l.whatsapp_number IN ($marks) OR l.phone_number IN ($marks))
              ORDER BY l.id DESC LIMIT 2";
        $stmt=$pdo->prepare($sql);$stmt->execute(array_merge([$company],$variants,$variants));
        $rows=$stmt->fetchAll(\PDO::FETCH_ASSOC);
        return count($rows)===1?$rows[0]:null;
    }
    private function optInIsValid(\PDO $pdo,int $company,int $leadId): bool {
        $stmt=$pdo->prepare('SELECT opted_in_at, opted_out_at FROM scpk_wa_marketing_optins WHERE company_id=? AND lead_id=?');
        $stmt->execute([$company,$leadId]);$opt=$stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$opt||empty($opt['opted_in_at'])||!empty($opt['opted_out_at'])) return false;
        // Any explicit STOP after opt-in blocks sending, not just the last 40 messages.
        $q=$pdo->prepare("SELECT 1 FROM wa_messages m
            JOIN wa_conversations c ON c.id=m.conversation_id
            WHERE c.lead_id=? AND c.company_id=? AND m.sender_type='lead'
              AND m.message_type='text' AND m.created_at>=?
              AND LOWER(TRIM(m.message_body)) IN
                ('stop','unsubscribe','opt out','stop marketing','band karo')
            LIMIT 1");
        $q->execute([$leadId,$company,$opt['opted_in_at']]);
        if ($q->fetchColumn()) return false;
        return true;
    }
    public function index() { header('Location: '.rtrim(BASE_URL,'/').'/inbox/broadcasts'); exit; }
    public function record_optin() {
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        $phone=$this->number((string)($data['phone']??''));
        $source=(string)($data['source']??'');$evidence=trim((string)($data['evidence']??''));
        if (!in_array($source,['website_form','whatsapp_chat','signed_form','other'],true) || strlen($evidence)<8 || strlen($evidence)>500) {
            $this->fail('Document a real opt-in source and evidence/reference (8–500 characters).');
        }
        $lead=$this->leadByNumber($pdo,$company,$phone);
        if (!$lead) $this->fail('Exactly one matching existing CRM chat is required');
        try {
            $stmt=$pdo->prepare('INSERT INTO scpk_wa_marketing_optins
                (company_id,lead_id,consent_source,consent_reference,opted_in_at,opted_out_at,recorded_by)
                VALUES (?,?,?,?,UTC_TIMESTAMP(),NULL,?)
                ON DUPLICATE KEY UPDATE consent_source=VALUES(consent_source),consent_reference=VALUES(consent_reference),
                opted_in_at=UTC_TIMESTAMP(),opted_out_at=NULL,recorded_by=VALUES(recorded_by)');
            $stmt->execute([$company,$lead['lead_id'],$source,$evidence,(int)$_SESSION['user_id']]);
            $this->json();echo json_encode(['status'=>'success','lead_name'=>$lead['full_name']]);
        }catch(\Throwable $e){$this->schemaNeeded($e);}
    }
    public function revoke_optin() {
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        $lead=$this->leadByNumber($pdo,$company,(string)($data['phone']??''));
        if (!$lead) $this->fail('Existing CRM chat not uniquely found');
        try {
            $stmt=$pdo->prepare('UPDATE scpk_wa_marketing_optins SET opted_out_at=UTC_TIMESTAMP() WHERE company_id=? AND lead_id=?');
            $stmt->execute([$company,$lead['lead_id']]);
            $this->json();echo json_encode(['status'=>'success']);
        }catch(\Throwable $e){$this->schemaNeeded($e);}
    }
    public function list_campaigns() {
        $company=$this->authorize();$this->json();$pdo=$this->db();
        try {
            $sql='SELECT c.id,c.name,c.template_name,c.template_language,c.status,c.created_at,
                (SELECT COUNT(*) FROM scpk_broadcast_recipients r WHERE r.campaign_id=c.id) AS total,
                (SELECT COUNT(*) FROM scpk_broadcast_recipients r WHERE r.campaign_id=c.id AND r.status=\'pending\') AS pending,
                (SELECT COUNT(*) FROM scpk_broadcast_recipients r WHERE r.campaign_id=c.id AND r.status=\'accepted\') AS accepted,
                (SELECT COUNT(*) FROM scpk_broadcast_recipients r WHERE r.campaign_id=c.id AND r.status IN (\'rejected\',\'unconfirmed\',\'skipped\',\'sending\')) AS issues
                FROM scpk_broadcast_campaigns c WHERE c.company_id=? ORDER BY c.id DESC LIMIT 50';
            $stmt=$pdo->prepare($sql);$stmt->execute([$company]);
            echo json_encode(['status'=>'success','data'=>$stmt->fetchAll(\PDO::FETCH_ASSOC)]);
        }catch(\Throwable $e){$this->schemaNeeded($e);}
    }
    public function create_campaign() {
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        $name=trim((string)($data['name']??''));
        if (strlen($name)<3||strlen($name)>120) $this->fail('Campaign name must be 3–120 characters');
        $t=$this->template((string)($data['template_name']??''),(string)($data['template_language']??''));
        $mediaId=trim((string)($data['media_id']??''));
        if ($t['_header_media_kind']!=='') {
            if (!$this->media($company,$mediaId)) $this->fail('This approved template needs matching saved gallery media');
            $mime=$this->media($company,$mediaId)['mime'];
            if ($t['_header_media_kind']==='image' && strpos($mime,'image/')!==0 ||
                $t['_header_media_kind']==='video' && $mime!=='video/mp4') $this->fail('Media type mismatch');
        } else $mediaId='';
        $phones=preg_split('/[\s,;]+/',(string)($data['phones']??''),-1,PREG_SPLIT_NO_EMPTY);
        if (!$phones || count($phones)>100) $this->fail('Enter 1–100 specific customer numbers');
        $leads=[];$skipped=[];
        try {
            foreach (array_unique(array_map([$this,'number'],$phones)) as $phone) {
                $lead=$this->leadByNumber($pdo,$company,$phone);
                if (!$lead) {$skipped[]='CRM chat not found/ambiguous: '.substr($phone,-4);continue;}
                if (!$this->optInIsValid($pdo,$company,(int)$lead['lead_id'])) {
                    $skipped[]='Missing opt-in or STOP: '.substr($phone,-4);continue;
                }
                if (strlen($phone)<11 || strlen($phone)>15) {
                    $skipped[]='Provide country code: '.substr($phone,-4);continue;
                }
                $lead['send_phone']=$phone;
                $leads[$lead['lead_id']]=$lead;
            }
            if (!$leads) $this->fail('No opted-in CRM customers. Record verified marketing consent first.');
            $pdo->beginTransaction();
            $stmt=$pdo->prepare('INSERT INTO scpk_broadcast_campaigns
                (company_id,created_by,name,template_name,template_language,media_library_id,status)
                VALUES (?,?,?,?,?,?,\'draft\')');
            $stmt->execute([$company,(int)$_SESSION['user_id'],$name,$t['name'],$t['language'],($mediaId?:null)]);
            $campaign=(int)$pdo->lastInsertId();
            $ins=$pdo->prepare('INSERT INTO scpk_broadcast_recipients
                (campaign_id,company_id,lead_id,conversation_id,phone,status) VALUES (?,?,?,?,?,\'pending\')');
            foreach ($leads as $lead) {
                $phone=$lead['send_phone']; // Explicitly entered international number; do not guess country code.
                $ins->execute([$campaign,$company,$lead['lead_id'],$lead['conversation_id'],$phone]);
            }
            $pdo->commit();
            echo json_encode(['status'=>'success','campaign_id'=>$campaign,'eligible'=>count($leads),'skipped'=>$skipped,'state'=>'draft']);
        }catch(\Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$this->schemaNeeded($e);}
    }
    public function pause_campaign() {
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();$id=(int)($data['campaign_id']??0);
        if ($id<1) $this->fail('Invalid campaign ID');
        try {
            $stmt=$pdo->prepare("UPDATE scpk_broadcast_campaigns SET status='paused' WHERE id=? AND company_id=? AND status IN ('draft','active')");
            $stmt->execute([$id,$company]);echo json_encode(['status'=>'success']);
        }catch(\Throwable $e){$this->schemaNeeded($e);}
    }
    public function send_batch() {
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        $id=(int)($data['campaign_id']??0);
        if ($id<1||($data['confirm']??'')!=='SEND_APPROVED_MARKETING') $this->fail('Explicit send confirmation required');
        try {
            $stmt=$pdo->prepare('SELECT * FROM scpk_broadcast_campaigns WHERE id=? AND company_id=? LIMIT 1');
            $stmt->execute([$id,$company]);$campaign=$stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$campaign||!in_array($campaign['status'],['draft','active'],true)) $this->fail('Campaign not found or paused/completed');
            $t=$this->template((string)$campaign['template_name'],(string)$campaign['template_language']);
            $header=$t['_header_media_kind'];
            $mediaMeta='';
            if($header!==''){
                $mediaId=(string)($campaign['media_library_id']??'');
                if(!$mediaId)$this->fail('Campaign header media is missing');
                $mediaMeta=$this->uploadMeta($company,$mediaId,$header);
            }
            $lock=$pdo->prepare("UPDATE scpk_broadcast_campaigns SET status='active' WHERE id=? AND company_id=? AND status IN ('draft','active')");
            $lock->execute([$id,$company]);
            $next=$pdo->prepare("SELECT r.* FROM scpk_broadcast_recipients r
                WHERE r.campaign_id=? AND r.company_id=? AND r.status='pending' ORDER BY r.id ASC LIMIT 2");
            $next->execute([$id,$company]);$batch=$next->fetchAll(\PDO::FETCH_ASSOC);
            $results=[];
            foreach($batch as $index=>$rec){
                $claim=$pdo->prepare("UPDATE scpk_broadcast_recipients SET status='sending',attempted_at=UTC_TIMESTAMP()
                    WHERE id=? AND campaign_id=? AND company_id=? AND status='pending'");
                $claim->execute([$rec['id'],$id,$company]);
                if ($claim->rowCount()!==1) continue;
                if(!$this->optInIsValid($pdo,$company,(int)$rec['lead_id'])){
                    $pdo->prepare("UPDATE scpk_broadcast_recipients SET status='skipped',error_code='NO_ACTIVE_OPTIN' WHERE id=?")->execute([$rec['id']]);
                    $results[]=['status'=>'skipped','last4'=>substr($rec['phone'],-4)];continue;
                }
                $components=[];
                if($header!=='')$components[]=['type'=>'header','parameters'=>[['type'=>$header,$header=>['id'=>$mediaMeta]]]];
                $templatePayload=['name'=>$t['name'],'language'=>['code'=>$t['language']]];
                if($components)$templatePayload['components']=$components;
                $payload=['messaging_product'=>'whatsapp','to'=>$rec['phone'],'type'=>'template','template'=>$templatePayload];
                $phoneId=defined('WA_PHONE_NUMBER_ID')?(string)WA_PHONE_NUMBER_ID:'';
                $token=defined('WA_ACCESS_TOKEN')?(string)WA_ACCESS_TOKEN:'';
                if(!ctype_digit($phoneId)||!$token)$this->fail('Meta configuration missing');
                $ch=curl_init('https://graph.facebook.com/v24.0/'.$phoneId.'/messages');
                curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE),
                    CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Content-Type: application/json'],
                    CURLOPT_RETURNTRANSFER=>true,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>20]);
                $raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$errno=(int)curl_errno($ch);curl_close($ch);
                $result=is_string($raw)?json_decode($raw,true):null;
                $wamid=is_array($result)?(string)($result['messages'][0]['id']??''):'';
                if($http>=200&&$http<300&&$wamid!==''){
                    // Begins with [Bot] so the HUMAN-agent takeover guard does not confuse
                    // an automated campaign with a real sales agent chat message.
                    $parts=['[Bot] [Broadcast: '.$campaign['name'].'] [Template: '.$t['name'].']'];
                    foreach (($t['components'] ?? []) as $part) {
                        $partType = strtoupper((string)($part['type'] ?? ''));
                        if (in_array($partType, ['HEADER','BODY','FOOTER'], true) &&
                            ($partType !== 'HEADER' || strtoupper((string)($part['format'] ?? 'TEXT')) === 'TEXT')) {
                            $content = trim((string)($part['text'] ?? ''));
                            if ($content !== '') $parts[]=$content;
                        }
                    }
                    $text=substr(implode("\n\n",$parts),0,8000);
                    $galleryUrl = $header !== '' ? rtrim(BASE_URL,'/') . '/inbox/template_media_preview?id=' . $campaign['media_library_id'] : null;
                    $gallery = $galleryUrl ? $this->media($company,(string)$campaign['media_library_id']) : null;
                    try{
                        $ins=$pdo->prepare("INSERT INTO wa_messages
                            (wa_message_id,conversation_id,sender_type,message_type,message_body,media_url,mime_type,delivery_status,is_internal)
                            VALUES (?,?, 'agent','template',?,?,?,'sent',0)");
                        $ins->execute([$wamid,$rec['conversation_id'],$text,$galleryUrl,($gallery['mime'] ?? null)]);
                        $pdo->prepare('UPDATE wa_conversations SET last_message_at=UTC_TIMESTAMP() WHERE id=?')->execute([$rec['conversation_id']]);
                    }catch(\Throwable $e){error_log('Broadcast accepted; CRM chat save failed, campaign '.$id.' code '.$e->getCode());}
                    $pdo->prepare("UPDATE scpk_broadcast_recipients SET status='accepted',wa_message_id=?,error_code=NULL WHERE id=?")->execute([$wamid,$rec['id']]);
                    $results[]=['status'=>'accepted','last4'=>substr($rec['phone'],-4)];
                }else{
                    $confirmedReject=$http>=400;
                    $code=is_array($result)?(string)($result['error']['code']??'HTTP_'.$http):'TRANSPORT_'.$errno;
                    $pdo->prepare('UPDATE scpk_broadcast_recipients SET status=?,error_code=? WHERE id=?')
                        ->execute([$confirmedReject?'rejected':'unconfirmed',substr($code,0,50),$rec['id']]);
                    $results[]=['status'=>$confirmedReject?'rejected':'unconfirmed','last4'=>substr($rec['phone'],-4),'code'=>$code];
                }
                if ($index<count($batch)-1) sleep(7);
            }
            $remaining=$pdo->prepare("SELECT COUNT(*) FROM scpk_broadcast_recipients WHERE campaign_id=? AND status='pending'");
            $remaining->execute([$id]);$pending=(int)$remaining->fetchColumn();
            if($pending===0)$pdo->prepare("UPDATE scpk_broadcast_campaigns SET status='completed' WHERE id=? AND company_id=? AND status='active'")->execute([$id,$company]);
            echo json_encode(['status'=>'success','results'=>$results,'pending'=>$pending,'sent_count'=>count($results)]);
        }catch(\Throwable $e){$this->schemaNeeded($e);}
    }
    // =====================================================================
    // SCPK Campaign Builder v2 — additive endpoints only. Existing send_batch,
    // consent, chat, bot and gallery endpoints above remain unchanged.
    // Requires CAMPAIGN_WIZARD_V2_SCHEMA.sql, never modifies existing columns.
    // =====================================================================
    private function wizardColumns(): array {
        $pdo=$this->db();
        $fields=$pdo->query('SHOW COLUMNS FROM leads')->fetchAll(\PDO::FETCH_ASSOC);
        $names=[];
        foreach($fields as $f) $names[(string)$f['Field']]=true;
        return $names;
    }

    private function wizardRow(\PDO $pdo,int $company,int $id): array {
        if($id<1) $this->fail('Save the campaign name first');
        $stmt=$pdo->prepare('SELECT c.*,w.wizard_step,w.audience_json,w.estimated_unit_rate
            FROM scpk_broadcast_campaigns c
            JOIN scpk_broadcast_wizard_data w ON w.campaign_id=c.id AND w.company_id=c.company_id
            WHERE c.id=? AND c.company_id=? LIMIT 1');
        $stmt->execute([$id,$company]);
        $row=$stmt->fetch(\PDO::FETCH_ASSOC);
        if(!$row) $this->fail('Campaign draft not found in your company');
        return $row;
    }

    private function wizardSettings($data): array {
        if(!is_array($data)) $this->fail('Invalid audience selection');
        $source=(string)($data['source']??'filters');
        if(!in_array($source,['csv','filters'],true)) $this->fail('Choose CSV or CRM filters');
        $raw=$data['phones']??[];
        if(!is_array($raw)||count($raw)>2000) $this->fail('CSV limited to 2,000 unique phone numbers per campaign');
        $phones=[];
        foreach($raw as $v){
            if(!is_string($v)) $this->fail('CSV phone values must be text');
            $p=$this->number($v);
            if(strlen($p)<11||strlen($p)>15) $this->fail('CSV numbers must include country code (11–15 digits)');
            $phones[$p]=$p;
        }
        if($source==='csv'&&!$phones) $this->fail('Upload a CSV with international WhatsApp numbers');
        $filters=[];
        foreach(['tag','stage','status','temperature'] as $key){
            $s=trim((string)($data[$key]??''));
            if(strlen($s)>100) $this->fail('Filter value is too long');
            $filters[$key]=$s;
        }
        $filters['agent_id']=max(0,(int)($data['agent_id']??0));
        return ['source'=>$source,'phones'=>array_values($phones)]+$filters;
    }

    /** Never adds contacts without recorded current marketing opt-in. */
    private function wizardEligible(\PDO $pdo,int $company,array $settings): array {
        $columns=$this->wizardColumns();
        $temp='';
        foreach(['lead_temperature','temperature','lead_temp'] as $name){
            if(isset($columns[$name])) {$temp=$name;break;}
        }
        if(($settings['temperature']??'')!=='' && $temp==='')
            $this->fail('Temperature filter unavailable: no temperature field exists in leads table');
        $status=isset($columns['lead_status'])?'l.lead_status':'\'\'';
        $stage=isset($columns['lead_stage'])?'l.lead_stage':'\'\'';
        $tags=isset($columns['tags'])?'l.tags':'\'\'';
        $assigned=isset($columns['assigned_to'])?'l.assigned_to':'0';
        $tempExpr=$temp!==''?'l.`'.$temp.'`':'\'\'';
        $q=$pdo->prepare("SELECT l.id AS lead_id,l.full_name,l.whatsapp_number,l.phone_number,
                   $stage AS stage,$status AS lead_status,$tags AS tags,$assigned AS assigned_to,
                   $tempExpr AS temperature,c.id AS conversation_id
            FROM leads l
            INNER JOIN wa_conversations c ON c.lead_id=l.id AND c.company_id=l.company_id
            INNER JOIN scpk_wa_marketing_optins o ON o.company_id=l.company_id AND o.lead_id=l.id
            WHERE l.company_id=? AND o.opted_in_at IS NOT NULL AND o.opted_out_at IS NULL
            ORDER BY l.id DESC LIMIT 10001");
        $q->execute([$company]);
        $rows=$q->fetchAll(\PDO::FETCH_ASSOC);
        if(count($rows)>10000) $this->fail('More than 10,000 opted-in leads; narrow your filters');
        $csv=array_fill_keys($settings['phones']??[],true);
        $found=[]; $skips=['missing_country_code'=>0,'opted_out_or_stopped'=>0,'filters_not_matched'=>0];
        foreach($rows as $r){
            if($settings['source']==='csv'){
                $stored=$this->number((string)($r['whatsapp_number']?:$r['phone_number']?:''));
                $match=null;
                foreach([$stored] as $candidate){
                    if(isset($csv[$candidate])){$match=$candidate;break;}
                }
                if($match===null) continue;
                $sendPhone=$match;
            } else {
                $sendPhone=$this->number((string)($r['whatsapp_number']?:$r['phone_number']?:''));
            }
            if(strlen($sendPhone)<11||strlen($sendPhone)>15){$skips['missing_country_code']++;continue;}
            foreach(['stage'=>'stage','status'=>'lead_status','temperature'=>'temperature'] as $key=>$column){
                if(($settings[$key]??'')!=='' && strcasecmp(trim((string)$r[$column]),(string)$settings[$key])!==0){
                    $skips['filters_not_matched']++;continue 2;
                }
            }
            if(($settings['tag']??'')!==''){
                $tags=array_map('trim',explode(',',strtolower((string)$r['tags'])));
                if(!in_array(strtolower((string)$settings['tag']),$tags,true)){$skips['filters_not_matched']++;continue;}
            }
            if(($settings['agent_id']??0)>0 && (int)$r['assigned_to']!==(int)$settings['agent_id']){
                $skips['filters_not_matched']++;continue;
            }
            if(!$this->optInIsValid($pdo,$company,(int)$r['lead_id'])){
                $skips['opted_out_or_stopped']++;continue;
            }
            $r['send_phone']=$sendPhone;
            $found[(int)$r['lead_id']]=$r;
            if(count($found)>2000) $this->fail('More than 2,000 eligible recipients. Narrow filters or split campaigns.');
        }
        return ['rows'=>array_values($found),'skipped'=>$skips];
    }

    public function wizard_options(){
        $company=$this->authorize();$this->json();$pdo=$this->db();
        try {
            $cols=$this->wizardColumns();
            $out=['tags'=>[],'stages'=>[],'statuses'=>[],'temperatures'=>[],'agents'=>[],'temperature_field'=>null];
            foreach(['stages'=>'lead_stage','statuses'=>'lead_status'] as $dest=>$column){
                if(isset($cols[$column])){
                    $s=$pdo->prepare('SELECT DISTINCT `'.$column.'` FROM leads WHERE company_id=? AND `'.$column.'` IS NOT NULL AND `'.$column.'`<>\'\' ORDER BY `'.$column.'` LIMIT 100');
                    $s->execute([$company]);$out[$dest]=$s->fetchAll(\PDO::FETCH_COLUMN);
                }
            }
            if(isset($cols['tags'])){
                $s=$pdo->prepare('SELECT tags FROM leads WHERE company_id=? AND tags IS NOT NULL AND tags<>\'\' LIMIT 10000');
                $s->execute([$company]);$unique=[];
                foreach($s->fetchAll(\PDO::FETCH_COLUMN) as $str){
                    foreach(explode(',',(string)$str) as $tag){$tag=trim($tag);if($tag!=='')$unique[strtolower($tag)]=$tag;}
                }
                $out['tags']=array_slice(array_values($unique),0,300);
                sort($out['tags'],SORT_NATURAL|SORT_FLAG_CASE);
            }
            foreach(['lead_temperature','temperature','lead_temp'] as $field){
                if(isset($cols[$field])){
                    $out['temperature_field']=$field;
                    $s=$pdo->prepare('SELECT DISTINCT `'.$field.'` FROM leads WHERE company_id=? AND `'.$field.'` IS NOT NULL AND `'.$field.'`<>\'\' ORDER BY `'.$field.'` LIMIT 100');
                    $s->execute([$company]);$out['temperatures']=$s->fetchAll(\PDO::FETCH_COLUMN);break;
                }
            }
            $s=$pdo->prepare('SELECT id,full_name FROM users WHERE company_id=? ORDER BY full_name LIMIT 200');
            $s->execute([$company]);$out['agents']=$s->fetchAll(\PDO::FETCH_ASSOC);
            echo json_encode(['status'=>'success','data'=>$out],JSON_INVALID_UTF8_SUBSTITUTE);
        }catch(\Throwable $e){error_log('Wizard options '.$e->getCode());$this->fail('Cannot load filters. Check database columns.');}
    }

    public function wizard_save(){
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        $id=(int)($data['campaign_id']??0);
        $name=trim((string)($data['name']??''));
        if(strlen($name)<3||strlen($name)>120) $this->fail('Campaign name must be 3–120 characters');
        $step=max(1,min(6,(int)($data['step']??1)));
        $aud=$data['audience']??['source'=>'filters','phones'=>[]];
        // An empty CSV is allowed while saving an unfinished draft.
        if(is_array($aud) && ($aud['source']??'')==='csv' && empty($aud['phones'])) $aud['source']='filters';
        $settings=$this->wizardSettings($aud);
        $lang=trim((string)($data['template_language']??''));
        $template=trim((string)($data['template_name']??''));
        if(($template==='')!==($lang==='')) $this->fail('Template name and language must be selected together');
        if(strlen($template)>255||strlen($lang)>16||($template!==''&&!preg_match('/^[a-z0-9_]+$/',$template)))$this->fail('Invalid template name');
        $mediaId=trim((string)($data['media_id']??''));
        if($mediaId!==''&&!preg_match('/^[a-f0-9]{32}$/',$mediaId))$this->fail('Invalid media library ID');
        $rate=$data['estimated_unit_rate']??null;
        if($rate===''||$rate===null) $rate=null;
        elseif(!is_numeric($rate)||(float)$rate<0||(float)$rate>100)$this->fail('Estimated rate must be ₹0–₹100 per delivered message');
        $json=json_encode($settings,JSON_UNESCAPED_UNICODE);
        if(strlen((string)$json)>150000)$this->fail('Audience too large to save');
        try {
            $pdo->beginTransaction();
            if($id>0){
                $row=$this->wizardRow($pdo,$company,$id);
                if($row['status']!=='draft') $this->fail('Already started campaign cannot be edited. Pause or review analytics.');
                $attempt=$pdo->prepare('SELECT 1 FROM scpk_broadcast_recipients WHERE campaign_id=? AND attempted_at IS NOT NULL LIMIT 1');
                $attempt->execute([$id]);if($attempt->fetchColumn())$this->fail('Campaign already attempted delivery; edits are locked');
                // If audience/template/media changes after preparation, clear only UNSENT
                // recipients. Never silently send a stale recipient snapshot.
                $oldSettings=json_decode((string)$row['audience_json'],true);
                $selectionChanged=($oldSettings!==$settings)
                    || (string)$row['template_name']!==$template
                    || (string)$row['template_language']!==$lang
                    || (string)($row['media_library_id']??'')!==$mediaId;
                if($selectionChanged){
                    $pdo->prepare("DELETE FROM scpk_broadcast_recipients WHERE campaign_id=? AND company_id=? AND status='pending'")
                        ->execute([$id,$company]);
                }
                $s=$pdo->prepare('UPDATE scpk_broadcast_campaigns SET name=?,template_name=?,template_language=?,media_library_id=? WHERE id=? AND company_id=?');
                $s->execute([$name,$template,$lang,$mediaId?:null,$id,$company]);
                $s=$pdo->prepare('UPDATE scpk_broadcast_wizard_data SET wizard_step=?,audience_json=?,estimated_unit_rate=? WHERE campaign_id=? AND company_id=?');
                $s->execute([$step,$json,$rate,$id,$company]);
            } else {
                $s=$pdo->prepare("INSERT INTO scpk_broadcast_campaigns(company_id,created_by,name,template_name,template_language,status) VALUES (?,?,?,'','','draft')");
                $s->execute([$company,(int)$_SESSION['user_id'],$name]);$id=(int)$pdo->lastInsertId();
                $s=$pdo->prepare('INSERT INTO scpk_broadcast_wizard_data(campaign_id,company_id,wizard_step,audience_json,estimated_unit_rate) VALUES(?,?,?,?,?)');
                $s->execute([$id,$company,$step,$json,$rate]);
            }
            $pdo->commit();
            $totalStmt=$pdo->prepare("SELECT COUNT(*) FROM scpk_broadcast_recipients WHERE campaign_id=? AND company_id=? AND status='pending'");
            $totalStmt->execute([$id,$company]);
            echo json_encode(['status'=>'success','campaign_id'=>$id,'step'=>$step,'pending'=>(int)$totalStmt->fetchColumn()]);
        }catch(\Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log('Wizard save '.$e->getMessage());$this->fail('Could not save draft. Check CAMPAIGN_WIZARD_V2_SCHEMA.sql',503);}
    }

    public function wizard_load(){
        $company=$this->authorize();$this->json();$pdo=$this->db();
        try{
            $row=$this->wizardRow($pdo,$company,(int)($_GET['id']??0));
            $aud=json_decode((string)$row['audience_json'],true);
            echo json_encode(['status'=>'success','data'=>[
                'campaign_id'=>(int)$row['id'],'name'=>$row['name'],'step'=>(int)$row['wizard_step'],
                'status'=>$row['status'],'audience'=>$aud?:['source'=>'filters','phones'=>[]],
                'template_name'=>$row['template_name'],'template_language'=>$row['template_language'],
                'media_id'=>$row['media_library_id'],'estimated_unit_rate'=>$row['estimated_unit_rate']]],JSON_INVALID_UTF8_SUBSTITUTE);
        }catch(\Throwable $e){$this->fail('Could not reload saved campaign',503);}
    }

    public function wizard_preview(){
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        try{
            $aud=$this->wizardSettings($data['audience']??[]);
            $matches=$this->wizardEligible($pdo,$company,$aud);
            $sample=[];
            foreach(array_slice($matches['rows'],0,15) as $r){
                $sample[]=['name'=>$r['full_name'],'number'=>'***'.substr($r['send_phone'],-4),
                    'stage'=>$r['stage'],'status'=>$r['lead_status']];
            }
            echo json_encode(['status'=>'success','eligible'=>count($matches['rows']),
                'sample'=>$sample,'skipped'=>$matches['skipped']],JSON_INVALID_UTF8_SUBSTITUTE);
        }catch(\Throwable $e){error_log('Wizard audience preview '.$e->getCode());$this->fail('Audience preview unavailable: '.$e->getMessage());}
    }

    private function wizardTemplateAndMedia(int $company,array $row): array {
        if(empty($row['template_name'])||empty($row['template_language']))$this->fail('Select an approved Marketing template first');
        $t=$this->template((string)$row['template_name'],(string)$row['template_language']);
        $kind=$t['_header_media_kind'];
        $metaId='';$gallery=null;
        if($kind!==''){
            $id=(string)($row['media_library_id']??'');
            if(!$id)$this->fail('Template requires gallery IMAGE/VIDEO header');
            $gallery=$this->media($company,$id);
            if(!$gallery || ($kind==='image'&&!strpos($gallery['mime'],'image/')===0)||($kind==='video'&&$gallery['mime']!=='video/mp4'))
                $this->fail('Gallery media missing or wrong header type');
        }
        return [$t,$kind,$gallery];
    }

    public function wizard_test(){
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        if(($data['confirm']??'')!=='SEND_SINGLE_TEST')$this->fail('Explicit one-person test send confirmation required');
        $id=(int)($data['campaign_id']??0);
        $row=$this->wizardRow($pdo,$company,$id);
        if($row['status']!=='draft')$this->fail('Test before final sending, while campaign is a draft');
        [$t,$kind,$gallery]=$this->wizardTemplateAndMedia($company,$row);
        $phone=$this->number((string)($data['phone']??''));
        if(strlen($phone)<11||strlen($phone)>15)$this->fail('Enter international WhatsApp test number with country code');
        $lead=$this->leadByNumber($pdo,$company,$phone);
        if(!$lead||!$this->optInIsValid($pdo,$company,(int)$lead['lead_id']))
            $this->fail('Test number must be an existing CRM chat with verified active marketing opt-in');
        // Claim once before contacting Meta. Network timeouts are never retried automatically.
        try{
            $s=$pdo->prepare("INSERT INTO scpk_broadcast_test_sends
                (campaign_id,company_id,lead_id,conversation_id,phone,template_name,template_language,media_library_id,status)
                VALUES (?,?,?,?,?,?,?,?, 'sending')");
            $s->execute([$id,$company,(int)$lead['lead_id'],(int)$lead['conversation_id'],$phone,
                $row['template_name'],$row['template_language'],(string)($row['media_library_id']??'')]);
        }catch(\Throwable $e){$this->fail('This test recipient has already been attempted. Review test status before repeating.');}
        $mediaMeta='';
        if($kind!=='')$mediaMeta=$this->uploadMeta($company,(string)$row['media_library_id'],$kind);
        $components=[];
        if($kind!=='')$components[]=['type'=>'header','parameters'=>[['type'=>$kind,$kind=>['id'=>$mediaMeta]]]];
        $template=['name'=>$t['name'],'language'=>['code'=>$t['language']]];
        if($components)$template['components']=$components;
        $waId='';$http=0;$error='UNCONFIRMED';
        $phoneId=defined('WA_PHONE_NUMBER_ID')?(string)WA_PHONE_NUMBER_ID:'';
        $token=defined('WA_ACCESS_TOKEN')?(string)WA_ACCESS_TOKEN:'';
        if(ctype_digit($phoneId)&&$token){
            $ch=curl_init('https://graph.facebook.com/v24.0/'.$phoneId.'/messages');
            curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode(['messaging_product'=>'whatsapp','to'=>$phone,'type'=>'template','template'=>$template],JSON_UNESCAPED_UNICODE),
                CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$token,'Content-Type: application/json'],
                CURLOPT_RETURNTRANSFER=>true,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>20]);
            $raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
            $res=is_string($raw)?json_decode($raw,true):null;
            $waId=is_array($res)?(string)($res['messages'][0]['id']??''):'';
            $error=is_array($res)?(string)($res['error']['code']??'NO_MESSAGE_ID'):'TRANSPORT_UNKNOWN';
        }
        $status=$waId!==''&&$http>=200&&$http<300?'accepted':($http>=400?'rejected':'unconfirmed');
        $pdo->prepare('UPDATE scpk_broadcast_test_sends SET status=?,wa_message_id=?,error_code=?
            WHERE campaign_id=? AND company_id=? AND phone=? AND template_name=? AND template_language=? AND media_library_id=?')
            ->execute([$status,$waId?:null,$status==='accepted'?null:substr($error,0,50),$id,$company,$phone,
                $row['template_name'],$row['template_language'],(string)($row['media_library_id']??'')]);
        if($status==='accepted'){
            $galleryUrl=$kind!==''?rtrim(BASE_URL,'/').'/inbox/template_media_preview?id='.$row['media_library_id']:null;
            $this->wizardStoreTestMessage($pdo,$lead,$waId,$t,$galleryUrl,$gallery);
        }
        echo json_encode(['status'=>'success','test_status'=>$status,'code'=>$status==='accepted'?null:$error,
            'message'=>'Meta API '.($status==='accepted'?'accepted one test message (not proof of delivery)':$status.'. Do NOT auto-retry uncertain results')]);
    }

    private function wizardStoreTestMessage(\PDO $pdo,array $lead,string $waId,array $t,?string $url,?array $media): void {
        $text='[Bot] [Campaign Test] [Template: '.$t['name'].']';
        foreach(($t['components']??[]) as $p){
            $type=strtoupper((string)($p['type']??''));
            if(in_array($type,['BODY','FOOTER'],true) || ($type==='HEADER'&&strtoupper((string)($p['format']??''))==='TEXT')){
                $v=trim((string)($p['text']??''));if($v!=='')$text.="\n\n".$v;
            }
        }
        try{
            $s=$pdo->prepare("INSERT INTO wa_messages
                (wa_message_id,conversation_id,sender_type,message_type,message_body,media_url,mime_type,delivery_status,is_internal)
                VALUES (?,?,'agent','template',?,?,?,'sent',0)");
            $s->execute([$waId,$lead['conversation_id'],$text,$url,$media['mime']??null]);
            $pdo->prepare('UPDATE wa_conversations SET last_message_at=UTC_TIMESTAMP() WHERE id=?')->execute([$lead['conversation_id']]);
        }catch(\Throwable $e){error_log('Campaign test accepted; chat store failed code '.$e->getCode());}
    }

    public function wizard_finalize(){
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        if(($data['confirm']??'')!=='PREPARE_REVIEWED_AUDIENCE')$this->fail('Explicit audience review confirmation required');
        $id=(int)($data['campaign_id']??0);
        $row=$this->wizardRow($pdo,$company,$id);
        if($row['status']!=='draft')$this->fail('Campaign already started or paused');
        $this->wizardTemplateAndMedia($company,$row);
        // A test for ANOTHER template/header must never authorize this final send.
        $test=$pdo->prepare("SELECT 1 FROM scpk_broadcast_test_sends
            WHERE company_id=? AND campaign_id=? AND template_name=? AND template_language=?
              AND media_library_id=? AND status='accepted' LIMIT 1");
        $test->execute([$company,$id,$row['template_name'],$row['template_language'],
            (string)($row['media_library_id']??'')]);
        if(!$test->fetchColumn())$this->fail('Send an accepted test for THIS template and exact header media before final sending');
        $aud=json_decode((string)$row['audience_json'],true);
        $settings=$this->wizardSettings($aud?:[]);
        $matches=$this->wizardEligible($pdo,$company,$settings);
        if(!$matches['rows'])$this->fail('No eligible customers after consent and audience filters');
        try{
            $pdo->beginTransaction();
            $check=$pdo->prepare('SELECT 1 FROM scpk_broadcast_recipients WHERE campaign_id=? AND attempted_at IS NOT NULL LIMIT 1');
            $check->execute([$id]);if($check->fetchColumn())throw new \RuntimeException('This campaign already attempted sends');
            $pdo->prepare("DELETE FROM scpk_broadcast_recipients WHERE campaign_id=? AND company_id=? AND status='pending'")->execute([$id,$company]);
            $ins=$pdo->prepare("INSERT INTO scpk_broadcast_recipients
                (campaign_id,company_id,lead_id,conversation_id,phone,status) VALUES(?,?,?,?,?,'pending')");
            foreach($matches['rows'] as $r){
                $ins->execute([$id,$company,$r['lead_id'],$r['conversation_id'],$r['send_phone']]);
            }
            $pdo->prepare('UPDATE scpk_broadcast_wizard_data SET wizard_step=5 WHERE campaign_id=? AND company_id=?')->execute([$id,$company]);
            $pdo->commit();
            echo json_encode(['status'=>'success','campaign_id'=>$id,'eligible'=>count($matches['rows']),
                'message'=>'Campaign queued as draft. NO final messages have been sent yet.']);
        }catch(\Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log('Wizard prepare '.$e->getCode());$this->fail('Could not prepare audience. No final messages sent.',503);}
    }

    public function wizard_resume(){
        $company=$this->authorize();$d=$this->post();$pdo=$this->db();
        $id=(int)($d['campaign_id']??0);
        if(($d['confirm']??'')!=='RESUME_PAUSED')$this->fail('Resume confirmation required');
        $s=$pdo->prepare("UPDATE scpk_broadcast_campaigns SET status='active'
            WHERE id=? AND company_id=? AND status='paused'");
        $s->execute([$id,$company]);
        if($s->rowCount()!==1)$this->fail('Campaign not paused or already resumed');
        echo json_encode(['status'=>'success','message'=>'Campaign resumed. No sends occur until Send next 2 is clicked.']);
    }

    public function wizard_analytics(){
        $company=$this->authorize();$this->json();$pdo=$this->db();
        $id=(int)($_GET['id']??0);
        try{
            $s=$pdo->prepare('SELECT c.name,c.status,c.template_name,c.template_language,c.media_library_id,w.estimated_unit_rate
                FROM scpk_broadcast_campaigns c LEFT JOIN scpk_broadcast_wizard_data w ON w.campaign_id=c.id AND w.company_id=c.company_id
                WHERE c.id=? AND c.company_id=? LIMIT 1');
            $s->execute([$id,$company]);$c=$s->fetch(\PDO::FETCH_ASSOC);
            if(!$c)$this->fail('Campaign not found');
            $s=$pdo->prepare('SELECT r.id,r.status,r.error_code,m.delivery_status
                FROM scpk_broadcast_recipients r
                LEFT JOIN wa_messages m ON m.wa_message_id=r.wa_message_id AND m.conversation_id=r.conversation_id
                WHERE r.campaign_id=? AND r.company_id=?');
            $s->execute([$id,$company]);
            $counts=['total'=>0,'pending'=>0,'accepted'=>0,'delivered'=>0,'read'=>0,
                'failed'=>0,'unconfirmed'=>0,'sending'=>0,'skipped'=>0];
            $seen=[];
            foreach($s->fetchAll(\PDO::FETCH_ASSOC) as $r){
                $rid=(int)$r['id'];if(isset($seen[$rid]))continue;$seen[$rid]=true;
                $counts['total']++;$status=(string)$r['status'];$delivery=(string)($r['delivery_status']??'');
                if($status==='pending')$counts['pending']++;
                if($status==='skipped')$counts['skipped']++;
                if($status==='sending')$counts['sending']++;
                if($status==='unconfirmed')$counts['unconfirmed']++;
                if($status==='rejected'||$delivery==='failed')$counts['failed']++;
                if($status==='accepted')$counts['accepted']++;
                if($status==='accepted'&&in_array($delivery,['delivered','read'],true))$counts['delivered']++;
                if($status==='accepted'&&$delivery==='read')$counts['read']++;
            }
            $s=$pdo->prepare('SELECT status,COUNT(*) AS qty FROM scpk_broadcast_test_sends
                WHERE campaign_id=? AND company_id=? AND template_name=? AND template_language=?
                  AND media_library_id=? GROUP BY status');
            $s->execute([$id,$company,(string)$c['template_name'],
                (string)$c['template_language'],(string)($c['media_library_id']??'')]);$test=[];
            foreach($s->fetchAll(\PDO::FETCH_ASSOC) as $v)$test[$v['status']]=(int)$v['qty'];
            $rate=$c['estimated_unit_rate']!==null?(float)$c['estimated_unit_rate']:null;
            echo json_encode(['status'=>'success','data'=>['name'=>$c['name'],'campaign_status'=>$c['status'],
                'template_name'=>$c['template_name'],'counts'=>$counts,'test'=>$test,
                'estimated_unit_rate'=>$rate,'estimated_cost_inr'=>$rate!==null?round($counts['delivered']*$rate,2):null,
                'cost_note'=>'Estimate only: delivered x manually entered rate. Actual Meta invoice may differ by country, pricing tier, exemptions and date.']],JSON_INVALID_UTF8_SUBSTITUTE);
        }catch(\Throwable $e){error_log('Wizard analytics '.$e->getCode());$this->fail('Campaign analytics unavailable. Verify migration and status webhook.',503);}
    }

    public function wizard_rate(){
        // A cost ESTIMATE setting is editable after sending. It never affects
        // message pricing, Meta configuration, audience or delivery state.
        $company=$this->authorize();$data=$this->post();$pdo=$this->db();
        $id=(int)($data['campaign_id']??0);
        $rate=$data['estimated_unit_rate']??null;
        if($rate===''||$rate===null)$rate=null;
        elseif(!is_numeric($rate)||(float)$rate<0||(float)$rate>100)$this->fail('Estimated INR rate must be ₹0–₹100');
        try{
            $this->wizardRow($pdo,$company,$id);
            $q=$pdo->prepare('UPDATE scpk_broadcast_wizard_data SET estimated_unit_rate=? WHERE campaign_id=? AND company_id=?');
            $q->execute([$rate,$id,$company]);
            echo json_encode(['status'=>'success','message'=>'Estimate rate updated; this is NOT an actual Meta cost']);
        }catch(\Throwable $e){$this->fail('Could not save estimate. Legacy campaigns may need a wizard draft record.',503);}
    }

}
