<?php 
namespace Controllers; 
use Core\Controller; 
use Models\Chat; 
use Core\Database;
use Core\Timezone;

class InboxController extends Controller {
    // Company-scope checks. Existing agent assignment permissions stay unchanged.
    private function companyId(): int {
        $id = (int)($_SESSION['company_id'] ?? 0);
        if ($id <= 0 || empty($_SESSION['user_id'])) $this->denyAccess();
        return $id;
    }

    private function denyAccess(): void {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Access denied']);
        exit;
    }

    private function conversationAllowed(\PDO $pdo, $conversationId): bool {
        $id = filter_var($conversationId, FILTER_VALIDATE_INT);
        if (!$id || $id <= 0) return false;
        $companyId = $this->companyId();
        $stmt = $pdo->prepare('SELECT 1 FROM wa_conversations c
            JOIN leads l ON l.id = c.lead_id
            WHERE c.id = ? AND c.company_id = ? AND l.company_id = ? LIMIT 1');
        $stmt->execute([$id, $companyId, $companyId]);
        return (bool)$stmt->fetchColumn();
    }

    private function leadAllowed(\PDO $pdo, $leadId): bool {
        $id = filter_var($leadId, FILTER_VALIDATE_INT);
        if (!$id || $id <= 0) return false;
        $stmt = $pdo->prepare('SELECT 1 FROM leads WHERE id = ? AND company_id = ? LIMIT 1');
        $stmt->execute([$id, $this->companyId()]);
        return (bool)$stmt->fetchColumn();
    }

    private function macroAllowed(\PDO $pdo, $macroId): bool {
        $id = filter_var($macroId, FILTER_VALIDATE_INT);
        if (!$id || $id <= 0) return false;
        $stmt = $pdo->prepare('SELECT 1 FROM agent_macros m
            JOIN users u ON m.agent_id = u.id
            WHERE m.id = ? AND u.company_id = ? LIMIT 1');
        $stmt->execute([$id, $this->companyId()]);
        return (bool)$stmt->fetchColumn();
    }

    private function checkOrigin(): void {
        // Defense in depth. A full CSRF-token rollout will cover all form/AJAX
        // endpoints in a later coordinated stage.
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') return;
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        $site = $origin !== '' ? $origin : $referer;
        if ($site === '') return; // Do not break legacy requests without these headers.
        $expected = parse_url(BASE_URL, PHP_URL_HOST);
        $actual = parse_url($site, PHP_URL_HOST);
        if (!$actual || !$expected || strcasecmp($actual, $expected) !== 0) {
            $this->denyAccess();
        }
    }

    private function agentAllowed(\PDO $pdo, $agentId): bool {
        $id = filter_var($agentId, FILTER_VALIDATE_INT);
        if (!$id || $id <= 0) return false;
        $stmt = $pdo->prepare('SELECT 1 FROM users WHERE id = ? AND company_id = ? LIMIT 1');
        $stmt->execute([$id, $this->companyId()]);
        return (bool)$stmt->fetchColumn();
    }
        
    
    public function index() {         
        $this->render_inbox('live');     
    } 

    public function live_chat() {
        $this->render_inbox('live');
    }

    public function history() {
        $this->render_inbox('history');
    }

    public function all_chats() {
        $this->render_inbox('all_chats');
    }

    public function macros() {
        $this->render_inbox('macros');
    }

    public function tags() {
        $this->render_inbox('tags');
    }
    
    public function templates() {
        $this->render_inbox('templates');
    }

    public function meta_ads() {
        $this->render_inbox('meta_ads');
    }

    public function broadcasts() {
        $this->render_inbox('broadcasts');
    }

    private function render_inbox($app_mode) {
        if (!isset($_SESSION['user_id'])) {              
            header('Location: ' . BASE_URL . 'auth');              
            exit;          
        }
        
        $company_id = $this->companyId();
        $chatModel = new Chat();          
        $active_chats = $chatModel->getActiveChats($company_id);          
        
        $pdo = Database::getInstance();
        $agents = [];
        $agentMap = [];
        
        try { 
            $agentsStmt = $pdo->prepare("SELECT id, full_name as name FROM users WHERE company_id = ? ORDER BY full_name ASC");
            $agentsStmt->execute([$company_id]);
            $agents = $agentsStmt->fetchAll(\PDO::FETCH_ASSOC); 
        } catch (\Exception $e) {
            try { $agentsStmt = $pdo->prepare("SELECT id, name FROM users WHERE company_id = ? ORDER BY name ASC");
                $agentsStmt->execute([$company_id]);
                $agents = $agentsStmt->fetchAll(\PDO::FETCH_ASSOC); } catch (\Exception $e2) {}
        }

        foreach($agents as $a) {
            $agentMap[$a['id']] = $a['name'];
        }

        foreach ($active_chats as &$chat) {
            if (!empty($chat['assigned_to']) && isset($agentMap[$chat['assigned_to']])) {
                $chat['agent_name'] = $agentMap[$chat['assigned_to']];
            }
        }

        $data = [              
            'title' => 'Unified Inbox - LeadFlow CRM',              
            'user_name' => $_SESSION['name'] ?? 'User',              
            'chats' => $active_chats,
            'agents' => $agents,
            'app_mode' => $app_mode,
            // Stage 5: read company display timezone only; SQL timestamps stay UTC.
            'crm_timezone' => Timezone::get($pdo, (int)$company_id) 
        ];                  
        $this->view('inbox', $data);
    }

    public function load_messages($conversation_id) {
        if (!isset($_SESSION['user_id'])) {              
            http_response_code(403);
            exit;          
        }
        
        // 🔥 MAGIC FIX: Unlocks PHP Session queue. Ab chat dusre APIs ka wait nahi karegi! 🔥
        $pdo = Database::getInstance();
        if (!$this->conversationAllowed($pdo, $conversation_id)) $this->denyAccess();
        $companyId = $this->companyId();
        session_write_close();

        header('Content-Type: application/json');
        
        try {
            $pdo = Database::getInstance();
            $pdo->prepare("UPDATE wa_conversations SET unread_count = 0 WHERE id = ? AND company_id = ?")
                ->execute([$conversation_id, $companyId]);
        } catch (\Exception $e) {}

        $chatModel = new Chat();
        $messages = $chatModel->getMessages($conversation_id, $companyId);
        
        echo json_encode(['status' => 'success', 'messages' => $messages]);
    }

    public function load_chat_list() {
        if (!isset($_SESSION['user_id'])) {              
            http_response_code(403);
            exit;          
        }
        
        header('Content-Type: application/json');
        $company_id = $this->companyId();
        $chatModel = new Chat();
        $active_chats = $chatModel->getActiveChats($company_id);

        $pdo = Database::getInstance();
        $agentMap = [];
        try {
            $agentStmt = $pdo->prepare("SELECT id, full_name as name FROM users WHERE company_id = ?");
            $agentStmt->execute([$company_id]);
            $agentsDb = $agentStmt->fetchAll(\PDO::FETCH_ASSOC);
            foreach($agentsDb as $a) $agentMap[$a['id']] = $a['name'];
        } catch (\Exception $e) {
            try {
                $agentStmt = $pdo->prepare("SELECT id, name FROM users WHERE company_id = ?");
                $agentStmt->execute([$company_id]);
                $agentsDb = $agentStmt->fetchAll(\PDO::FETCH_ASSOC);
                foreach($agentsDb as $a) $agentMap[$a['id']] = $a['name'];
            } catch (\Exception $e2) {}
        }

        $leadIds = array_unique(array_column($active_chats, 'lead_id'));
        $adNameMap = [];
        if (!empty($leadIds)) {
            $inQuery = implode(',', array_map('intval', $leadIds));
            try {
                $leadsDb = $pdo->query("SELECT id, meta_ad_name FROM leads WHERE id IN ($inQuery)")->fetchAll(\PDO::FETCH_ASSOC);
                foreach($leadsDb as $l) $adNameMap[$l['id']] = $l['meta_ad_name'];
            } catch (\Exception $e) {}
        }

        $customerMsgMap = [];
        try {
            $custStmt = $pdo->prepare("SELECT m.conversation_id, MAX(m.created_at) as last_cust_time
                FROM wa_messages m JOIN wa_conversations c ON c.id = m.conversation_id
                JOIN leads l ON l.id = c.lead_id
                WHERE m.sender_type != 'agent' AND c.company_id = ? AND l.company_id = ?
                GROUP BY m.conversation_id");
            $custStmt->execute([$company_id, $company_id]);
            $custQuery = $custStmt->fetchAll(\PDO::FETCH_ASSOC);
            foreach($custQuery as $cq) {
                $customerMsgMap[$cq['conversation_id']] = $cq['last_cust_time'];
            }
        } catch (\Exception $e) {}

        foreach ($active_chats as &$chat) {
            if (!empty($chat['assigned_to']) && isset($agentMap[$chat['assigned_to']])) {
                $chat['agent_name'] = $agentMap[$chat['assigned_to']];
            }
            $chat['last_customer_msg_at'] = $customerMsgMap[$chat['conversation_id']] ?? null;
            $chat['meta_ad_name'] = $adNameMap[$chat['lead_id']] ?? null; 
        }
        
        echo json_encode(['status' => 'success', 'chats' => $active_chats]);
    }

    /**
     * Inbox-only pagination. Uses the same conversation categories as the
     * existing inbox.js (unread override, Meta 72h/other 24h, human replies).
     * This is read-only: no bot, message, assignment or database changes.
     * Same COUNT -> 50/page -> OFFSET pattern as WebsiteleadsController,
     * but classify BEFORE slicing to avoid missing/incorrect chat categories.
     */
    public function load_chat_list_paged() {
        if (empty($_SESSION['user_id'])) $this->denyAccess();
        $companyId = $this->companyId();
        $role = strtolower(trim((string)($_SESSION['role'] ?? '')));
        $agentName = strtolower(trim((string)($_SESSION['name'] ?? '')));
        // Free the PHP session lock, as load_messages() already does.
        if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, private');

        $limit = 50;
        $page = max(1, min(100000, (int)($_GET['page'] ?? 1)));
        $tab = strtoupper(trim((string)($_GET['tab'] ?? 'ACTIVE')));
        if (!in_array($tab, ['ACTIVE', 'INTERVENED', 'EXPIRED', 'ALL_CHATS'], true)) $tab = 'ACTIVE';
        $search = strtolower(trim((string)($_GET['search'] ?? '')));
        $tag = strtolower(trim((string)($_GET['tag'] ?? '')));
        $agentFilter = strtolower(trim((string)($_GET['agent'] ?? '')));
        $onlyUnread = (string)($_GET['unread'] ?? '') === 'unread';
        $startDate = (string)($_GET['start_date'] ?? '');
        $endDate = (string)($_GET['end_date'] ?? '');
        $focusId = max(0, (int)($_GET['focus'] ?? 0));

        try {
            $pdo = Database::getInstance();
            $timezone = Timezone::get($pdo, $companyId);
            $startUtc = null;
            $endUtc = null;
            if ($this->isInboxCalendarDate($startDate)) {
                $startUtc = Timezone::toUtc($startDate . ' 00:00:00', $timezone);
            }
            if ($this->isInboxCalendarDate($endDate)) {
                $afterEnd = (new \DateTimeImmutable($endDate, new \DateTimeZone($timezone)))
                    ->modify('+1 day')->format('Y-m-d');
                $endUtc = Timezone::toUtc($afterEnd . ' 00:00:00', $timezone);
            }

            // Exactly the same tenant-scoped source as Chat::getActiveChats(),
            // without its LIMIT 500. This query DOES NOT join wa_messages.
            $stmt = $pdo->prepare("SELECT c.id AS conversation_id, c.last_message_at,
                       c.agent_name, COALESCE(c.unread_count, 0) AS unread_count,
                       l.id AS lead_id, l.full_name, l.whatsapp_number,
                       l.lead_stage AS status, l.lead_source, l.created_at,
                       l.tags, l.assigned_to, l.meta_ad_name
                FROM wa_conversations c INNER JOIN leads l ON l.id = c.lead_id
                WHERE c.company_id = ? AND l.company_id = ?
                ORDER BY c.last_message_at DESC, c.id DESC");
            $stmt->execute([$companyId, $companyId]);
            $baseChats = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            // Preserve the current InboxController agent-name mapping.
            $agentMap = [];
            try {
                $agentStmt = $pdo->prepare('SELECT id, full_name AS name FROM users WHERE company_id = ?');
                $agentStmt->execute([$companyId]);
                foreach ($agentStmt->fetchAll(\PDO::FETCH_ASSOC) as $a) $agentMap[$a['id']] = $a['name'];
            } catch (\Exception $e) {
                try {
                    $agentStmt = $pdo->prepare('SELECT id, name FROM users WHERE company_id = ?');
                    $agentStmt->execute([$companyId]);
                    foreach ($agentStmt->fetchAll(\PDO::FETCH_ASSOC) as $a) $agentMap[$a['id']] = $a['name'];
                } catch (\Exception $ignored) {}
            }

            // One grouped message read, not thousands of correlated EXISTS
            // subqueries (the previous pagination version could time out).
            // MAX ignores bot messages as customer interactions because
            // customers are sender_type != agent, exactly as the original JS.
            // Search message content in the SAME grouped read only when a
            // search term is supplied. Match customer messages ONLY (not bot/agent).
            $messageSearchColumn = $search !== ''
                ? ", MAX(CASE WHEN m.sender_type = 'lead' AND LOCATE(?, LOWER(m.message_body)) > 0 THEN 1 ELSE 0 END) AS message_search_match"
                : '';
            $messageStmt = $pdo->prepare("SELECT m.conversation_id,
                    MAX(CASE WHEN m.sender_type != 'agent' THEN m.created_at END) AS last_customer_msg_at,
                    SUM(CASE WHEN m.sender_type = 'agent'
                             AND m.message_body NOT LIKE '[Bot]%' THEN 1 ELSE 0 END) AS agent_replies{$messageSearchColumn}
                FROM wa_messages m
                INNER JOIN wa_conversations c ON c.id = m.conversation_id
                INNER JOIN leads l ON l.id = c.lead_id
                WHERE c.company_id = ? AND l.company_id = ?
                GROUP BY m.conversation_id");
            // Placeholder order: SELECT search term first, tenant checks next.
            $messageStmt->execute($search !== ''
                ? [$search, $companyId, $companyId]
                : [$companyId, $companyId]);
            $messageStats = [];
            while ($m = $messageStmt->fetch(\PDO::FETCH_ASSOC)) {
                $messageStats[(int)$m['conversation_id']] = $m;
            }

            $now = time();
            $counts = ['ACTIVE' => 0, 'INTERVENED' => 0, 'EXPIRED' => 0, 'ALL_CHATS' => 0];
            $filtered = [];
            foreach ($baseChats as $chat) {
                // Non-admin sees exactly their own assigned chat names,
                // matching the original inbox.js permission check.
                if (!empty($chat['assigned_to']) && isset($agentMap[$chat['assigned_to']])) {
                    $chat['agent_name'] = $agentMap[$chat['assigned_to']];
                }
                $effectiveAgent = strtolower(trim((string)($chat['agent_name'] ?? '')));
                if ($role !== 'admin' && ($effectiveAgent === '' || $effectiveAgent !== $agentName)) continue;

                $id = (int)$chat['conversation_id'];
                $stats = $messageStats[$id] ?? [];
                $chat['agent_replies'] = (int)($stats['agent_replies'] ?? 0);
                $chat['last_customer_msg_at'] = $stats['last_customer_msg_at'] ?? null;
                $unreadCount = (int)($chat['unread_count'] ?? 0);
                $metaAd = (string)($chat['meta_ad_name'] ?? '');
                $maxHours = ($metaAd !== '' && $metaAd !== 'null') ? 72 : 24;
                $isExpired = true;
                if ($chat['last_customer_msg_at']) {
                    // wa_messages.created_at is UTC in the current CRM.
                    $customerTime = strtotime($chat['last_customer_msg_at'] . ' UTC');
                    if ($customerTime !== false && (($now - $customerTime) / 3600) <= $maxHours) $isExpired = false;
                }
                if ($unreadCount > 0) $isExpired = false;
                $category = $isExpired ? 'EXPIRED' : ($chat['agent_replies'] > 0 ? 'INTERVENED' : 'ACTIVE');
                $chat['chat_category'] = $category;
                ++$counts[$category];
                ++$counts['ALL_CHATS'];

                // All filters are applied BEFORE LIMIT/OFFSET, as in Website Leads.
                if ($tab !== 'ALL_CHATS' && $category !== $tab) continue;
                // Preserve name/phone matching; also include every conversation
                // containing the query in any saved inbound/outbound message.
                if ($search !== ''
                    && strpos(strtolower((string)($chat['full_name'] ?? '') . ' ' . (string)($chat['whatsapp_number'] ?? '')), $search) === false
                    && empty($stats['message_search_match'])) continue;
                if ($onlyUnread && $unreadCount <= 0) continue;
                if ($tag !== '' && strpos(strtolower((string)($chat['tags'] ?? '')), $tag) === false) continue;
                if ($agentFilter !== '' && strpos($effectiveAgent, $agentFilter) === false) continue;
                $createdAt = (string)($chat['created_at'] ?? '');
                if ($startUtc !== null && $createdAt !== '' && $createdAt < $startUtc) continue;
                if ($endUtc !== null && $createdAt !== '' && $createdAt >= $endUtc) continue;
                $filtered[] = $chat;
            }

            $filteredTotal = count($filtered);
            $totalPages = max(1, (int)ceil($filteredTotal / $limit));
            if ($focusId && $page === 1) {
                foreach ($filtered as $position => $chat) {
                    if ((int)$chat['conversation_id'] === $focusId) {
                        $page = (int)floor($position / $limit) + 1;
                        break;
                    }
                }
            }
            $page = min($page, $totalPages);
            $offset = ($page - 1) * $limit;
            $pageChats = array_slice($filtered, $offset, $limit);
            echo json_encode([
                'status' => 'success', 'chats' => $pageChats,
                'counts' => $counts, 'filtered_total' => $filteredTotal,
                'page' => $page, 'total_pages' => $totalPages, 'page_size' => $limit
            ], JSON_INVALID_UTF8_SUBSTITUTE);
        } catch (\Throwable $e) {
            error_log('Inbox pagination failure: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Inbox list query failed; see PHP error log']);
        }
        exit;
    }

    private function isInboxCalendarDate($value) {
        if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value)) return false;
        $parts = explode('-', $value);
        return checkdate((int)$parts[1], (int)$parts[2], (int)$parts[0]);
    }

    public function update_status() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            
            $lead_id = $input['lead_id'] ?? null;
            $status = trim($input['status'] ?? '');

            if ($lead_id && !empty($status)) {
                $pdo = Database::getInstance();
                if (!$this->leadAllowed($pdo, $lead_id)) $this->denyAccess();
                $pdo->prepare("UPDATE leads SET lead_stage = ? WHERE id = ?")->execute([$status, $lead_id]);
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error']);
            }
            exit;
        }
    }

    public function add_tag() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            
            $lead_id = $input['lead_id'] ?? null;
            $new_tag = trim($input['tag'] ?? '');

            if ($lead_id && !empty($new_tag)) {
                $pdo = Database::getInstance();
                if (!$this->leadAllowed($pdo, $lead_id)) $this->denyAccess();

                try {
                    $stmt = $pdo->prepare("SELECT id FROM crm_tags WHERE name = ?");
                    $stmt->execute([$new_tag]);
                    if (!$stmt->fetch()) {
                        $pdo->prepare("INSERT INTO crm_tags (name, created_by) VALUES (?, ?)")->execute([$new_tag, $_SESSION['user_id']]);
                    }
                } catch (\Exception $e) {
                    $stmt = $pdo->prepare("SELECT id FROM crm_tags WHERE name = ?");
                    $stmt->execute([$new_tag]);
                    if (!$stmt->fetch()) {
                        $pdo->prepare("INSERT INTO crm_tags (name) VALUES (?)")->execute([$new_tag]);
                    }
                }

                $stmt = $pdo->prepare("SELECT tags FROM leads WHERE id = ?");
                $stmt->execute([$lead_id]);
                $lead = $stmt->fetch();
                
                $current_tags = $lead['tags'] ? explode(',', $lead['tags']) : [];
                if (!in_array($new_tag, $current_tags)) {
                    $current_tags[] = $new_tag;
                    $updated_tags = implode(',', $current_tags);
                    $pdo->prepare("UPDATE leads SET tags = ? WHERE id = ?")->execute([$updated_tags, $lead_id]);
                }
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error']);
            }
            exit;
        }
    }

    public function remove_tag() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            
            $lead_id = $input['lead_id'] ?? null;
            $tag_to_remove = trim($input['tag'] ?? '');

            if ($lead_id && !empty($tag_to_remove)) {
                $pdo = Database::getInstance();
                if (!$this->leadAllowed($pdo, $lead_id)) $this->denyAccess();
                $stmt = $pdo->prepare("SELECT tags FROM leads WHERE id = ?");
                $stmt->execute([$lead_id]);
                $lead = $stmt->fetch();
                
                $current_tags = $lead['tags'] ? explode(',', $lead['tags']) : [];
                $new_tags_array = array_filter($current_tags, function($t) use ($tag_to_remove) {
                    return strtolower(trim($t)) !== strtolower($tag_to_remove);
                });
                
                $updated_tags = implode(',', $new_tags_array);
                $pdo->prepare("UPDATE leads SET tags = ? WHERE id = ?")->execute([$updated_tags, $lead_id]);
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error']);
            }
            exit;
        }
    }

    public function send_message() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) {
            http_response_code(403);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            
            $input = json_decode(file_get_contents('php://input'), true);
            $conversation_id = $input['conversation_id'] ?? null;
            $message_text = trim($input['message'] ?? '');
            
            $is_internal = isset($input['is_internal']) && $input['is_internal'] == 1;
            $base64_data = $input['attachment_base64'] ?? null;
            $is_template = isset($input['is_template']) && $input['is_template'] == 1;
            $template_name = $input['template_name'] ?? '';
            $template_lang = $input['template_language'] ?? 'en_US'; 
            $template_values = $input['template_values'] ?? []; // Optional approved-template variables from WA Templates popup.

            
            // WhatsApp reply reference: stored only if the quoted message belongs to this conversation.
            $reply_to_message_id = (!empty($input['reply_to_message_id']) && is_string($input['reply_to_message_id']) && $input['reply_to_message_id'] !== 'undefined')
                ? substr($input['reply_to_message_id'], 0, 255) : null;
            
            $media_url = null;
            $msg_type = 'text';
            $mime_type = null;

            if (!$conversation_id || (empty($message_text) && empty($base64_data) && !$is_template)) {
                echo json_encode(['status' => 'error', 'message' => 'Missing message or attachment']);
                exit;
            }

            // Check access BEFORE uploading files, sending WhatsApp or writing chat rows.
            $pdo = Database::getInstance();
            if (!$this->conversationAllowed($pdo, $conversation_id)) $this->denyAccess();

            if ($reply_to_message_id !== null) {
                $referenceCheck = $pdo->prepare('SELECT 1 FROM wa_messages WHERE conversation_id = ? AND wa_message_id = ? LIMIT 1');
                $referenceCheck->execute([$conversation_id, $reply_to_message_id]);
                if (!$referenceCheck->fetchColumn()) {
                    $reply_to_message_id = null; // Never link to a message in another chat.
                }
            }

            if (!empty($base64_data)) {
                $parts = explode(';base64,', $base64_data);
                if (count($parts) === 2) {
                    $mime_type = str_replace('data:', '', $parts[0]);
                    $file_data = base64_decode($parts[1]);
                    
                    $ext = 'bin'; 
                    if (strpos($mime_type, 'image/') !== false) {
                        $msg_type = 'image';
                        $ext = str_replace('image/', '', $mime_type);
                        if($ext == 'jpeg') $ext = 'jpg';
                    } elseif (strpos($mime_type, 'video/') !== false) {
                        $msg_type = 'video';
                        $ext = 'mp4';
                    } elseif (strpos($mime_type, 'audio/') !== false) {
                        $msg_type = 'audio';
                        $ext = 'mp3';
                    } elseif (strpos($mime_type, 'pdf') !== false) {
                        $msg_type = 'document';
                        $ext = 'pdf';
                    } else {
                        $msg_type = 'document';
                        $ext = 'docx';
                    }
                    
                    $file_name = time() . '_' . uniqid() . '.' . $ext;
                    $upload_path = $_SERVER['DOCUMENT_ROOT'] . '/uploads/chat/';
                    if (!is_dir($upload_path)) {
                        mkdir($upload_path, 0777, true);
                    }
                    file_put_contents($upload_path . $file_name, $file_data);
                    $media_url = rtrim(BASE_URL, '/') . '/uploads/chat/' . $file_name;
                }
            }

            if ($is_template) {
                $msg_type = 'template';
            }

            $pdo = Database::getInstance();
            $stmt = $pdo->prepare("SELECT l.id as lead_id, l.whatsapp_number, l.phone_number, l.meta_ad_name FROM wa_conversations c JOIN leads l ON c.lead_id = l.id WHERE c.id = ? AND c.company_id = ? AND l.company_id = ?");
            $stmt->execute([$conversation_id, $this->companyId(), $this->companyId()]);
            $lead = $stmt->fetch();

            if (!$lead) {
                echo json_encode(['status' => 'error', 'message' => 'Lead not found']);
                exit;
            }

            // ========================================================
            // 🔥 SERVER-SIDE 24/72H STRICT BLOCK (PREVENTS SINGLE TICK) 🔥
            // ========================================================
            if (!$is_internal && !$is_template) {
                $time_check = $pdo->prepare("SELECT TIMESTAMPDIFF(HOUR, COALESCE((SELECT created_at FROM wa_messages WHERE conversation_id = ? AND sender_type = 'lead' ORDER BY created_at DESC LIMIT 1), (SELECT created_at FROM leads WHERE id = ?)), CURRENT_TIMESTAMP) as hours_diff");
                $time_check->execute([$conversation_id, $lead['lead_id']]);
                $hours_diff = (int)$time_check->fetchColumn();
                
                $max_hours = !empty($lead['meta_ad_name']) ? 72 : 24;
                
                if ($hours_diff >= $max_hours) {
                    echo json_encode(['status' => 'error', 'message' => "WhatsApp Block: The $max_hours-Hour window has expired! You can ONLY send Template messages."]);
                    exit;
                }
            }

            $recipient_phone = $lead['whatsapp_number'] ?? $lead['phone_number'];
            $recipient_phone_clean = preg_replace('/[^0-9]/', '', $recipient_phone);
            
            $wa_message_id = null;

            if (!$is_internal) {
                if ($is_template) {
                    $phone_id = defined('WA_PHONE_NUMBER_ID') ? WA_PHONE_NUMBER_ID : '';
                    $token = defined('WA_ACCESS_TOKEN') ? WA_ACCESS_TOKEN : '';
                    
                    // Only this template branch is changed. Resolve its LIVE approved Meta
                    // definition and construct exactly the components Meta expects.
                    // Existing chat, media, assignment and bot-stop behavior is untouched.
                    $definitionResult = $this->crmTemplateDefinition((string)$template_name, (string)$template_lang);
                    if (isset($definitionResult['error'])) {
                        echo json_encode(['status' => 'error', 'message' => $definitionResult['error']]);
                        exit;
                    }
                    $componentResult = $this->crmTemplateSendComponents($definitionResult['definition'], $template_values);
                    if (isset($componentResult['error'])) {
                        echo json_encode(['status' => 'error', 'message' => $componentResult['error']]);
                        exit;
                    }
                    // Show the ACTUAL approved template text and selected gallery
                    // image/video inside Inbox after Meta accepts the message.
                    // Never trust browser-submitted preview text for chat history.
                    $message_text = $this->scpkTemplatePreviewText($definitionResult['definition'], $template_values);
                    $galleryId = (string)($input['template_media_library_id'] ?? '');
                    if ($galleryId !== '') {
                        $galleryMedia = $this->scpkMediaRecord($galleryId);
                        if (!$galleryMedia) {
                            echo json_encode(['status'=>'error','message'=>'Selected gallery media no longer exists']); exit;
                        }
                        $templateHeaderFormat = '';
                        foreach (($definitionResult['definition']['components'] ?? []) as $comp) {
                            if (strtoupper((string)($comp['type'] ?? '')) === 'HEADER') {
                                $templateHeaderFormat = strtoupper((string)($comp['format'] ?? ''));
                            }
                        }
                        if (($templateHeaderFormat === 'IMAGE' && strpos($galleryMedia['mime'], 'image/') !== 0)
                            || ($templateHeaderFormat === 'VIDEO' && $galleryMedia['mime'] !== 'video/mp4')
                            || !in_array($templateHeaderFormat, ['IMAGE','VIDEO'], true)) {
                            echo json_encode(['status'=>'error','message'=>'Gallery file does not match the approved template header']); exit;
                        }
                        $media_url = rtrim(BASE_URL, '/') . '/inbox/template_media_preview?id=' . $galleryId;
                        $mime_type = $galleryMedia['mime'];
                    }
                    $postData = [
                        'messaging_product' => 'whatsapp',
                        'to' => $recipient_phone_clean,
                        'type' => 'template',
                        'template' => [
                            'name' => $definitionResult['definition']['name'],
                            'language' => ['code' => $definitionResult['definition']['language']]
                        ]
                    ];
                    if ($componentResult['components']) {
                        $postData['template']['components'] = $componentResult['components'];
                    }
                    if (empty($token) || empty($phone_id)) {
                        echo json_encode(['status' => 'error', 'message' => 'WhatsApp phone ID/token is not configured']);
                        exit;
                    }
                    $ch = curl_init("https://graph.facebook.com/v24.0/{$phone_id}/messages");
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_SSL_VERIFYPEER => true,
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => json_encode($postData, JSON_UNESCAPED_UNICODE),
                        CURLOPT_CONNECTTIMEOUT => 5,
                        CURLOPT_TIMEOUT => 18,
                        CURLOPT_HTTPHEADER => [
                            'Authorization: Bearer ' . $token,
                            'Content-Type: application/json'
                        ]
                    ]);
                    $res = curl_exec($ch);
                    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $errno = (int)curl_errno($ch);
                    curl_close($ch);
                    $resJson = is_string($res) ? json_decode($res, true) : null;
                    if (!is_array($resJson)) {
                        echo json_encode(['status' => 'error', 'message' =>
                            'Meta API response unconfirmed (HTTP ' . $httpCode . ', transport ' . $errno . '). Check recipient WhatsApp before resending.']);
                        exit;
                    }
                    if ($httpCode < 200 || $httpCode >= 300) {
                        $errorCode = $resJson['error']['code'] ?? $httpCode;
                        $errorMsg = $resJson['error']['message'] ?? 'Meta rejected the template';
                        echo json_encode(['status' => 'error', 'message' => 'Meta API Rejected (#' . $errorCode . '): ' . $errorMsg]);
                        exit;
                    }
                    // Meta acceptance is NOT delivery; existing statuses update later.

                    if (isset($resJson['error'])) {
                        $meta_error = $resJson['error']['message'] ?? 'Unknown Error';
                        echo json_encode(['status' => 'error', 'message' => "Meta API Rejected: " . $meta_error]);
                        exit;
                    }
                    
                    if (isset($resJson['messages'][0]['id'])) {
                        $wa_message_id = $resJson['messages'][0]['id'];
                    }

                } else {
                    $waService = new \Services\WhatsAppService();
                    $apiResponse = null;

                    // 🔥 SENDING REPLY CONTEXT TO META 🔥
                    if ($media_url) {
                        if ($msg_type === 'image') $apiResponse = $waService->sendImageMessage($recipient_phone_clean, $media_url, $message_text, $reply_to_message_id);
                        elseif ($msg_type === 'video') $apiResponse = $waService->sendVideoMessage($recipient_phone_clean, $media_url, $message_text, $reply_to_message_id);
                        elseif ($msg_type === 'audio') $apiResponse = $waService->sendAudioMessage($recipient_phone_clean, $media_url, $reply_to_message_id);
                        elseif ($msg_type === 'document') $apiResponse = $waService->sendDocumentMessage($recipient_phone_clean, $media_url, $message_text, $reply_to_message_id);
                    } else if (!empty($message_text)) {
                        $apiResponse = $waService->sendTextMessage($recipient_phone_clean, $message_text, $reply_to_message_id);
                    }

                    if (isset($apiResponse['response']['error'])) {
                        echo json_encode(['status' => 'error', 'message' => "Meta Delivery Failed: " . $apiResponse['response']['error']['message']]);
                        exit;
                    }

                    if ($apiResponse && isset($apiResponse['response']['messages'][0]['id'])) {
                        $wa_message_id = $apiResponse['response']['messages'][0]['id'];
                    }
                }

                if (empty($wa_message_id)) {
                    echo json_encode(['status' => 'error', 'message' => "Failed to fetch Message ID. Check Meta Configuration."]);
                    exit;
                }
            }

            $stmt = $pdo->prepare("
                INSERT INTO wa_messages (wa_message_id, conversation_id, sender_type, message_type, message_body, media_url, mime_type, delivery_status, is_internal, reply_to_wa_message_id) 
                VALUES (?, ?, 'agent', ?, ?, ?, ?, 'sent', ?, ?)
            ");
            $stmt->execute([$wa_message_id, $conversation_id, $msg_type, $message_text, $media_url, $mime_type, $is_internal ? 1 : 0, $is_internal ? null : ($is_template ? null : $reply_to_message_id)]);

            $pdo->prepare("UPDATE wa_conversations SET last_message_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$conversation_id]);

            // ==========================================
            // 🔥 BOT AUTO-STOP LOGIC (AGENT TAKEOVER) 🔥
            // ==========================================
            if (!$is_internal) {
                $stateFile = __DIR__ . '/bot_states.json';
                $states = file_exists($stateFile) ? json_decode(file_get_contents($stateFile), true) : [];
                
                if (!isset($states[$recipient_phone_clean])) {
                    $states[$recipient_phone_clean] = ['step' => 'HUMAN_AGENT', 'data' => []];
                } else {
                    $states[$recipient_phone_clean]['step'] = 'HUMAN_AGENT'; // Bot ko chup kara do
                }
                
                file_put_contents($stateFile, json_encode($states, JSON_PRETTY_PRINT));
            }

            echo json_encode(['status' => 'success', 'message_body' => $message_text, 'media_url' => $media_url]);
            exit;
        }
    }
    
    public function assign_chat() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            header('Content-Type: application/json');
            $input = json_decode(file_get_contents('php://input'), true);
            $convo_id = $input['conversation_id'] ?? null;
            $agent_name = $input['agent_name'] ?? null;
            $agent_id = $input['agent_id'] ?? null;
            
            if ($convo_id) {
                $pdo = Database::getInstance();
                if (!$this->conversationAllowed($pdo, $convo_id)) $this->denyAccess();
                if ($agent_id && !$this->agentAllowed($pdo, $agent_id)) $this->denyAccess();

                if ($agent_name) {
                    $pdo->prepare("UPDATE wa_conversations SET agent_name = ? WHERE id = ? AND company_id = ?")
                        ->execute([$agent_name, $convo_id, $this->companyId()]);
                }
                
                if ($agent_id) {
                    $stmt = $pdo->prepare("SELECT lead_id FROM wa_conversations WHERE id = ? AND company_id = ?");
                    $stmt->execute([$convo_id, $this->companyId()]);
                    $convo = $stmt->fetch();
                    if ($convo) {
                        $pdo->prepare("UPDATE leads SET assigned_to = ? WHERE id = ? AND company_id = ?")
                            ->execute([$agent_id, $convo['lead_id'], $this->companyId()]);
                    }
                }
                
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error']);
            }
            exit;
        }
    }

    // WA Templates manager: find a recipient strictly within this CRM company.
    // Sending still uses the existing inbox/send_message access checks and DB logic.
    public function template_recipient() {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, private');
        $companyId = $this->companyId();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'GET required']); return;
        }
        $phone = preg_replace('/[^0-9]/', '', (string)($_GET['phone'] ?? ''));
        if (strlen($phone) < 10 || strlen($phone) > 15) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Enter a valid WhatsApp number (10–15 digits)']); return;
        }
        $variants = [$phone];
        if (strlen($phone) === 10) $variants[] = '91' . $phone;
        if (strlen($phone) === 12 && substr($phone, 0, 2) === '91') $variants[] = substr($phone, 2);
        $variants = array_values(array_unique($variants));
        $marks = implode(',', array_fill(0, count($variants), '?'));
        try {
            $pdo = Database::getInstance();
            $sql = "SELECT l.id AS lead_id, l.full_name, c.id AS conversation_id
                    FROM leads l INNER JOIN wa_conversations c
                      ON c.lead_id = l.id AND c.company_id = l.company_id
                    WHERE l.company_id = ? AND
                      (l.whatsapp_number IN ($marks) OR l.phone_number IN ($marks))
                    ORDER BY c.last_message_at DESC, c.id DESC LIMIT 20";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_merge([$companyId], $variants, $variants));
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            if (!$rows) {
                echo json_encode(['status' => 'error', 'message' => 'This phone has no CRM chat. Open an existing lead/chat first.']); return;
            }
            if (count(array_unique(array_column($rows, 'lead_id'))) > 1) {
                echo json_encode(['status' => 'error', 'message' => 'More than one CRM lead matches this phone; resolve duplicates before sending.']); return;
            }
            echo json_encode(['status' => 'success', 'lead_name' => $rows[0]['full_name'],
                'conversation_id' => (int)$rows[0]['conversation_id']]);
        } catch (\Throwable $e) {
            error_log('Template recipient lookup error: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Recipient lookup unavailable']);
        }
    }

    // Media header for an approved IMAGE template: upload the selected file directly
    // to Meta's WhatsApp media API. No public web folder or temporary DB record.
    public function template_header_media_upload() {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, private');
        $this->companyId();
        $this->checkOrigin();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'POST required']); return;
        }
        $file = $_FILES['header_media'] ?? null;
        if (!is_array($file) || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            echo json_encode(['status' => 'error', 'message' =>
                'Choose a JPG/PNG image. If uploading fails, check the Hostinger PHP upload limit.']); return;
        }
        $tmp = (string)($file['tmp_name'] ?? '');
        $size = (int)($file['size'] ?? 0);
        if ($size < 1 || $size > 5 * 1024 * 1024 || !is_uploaded_file($tmp)) {
            echo json_encode(['status' => 'error', 'message' => 'Image must be an uploaded JPG/PNG under 5 MB']); return;
        }
        if (!function_exists('finfo_open') || !function_exists('curl_init') || !class_exists('CURLFile')) {
            echo json_encode(['status' => 'error', 'message' => 'Server image upload support is unavailable']); return;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_file($finfo, $tmp) : false;
        if ($finfo) finfo_close($finfo);
        $imageInfo = @getimagesize($tmp);
        if (!in_array($mime, ['image/jpeg', 'image/png'], true) || !$imageInfo) {
            echo json_encode(['status' => 'error', 'message' => 'Only real JPG/PNG images are supported']); return;
        }
        // Verify the selected template is approved and really requires an IMAGE header.
        $def = $this->crmTemplateDefinition((string)($_POST['template_name'] ?? ''),
            (string)($_POST['template_language'] ?? ''));
        if (isset($def['error'])) {
            echo json_encode(['status' => 'error', 'message' => $def['error']]); return;
        }
        $isImageHeader = false;
        foreach (($def['definition']['components'] ?? []) as $component) {
            if (strtoupper((string)($component['type'] ?? '')) === 'HEADER' &&
                strtoupper((string)($component['format'] ?? '')) === 'IMAGE') {
                $isImageHeader = true;
                break;
            }
        }
        if (!$isImageHeader) {
            echo json_encode(['status' => 'error', 'message' => 'The approved template has no image header']); return;
        }
        $token = defined('WA_ACCESS_TOKEN') ? (string)WA_ACCESS_TOKEN : '';
        $phoneId = defined('WA_PHONE_NUMBER_ID') ? (string)WA_PHONE_NUMBER_ID : '';
        if (!$token || !ctype_digit($phoneId)) {
            echo json_encode(['status' => 'error', 'message' => 'WhatsApp media configuration missing']); return;
        }
        $ext = $mime === 'image/png' ? 'png' : 'jpg';
        $ch = curl_init('https://graph.facebook.com/v24.0/' . $phoneId . '/media');
        if (!$ch) {
            echo json_encode(['status' => 'error', 'message' => 'Could not start Meta media upload']); return;
        }
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => [
                'messaging_product' => 'whatsapp',
                'type' => $mime,
                'file' => new \CURLFile($tmp, $mime, 'template-header.' . $ext)
            ],
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 25
        ]);
        $raw = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $meta = is_string($raw) ? json_decode($raw, true) : null;
        $mediaId = is_array($meta) ? ($meta['id'] ?? '') : '';
        if ($http >= 200 && $http < 300 && is_string($mediaId) &&
            preg_match('/^[0-9]{5,64}$/', $mediaId)) {
            echo json_encode(['status' => 'success', 'media_id' => $mediaId]); return;
        }
        $code = is_array($meta) ? ($meta['error']['code'] ?? 'unknown') : 'transport';
        error_log('Template image header upload failed; Meta HTTP ' . $http . ' code ' . $code);
        echo json_encode(['status' => 'error',
            'message' => 'Meta image upload failed (HTTP ' . $http . ', code ' . $code . '). Image was not sent.']);
    }

    // Read current WABA template definition on the server; never trust the browser's
    // cached component schema when constructing send parameters.
    private function crmTemplateDefinition(string $name, string $language): array {
        if (!preg_match('/^[a-z0-9_]{1,512}$/', $name) ||
            !preg_match('/^[A-Za-z_]{2,16}$/', $language)) {
            return ['error' => 'Invalid template name/language'];
        }
        $waba = defined('WA_WABA_ID') ? (string)WA_WABA_ID : '';
        $token = defined('WA_ACCESS_TOKEN') ? (string)WA_ACCESS_TOKEN : '';
        if (!ctype_digit($waba) || !$token) return ['error' => 'WhatsApp template configuration missing'];
        $url = "https://graph.facebook.com/v24.0/{$waba}/message_templates?fields=name,language,status,parameter_format,components&limit=100";
        for ($page = 0; $page < 5; ++$page) {
            $ch = curl_init($url);
            if (!$ch) return ['error' => 'Meta API connection could not start'];
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 15,
                CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token]]);
            $body = curl_exec($ch);
            $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $decoded = is_string($body) ? json_decode($body, true) : null;
            if ($http !== 200 || !is_array($decoded)) {
                return ['error' => 'Could not verify template definition from Meta. Please retry later.'];
            }
            foreach (($decoded['data'] ?? []) as $item) {
                if (($item['name'] ?? '') === $name && ($item['language'] ?? '') === $language) {
                    if (($item['status'] ?? '') !== 'APPROVED') return ['error' => 'Template is not approved in Meta'];
                    return ['definition' => $item];
                }
            }
            $next = $decoded['paging']['next'] ?? '';
            // Follow Meta-only pagination, never arbitrary URLs from an API response.
            if (!$next || !is_string($next) || !preg_match('~^https://graph\.facebook\.com/v24\.0/~', $next)) break;
            $url = $next;
        }
        return ['error' => 'Approved template was not found in the configured WABA'];
    }

    // Build only approved template component types. Unsupported advanced formats
    // are rejected BEFORE contacting Meta, rather than sending wrong parameters.
    private function crmTemplateSendComponents(array $definition, $values): array {
        if (!is_array($values)) return ['error' => 'Template variables must be an object'];
        $named = strtoupper((string)($definition['parameter_format'] ?? 'POSITIONAL')) === 'NAMED';
        $components = [];
        foreach (($definition['components'] ?? []) as $component) {
            $type = strtoupper((string)($component['type'] ?? ''));
            if ($type === 'HEADER') {
                $format = strtoupper((string)($component['format'] ?? 'TEXT'));
                if ($format === 'TEXT') {
                    preg_match_all('/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/', (string)($component['text'] ?? ''), $matches);
                    $keys = array_values(array_unique($matches[1]));
                    $params = [];
                    foreach ($keys as $key) {
                        $value = trim((string)($values['header_text'][$key] ?? ''));
                        if ($value === '' || strlen($value) > 1024) return ['error' => 'Fill header variable ' . $key];
                        $param = ['type' => 'text', 'text' => $value];
                        if ($named && !ctype_digit($key)) $param['parameter_name'] = $key;
                        $params[] = $param;
                    }
                    if ($params) $components[] = ['type' => 'header', 'parameters' => $params];
                } elseif (in_array($format, ['IMAGE', 'VIDEO', 'DOCUMENT'], true)) {
                    // IMAGE headers can use either an uploaded Meta media ID or an HTTPS image URL.
                    // VIDEO / DOCUMENT headers keep their existing URL behavior unchanged.
                    $mediaId = in_array($format, ['IMAGE', 'VIDEO'], true) ? trim((string)($values['header_media_id'] ?? '')) : '';
                    if ($mediaId !== '') {
                        if (!preg_match('/^[0-9]{5,64}$/', $mediaId)) {
                            return ['error' => 'Invalid uploaded Meta media ID; prepare the gallery media again'];
                        }
                        $mediaParam = ['id' => $mediaId];
                    } else {
                        $url = trim((string)($values['header_media_url'] ?? ''));
                        if (!filter_var($url, FILTER_VALIDATE_URL) || parse_url($url, PHP_URL_SCHEME) !== 'https'
                            || strlen($url) > 2048) {
                            return ['error' => $format === 'IMAGE'
                                ? 'IMAGE header: choose a JPG/PNG file or enter a full public HTTPS image URL'
                                : 'Enter a full public HTTPS ' . strtolower($format) . ' header URL'];
                        }
                        $mediaParam = ['link' => $url];
                    }
                    $key = strtolower($format);
                    $param = ['type' => $key, $key => $mediaParam];
                    if ($format === 'DOCUMENT') $param['document']['filename'] = basename((string)parse_url($url, PHP_URL_PATH));
                    $components[] = ['type' => 'header', 'parameters' => [$param]];
                } else return ['error' => 'This template header format is not supported for direct sending'];
            } elseif ($type === 'BODY') {
                preg_match_all('/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/', (string)($component['text'] ?? ''), $matches);
                $keys = array_values(array_unique($matches[1]));
                if (!$named) usort($keys, static function($a,$b) { return (int)$a <=> (int)$b; });
                $params = [];
                foreach ($keys as $key) {
                    $value = trim((string)($values['body'][$key] ?? ''));
                    if ($value === '' || strlen($value) > 1024) return ['error' => 'Fill body variable ' . $key];
                    $param = ['type' => 'text', 'text' => $value];
                    if ($named) $param['parameter_name'] = $key;
                    $params[] = $param;
                }
                if ($params) $components[] = ['type' => 'body', 'parameters' => $params];
            } elseif ($type === 'BUTTONS') {
                foreach (($component['buttons'] ?? []) as $index => $button) {
                    $btype = strtoupper((string)($button['type'] ?? ''));
                    if ($btype === 'URL' && preg_match('/\{\{\s*1\s*\}\}/', (string)($button['url'] ?? ''))) {
                        $value = trim((string)($values['button_url'][(string)$index] ?? ''));
                        if ($value === '' || strlen($value) > 1024) return ['error' => 'Fill dynamic URL for button ' . ($index+1)];
                        $components[] = ['type'=>'button', 'sub_type'=>'url', 'index'=>(string)$index,
                            'parameters'=>[['type'=>'text','text'=>$value]]];
                    } elseif (!in_array($btype, ['URL', 'PHONE_NUMBER', 'QUICK_REPLY', 'COPY_CODE'], true)) {
                        return ['error' => 'This template has an advanced button unsupported by this simple sender'];
                    }
                }
            } elseif ($type === 'FOOTER') {
                continue;
            } else return ['error' => 'This advanced Meta template component is not supported by this sender'];
        }
        return ['components' => $components];
    }

    private function scpkCheckActionToken(): void {
        $expected = (string)($_SESSION['scpk_action_csrf'] ?? '');
        $provided = (string)($_SERVER['HTTP_X_SCPK_CSRF'] ?? '');
        if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
            $this->denyAccess();
        }
    }

    // SCPK private media gallery: files are OUTSIDE public_html and served only to
    // authenticated CRM users of this company. No public image URLs are created.
    private function scpkMediaDirectory(bool $create = false): string {
        $dir = dirname(__DIR__, 3) . '/crm_private_template_media/company_' . $this->companyId();
        if ($create && !is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new \RuntimeException('Cannot create private media directory');
        }
        return $dir;
    }

    private function scpkMediaRecord(string $id): ?array {
        if (!preg_match('/^[a-f0-9]{32}$/', $id)) return null;
        $dir = $this->scpkMediaDirectory();
        $path = $dir . '/' . $id . '.json';
        if (!is_file($path) || !is_readable($path)) return null;
        $record = json_decode((string)@file_get_contents($path), true);
        if (!is_array($record) || ($record['id'] ?? '') !== $id ||
            !in_array(($record['mime'] ?? ''), ['image/jpeg', 'image/png', 'video/mp4'], true)) return null;
        $ext = ['image/jpeg'=>'jpg','image/png'=>'png','video/mp4'=>'mp4'][$record['mime']];
        $record['file_path'] = $dir . '/' . $id . '.' . $ext;
        return is_file($record['file_path']) && is_readable($record['file_path']) ? $record : null;
    }

    public function template_media_library() {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: private, no-store');
        $this->companyId();
        $folder = $this->scpkMediaDirectory();
        $items = [];
        if (is_dir($folder)) {
            foreach ((array)glob($folder . '/*.json') as $path) {
                $id = basename($path, '.json');
                $record = $this->scpkMediaRecord($id);
                if (!$record) continue;
                $items[] = [
                    'id'=>$id, 'name'=>(string)($record['name'] ?? 'Media'),
                    'mime'=>$record['mime'], 'size'=>(int)($record['size'] ?? 0),
                    'created_at'=>(int)($record['created_at'] ?? 0),
                    'preview_url'=>rtrim(BASE_URL, '/') . '/inbox/template_media_preview?id=' . $id
                ];
            }
        }
        usort($items, static function($a, $b) { return $b['created_at'] <=> $a['created_at']; });
        echo json_encode(['status'=>'success', 'data'=>array_slice($items, 0, 500)]);
    }

    public function template_media_upload() {
        header('Content-Type: application/json; charset=utf-8');
        $this->companyId(); $this->checkOrigin(); $this->scpkCheckActionToken();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); echo json_encode(['status'=>'error','message'=>'POST required']); return; }
        $item = $_FILES['media'] ?? null;
        if (!is_array($item) || (int)($item['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            echo json_encode(['status'=>'error','message'=>'Select JPG, PNG, or MP4. Check Hostinger upload_max_filesize / post_max_size.']); return;
        }
        $tmp = (string)($item['tmp_name'] ?? '');
        $size = (int)($item['size'] ?? 0);
        if ($size < 1 || !is_uploaded_file($tmp) || !function_exists('finfo_open')) {
            echo json_encode(['status'=>'error','message'=>'Invalid uploaded file']); return;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_file($finfo, $tmp) : false;
        if ($finfo) finfo_close($finfo);
        if (!in_array($mime, ['image/jpeg','image/png','video/mp4'], true)) {
            echo json_encode(['status'=>'error','message'=>'Only genuine JPG/PNG images or MP4 videos can be saved']); return;
        }
        $limit = $mime === 'video/mp4' ? 16 * 1024 * 1024 : 5 * 1024 * 1024;
        if ($size > $limit) { echo json_encode(['status'=>'error','message'=>'Media too large. Image maximum 5MB; video maximum 16MB.']); return; }
        if ($mime !== 'video/mp4' && !@getimagesize($tmp)) {
            echo json_encode(['status'=>'error','message'=>'Invalid image content']); return;
        }
        try {
            $dir = $this->scpkMediaDirectory(true);
            $id = bin2hex(random_bytes(16));
            $ext = ['image/jpeg'=>'jpg','image/png'=>'png','video/mp4'=>'mp4'][$mime];
            $filePath = $dir . '/' . $id . '.' . $ext;
            if (!@move_uploaded_file($tmp, $filePath)) throw new \RuntimeException('Media file could not be saved');
            @chmod($filePath, 0600);
            $record = ['id'=>$id,'name'=>substr(basename((string)($item['name'] ?? 'Media')),0,120),
                'mime'=>$mime, 'size'=>$size, 'created_at'=>time()];
            $saved = @file_put_contents($dir . '/' . $id . '.json.tmp', json_encode($record, JSON_UNESCAPED_UNICODE), LOCK_EX);
            if ($saved === false || !@rename($dir . '/' . $id . '.json.tmp', $dir . '/' . $id . '.json')) {
                @unlink($filePath); throw new \RuntimeException('Media index could not be saved');
            }
            echo json_encode(['status'=>'success','media'=>['id'=>$id,'name'=>$record['name'],'mime'=>$mime,'size'=>$size]]);
        } catch (\Throwable $e) {
            error_log('SCPK template media save error: ' . $e->getMessage());
            echo json_encode(['status'=>'error','message'=>'Cannot save private media. Check directory permissions.']);
        }
    }

    public function template_media_preview() {
        $this->companyId();
        $id = (string)($_GET['id'] ?? '');
        $item = $this->scpkMediaRecord($id);
        if (!$item) { http_response_code(404); exit; }
        $path = $item['file_path']; $size = (int)filesize($path);
        header('Content-Type: ' . $item['mime']);
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: inline');
        header('Cache-Control: private, no-store');
        header('Accept-Ranges: bytes');
        $start = 0; $end = $size - 1;
        $range = $_SERVER['HTTP_RANGE'] ?? '';
        if ($range !== '') {
            if (!preg_match('/^bytes=(\d*)-(\d*)$/', $range, $match)) {
                http_response_code(416); header('Content-Range: bytes */' . $size); exit;
            }
            if ($match[1] === '' && $match[2] === '') { http_response_code(416); exit; }
            if ($match[1] === '') {
                $suffix = (int)$match[2];
                if ($suffix <= 0) { http_response_code(416); exit; }
                $start = max(0, $size - $suffix);
            } else {
                $start = (int)$match[1];
                if ($match[2] !== '') $end = min($end, (int)$match[2]);
            }
            if ($start > $end || $start >= $size) {
                http_response_code(416); header('Content-Range: bytes */' . $size); exit;
            }
            http_response_code(206);
            header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
        }
        header('Content-Length: ' . ($end - $start + 1));
        $fh = @fopen($path, 'rb');
        if (!$fh) exit;
        fseek($fh, $start); $remain = $end - $start + 1;
        while ($remain > 0 && !feof($fh)) {
            $chunk = fread($fh, min($remain, 65536));
            if ($chunk === false || $chunk === '') break;
            echo $chunk; $remain -= strlen($chunk);
        }
        fclose($fh);
    }

    public function template_media_prepare() {
        header('Content-Type: application/json; charset=utf-8');
        $this->companyId(); $this->checkOrigin(); $this->scpkCheckActionToken();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); echo json_encode(['status'=>'error','message'=>'POST required']); return; }
        $item = $this->scpkMediaRecord((string)($_POST['media_id'] ?? ''));
        if (!$item) { echo json_encode(['status'=>'error','message'=>'Gallery media not found']); return; }
        $def = $this->crmTemplateDefinition((string)($_POST['template_name'] ?? ''), (string)($_POST['template_language'] ?? ''));
        if (isset($def['error'])) { echo json_encode(['status'=>'error','message'=>$def['error']]); return; }
        $required = null;
        foreach (($def['definition']['components'] ?? []) as $c) {
            if (strtoupper((string)($c['type'] ?? '')) === 'HEADER') {
                $format = strtoupper((string)($c['format'] ?? ''));
                if ($format === 'IMAGE' || $format === 'VIDEO') $required = strtolower($format);
            }
        }
        $kind = strpos($item['mime'], 'image/') === 0 ? 'image' : 'video';
        if ($required === null || $required !== $kind) { echo json_encode(['status'=>'error','message'=>'Selected media does not match approved template header']); return; }
        $token = defined('WA_ACCESS_TOKEN') ? (string)WA_ACCESS_TOKEN : '';
        $phone = defined('WA_PHONE_NUMBER_ID') ? (string)WA_PHONE_NUMBER_ID : '';
        if (!$token || !ctype_digit($phone) || !function_exists('curl_init') || !class_exists('CURLFile')) {
            echo json_encode(['status'=>'error','message'=>'Meta upload configuration not available']); return;
        }
        $ch = curl_init('https://graph.facebook.com/v24.0/' . $phone . '/media');
        if (!$ch) { echo json_encode(['status'=>'error','message'=>'Cannot connect to Meta']); return; }
        curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>[
                'messaging_product'=>'whatsapp', 'type'=>$item['mime'],
                'file'=>new \CURLFile($item['file_path'], $item['mime'], basename($item['file_path']))],
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_CONNECTTIMEOUT=>5, CURLOPT_TIMEOUT=>40,
            CURLOPT_HTTPHEADER=>['Authorization: Bearer ' . $token]]);
        $raw = curl_exec($ch); $http=(int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        $mediaId = is_array($data) ? (string)($data['id'] ?? '') : '';
        if ($http >= 200 && $http < 300 && preg_match('/^[0-9]{5,64}$/', $mediaId)) {
            echo json_encode(['status'=>'success','media_id'=>$mediaId,'kind'=>$kind]); return;
        }
        error_log('SCPK media gallery Meta upload failed HTTP ' . $http . ' code ' . (is_array($data) ? ($data['error']['code'] ?? 'unknown') : 'transport'));
        echo json_encode(['status'=>'error','message'=>'Meta rejected media upload. Check Meta permissions/format (HTTP ' . $http . ').']);
    }

    // Generate a readable WhatsApp chat bubble from the live approved template.
    // This does not change the outgoing Meta template payload.
    private function scpkTemplatePreviewText(array $definition, $values): string {
        $values = is_array($values) ? $values : [];
        $sections = ['[Template: ' . (string)($definition['name'] ?? '') . ']'];
        foreach (($definition['components'] ?? []) as $part) {
            $type = strtoupper((string)($part['type'] ?? ''));
            if (!in_array($type, ['HEADER','BODY','FOOTER'], true)) continue;
            if ($type === 'HEADER' && strtoupper((string)($part['format'] ?? 'TEXT')) !== 'TEXT') continue;
            $text = (string)($part['text'] ?? '');
            if ($text === '') continue;
            $category = $type === 'HEADER' ? 'header_text' : ($type === 'BODY' ? 'body' : 'footer');
            if ($category !== 'footer') {
                $text = preg_replace_callback('/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/',
                    static function ($match) use ($values, $category) {
                        return (string)($values[$category][$match[1]] ?? $match[0]);
                    }, $text);
            }
            $sections[] = $text;
        }
        return substr(implode("\n\n", $sections), 0, 8000);
    }

    public function get_templates() {
        $this->companyId();
        $waba_id = defined('WA_WABA_ID') ? WA_WABA_ID : ''; 
        $access_token = defined('WA_ACCESS_TOKEN') ? WA_ACCESS_TOKEN : '';

        if (empty($waba_id) || empty($access_token)) {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'error', 'message' => 'WABA ID or Access Token is missing in config.php']);
            exit;
        }

        $url = "https://graph.facebook.com/v24.0/{$waba_id}/message_templates?limit=100";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        header('Content-Type: application/json');
        
        if ($httpcode !== 200) {
            echo json_encode(['status' => 'error', 'error_detail' => json_decode($response, true)]);
            exit;
        }

        echo $response;
        exit;
    }

    public function get_macros() {
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        
        $pdo = Database::getInstance();

        try { $pdo->query("SELECT media_url FROM agent_macros LIMIT 1"); } 
        catch (\Exception $e) { $pdo->exec("ALTER TABLE agent_macros ADD COLUMN media_url VARCHAR(255) NULL DEFAULT NULL"); }

        try {
            $stmt = $pdo->prepare("SELECT m.*, u.full_name as agent_name FROM agent_macros m
                JOIN users u ON m.agent_id = u.id WHERE u.company_id = ? ORDER BY m.created_at DESC");
            $stmt->execute([$this->companyId()]);
        } catch (\Exception $e) {
            $stmt = $pdo->prepare("SELECT m.*, u.name as agent_name FROM agent_macros m
                JOIN users u ON m.agent_id = u.id WHERE u.company_id = ? ORDER BY m.created_at DESC");
            $stmt->execute([$this->companyId()]);
        }
        $macros = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        echo json_encode(['status' => 'success', 'data' => $macros]);
        exit;
    }

    public function save_macro() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        $shortcut = trim($input['shortcut'] ?? '');
        $message = trim($input['message'] ?? '');
        
        $media_url = $input['media_url'] ?? null;
        $base64_data = $input['attachment_base64'] ?? null;
        $remove_image = $input['remove_image'] ?? 0;

        if ($id && !$this->macroAllowed(Database::getInstance(), $id)) $this->denyAccess();

        if (!empty($shortcut) && !empty($message)) {
            if (substr($shortcut, 0, 1) !== '/') {
                $shortcut = '/' . $shortcut;
            }
            
            if ($remove_image == 1) {
                $media_url = null;
            } elseif (!empty($base64_data) && strpos($base64_data, 'data:image') === 0) {
                $parts = explode(';base64,', $base64_data);
                if (count($parts) === 2) {
                    $mime_type = str_replace('data:', '', $parts[0]);
                    $file_data = base64_decode($parts[1]);
                    $ext = 'jpg';
                    if (strpos($mime_type, 'png') !== false) $ext = 'png';
                    
                    $file_name = 'macro_' . time() . '_' . uniqid() . '.' . $ext;
                    $upload_path = $_SERVER['DOCUMENT_ROOT'] . '/uploads/macros/';
                    if (!is_dir($upload_path)) mkdir($upload_path, 0777, true);
                    file_put_contents($upload_path . $file_name, $file_data);
                    
                    $media_url = rtrim(BASE_URL, '/') . '/uploads/macros/' . $file_name;
                }
            }

            $pdo = Database::getInstance();
            if ($id) {
                $pdo->prepare("UPDATE agent_macros SET shortcut = ?, message = ?, media_url = ? WHERE id = ? AND agent_id IN (SELECT id FROM users WHERE company_id = ?)")
                    ->execute([$shortcut, $message, $media_url, $id, $this->companyId()]);
            } else {
                $pdo->prepare("INSERT INTO agent_macros (agent_id, shortcut, message, media_url, created_at) VALUES (?, ?, ?, ?, NOW())")
                    ->execute([$_SESSION['user_id'], $shortcut, $message, $media_url]);
            }
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Shortcut and message are required.']);
        }
        exit;
    }

    public function delete_macro() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        
        if ($id) {
            $pdo = Database::getInstance();
            if (!$this->macroAllowed($pdo, $id)) $this->denyAccess();
            $pdo->prepare("DELETE FROM agent_macros WHERE id = ? AND agent_id IN (SELECT id FROM users WHERE company_id = ?)")
                ->execute([$id, $this->companyId()]);
            echo json_encode(['status' => 'success']);
        }
        exit;
    }

    public function get_global_tags() {
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        $pdo = Database::getInstance();

        try { $pdo->query("SELECT created_by FROM crm_tags LIMIT 1"); } 
        catch (\Exception $e) { $pdo->exec("ALTER TABLE crm_tags ADD COLUMN created_by INT NULL DEFAULT NULL"); }

        try {
            $stmt = $pdo->query("SELECT t.*, u.full_name as created_by_name FROM crm_tags t LEFT JOIN users u ON t.created_by = u.id ORDER BY t.name ASC");
        } catch (\Exception $e) {
            try {
                $stmt = $pdo->query("SELECT t.*, u.name as created_by_name FROM crm_tags t LEFT JOIN users u ON t.created_by = u.id ORDER BY t.name ASC");
            } catch (\Exception $e2) {
                $stmt = $pdo->query("SELECT t.*, 'Admin' as created_by_name FROM crm_tags t ORDER BY t.name ASC");
            }
        }
        $tags = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        echo json_encode(['status' => 'success', 'data' => $tags]);
        exit;
    }

    public function save_global_tag() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        $name = trim($input['name'] ?? '');
        
        if (!empty($name)) {
            $pdo = Database::getInstance();
            if ($id) {
                $pdo->prepare("UPDATE crm_tags SET name = ? WHERE id = ?")->execute([$name, $id]);
            } else {
                try {
                    $pdo->prepare("INSERT INTO crm_tags (name, created_by) VALUES (?, ?)")->execute([$name, $_SESSION['user_id']]);
                } catch (\Exception $e) {
                    $pdo->prepare("INSERT INTO crm_tags (name) VALUES (?)")->execute([$name]);
                }
            }
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Tag name is required.']);
        }
        exit;
    }

    public function delete_global_tag() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        if ($id) {
            $pdo = Database::getInstance();
            $pdo->prepare("DELETE FROM crm_tags WHERE id = ?")->execute([$id]);
            echo json_encode(['status' => 'success']);
        }
        exit;
    }

    public function sync_meta_ads() {
        $this->checkOrigin();
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            exit;
        }

        $access_token = defined('WA_ACCESS_TOKEN') ? WA_ACCESS_TOKEN : '';
        $ad_account_id = defined('META_AD_ACCOUNT_ID') ? META_AD_ACCOUNT_ID : '';

        if (empty($access_token) || empty($ad_account_id)) {
            echo json_encode(['status' => 'error', 'message' => 'Meta Token or Ad Account ID is missing in settings.']);
            exit;
        }

        $url = "https://graph.facebook.com/v19.0/{$ad_account_id}/ads?fields=id,name,status,campaign{name}&limit=100&access_token={$access_token}";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);

        if ($httpcode !== 200 || isset($data['error'])) {
            $err = $data['error']['message'] ?? 'Failed to fetch ads from Meta';
            echo json_encode(['status' => 'error', 'message' => $err]);
            exit;
        }

        $pdo = Database::getInstance();
        $company_id = $this->companyId();
        $synced_count = 0;

        foreach ($data['data'] as $ad) {
            $ad_id = $ad['id'];
            $ad_name = $ad['name'];
            $status = $ad['status'];
            $campaign_name = $ad['campaign']['name'] ?? 'Unknown Campaign';

            try {
                $stmt = $pdo->prepare("
                    INSERT INTO meta_ads (company_id, ad_id, campaign_name, ad_name, status) 
                    VALUES (?, ?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE 
                    campaign_name = VALUES(campaign_name), ad_name = VALUES(ad_name), status = VALUES(status), updated_at = CURRENT_TIMESTAMP
                ");
                $stmt->execute([$company_id, $ad_id, $campaign_name, $ad_name, $status]);
                $synced_count++;
            } catch (\Exception $e) {}
        }

        echo json_encode(['status' => 'success', 'message' => "Successfully synced {$synced_count} ads."]);
        exit;
    }

    // Read-only Meta Ad creative preview. This endpoint does NOT change ad sync,
    // lead attribution, WhatsApp sending, or any CRM database row.
    public function get_meta_ad_media() {
        if (empty($_SESSION['user_id'])) $this->denyAccess();
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: private, no-store');
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
            exit;
        }

        $companyId = $this->companyId();
        $requestedId = trim((string)($_GET['ad_id'] ?? ''));
        $requestedName = trim((string)($_GET['ad_name'] ?? ''));
        if (($requestedId !== '' && !preg_match('/^[0-9]{5,30}$/D', $requestedId)) ||
            ($requestedId === '' && ($requestedName === '' || strlen($requestedName) > 255))) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid ad lookup']);
            exit;
        }

        try {
            $pdo = Database::getInstance();
            if ($requestedId !== '') {
                $stmt = $pdo->prepare('SELECT ad_id, ad_name FROM meta_ads WHERE company_id = ? AND ad_id = ? LIMIT 2');
                $stmt->execute([$companyId, $requestedId]);
            } else {
                // A lead currently stores only meta_ad_name, not its source ad_id.
                // Only show media if the name matches exactly ONE ad in this tenant.
                // Never guess if multiple creatives have the same name.
                $stmt = $pdo->prepare('SELECT ad_id, ad_name FROM meta_ads WHERE company_id = ? AND BINARY ad_name = BINARY ? LIMIT 2');
                $stmt->execute([$companyId, $requestedName]);
            }
            $matches = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Throwable $e) {
            error_log('CRM ad creative lookup failed: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Creative lookup failed']);
            exit;
        }
        if (count($matches) !== 1) {
            echo json_encode(['status' => 'unavailable', 'message' => count($matches) > 1
                ? 'Multiple ads have the same name; exact source video cannot be identified.'
                : 'Matching synced ad not found.']);
            exit;
        }

        $adId = (string)$matches[0]['ad_id'];
        if (!preg_match('/^[0-9]{5,30}$/D', $adId)) {
            echo json_encode(['status' => 'unavailable', 'message' => 'Invalid saved Ad ID']);
            exit;
        }
        $token = defined('WA_ACCESS_TOKEN') ? (string)WA_ACCESS_TOKEN : '';
        if ($token === '' || !function_exists('curl_init')) {
            echo json_encode(['status' => 'unavailable', 'message' => 'Meta API access unavailable']);
            exit;
        }

        // Official Meta ad-preview iframe, fetched ONLY when someone clicks a
        // video with no direct source. Avoid 3-5 extra API calls for every row.
        // Do not persist the preview URL: Meta signs/expires these previews.
        if (($_GET['preview'] ?? '') === '1') {
            $formats = ['INSTAGRAM_STANDARD', 'MOBILE_FEED_STANDARD',
                        'INSTAGRAM_REELS', 'INSTAGRAM_STORY'];
            $lastCode = null;
            foreach ($formats as $format) {
                $previewEndpoint = 'https://graph.facebook.com/v24.0/' . rawurlencode($adId)
                    . '/previews?ad_format=' . rawurlencode($format);
                $ch = curl_init($previewEndpoint);
                if (!$ch) continue;
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_CONNECTTIMEOUT => 3,
                    CURLOPT_TIMEOUT => 8,
                    CURLOPT_FOLLOWLOCATION => false
                ]);
                $raw = curl_exec($ch);
                $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if (!is_string($raw)) continue;
                $payload = json_decode($raw, true);
                if (!is_array($payload)) continue;
                if ($status !== 200 || isset($payload['error'])) {
                    $lastCode = $payload['error']['code'] ?? $status;
                    continue;
                }
                foreach (($payload['data'] ?? []) as $preview) {
                    if (!is_array($preview)) continue;
                    $body = (string)($preview['body'] ?? '');
                    // Never return or inject Meta's raw iframe HTML.
                    // Extract only the HTTPS, Meta-owned preview iframe URL.
                    if (!preg_match('~<iframe\b[^>]*\bsrc\s*=\s*(["\x27])(.*?)\1~is', $body, $match)) continue;
                    $candidate = html_entity_decode($match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    $parts = parse_url($candidate);
                    if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https') continue;
                    if (!in_array(strtolower((string)($parts['host'] ?? '')),
                                  ['www.facebook.com', 'facebook.com', 'business.facebook.com'], true)) continue;
                    if (($parts['path'] ?? '') !== '/ads/api/preview_iframe.php') continue;
                    if (strlen($candidate) > 8192) continue;
                    echo json_encode([
                        'status' => 'success', 'ad_id' => $adId,
                        'preview_url' => $candidate, 'format' => $format
                    ], JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
                    exit;
                }
            }
            echo json_encode([
                'status' => 'unavailable',
                'message' => 'Meta did not provide an embeddable ad preview for this ad. Check ads_read, Page access and ad placement.',
                'meta_code' => is_numeric($lastCode) ? (int)$lastCode : null
            ]);
            exit;
        }

        // Use a supported version solely for the NEW read-only preview call.
        // Existing sync_meta_ads() remains exactly unchanged.
        $graph = function (string $objectId, string $fields) use ($token): ?array {
            $url = 'https://graph.facebook.com/v24.0/' . rawurlencode($objectId)
                 . '?fields=' . rawurlencode($fields);
            $ch = curl_init($url);
            if (!$ch) return null;
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token],
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_CONNECTTIMEOUT => 4,
                CURLOPT_TIMEOUT => 12,
                CURLOPT_FOLLOWLOCATION => false
            ]);
            $body = curl_exec($ch);
            $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if (!is_string($body) || $http !== 200) return null;
            $json = json_decode($body, true);
            return is_array($json) && !isset($json['error']) ? $json : null;
        };

        $ad = $graph($adId, 'creative{thumbnail_url,image_url,video_id,object_story_spec,asset_feed_spec}');
        if (!$ad || empty($ad['creative']) || !is_array($ad['creative'])) {
            echo json_encode(['status' => 'unavailable', 'message' => 'Meta did not return accessible ad creative media. Check ads_read and ad account permissions.']);
            exit;
        }
        $creative = $ad['creative'];
        $story = $creative['object_story_spec'] ?? [];
        $story = is_array($story) ? $story : [];
        $videoData = $story['video_data'] ?? [];
        $videoData = is_array($videoData) ? $videoData : [];
        $asset = $creative['asset_feed_spec'] ?? [];
        $assetVideos = is_array($asset) ? ($asset['videos'] ?? []) : [];
        $firstAssetVideo = is_array($assetVideos) && count($assetVideos) === 1 ? ($assetVideos[0] ?? []) : [];
        $firstAssetVideo = is_array($firstAssetVideo) ? $firstAssetVideo : [];
        $videoId = (string)($creative['video_id'] ?? $videoData['video_id'] ?? $firstAssetVideo['video_id'] ?? '');
        // Dynamic creatives may contain several videos; never pick one arbitrarily.
        if ($videoId === '' && is_array($assetVideos) && count($assetVideos) > 1) {
            echo json_encode(['status' => 'unavailable', 'message' => 'This dynamic ad has multiple video assets; exact creative cannot be identified.']);
            exit;
        }

        $linkData = $story['link_data'] ?? [];
        $linkData = is_array($linkData) ? $linkData : [];
        $thumbnail = (string)($creative['thumbnail_url'] ?? $videoData['image_url'] ??
            $creative['image_url'] ?? $linkData['picture'] ?? $firstAssetVideo['thumbnail_url'] ?? '');
        $videoUrl = '';
        if (preg_match('/^[0-9]{5,30}$/D', $videoId)) {
            $video = $graph($videoId, 'source,picture');
            if ($video) {
                $videoUrl = (string)($video['source'] ?? '');
                if ($thumbnail === '') $thumbnail = (string)($video['picture'] ?? '');
            }
        }
        // URLs arrive from Meta. Never accept javascript:, data:, or other schemes.
        $validHttps = static function ($url): string {
            return is_string($url) && strlen($url) <= 4096 &&
                filter_var($url, FILTER_VALIDATE_URL) &&
                strtolower((string)parse_url($url, PHP_URL_SCHEME)) === 'https' ? $url : '';
        };
        $thumbnail = $validHttps($thumbnail);
        $videoUrl = $validHttps($videoUrl);
        if ($thumbnail === '' && $videoUrl === '') {
            echo json_encode(['status' => 'unavailable', 'message' => 'No accessible video or image URL for this ad']);
            exit;
        }
        echo json_encode([
            'status' => 'success', 'ad_id' => $adId,
            'kind' => $videoId !== '' ? 'video' : 'image',
            'thumbnail_url' => $thumbnail, 'video_url' => $videoUrl,
            'playable' => $videoUrl !== ''
        ], JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    // Inbox Notes tab: read existing Lead Profile notes; no new table or write path.
    public function get_lead_notes() {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: private, no-store');
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
            exit;
        }
        $companyId = $this->companyId();
        $leadId = filter_var($_GET['lead_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$leadId || $leadId <= 0) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid lead']);
            exit;
        }
        try {
            $pdo = Database::getInstance();
            if (!$this->leadAllowed($pdo, $leadId)) $this->denyAccess();
            $stmt = $pdo->prepare("SELECT id, note_text, created_by, created_at
                FROM lead_notes WHERE lead_id = ? AND note_type = 'Note'
                ORDER BY created_at DESC, id DESC LIMIT 50");
            $stmt->execute([$leadId]);
            echo json_encode(['status' => 'success', 'data' => $stmt->fetchAll(\PDO::FETCH_ASSOC)], JSON_INVALID_UTF8_SUBSTITUTE);
        } catch (\Throwable $e) {
            error_log('Inbox Notes read failed: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Unable to load notes']);
        }
        exit;
    }

    public function get_meta_ads() {
        if (!isset($_SESSION['user_id'])) exit;
        header('Content-Type: application/json');
        
        $pdo = Database::getInstance();
        $company_id = $this->companyId();

        try {
            $stmt = $pdo->prepare("SELECT * FROM meta_ads WHERE company_id = ? ORDER BY created_at DESC");
            $stmt->execute([$company_id]);
            $ads = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'success', 'data' => $ads]);
        } catch (\Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        exit;
    }
} 
?>