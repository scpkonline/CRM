<?php 
namespace Controllers; 
use Core\Controller; 
use Core\Database;

class DashboardController extends Controller {          
    
    public function index() {          
        if (!isset($_SESSION['user_id'])) {              
            header('Location: ' . BASE_URL . 'auth');              
            exit;          
        }          
        
        $pdo = Database::getInstance();
        $company_id = $_SESSION['company_id'] ?? 1;
        // The shared DB session must stay UTC (Database.php controls it).
        $displayTimezone = \Core\Timezone::get($pdo, (int)$company_id);

        // =========================================================
        // 🚀 OPTIMIZATION 1: N+1 FIX (4 Queries merged into 1)
        // =========================================================
        $topMetrics = $pdo->query("
            SELECT 
                COUNT(*) as total_leads,
                SUM(CASE WHEN LOWER(lead_source) = 'website' THEN 1 ELSE 0 END) as website_leads,
                SUM(CASE WHEN LOWER(lead_source) = 'whatsapp' THEN 1 ELSE 0 END) as whatsapp_leads,
                SUM(CASE WHEN lead_stage IS NULL OR LOWER(lead_stage) = 'new' OR lead_stage = '' THEN 1 ELSE 0 END) as active_leads
            FROM leads 
            WHERE company_id = $company_id
        ")->fetch(\PDO::FETCH_ASSOC);

        $total_leads = $topMetrics['total_leads'] ?? 0;
        $website_leads = $topMetrics['website_leads'] ?? 0;
        $whatsapp_leads = $topMetrics['whatsapp_leads'] ?? 0;
        $active_leads = $topMetrics['active_leads'] ?? 0;

        // 2. Fetch all Sales Agents
        $agents = [];
        try {
            $agents = $pdo->query("SELECT id, full_name as name FROM users WHERE LOWER(role) = 'sales' AND company_id = $company_id ORDER BY full_name ASC")->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            try {
                $agents = $pdo->query("SELECT id, name FROM users WHERE LOWER(role) = 'sales' AND company_id = $company_id ORDER BY name ASC")->fetchAll(\PDO::FETCH_ASSOC);
            } catch (\Exception $e2) {}
        }

        $sequence = ['mukul', 'dolly', 'varsha', 'manisha', 'naaz', 'sakshi', 'mansi'];
        usort($agents, function($a, $b) use ($sequence) {
            $posA = array_search(strtolower(trim($a['name'])), $sequence);
            $posB = array_search(strtolower(trim($b['name'])), $sequence);
            
            if ($posA === false) $posA = 999;
            if ($posB === false) $posB = 999;
            
            if ($posA === $posB) {
                return strcmp($a['name'], $b['name']);
            }
            return $posA <=> $posB;
        });

        $team_stats = [];
        foreach ($agents as $agent) {
            $team_stats[$agent['id']] = [
                'name' => strtoupper($agent['name']),
                'pending' => 0,
                'pending_wa' => 0,    // New field for WhatsApp breakdown
                'pending_web' => 0,   // New field for Website breakdown
                'catalog' => 0,
                'followup' => 0,
                'negotiation' => 0,
                'sold' => 0,
                'unqualified' => 0
            ];
        }

        // =========================================================
        // 🚀 OPTIMIZATION 2: Grouped Query includes lead_source now
        // =========================================================
        $stmtStats = $pdo->prepare("SELECT assigned_to, lead_stage, LOWER(lead_source) as lead_source, COUNT(*) as count FROM leads WHERE company_id = ? GROUP BY assigned_to, lead_stage, LOWER(lead_source)");
        $stmtStats->execute([$company_id]);
        $stats = $stmtStats->fetchAll(\PDO::FETCH_ASSOC);

        $unassigned_stats = ['pending' => 0, 'pending_wa' => 0, 'pending_web' => 0];

        foreach ($stats as $row) {
            $agent_id = $row['assigned_to'] ?: 0;
            $stage = strtolower(trim((string)($row['lead_stage'] ?? 'new')));
            if (empty($stage)) $stage = 'new';
            $count = (int)$row['count'];
            $source = trim((string)$row['lead_source']);

            if ($stage === 'new') {
                if (isset($team_stats[$agent_id])) {
                    $team_stats[$agent_id]['pending'] += $count;
                    if (strpos($source, 'whats') !== false) {
                        $team_stats[$agent_id]['pending_wa'] += $count;
                    } else {
                        $team_stats[$agent_id]['pending_web'] += $count;
                    }
                } elseif ($agent_id == 0) {
                    $unassigned_stats['pending'] += $count;
                    if (strpos($source, 'whats') !== false) {
                        $unassigned_stats['pending_wa'] += $count;
                    } else {
                        $unassigned_stats['pending_web'] += $count;
                    }
                }
            } else {
                $metric = '';
                if ($stage === 'qualified' || $stage === 'catalog sharing') $metric = 'catalog';
                elseif ($stage === 'follow up') $metric = 'followup';
                elseif ($stage === 'negotiation') $metric = 'negotiation';
                elseif ($stage === 'sold') $metric = 'sold';
                elseif ($stage === 'unqualified') $metric = 'unqualified';

                if ($metric && isset($team_stats[$agent_id])) {
                    $team_stats[$agent_id][$metric] += $count;
                }
            }
        }

        $pendingBreakdown = [];
        $totalPendingLeads = 0;

        foreach ($team_stats as $stat) {
            if ($stat['pending'] > 0) {
                $pendingBreakdown[] = [
                    'agent_name' => ucwords(strtolower($stat['name'])),
                    'wa' => $stat['pending_wa'],
                    'web' => $stat['pending_web'],
                    'total' => $stat['pending']
                ];
            }
            $totalPendingLeads += $stat['pending'];
        }

        if ($unassigned_stats['pending'] > 0) {
            $pendingBreakdown[] = [
                'agent_name' => 'Unassigned Leads',
                'wa' => $unassigned_stats['pending_wa'],
                'web' => $unassigned_stats['pending_web'],
                'total' => $unassigned_stats['pending']
            ];
            $totalPendingLeads += $unassigned_stats['pending'];
        }

        usort($pendingBreakdown, function($a, $b) {
            return $b['total'] <=> $a['total'];
        });

        // =======================================================
        // WIDGET 2: LAST 10 DAYS INTAKE (WhatsApp, Website, Total)
        // =======================================================
        $last10Days = [];
        $localToday = new \DateTimeImmutable('today', new \DateTimeZone($displayTimezone));
        for ($i = 9; $i >= 0; $i--) {
            $day = $localToday->modify('-' . $i . ' days');
            $dateKey = $day->format('Y-m-d');
            $last10Days[$dateKey] = [
                'date' => $day->format('d-M-Y'),
                'whatsapp' => 0,
                'website' => 0,
                'total' => 0
            ];
        }

        // Group on the selected company's calendar dates. Only UTC and
        // Asia/Kolkata are allowed by the existing Timezone.php choices.
        $offsetMinutes = $displayTimezone === 'Asia/Kolkata' ? 330 : 0;
        $firstLocalDay = $localToday->modify('-9 days');
        $startUtc = \Core\Timezone::toUtc($firstLocalDay->format('Y-m-d') . ' 00:00:00', $displayTimezone);
        $endUtc = \Core\Timezone::toUtc($localToday->modify('+1 day')->format('Y-m-d') . ' 00:00:00', $displayTimezone);
        $localDaySql = "DATE(DATE_ADD(created_at, INTERVAL {$offsetMinutes} MINUTE))";
        $stmt10 = $pdo->prepare("SELECT {$localDaySql} as lead_date, LOWER(lead_source) as source, COUNT(*) as total_count
                                 FROM leads
                                 WHERE company_id = ? AND created_at >= ? AND created_at < ?
                                 GROUP BY {$localDaySql}, LOWER(lead_source)");
        $stmt10->execute([$company_id, $startUtc, $endUtc]);
        $rows10 = $stmt10->fetchAll(\PDO::FETCH_ASSOC);

        $total10DaysLeads = 0;
        foreach ($rows10 as $r) {
            $lDate = $r['lead_date'];
            if (isset($last10Days[$lDate])) {
                $src = trim($r['source']);
                $cnt = (int)$r['total_count'];
                
                if (strpos($src, 'whats') !== false) {
                    $last10Days[$lDate]['whatsapp'] += $cnt;
                } elseif (strpos($src, 'web') !== false) {
                    $last10Days[$lDate]['website'] += $cnt;
                } else {
                    $last10Days[$lDate]['website'] += $cnt;
                }
                $last10Days[$lDate]['total'] += $cnt;
                $total10DaysLeads += $cnt;
            }
        }
        $dailyLeadsList = array_reverse(array_values($last10Days));

        // =======================================================
        // WIDGET 3: SALES EXECUTIVE PERFORMANCE RANKING
        // =======================================================
        $performanceRank = [];
        $maxSold = 1;
        foreach ($team_stats as $agentId => $stat) {
            $soldCount = (int)$stat['sold'];
            $activeCount = (int)($stat['catalog'] + $stat['followup'] + $stat['negotiation']);
            if ($soldCount > $maxSold) {
                $maxSold = $soldCount;
            }
            $performanceRank[] = [
                'agent_id' => $agentId,
                'name' => ucwords(strtolower($stat['name'])),
                'sold' => $soldCount,
                'active' => $activeCount,
                'pending' => (int)$stat['pending']
            ];
        }

        usort($performanceRank, function($a, $b) {
            if ($b['sold'] === $a['sold']) {
                return $b['active'] <=> $a['active'];
            }
            return $b['sold'] <=> $a['sold'];
        });

        $data = [              
            'title' => 'Dashboard - SCPK CRM',              
            'user_name' => $_SESSION['name'] ?? 'User',
            'user_role' => isset($_SESSION['role']) ? strtoupper($_SESSION['role']) : 'SALES',
            'total_leads' => $total_leads,
            'website_leads' => $website_leads,
            'whatsapp_leads' => $whatsapp_leads,
            'active_leads' => $active_leads,
            'team_stats' => $team_stats,
            'pendingBreakdown' => $pendingBreakdown,
            'totalPendingLeads' => $totalPendingLeads,
            'dailyLeadsList' => $dailyLeadsList,
            'total10DaysLeads' => $total10DaysLeads,
            'performanceRank' => $performanceRank,
            'maxSold' => $maxSold,
            'displayTimezone' => $displayTimezone
        ];                  
        
        $this->view('dashboard', $data);     
    }      
}