<?php 
namespace Models; 
use Core\Database; 
use PDO; 

class Lead {     
    private $db;     
    
    public function __construct() {         
        $this->db = Database::getInstance();     
    }     
    
    // 1. Fetch all leads with Safety Limit (Avoids memory crash on 1 Lakh+ leads)
    public function getAllLeads($company_id, $limit = 300) {         
        $stmt = $this->db->prepare("             
            SELECT id, full_name, phone_number, whatsapp_number, email, lead_source, products_of_interest, lead_stage, created_at, assigned_to              
            FROM leads              
            WHERE company_id = ?              
            ORDER BY created_at DESC 
            LIMIT " . (int)$limit . "
        ");         
        $stmt->execute([$company_id]);         
        return $stmt->fetchAll(PDO::FETCH_ASSOC);     
    } 
    
    // 2. Fetch a single lead by ID 
    // 🔥 OPTIMIZATION: Joined the 'users' table here to fetch the Agent Name instantly. 
    // This stops the controller from making extra trips to the database!
    public function getLeadById($company_id, $lead_id) {         
        $stmt = $this->db->prepare("             
            SELECT l.*, u.full_name as assigned_to_name 
            FROM leads l 
            LEFT JOIN users u ON l.assigned_to = u.id
            WHERE l.company_id = ? AND l.id = ?          
        ");         
        $stmt->execute([$company_id, $lead_id]);         
        return $stmt->fetch(PDO::FETCH_ASSOC);     
    }  

    // 3. Add a new manual lead
    public function addLead($data) {
        $stmt = $this->db->prepare("
            INSERT INTO leads (company_id, full_name, phone_number, email, products_of_interest, lead_source, lead_stage, created_at) 
            VALUES (?, ?, ?, ?, ?, 'Manual', 'new', NOW())
        ");
        return $stmt->execute([
            $data['company_id'] ?? 1, 
            $data['full_name'] ?? '', 
            $data['phone_number'] ?? '', 
            $data['email'] ?? '',
            $data['products_of_interest'] ?? ''
        ]);
    }

    // ==========================================================
    // 🔥 4. NEW: ULTRA-FAST SEARCH & FILTER FUNCTION 🔥
    // Yeh function Phone, Email aur Name par rocket ki tarah search karega
    // ==========================================================
    public function searchAndFilterLeads($company_id, $searchKeyword = '', $stage = '', $source = '', $agent_id = null, $limit = 300) {
        $query = "SELECT id, full_name, phone_number, whatsapp_number, email, lead_source, products_of_interest, lead_stage, created_at, assigned_to 
                  FROM leads WHERE company_id = ?";
        $params = [$company_id];

        // Search logic for Phone, Email & Name
        if (!empty($searchKeyword)) {
            // Hum LIKE use kar rahe hain taaki partial match bhi kaam kare (e.g. '9876' likhne par 9876543210 mil jaye)
            $query .= " AND (phone_number LIKE ? OR whatsapp_number LIKE ? OR email LIKE ? OR full_name LIKE ?)";
            $keywordPattern = '%' . trim($searchKeyword) . '%';
            $params[] = $keywordPattern;
            $params[] = $keywordPattern;
            $params[] = $keywordPattern;
            $params[] = $keywordPattern;
        }

        // Apply Stage Filter
        if (!empty($stage)) {
            $query .= " AND lead_stage = ?";
            $params[] = $stage;
        }

        // Apply Source Filter
        if (!empty($source)) {
            $query .= " AND lead_source = ?";
            $params[] = $source;
        }

        // Apply Agent Filter
        if ($agent_id !== null) {
            $query .= " AND assigned_to = ?";
            $params[] = $agent_id;
        }

        $query .= " ORDER BY created_at DESC LIMIT " . (int)$limit;

        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>