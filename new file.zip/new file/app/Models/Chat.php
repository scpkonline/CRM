<?php
namespace Models;

use Core\Database;
use PDO;

class Chat {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getActiveChats($company_id) {
        $company_id = (int)$company_id;
        if ($company_id <= 0) {
            return [];
        }

        // Keep the original ACTIVE / INTERVENED calculation unchanged.
        $stmt = $this->db->prepare("
            SELECT c.id as conversation_id, c.last_message_at, c.agent_name,
                   l.id as lead_id, l.full_name, l.whatsapp_number,
                   l.lead_stage as status,
                   l.lead_source, l.created_at, l.tags, l.assigned_to,
                   COALESCE(c.unread_count, 0) as unread_count,
                   (SELECT COUNT(id) FROM wa_messages
                    WHERE conversation_id = c.id
                      AND sender_type = 'agent'
                      AND message_body NOT LIKE '[Bot]%') as agent_replies
            FROM wa_conversations c
            JOIN leads l ON c.lead_id = l.id
            WHERE c.company_id = ? AND l.company_id = ?
            ORDER BY c.last_message_at DESC
            LIMIT 500
        ");
        $stmt->execute([$company_id, $company_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Compatible with BOTH controller versions:
     *   old: getMessages($conversation_id)
     *   new: getMessages($conversation_id, $company_id)
     * For the old call, the logged-in session determines company ownership.
     */
    public function getMessages($conversation_id, $company_id = null) {
        $conversation_id = (int)$conversation_id;
        $session_company_id = (int)($_SESSION['company_id'] ?? 0);
        $company_id = $company_id === null ? $session_company_id : (int)$company_id;

        // Never permit cross-company reads, including when the second argument
        // is provided explicitly. Webhooks use their own code, not this method.
        if (empty($_SESSION['user_id']) || $conversation_id <= 0 ||
            $session_company_id <= 0 || $company_id !== $session_company_id) {
            return [];
        }

        $allowed = $this->db->prepare("
            SELECT 1
            FROM wa_conversations c
            JOIN leads l ON l.id = c.lead_id
            WHERE c.id = ? AND c.company_id = ? AND l.company_id = ?
            LIMIT 1
        ");
        $allowed->execute([$conversation_id, $company_id, $company_id]);
        if (!$allowed->fetchColumn()) {
            return [];
        }

        // Preserve the original read-receipt behavior.
        try {
            $this->db->prepare("
                UPDATE wa_messages
                SET is_read = 1, delivery_status = 'read'
                WHERE conversation_id = ?
                  AND sender_type = 'lead'
                  AND (is_read = 0 OR delivery_status != 'read')
            ")->execute([$conversation_id]);
        } catch (\Exception $e) {
            // A read-receipt error must not stop the Inbox from loading.
        }

        $stmt = $this->db->prepare("
            SELECT id, wa_message_id, sender_type, message_type, message_body,
                   created_at, delivery_status, media_url, mime_type, is_internal,
                   reply_to_wa_message_id
            FROM wa_messages
            WHERE conversation_id = ?
            ORDER BY created_at ASC, id ASC
        ");
        $stmt->execute([$conversation_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
