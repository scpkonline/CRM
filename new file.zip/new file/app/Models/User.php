<?php
namespace Models;
use Core\Database;
use PDO;

class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // Fetch all team members with assigned lead counts
    public function getTeamMembers($company_id) {
        // 🔥 OPTIMIZATION: Removed slow LEFT JOIN + GROUP BY. 
        // Used an ultra-fast Correlated Subquery to get the count directly.
        $stmt = $this->db->prepare("
            SELECT u.id, u.full_name, u.email, u.role, u.permissions, u.created_at, 
                   (SELECT COUNT(id) FROM leads WHERE assigned_to = u.id) as assigned_leads 
            FROM users u 
            WHERE u.company_id = ? 
            ORDER BY u.role ASC, u.created_at DESC
        ");
        $stmt->execute([$company_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fetch a single user by ID
    public function getUserById($company_id, $user_id) {
        $stmt = $this->db->prepare("SELECT id, full_name, email, role, permissions FROM users WHERE company_id = ? AND id = ?");
        $stmt->execute([$company_id, $user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Add a new team member
    public function addUser($company_id, $name, $email, $password, $role, $permissions) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $json_permissions = json_encode($permissions);

        $stmt = $this->db->prepare("
            INSERT INTO users (company_id, full_name, email, password_hash, role, permissions) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$company_id, $name, $email, $hashed_password, $role, $json_permissions]);
    }

    // Update an existing user
    public function updateUser($company_id, $user_id, $name, $email, $role, $permissions, $password = null) {
        $json_permissions = json_encode($permissions);

        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("
                UPDATE users 
                SET full_name = ?, email = ?, password_hash = ?, role = ?, permissions = ? 
                WHERE company_id = ? AND id = ?
            ");
            return $stmt->execute([$name, $email, $hashed_password, $role, $json_permissions, $company_id, $user_id]);
        } else {
            $stmt = $this->db->prepare("
                UPDATE users 
                SET full_name = ?, email = ?, role = ?, permissions = ? 
                WHERE company_id = ? AND id = ?
            ");
            return $stmt->execute([$name, $email, $role, $json_permissions, $company_id, $user_id]);
        }
    }
}
?>