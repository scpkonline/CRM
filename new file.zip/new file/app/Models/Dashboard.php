<?php
namespace Models;
use Core\Database;
use PDO;

class Dashboard {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getStats($company_id) {
        // 🔥 OPTIMIZATION 1: Merged 2 separate COUNT queries into 1 single ultra-fast query using Conditional Aggregation.
        // Instead of hitting the 'leads' table twice, we do it in one go.
        // Also replaced COUNT(*) with COUNT(id) for faster primary key scanning.
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(id) as total_leads,
                COALESCE(SUM(CASE WHEN lead_status = 'won' THEN 1 ELSE 0 END), 0) as won_leads
            FROM leads 
            WHERE company_id = ?
        ");
        $stmt->execute([$company_id]);
        $leadStats = $stmt->fetch(PDO::FETCH_ASSOC);

        $total_leads = (int)($leadStats['total_leads'] ?? 0);
        $won_leads = (int)($leadStats['won_leads'] ?? 0);

        // 2. Active WhatsApp Chats Count
        $stmt = $this->db->prepare("SELECT COUNT(id) FROM wa_conversations WHERE company_id = ?");
        $stmt->execute([$company_id]);
        $active_chats = (int)$stmt->fetchColumn();

        // 3. Pending Tasks Count
        $stmt = $this->db->prepare("
            SELECT COUNT(t.id) FROM lead_tasks t 
            JOIN leads l ON t.lead_id = l.id 
            WHERE l.company_id = ? AND t.status = 'pending'
        ");
        $stmt->execute([$company_id]);
        $pending_tasks = (int)$stmt->fetchColumn();

        // 4. Win Rate Calculation
        $win_rate = ($total_leads > 0) ? round(($won_leads / $total_leads) * 100) : 0;

        return [
            'total_leads' => $total_leads,
            'active_chats' => $active_chats,
            'pending_tasks' => $pending_tasks,
            'win_rate' => $win_rate
        ];
    }

    // Fetch the 5 most recent leads for the table
    public function getRecentLeads($company_id) {
        // 🔥 OPTIMIZATION 2: Directly picking specific columns instead of loading everything in memory.
        $stmt = $this->db->prepare("
            SELECT id, full_name, phone_number, whatsapp_number, lead_source, products_of_interest, lead_status, created_at 
            FROM leads 
            WHERE company_id = ? 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $stmt->execute([$company_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>