<?php
namespace Models;
use Core\Database;
use PDO;

class Task {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // 🔥 OPTIMIZATION: Added role-based filtering, LEFT JOIN, and a safe Limit
    public function getAllTasks($company_id, $user_id = null, $role = 'SALES', $limit = 500) {
        $query = "
            SELECT t.id, t.task_type, t.task_title, t.due_date, t.status, 
                   l.full_name as lead_name, l.id as lead_id,
                   u.full_name as assigned_name 
            FROM lead_tasks t
            JOIN leads l ON t.lead_id = l.id
            LEFT JOIN users u ON t.assigned_to = u.id
            WHERE l.company_id = ?
        ";
        
        $params = [$company_id];

        // Agar user ADMIN nahi hai, toh sirf uske khud ke tasks dikhao
        if (strtoupper($role) !== 'ADMIN' && $user_id !== null) {
            $query .= " AND t.assigned_to = ?";
            $params[] = $user_id;
        }

        // Pending tasks ko sabse upar rakho, aur completed ko neeche
        // Sath hi LIMIT 500 laga diya taaki server hang na ho
        $query .= " ORDER BY FIELD(t.status, 'pending', 'completed'), t.due_date ASC LIMIT " . (int)$limit;

        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>