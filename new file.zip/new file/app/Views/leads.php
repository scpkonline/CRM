<?php
    $filters = $filters ?? [];
    
    // Check if any actual filter is applied (ignoring default status='new')
    $hasActiveFilters = (
        (!empty($filters['search'])) ||
        (isset($filters['status']) && $filters['status'] !== 'new') ||
        (!empty($filters['source'])) ||
        (!empty($filters['agent'])) ||
        (!empty($filters['tag'])) ||
        (!empty($filters['temp'])) ||
        (!empty($filters['start_date'])) ||
        (!empty($filters['end_date']))
    );
    
    function getPaginationUrl($params, $newPage) {
        $params['page'] = $newPage;
        return '?' . http_build_query($params);
    }
?>
<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Lead Management') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <style>          
        body { background-color: #f4f7f6; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; overflow: hidden; }                  
        input[type="text"]::-webkit-search-decoration,
        input[type="text"]::-webkit-search-cancel-button,
        input[type="text"]::-webkit-search-results-button,
        input[type="text"]::-webkit-search-results-decoration,
        input[type="date"]::-webkit-clear-button { display: none !important; }

        .main-content { margin-left: 250px; padding: 15px 20px; transition: all 0.3s ease; height: calc(100vh - 70px); display: flex; flex-direction: column; }          
        .main-content.expanded { margin-left: 80px; }
        
        .page-header { flex-shrink: 0; display: flex; justify-content: space-between; align-items: center; background: #fff; padding: 10px 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); margin-bottom: 15px; }
        .page-title { margin: 0; font-size: 20px; font-weight: 700; color: #333; }
        .user-profile { display: flex; align-items: center; gap: 12px; color: #555; font-size: 13px; }
        .avatar-circle { width: 32px; height: 32px; background: #4e73df; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; }

        .card-custom { flex-grow: 1; display: flex; flex-direction: column; background: #fff; border-radius: 8px; border: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); overflow: hidden; margin-bottom: 10px; min-height: 0; }
        .card-header-custom { flex-shrink: 0; padding: 15px 20px; border-bottom: 1px solid #f0f0f0; display: flex; flex-direction: column; background: #fff; z-index: 2; }
        
        .search-filter-box { display: flex; align-items: stretch; border: 1px solid #ced4da; border-radius: 6px; overflow: hidden; width: 350px; transition: all 0.3s; }
        .search-filter-box:focus-within { border-color: #86b7fe; box-shadow: 0 0 0 0.25rem rgba(13,110,253,.25); }
        .search-filter-box .input-group-text { background: #fff; border: none; color: #999; padding: 6px 12px; }
        .search-filter-box .form-control { border: none; box-shadow: none; font-size: 13px; padding: 6px 10px; outline: none; }
        .search-filter-box .btn-filter { background: #fdfdfd; border: none; border-left: 1px solid #ced4da; font-size: 13px; font-weight: 600; color: #555; padding: 0 15px; transition: all 0.2s; display: flex; align-items: center; gap: 6px; }
        .search-filter-box .btn-filter:hover { background: #e9ecef; }
        
        .filter-panel { background: #fdfdfd; border-radius: 8px; padding: 15px; border: 1px solid #eaeaea; margin-top: 15px; display: none; }
        .filter-panel.show { display: block; }
        .filter-panel .form-select-sm { padding-right: 32px !important; text-overflow: ellipsis; }
        
        .btn-add-lead { background: #4e73df; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px; box-shadow: 0 2px 4px rgba(78,115,223,0.2); transition: all 0.2s; }
        .btn-add-lead:hover { background: #3a5bba; }

        .table-responsive { flex-grow: 1; overflow-y: auto; background: #fff; }
        .table-responsive::-webkit-scrollbar { width: 6px; }
        .table-responsive::-webkit-scrollbar-track { background: #f1f1f1; }
        .table-responsive::-webkit-scrollbar-thumb { background: #ccc; border-radius: 4px; }

        .table { margin-bottom: 0; }
        .table th { position: sticky; top: 0; background-color: #f8fafc; color: #333; font-weight: 700; font-size: 13px; padding: 12px 15px; z-index: 10; box-shadow: inset 0 -1px 0 #e2e8f0; border-bottom: none; }
        .table td { vertical-align: middle; padding: 12px 15px; border-bottom: 1px solid #f8f9fa; }
        
        .contact-stack { display: flex; flex-direction: column; gap: 4px; }
        .contact-name { font-size: 14px; font-weight: 700; color: #333; }
        .contact-company { font-size: 12px; font-weight: 600; color: #4e73df; }
        .contact-detail { font-size: 12px; color: #555; }
        .address-box { line-height: 1.5; font-size: 12px; color: #555; }
        
        .product-scroll-box { max-height: 95px; overflow-y: auto; padding-right: 5px; }
        .product-scroll-box::-webkit-scrollbar { width: 4px; }
        .product-scroll-box::-webkit-scrollbar-thumb { background: #ccc; border-radius: 4px; }
        .product-list { font-size: 12px; color: #222; line-height: 1.6; margin-bottom: 0; padding-left: 20px; }
        
        .btn-action-group { display: flex; gap: 5px; flex-direction: column; }
        .btn-open-profile { color: #4e73df; border: 1px solid #4e73df; border-radius: 4px; padding: 3px 10px; font-size: 12px; font-weight: 600; text-align: center; text-decoration: none; transition: all 0.2s; }
        .btn-open-profile:hover { background: #4e73df; color: #fff; }
        
        .btn-qualified { color: #198754; border: 1px solid #198754; border-radius: 4px; padding: 3px 10px; font-size: 12px; font-weight: 600; background: transparent; text-align: center; transition: all 0.2s; cursor: pointer; }
        .btn-qualified:hover { background: #198754; color: #fff; }

        .btn-unqualified { color: #dc3545; border: 1px solid #dc3545; border-radius: 4px; padding: 3px 10px; font-size: 12px; font-weight: 600; background: transparent; text-align: center; transition: all 0.2s; cursor: pointer; }
        .btn-unqualified:hover { background: #dc3545; color: #fff; }

        .source-badge { font-size: 10px; padding: 4px 8px; border-radius: 4px; font-weight: 700; color: #fff; text-transform: uppercase; }
        .source-website { background-color: #ffc107; color: #000; } 
        .source-whatsapp { background-color: #198754; }
        .source-manual { background-color: #0dcaf0; color: #000; }
        
        .serial-no { white-space: nowrap; font-weight: 700; color: #4e73df; font-size: 13px; text-align: center; vertical-align: middle; background-color: #f8fafc; border-radius: 6px; padding: 4px 8px; display: inline-block; }

        .form-check-input { width: 1.2em; height: 1.2em; cursor: pointer; }
        .row-selected { background-color: #eff6ff !important; }

        .tag-badge { font-size: 11px; padding: 4px 8px; background-color: #f8f9fa; color: #4f46e5; border: 1px solid #e0e7ff; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px; font-weight: 600; }
        .tag-badge i { cursor: pointer; color: #9ca3af; transition: 0.2s; }
        .tag-badge i:hover { color: #ef4444; }

        .btn-add-tag { background-color: #f8f9fa; color: #4f46e5; border: 1px solid #e0e7ff; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 4px; transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 3px; }
        .btn-add-tag:hover, .btn-add-tag[aria-expanded="true"] { background-color: #4f46e5; color: #ffffff; border-color: #4f46e5; }

        .note-tooltip-container { position: relative; display: inline-block; width: 100%; }
        .note-text-preview { max-width: 140px; font-size: 11.5px; cursor: help; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; color: #333; font-weight: 500; }
        .note-tooltip-box { visibility: hidden; opacity: 0; position: absolute; bottom: 125%; left: 0; background-color: #212529; color: #fff; padding: 10px 14px; border-radius: 6px; font-size: 12px; min-width: 150px; width: max-content; max-width: 280px; white-space: normal; word-wrap: break-word; z-index: 1050; box-shadow: 0 4px 15px rgba(0,0,0,0.3); transition: opacity 0.2s ease, visibility 0.2s ease; line-height: 1.5; text-align: left !important; }
        .note-tooltip-box::after { content: ''; position: absolute; top: 100%; left: 20px; border-width: 6px; border-style: solid; border-color: #212529 transparent transparent transparent; }
        .note-tooltip-container:hover .note-tooltip-box { visibility: visible; opacity: 1; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0 !important; padding: 10px !important; height: calc(100dvh - 70px) !important; }
            .search-filter-box-mobile-wrap { width: 100%; flex-wrap: wrap; }
            .input-group.shadow-sm { max-width: 100% !important; flex-grow: 1; }
            .filter-panel .row > div { margin-bottom: 12px; }
            .card-header-custom { padding: 10px 15px; }
            .table th, .table td { padding: 10px !important; }
            .btn-action-group { flex-direction: row; flex-wrap: wrap; }
            .btn-action-group > * { flex: 1 1 auto; }
            .note-tooltip-box { width: 200px; left: auto; right: -50px; transform: none; }
            .note-tooltip-box::after { left: auto; right: 60px; margin-left: 0; }
        }
    </style> 
</head> 
<body>      
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content" id="mainContent">          

        <div class="card card-custom">
            <!-- 🔥 SOLID FORM FOR SEARCH AND FILTER 🔥 -->
            <form id="filterForm" method="GET" action="<?= BASE_URL ?>leads">
                <div class="card-header-custom">
                    <div class="d-flex justify-content-between align-items-center w-100 flex-wrap gap-3">
                        <div class="d-flex gap-2 align-items-center search-filter-box-mobile-wrap">
                            <div class="input-group shadow-sm" style="max-width: 320px;">
                                <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                                <input type="text" name="search" id="searchLeads" class="form-control border-start-0 shadow-none" placeholder="Search Number, Name..." style="font-size: 13px;" value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm shadow-sm fw-bold">Search</button>
                            
                            <button class="btn btn-light border shadow-sm fw-bold text-secondary d-flex align-items-center gap-2" style="font-size: 13px;" id="toggleFilterBtn" type="button">
                                <i class="bi bi-funnel"></i> Filters 
                                <span id="leadCountBadge" class="badge bg-primary rounded-pill px-2 ms-1"><?= $total_leads ?? 0 ?></span>
                            </button>
                            
                            <?php if($hasActiveFilters): ?>
                                <button type="button" class="btn btn-light border shadow-sm fw-bold text-danger d-flex align-items-center gap-1" style="font-size: 13px;" onclick="clearAllFilters()" title="Clear all filters">
                                    <i class="bi bi-x-lg"></i> Clear
                                </button>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex align-items-center gap-2">
                            <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                <a href="<?= BASE_URL ?>leads/export_csv?<?= http_build_query($filters) ?>" onclick="exportSelectedLeads(event)" class="btn btn-outline-success btn-sm fw-bold d-flex align-items-center gap-1 shadow-sm">
                                    <i class="bi bi-file-earmark-excel"></i> <span class="d-none d-sm-inline">Export CSV</span>
                                </a>
                                <button type="button" class="btn btn-outline-danger btn-sm fw-bold d-flex align-items-center gap-1 shadow-sm" id="bulkDeleteBtn" onclick="deleteSelectedLeads()" style="display:none;">
                                    <i class="bi bi-trash"></i> <span class="d-none d-sm-inline">Delete Selected</span>
                                </button>
                            <?php endif; ?>
                            <button type="button" class="btn-add-lead" data-bs-toggle="modal" data-bs-target="#addLeadModal">
                                <i class="bi bi-plus-lg"></i> <span class="d-none d-sm-inline">Add New Lead</span>
                            </button>
                        </div>
                    </div>

                    <div class="filter-panel w-100 <?= ($hasActiveFilters && empty($filters['search'])) ? 'show' : '' ?>" id="advancedFilterPanel">
                        <div class="row g-3">
                            <div class="col-md-2">
                                <label class="form-label" style="font-size:11px; font-weight:bold; color:#777; margin-bottom:2px;">Lead Status</label>
                                <select class="form-select form-select-sm shadow-none border-secondary-subtle fw-bold" name="status" onchange="this.form.submit()">
                                    <option value="new" <?= (($filters['status'] ?? 'new') == 'new') ? 'selected' : '' ?>>New Leads (Pending)</option>
                                    <option value="pipeline" class="text-primary" <?= (($filters['status'] ?? '') == 'pipeline') ? 'selected' : '' ?>>In Pipeline (Tasks)</option>
                                    <option value="unqualified" class="text-danger" <?= (($filters['status'] ?? '') == 'unqualified') ? 'selected' : '' ?>>Hidden (Unqualified)</option>
                                    <option value="all" class="text-success" <?= (($filters['status'] ?? '') == 'all') ? 'selected' : '' ?>>View All Leads</option>
                                    <option value="catalog_sharing" <?= (($filters['status'] ?? '') == 'catalog_sharing') ? 'selected' : '' ?>>Catalog Sharing</option>
                                    <option value="follow_up" <?= (($filters['status'] ?? '') == 'follow_up') ? 'selected' : '' ?>>Follow Up</option>
                                    <option value="negotiation" <?= (($filters['status'] ?? '') == 'negotiation') ? 'selected' : '' ?>>Negotiation</option>
                                    <option value="sold" <?= (($filters['status'] ?? '') == 'sold') ? 'selected' : '' ?>>Sold</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label" style="font-size:11px; font-weight:bold; color:#777; margin-bottom:2px;">Tags (Labels)</label>
                                <select class="form-select form-select-sm shadow-none border-secondary-subtle fw-bold" name="tag" onchange="this.form.submit()">
                                    <option value="">All Tags</option>
                                    <?php if(!empty($tags)): ?>
                                        <?php foreach($tags as $t): ?>
                                            <option value="<?= htmlspecialchars($t['name']) ?>" <?= (($filters['tag'] ?? '') == $t['name']) ? 'selected' : '' ?>><?= htmlspecialchars($t['name']) ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label" style="font-size:11px; font-weight:bold; color:#777; margin-bottom:2px;">Temperature</label>
                                <select class="form-select form-select-sm shadow-none border-secondary-subtle fw-bold" name="temp" onchange="this.form.submit()">
                                    <option value="">All Temperatures</option>
                                    <option value="hot" class="text-danger" <?= (($filters['temp'] ?? '') == 'hot') ? 'selected' : '' ?>>🔥 Hot</option>
                                    <option value="warm" class="text-warning" <?= (($filters['temp'] ?? '') == 'warm') ? 'selected' : '' ?>>⭐ Warm</option>
                                    <option value="cold" class="text-info" <?= (($filters['temp'] ?? '') == 'cold') ? 'selected' : '' ?>>❄️ Cold</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label" style="font-size:11px; font-weight:bold; color:#777; margin-bottom:2px;">Source</label>
                                <select class="form-select form-select-sm shadow-none border-secondary-subtle" name="source" onchange="this.form.submit()">
                                    <option value="">All Sources</option>
                                    <option value="website" <?= (($filters['source'] ?? '') == 'website') ? 'selected' : '' ?>>Website</option>
                                    <option value="whatsapp" <?= (($filters['source'] ?? '') == 'whatsapp') ? 'selected' : '' ?>>WhatsApp</option>
                                    <option value="manual" <?= (($filters['source'] ?? '') == 'manual') ? 'selected' : '' ?>>Manual</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label" style="font-size:11px; font-weight:bold; color:#777; margin-bottom:2px;">Filter by Agent</label>
                                <select class="form-select form-select-sm shadow-none border-secondary-subtle" name="agent" onchange="this.form.submit()">
                                    <option value="">All Agents / Unassigned</option>
                                    <?php if(!empty($agents)): ?>
                                        <?php foreach($agents as $agent): ?>
                                            <option value="<?= $agent['id'] ?>" <?= (($filters['agent'] ?? '') == $agent['id']) ? 'selected' : '' ?>><?= htmlspecialchars($agent['name']) ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-1">
                                <label class="form-label" style="font-size:11px; font-weight:bold; color:#777; margin-bottom:2px;">Start Date</label>
                                <input type="date" name="start_date" max="<?= htmlspecialchars($todayLocal ?? date('Y-m-d')) ?>" value="<?= htmlspecialchars($filters['start_date'] ?? '') ?>" class="form-control form-control-sm shadow-none border-secondary-subtle text-muted" onchange="this.form.submit()">
                            </div>
                            <div class="col-md-1">
                                <label class="form-label" style="font-size:11px; font-weight:bold; color:#777; margin-bottom:2px;">End Date</label>
                                <input type="date" name="end_date" max="<?= htmlspecialchars($todayLocal ?? date('Y-m-d')) ?>" value="<?= htmlspecialchars($filters['end_date'] ?? '') ?>" class="form-control form-control-sm shadow-none border-secondary-subtle text-muted" onchange="this.form.submit()">
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                <th class="text-center" style="width: 40px;">
                                    <div class="form-check d-flex justify-content-center m-0">
                                        <input class="form-check-input" type="checkbox" id="selectAllCheckbox" onclick="toggleAllCheckboxes()">
                                    </div>
                                </th>
                            <?php endif; ?>
                            <th class="text-center" style="width: 100px; white-space: nowrap;">Lead ID</th>
                            <th style="min-width: 250px;">Name & Contact</th>
                            <th>Source</th>
                            <th style="min-width: 140px;">Location</th>
                            <th style="min-width: 180px;">Product Interest</th>
                            <th style="min-width: 140px;">Assigned To</th>
                            <th style="min-width: 120px;">Date Created <small class="text-muted">(<?= htmlspecialchars($displayTimezone ?? 'Asia/Kolkata') ?>)</small></th>
                            <th style="min-width: 160px;">Tags</th>
                            <th style="min-width: 180px;">Notes</th>
                            <th style="min-width: 120px;">Action</th>
                        </tr>
                    </thead>
                    <tbody id="leadsTableBody">
                        <?php if (empty($leads)): ?>
                            <tr>
                                <td colspan="<?= (($user_role ?? 'SALES') === 'ADMIN') ? '11' : '10' ?>" class="text-center py-5 text-muted">
                                    <i class="bi bi-people fs-1 d-block mb-2"></i>
                                    No leads found for this search/filter.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php 
                                $agent_colors = ['#e3f2fd', '#d1e7dd', '#fff3cd', '#f8d7da', '#e2e3e5', '#cff4fc', '#f1aeb5', '#e8f5e9'];
                                $pdoInstance = \Core\Database::getInstance(); 
                                
                                foreach ($leads as $lead): 
                                    
                                    $currentBgColor = '#ffffff';
                                    $assignedAgentName = 'Unassigned';
                                    
                                    if (!empty($lead['assigned_to'])) {
                                        $colorIndex = $lead['assigned_to'] % count($agent_colors);
                                        $currentBgColor = $agent_colors[$colorIndex];
                                        
                                        foreach($agents as $ag) {
                                            if($ag['id'] == $lead['assigned_to']) {
                                                $assignedAgentName = strtolower($ag['name']);
                                                break;
                                            }
                                        }
                                    }

                                    $leadStage = strtolower(trim($lead['lead_stage'] ?? 'new'));
                                    $leadSource = strtolower($lead['lead_source'] ?? 'manual');
                            ?>
                                <tr class="lead-row" id="row_<?= $lead['id'] ?>">
                                    
                                    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                        <td class="text-center">
                                            <div class="form-check d-flex justify-content-center m-0">
                                                <input class="form-check-input lead-checkbox" type="checkbox" value="<?= $lead['id'] ?>" onchange="handleCheckboxChange(this)">
                                            </div>
                                        </td>
                                    <?php endif; ?>

                                    <td class="text-center">
                                        <span class="serial-no">#LD-<?= str_pad($lead['id'], 4, '0', STR_PAD_LEFT) ?></span>
                                    </td>

                                    <td>
                                        <div class="contact-stack">
                                            <span class="contact-name lead-name"><?= htmlspecialchars($lead['full_name'] ?? 'N/A') ?></span>
                                            
                                            <?php if(!empty($lead['company_name'])): ?>
                                                <span class="contact-company">
                                                    <i class="bi bi-building" style="color: #8c98e8; margin-right: 3px;"></i>
                                                    <?= htmlspecialchars($lead['company_name']) ?>
                                                </span>
                                            <?php endif; ?>

                                            <span class="contact-detail">
                                                <i class="bi bi-telephone text-success" style="margin-right: 3px;"></i>
                                                <?= htmlspecialchars($lead['phone_number'] ?? $lead['whatsapp_number'] ?? 'N/A') ?>
                                            </span>
                                            
                                            <?php if(!empty($lead['email'])): ?>
                                                <span class="contact-detail" style="color: #666;">
                                                    <i class="bi bi-envelope" style="color: #8c98e8; margin-right: 3px;"></i>
                                                    <?php echo str_replace('@', '<span>@</span>', htmlspecialchars($lead['email'])); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    
                                    <td>
                                        <?php $badgeClass = ($leadSource == 'website') ? 'source-website' : (($leadSource == 'whatsapp') ? 'source-whatsapp' : 'source-manual'); ?>
                                        <span class="source-badge <?= $badgeClass ?>">
                                            <?= htmlspecialchars($lead['lead_source'] ?? 'Manual') ?>
                                        </span>
                                    </td>

                                    <td>
                                        <div class="address-box">
                                            <?= htmlspecialchars($lead['city'] ?? '') ?><br>
                                            <?= htmlspecialchars($lead['state'] ?? '') ?><br>
                                            <?= htmlspecialchars($lead['postal_code'] ?? '') ?><br>
                                            <span class="fw-bold text-dark"><?= htmlspecialchars($lead['country'] ?? '') ?></span>
                                        </div>
                                    </td>
                                    
                                    <td>
                                        <div class="product-scroll-box">
                                            <?php 
                                                $raw_products = html_entity_decode($lead['products_of_interest'] ?? '', ENT_QUOTES);
                                                $raw_products = preg_replace('/ - \$[0-9\.]+/', '|', $raw_products);
                                                $raw_products = str_replace([',', "\n", "\r"], '|', $raw_products);
                                                
                                                $product_array = array_filter(array_map('trim', explode('|', $raw_products)));
                                                
                                                if (!empty($product_array)) {
                                                    echo '<ol class="product-list lead-products">';
                                                    foreach($product_array as $prod) {
                                                        echo "<li>" . htmlspecialchars($prod) . "</li>";
                                                    }
                                                    echo '</ol>';
                                                } else {
                                                    echo '<span class="text-muted" style="font-size:12px;">None</span>';
                                                }
                                            ?>
                                        </div>
                                    </td>

                                    <td>
                                        <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                            <select class="form-select form-select-sm assign-dropdown" onchange="assignLead(<?= $lead['id'] ?>, this)" style="width: 140px; box-shadow: none; border-color: #ddd; font-size: 13px; font-weight: 500; background-color: <?= $currentBgColor ?>; color: #333; padding: 5px 10px;">
                                                <option value="" style="background: #ffffff;">Unassigned</option>
                                                <?php foreach($agents as $agent): ?>
                                                    <?php $optColor = $agent_colors[$agent['id'] % count($agent_colors)]; ?>
                                                    <option value="<?= $agent['id'] ?>" data-color="<?= $optColor ?>" style="background: #ffffff;" <?= (isset($lead['assigned_to']) && $lead['assigned_to'] == $agent['id']) ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($agent['name']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php else: ?>
                                            <?php if(empty($lead['assigned_to'])): ?>
                                                <span class="badge bg-secondary border border-secondary text-white" style="font-weight: 500; font-size: 12px; padding: 6px 10px;">Unassigned</span>
                                            <?php else: ?>
                                                <span class="badge text-dark" style="font-weight: 600; font-size: 12px; background-color: <?= $currentBgColor ?>; padding: 6px 10px; border: 1px solid #ccc;">
                                                    Assigned to You
                                                </span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>

                                    <td style="font-size: 12px;">
                                        <?php
                                            // Database UTC timestamp is displayed in company Preferences timezone
                                            $createdAt = $lead['created_at'] ?? null;
                                            echo '<span class="d-block text-dark fw-medium">' . htmlspecialchars(\Core\Timezone::formatUtc($createdAt, $displayTimezone ?? 'Asia/Kolkata', 'M d, Y')) . '</span>';
                                            echo '<small class="text-muted">' . htmlspecialchars(\Core\Timezone::formatUtc($createdAt, $displayTimezone ?? 'Asia/Kolkata', 'h:i A')) . '</small>';
                                        ?>
                                    </td>
                                    
                                    <td>
                                        <div class="d-flex flex-wrap gap-2 align-items-center">
                                            <?php 
                                                $leadTags = !empty($lead['tags']) ? array_filter(array_map('trim', explode(',', $lead['tags']))) : [];
                                                if (!empty($leadTags)):
                                                    foreach($leadTags as $t): 
                                            ?>
                                                    <span class="tag-badge shadow-sm">
                                                        <?= htmlspecialchars($t) ?>
                                                        <i class="bi bi-x fs-6 ms-1" style="line-height: 1;" onclick="removeLeadTag(<?= $lead['id'] ?>, '<?= htmlspecialchars(addslashes($t)) ?>')"></i>
                                                    </span>
                                            <?php 
                                                    endforeach;
                                                endif; 
                                            ?>
                                            
                                            <div class="dropdown d-inline-block">
                                                <button class="btn-add-tag" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                                    <i class="bi bi-plus" style="font-size:14px; margin-left:-3px;"></i> Tag
                                                </button>
                                                <div class="dropdown-menu p-2 shadow-lg border-0" style="min-width: 220px; z-index: 9999; border-radius: 8px;">
                                                    <div class="d-flex gap-1 mb-2">
                                                        <button class="btn btn-sm btn-light border flex-grow-1 fw-bold text-dark" style="font-size: 11px;" onclick="switchTagMode(<?= $lead['id'] ?>, 'select')" id="btn_mode_select_<?= $lead['id'] ?>">Select Tag</button>
                                                        <button class="btn btn-sm btn-white border flex-grow-1 text-muted" style="font-size: 11px;" onclick="switchTagMode(<?= $lead['id'] ?>, 'new')" id="btn_mode_new_<?= $lead['id'] ?>">New Tag</button>
                                                    </div>
                                                    
                                                    <div class="input-group input-group-sm" id="mode_select_<?= $lead['id'] ?>">
                                                        <select class="form-select shadow-none border-secondary-subtle" id="existing_tag_<?= $lead['id'] ?>">
                                                            <option value="" disabled selected>Select a tag...</option>
                                                            <?php foreach($tags as $ut): ?>
                                                                <option value="<?= htmlspecialchars($ut['name']) ?>"><?= htmlspecialchars($ut['name']) ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                        <button class="btn btn-outline-secondary" onclick="submitTag(<?= $lead['id'] ?>, 'existing')"><i class="bi bi-plus"></i></button>
                                                    </div>

                                                    <div class="input-group input-group-sm d-none" id="mode_new_<?= $lead['id'] ?>">
                                                        <input type="text" class="form-control shadow-none border-secondary-subtle" id="new_tag_<?= $lead['id'] ?>" placeholder="Create new tag...">
                                                        <button class="btn btn-outline-secondary" onclick="submitTag(<?= $lead['id'] ?>, 'new')"><i class="bi bi-plus"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    
                                    <td>
                                        <div class="d-flex align-items-center gap-1 mb-1">
                                            <span class="text-muted fw-bold" style="font-size: 10px; text-transform: uppercase;">
                                                <i class="bi bi-journal-text"></i> Note
                                            </span>
                                            <button type="button" class="btn btn-sm btn-light border p-0 ms-1 text-primary shadow-sm rounded-circle" style="font-size: 14px; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;" onclick="openNoteModal(<?= $lead['id'] ?>); event.stopPropagation();" title="Add Note">
                                                <i class="bi bi-plus"></i>
                                            </button>
                                        </div>
                                        <?php
                                        if (isset($pdoInstance)) {
                                            $stmtNote = $pdoInstance->prepare("SELECT note_text FROM lead_notes WHERE lead_id = ? AND note_type = 'Note' ORDER BY created_at DESC LIMIT 1");
                                            $stmtNote->execute([$lead['id']]);
                                            $latestNote = $stmtNote->fetchColumn();
                                        } else {
                                            $latestNote = false;
                                        }
                                        ?>
                                        
                                        <?php if($latestNote): ?>
                                            <div class="note-tooltip-container mt-1">
                                                <span class="note-text-preview"><?= htmlspecialchars($latestNote) ?></span>
                                                <div class="note-tooltip-box"><?= nl2br(htmlspecialchars(trim($latestNote))) ?></div>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-muted mt-1" style="font-style: italic; font-size: 10px;">No notes...</div>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <div class="btn-action-group">
                                            <a href="<?= BASE_URL ?>leadprofile/index/<?= $lead['id'] ?>?ref=leads" class="btn-open-profile">
                                                Open Profile
                                            </a>
                                            <button onclick="markQualified(<?= $lead['id'] ?>)" class="btn-qualified">
                                                <i class="bi bi-check-circle"></i> Qualified
                                            </button>
                                            <button onclick="markUnqualified(<?= $lead['id'] ?>)" class="btn-unqualified">
                                                <i class="bi bi-x-circle"></i> Unqualified
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- 🔥 PERFECT RELIABLE PAGINATION WITH DIRECT JUMP 🔥 -->
            <?php if (($total_pages ?? 0) > 1): ?>
            <div class="card-footer bg-white border-top d-flex justify-content-between align-items-center py-3" id="paginationWrapper">
                <div class="d-flex align-items-center">
                    <span class="text-muted small fw-bold me-3">Page <?= $current_page ?> of <?= $total_pages ?></span>
                    
                    <div class="d-flex align-items-center bg-light border rounded px-2" style="height: 30px;">
                        <span class="text-muted small fw-bold me-2" style="font-size: 11px;">Go to:</span>
                        <input type="number" class="form-control form-control-sm text-center shadow-none p-0 border-0 bg-transparent fw-bold" style="width: 40px; font-size:12px;" min="1" max="<?= $total_pages ?>" value="<?= $current_page ?>" 
                               onchange="window.location.href='<?= getPaginationUrl($filters, '') ?>'+this.value">
                    </div>
                </div>

                <ul class="pagination pagination-sm mb-0 shadow-sm">
                    <li class="page-item <?= ($current_page <= 1) ? 'disabled' : '' ?>">
                        <a class="page-link text-primary fw-bold" href="<?= getPaginationUrl($filters, $current_page - 1) ?>">Previous</a>
                    </li>
                    
                    <?php 
                    $start_page = max(1, $current_page - 2);
                    $end_page = min($total_pages, $current_page + 2);
                    for ($i = $start_page; $i <= $end_page; $i++): 
                    ?>
                        <li class="page-item <?= ($i == $current_page) ? 'active' : '' ?>">
                            <a class="page-link" href="<?= getPaginationUrl($filters, $i) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    
                    <li class="page-item <?= ($current_page >= $total_pages) ? 'disabled' : '' ?>">
                        <a class="page-link text-primary fw-bold" href="<?= getPaginationUrl($filters, $current_page + 1) ?>">Next</a>
                    </li>
                </ul>
            </div>
            <?php endif; ?>

        </div>
    </div> 

    <!-- Modal for Adding Manual Lead -->
    <div class="modal fade" id="addLeadModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow-lg">
          <form action="<?= BASE_URL ?>leads/add" method="POST">
              <div class="modal-header bg-light border-bottom-0 pb-3">
                <h5 class="modal-title fw-bold text-dark">
                    <i class="bi bi-person-plus-fill text-primary me-2"></i>Add New Lead
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body pt-2 pb-4 px-4">
                <div class="row g-3">
                    <div class="col-12 mb-1 mt-2">
                        <h6 class="fw-bold text-muted border-bottom pb-2" style="font-size: 13px; text-transform: uppercase;">Contact Details</h6>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary small mb-1">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="full_name" class="form-control shadow-none border-secondary-subtle" required placeholder="Enter full name">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary small mb-1">Phone Number <span class="text-danger">*</span></label>
                        <input type="text" name="phone_number" class="form-control shadow-none border-secondary-subtle" required placeholder="e.g. 9876543210">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary small mb-1">Email Address</label>
                        <input type="email" name="email" class="form-control shadow-none border-secondary-subtle" placeholder="Email (optional)">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary small mb-1">Company Name</label>
                        <input type="text" name="company_name" class="form-control shadow-none border-secondary-subtle" placeholder="Business name (optional)">
                    </div>
                    
                    <div class="col-12 mb-1 mt-4">
                        <h6 class="fw-bold text-muted border-bottom pb-2" style="font-size: 13px; text-transform: uppercase;">Location Details</h6>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary small mb-1">City</label>
                        <input type="text" name="city" class="form-control shadow-none border-secondary-subtle" placeholder="e.g. Mumbai">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary small mb-1">State</label>
                        <input type="text" name="state" class="form-control shadow-none border-secondary-subtle" placeholder="e.g. Maharashtra">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold text-secondary small mb-1">Postal / PIN Code</label>
                        <input type="text" name="postal_code" class="form-control shadow-none border-secondary-subtle" placeholder="e.g. 400001">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold text-secondary small mb-1">Country</label>
                        <input type="text" name="country" class="form-control shadow-none border-secondary-subtle" value="India">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold text-secondary small mb-1">Based In</label>
                        <select name="based_in" class="form-select shadow-none border-secondary-subtle">
                            <option value="Domestic" selected>Domestic</option>
                            <option value="International">International</option>
                        </select>
                    </div>

                    <div class="col-12 mb-1 mt-4">
                        <h6 class="fw-bold text-muted border-bottom pb-2" style="font-size: 13px; text-transform: uppercase;">Interest & Requirements</h6>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-bold text-secondary small mb-1">Product Interest</label>
                        <textarea name="products_of_interest" class="form-control shadow-none border-secondary-subtle" rows="2" placeholder="e.g. Kurti, Dupatta Set, Co-Ord Sets..."></textarea>
                    </div>
                </div>
              </div>
              <div class="modal-footer bg-light border-top-0 pt-0">
                <button type="button" class="btn btn-light border fw-bold text-secondary shadow-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4 shadow-sm"><i class="bi bi-save me-1"></i> Save Lead</button>
              </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Modal for Adding Quick Note -->
    <iframe name="hidden_note_iframe" id="hidden_note_iframe" style="display:none;"></iframe>
    <div class="modal fade" id="addNoteModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
          <form action="<?= BASE_URL ?>leadprofile/add_note" method="POST" target="hidden_note_iframe" id="noteForm">
              <div class="modal-header bg-light border-bottom-0 pb-3">
                <h5 class="modal-title fw-bold text-dark"><i class="bi bi-journal-plus text-primary me-2"></i>Add Quick Note</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body pt-2 pb-4 px-4">
                <input type="hidden" name="lead_id" id="note_lead_id">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Note Text <span class="text-danger">*</span></label>
                    <textarea name="note" class="form-control shadow-none border-secondary-subtle" rows="3" required placeholder="Type your note here..."></textarea>
                </div>
              </div>
              <div class="modal-footer bg-light border-top-0 pt-0">
                <button type="button" class="btn btn-light border fw-bold text-secondary shadow-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4 shadow-sm" onclick="handleNoteSubmit()"><i class="bi bi-save me-1"></i> Save Note</button>
              </div>
          </form>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const baseUrl = '<?= rtrim(BASE_URL, '/') ?>/';

        // Toggle advanced filters
        document.getElementById('toggleFilterBtn').addEventListener('click', function() {
            document.getElementById('advancedFilterPanel').classList.toggle('show');
        });

        function clearAllFilters() {
            document.getElementById('searchLeads').value = '';
            document.querySelector('select[name="status"]').value = 'new';
            document.querySelector('select[name="agent"]').value = '';
            document.querySelector('select[name="tag"]').value = '';
            document.querySelector('select[name="source"]').value = '';
            document.querySelector('select[name="temp"]').value = '';
            document.querySelector('input[name="start_date"]').value = '';
            document.querySelector('input[name="end_date"]').value = '';
            document.getElementById('filterForm').submit();
        }

        // Tags Logic
        function switchTagMode(leadId, mode) {
            if(mode === 'select') {
                document.getElementById('mode_select_' + leadId).classList.remove('d-none');
                document.getElementById('mode_new_' + leadId).classList.add('d-none');
                document.getElementById('btn_mode_select_' + leadId).classList.replace('btn-white', 'btn-light');
                document.getElementById('btn_mode_select_' + leadId).classList.replace('text-muted', 'text-dark');
                document.getElementById('btn_mode_select_' + leadId).classList.add('fw-bold');
                document.getElementById('btn_mode_new_' + leadId).classList.replace('btn-light', 'btn-white');
                document.getElementById('btn_mode_new_' + leadId).classList.replace('text-dark', 'text-muted');
                document.getElementById('btn_mode_new_' + leadId).classList.remove('fw-bold');
            } else {
                document.getElementById('mode_new_' + leadId).classList.remove('d-none');
                document.getElementById('mode_select_' + leadId).classList.add('d-none');
                document.getElementById('btn_mode_new_' + leadId).classList.replace('btn-white', 'btn-light');
                document.getElementById('btn_mode_new_' + leadId).classList.replace('text-muted', 'text-dark');
                document.getElementById('btn_mode_new_' + leadId).classList.add('fw-bold');
                document.getElementById('btn_mode_select_' + leadId).classList.replace('btn-light', 'btn-white');
                document.getElementById('btn_mode_select_' + leadId).classList.replace('text-dark', 'text-muted');
                document.getElementById('btn_mode_select_' + leadId).classList.remove('fw-bold');
            }
        }

        function submitTag(leadId, mode) {
            let tagVal = '';
            if(mode === 'existing') {
                tagVal = document.getElementById('existing_tag_' + leadId).value;
            } else {
                tagVal = document.getElementById('new_tag_' + leadId).value;
            }
            if(tagVal && tagVal.trim() !== '') {
                fetch(`${baseUrl}leadprofile/add_tag`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ lead_id: leadId, tag: tagVal.trim() })
                }).then(response => response.json()).then(data => {
                    if (data.status === 'success') { window.location.reload(); } 
                    else { alert("Failed to add tag."); }
                }).catch(error => console.error('Error adding tag:', error));
            }
        }

        function removeLeadTag(leadId, tag) {
            fetch(`${baseUrl}leadprofile/remove_tag`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ lead_id: leadId, tag: tag.trim() })
            }).then(response => response.json()).then(data => {
                if (data.status === 'success') { window.location.reload(); } 
                else { alert("Failed to remove tag."); }
            }).catch(error => console.error('Error removing tag:', error));
        }

        // Quick Notes Logic
        let noteModalInstance;
        function openNoteModal(leadId) {
            document.getElementById('note_lead_id').value = leadId;
            document.getElementById('noteForm').reset();
            if(!noteModalInstance) { noteModalInstance = new bootstrap.Modal(document.getElementById('addNoteModal')); }
            noteModalInstance.show();
        }

        function handleNoteSubmit() {
            setTimeout(() => { if(noteModalInstance) { noteModalInstance.hide(); } window.location.reload(); }, 800);
        }

        // Lead Qualification Logic
        function markQualified(leadId) {
            fetch(`${baseUrl}leads/mark_qualified`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lead_id: leadId }) })
            .then(r=>r.json()).then(d => { if(d.status==='success') { window.location.reload(); } });
        }

        function markUnqualified(leadId) {
            fetch(`${baseUrl}leads/mark_unqualified`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lead_id: leadId }) })
            .then(r=>r.json()).then(d => { if(d.status==='success') { window.location.reload(); } });
        }

        function assignLead(leadId, selectElement) {
            let agentId = selectElement.value;
            let selectedOption = selectElement.options[selectElement.selectedIndex];
            
            if(agentId === "") { selectElement.style.backgroundColor = "#ffffff"; } 
            else { selectElement.style.backgroundColor = selectedOption.getAttribute('data-color'); }
            
            fetch(`${baseUrl}leads/assign_lead`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lead_id: leadId, agent_id: agentId }) }).catch(e => {});
        }

        // Export all filtered leads, or only the checked leads on the current page.
        // The existing CSV link remains functional when nothing is checked.
        function exportSelectedLeads(event) {
            const selectedBoxes = document.querySelectorAll('.lead-checkbox:checked');
            if (selectedBoxes.length === 0) return;

            event.preventDefault();
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `${baseUrl}leads/export_csv`;
            form.style.display = 'none';

            const filters = new FormData(document.getElementById('filterForm'));
            filters.forEach((value, key) => {
                const field = document.createElement('input');
                field.type = 'hidden';
                field.name = key;
                field.value = value;
                form.appendChild(field);
            });

            selectedBoxes.forEach(checkbox => {
                const field = document.createElement('input');
                field.type = 'hidden';
                field.name = 'selected_ids[]';
                field.value = checkbox.value;
                form.appendChild(field);
            });

            document.body.appendChild(form);
            form.submit();
            setTimeout(() => form.remove(), 1000);
        }

        // Bulk Actions
        function toggleAllCheckboxes() {
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            const checkboxes = document.querySelectorAll('.lead-checkbox');
            let anyChecked = false;
            checkboxes.forEach(cb => { cb.checked = selectAllCheckbox.checked; handleRowStyle(cb); if(cb.checked) anyChecked = true; });
            toggleDeleteButton(anyChecked);
        }

        function handleCheckboxChange(checkbox) {
            handleRowStyle(checkbox); const anyChecked = document.querySelectorAll('.lead-checkbox:checked').length > 0;
            toggleDeleteButton(anyChecked);
            if (!checkbox.checked) { let selectAll = document.getElementById('selectAllCheckbox'); if(selectAll) selectAll.checked = false; }
        }

        function handleRowStyle(checkbox) { let row = checkbox.closest('tr'); if (checkbox.checked) { row.classList.add('row-selected'); } else { row.classList.remove('row-selected'); } }

        function toggleDeleteButton(show) { const deleteBtn = document.getElementById('bulkDeleteBtn'); if (deleteBtn) { deleteBtn.style.display = show ? 'flex' : 'none'; } }

        function deleteSelectedLeads() {
            const selectedBoxes = document.querySelectorAll('.lead-checkbox:checked');
            if (selectedBoxes.length === 0) return;
            if (confirm(`Are you sure you want to permanently delete ${selectedBoxes.length} selected lead(s)? This cannot be undone.`)) {
                let leadIds = Array.from(selectedBoxes).map(cb => cb.value);
                fetch(`${baseUrl}leads/delete_bulk`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lead_ids: leadIds }) })
                .then(response => response.json()).then(data => {
                    if (data.status === 'success') {
                        window.location.reload();
                    } else { alert('Error deleting leads.'); }
                }).catch(e => {});
            }
        }

        // Scroll Memory
        window.addEventListener('beforeunload', function() {
            let tableContainer = document.querySelector('.table-responsive');
            if (tableContainer) { sessionStorage.setItem('leadsScrollState', tableContainer.scrollTop); }
        });

        document.addEventListener("DOMContentLoaded", () => {
            let savedScroll = sessionStorage.getItem('leadsScrollState');
            if (savedScroll) {
                setTimeout(() => {
                    let tableContainer = document.querySelector('.table-responsive');
                    if (tableContainer) tableContainer.scrollTop = savedScroll;
                }, 50);
            }
        });

        // 🔥 SILENT AUTO-REFRESH 🔥
        function refreshSilently() {
            // Do not discard selected rows while preparing a CSV export.
            if (document.querySelector('.lead-checkbox:checked')) return;
            let isDropdownOpen = document.activeElement && document.activeElement.tagName.toLowerCase() === 'select';
            let searchBoxFocused = document.activeElement && document.activeElement.id === 'searchLeads';
            let isNoteFocused = document.activeElement && document.activeElement.tagName.toLowerCase() === 'textarea' && document.activeElement.name === 'note';
            let noteModalEl = document.getElementById('addNoteModal'); let isNoteModalOpen = noteModalEl && noteModalEl.classList.contains('show');
            let isTypingTag = document.activeElement && document.activeElement.tagName.toLowerCase() === 'input' && document.activeElement.id.startsWith('new_tag_');
            let isAnyDropdownExpanded = false;
            if (document.querySelector('[data-bs-toggle="dropdown"][aria-expanded="true"]') !== null) isAnyDropdownExpanded = true;
            if (document.querySelector('.dropdown-menu.show') !== null) isAnyDropdownExpanded = true;

            if (!isDropdownOpen && !searchBoxFocused && !isNoteFocused && !isNoteModalOpen && !isAnyDropdownExpanded && !isTypingTag) {
                fetch(window.location.href).then(response => response.text()).then(html => {
                    let parser = new DOMParser(); 
                    let doc = parser.parseFromString(html, 'text/html');
                    
                    let oldTbody = document.getElementById('leadsTableBody'); 
                    let newTbody = doc.getElementById('leadsTableBody');
                    
                    if (oldTbody && newTbody && oldTbody.innerHTML !== newTbody.innerHTML) {
                        oldTbody.innerHTML = newTbody.innerHTML; 
                        
                        let oldBadge = document.getElementById('leadCountBadge');
                        let newBadge = doc.getElementById('leadCountBadge');
                        if (oldBadge && newBadge) oldBadge.innerText = newBadge.innerText;

                        let oldPagination = document.getElementById('paginationWrapper');
                        let newPagination = doc.getElementById('paginationWrapper');
                        if (oldPagination && newPagination) {
                            oldPagination.innerHTML = newPagination.innerHTML;
                        }
                    }
                }).catch(e => {});
            }
        }

        let refreshTimer = setInterval(refreshSilently, 10000); 
        document.querySelector('.table-responsive').addEventListener('mouseenter', () => { clearInterval(refreshTimer); });
        document.querySelector('.table-responsive').addEventListener('mouseleave', () => { refreshTimer = setInterval(refreshSilently, 10000); });
    </script>
</body> 
</html>