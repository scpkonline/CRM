<?php 
    // Tasks & Leads sidebar iframe view (Full Responsive Mobile & Desktop)
    if (isset($_GET['ref']) && strpos($_GET['ref'], 'sidebar') !== false): 
?>
<style>
    /* Kill CRM Shell Navigation & Headers when inside an iframe */
    .sidebar, .global-top-header, .sidebar-overlay, .back-btn, #mobileMenuBtn, .left-col .back-btn { 
        display: none !important; height: 0 !important; margin: 0 !important; padding: 0 !important; 
    }
    
    html, body { 
        background-color: #f4f7f6 !important; 
        padding: 0 !important; 
        margin: 0 !important; 
        overflow: hidden !important; 
        height: 100dvh !important; 
        width: 100vw !important; 
    }

    .main-content { 
        margin: 0 !important; 
        padding: 0 !important; 
        height: 100dvh !important; 
        width: 100vw !important; 
        display: flex !important; 
        flex-direction: column !important; 
        overflow: hidden !important; 
        border: none !important; 
        background: #fff !important; 
    }

    /* DESKTOP VIEW */
    @media (min-width: 769px) {
        #mobileProfileTabs { display: none !important; }

        .content-area { 
            display: flex !important; 
            flex-direction: row !important; 
            flex-grow: 1 !important; 
            width: 100% !important; 
            height: 100vh !important; 
            max-height: 100vh !important; 
            overflow: hidden !important; 
            margin: 0 !important; 
            padding: 0 !important; 
        }

        .left-col { 
            width: 280px !important; 
            min-width: 280px !important; 
            max-width: 280px !important; 
            flex-shrink: 0 !important; 
            height: 100vh !important; 
            max-height: 100vh !important; 
            overflow-y: auto !important; 
            padding: 15px 20px !important; 
            border-right: 1px solid #ddd !important; 
            background: #fff !important; 
            box-sizing: border-box !important; 
            display: block !important; 
        }
        .left-col .mobile-collapse-wrapper { display: block !important; }
        .left-col .info-title { margin-top: 0 !important; margin-bottom: 15px !important; padding-bottom: 8px !important; }

        .middle-col { 
            flex: 1 1 0 !important; 
            min-width: 0 !important; 
            display: flex !important; 
            flex-direction: column !important; 
            height: 100vh !important; 
            max-height: 100vh !important; 
            overflow: hidden !important; 
            border-right: 1px solid #ddd !important; 
            background: #efeae2 !important; 
        }
        .chat-top { height: 55px !important; min-height: 55px !important; flex-shrink: 0 !important; padding: 0 15px !important; background: #f0f2f5 !important; border-bottom: 1px solid #ddd !important; }
        .chat-body { flex: 1 1 0 !important; min-height: 0 !important; height: 0 !important; overflow-y: auto !important; padding: 15px !important; }
        #wa-window-alert { flex-shrink: 0 !important; padding: 4px 15px !important; }
        .chat-footer { flex-shrink: 0 !important; margin-top: auto !important; background: #f0f2f5 !important; padding: 8px 12px !important; border-top: 1px solid #ddd !important; z-index: 10 !important; }

        .right-col { 
            width: 320px !important; 
            min-width: 320px !important; 
            max-width: 320px !important; 
            flex-shrink: 0 !important; 
            display: flex !important; 
            flex-direction: column !important; 
            height: 100vh !important; 
            max-height: 100vh !important; 
            overflow: hidden !important; 
            border-left: 1px solid #ddd !important; 
            background: #fff !important; 
            box-sizing: border-box !important; 
        }
        #crmToolsWrapper {
            display: flex !important;
            flex-direction: column !important;
            flex-grow: 1 !important;
            height: 100% !important;
            min-height: 0 !important;
            overflow: hidden !important;
        }
        .right-col .tabs, .right-col .notes-area { flex-shrink: 0 !important; }
        .right-col .timeline-container { 
            flex: 1 1 0 !important; 
            height: 0 !important; 
            min-height: 0 !important; 
            overflow-y: auto !important; 
            padding: 15px 20px !important; 
        }
    }

    /* MOBILE VIEW FIXES */
    @media (max-width: 768px) {
        #mobileProfileTabs {
            display: flex !important;
            background: #fff;
            border-bottom: 1px solid #ddd;
            height: 48px;
            flex-shrink: 0;
            z-index: 20;
            width: 100%;
        }
        .m-tab-btn {
            flex: 1;
            border: none;
            background: transparent;
            font-size: 13px;
            font-weight: 600;
            color: #64748b;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            border-bottom: 3px solid transparent;
            cursor: pointer;
        }
        .m-tab-btn.active {
            color: #0d6efd;
            border-bottom: 3px solid #0d6efd;
            background: #f8fafc;
        }

        .content-area { 
            display: flex !important; 
            flex-direction: column !important; 
            flex: 1 1 auto !important; 
            height: calc(100dvh - 118px) !important; 
            max-height: calc(100dvh - 118px) !important; 
            width: 100vw !important; 
            overflow: hidden !important; 
            position: relative;
        }
        
        .content-area.show-info .left-col { 
            display: block !important; 
            width: 100vw !important; 
            height: 100% !important; 
            overflow-y: auto !important; 
            padding: 15px 20px 80px 20px !important; 
            box-sizing: border-box !important; 
            border: none !important;
        }
        .content-area.show-info .middle-col, 
        .content-area.show-info .right-col { display: none !important; }
        .left-col .mobile-toggle-header { display: none !important; }
        .left-col .mobile-collapse-wrapper { display: block !important; }

        .content-area.show-chat .middle-col { 
            display: flex !important; 
            flex-direction: column !important; 
            width: 100vw !important; 
            height: 100% !important; 
            min-height: 0 !important; 
            overflow: hidden !important; 
            background: #efeae2 !important; 
            border: none !important;
        }
        .content-area.show-chat .left-col, 
        .content-area.show-chat .right-col { display: none !important; }
        .middle-col .chat-top { height: 50px !important; min-height: 50px !important; flex-shrink: 0 !important; }
        .middle-col .chat-body { 
            flex: 1 1 auto !important; 
            min-height: 0 !important; 
            height: auto !important; 
            overflow-y: auto !important; 
            padding: 10px !important; 
        }
        .middle-col .chat-footer { 
            flex-shrink: 0 !important; 
            margin-top: auto !important; 
            padding: 8px 10px !important; 
            background: #f0f2f5 !important; 
            border-top: 1px solid #ddd !important; 
            z-index: 50 !important; 
            padding-bottom: calc(10px + env(safe-area-inset-bottom)) !important; 
        }
        .chat-footer-inner { padding: 10px !important; }

        .content-area.show-notes .right-col { 
            display: flex !important; 
            flex-direction: column !important; 
            width: 100vw !important; 
            height: 100% !important; 
            overflow: hidden !important; 
            border: none !important; 
        }
        .content-area.show-notes .left-col, 
        .content-area.show-notes .middle-col { display: none !important; }
        .right-col .mobile-toggle-header { display: none !important; }
        #crmToolsWrapper { 
            display: flex !important; 
            flex-direction: column !important; 
            height: 100% !important; 
            flex: 1 1 0 !important; 
            min-height: 0 !important; 
            overflow: hidden !important; 
        }
        .right-col .timeline-container { 
            flex: 1 1 0 !important; 
            height: 0 !important; 
            min-height: 0 !important; 
            overflow-y: auto !important; 
            padding: 15px 15px 80px 15px !important; 
        }
    }
</style>

<div id="mobileProfileTabs">
    <button type="button" class="m-tab-btn active" id="mTabChat" onclick="switchMobileView('chat')">
        <i class="bi bi-chat-dots-fill text-success"></i> Chat
    </button>
    <button type="button" class="m-tab-btn" id="mTabInfo" onclick="switchMobileView('info')">
        <i class="bi bi-person-lines-fill text-primary"></i> Info
    </button>
    <button type="button" class="m-tab-btn" id="mTabNotes" onclick="switchMobileView('notes')">
        <i class="bi bi-journal-text text-warning"></i> Notes
    </button>
</div>

<script>
    function switchMobileView(tab) {
        if (window.innerWidth > 768) return;
        
        let container = document.querySelector('.content-area');
        let btnChat = document.getElementById('mTabChat');
        let btnInfo = document.getElementById('mTabInfo');
        let btnNotes = document.getElementById('mTabNotes');

        if (!container) return;

        [btnChat, btnInfo, btnNotes].forEach(b => { if(b) b.classList.remove('active'); });
        container.classList.remove('show-chat', 'show-info', 'show-notes');

        if (tab === 'chat') {
            if (btnChat) btnChat.classList.add('active');
            container.classList.add('show-chat');
            let chatBox = document.getElementById('messageContainer');
            if (chatBox) {
                setTimeout(() => { chatBox.scrollTop = chatBox.scrollHeight; }, 100);
            }
        } else if (tab === 'info') {
            if (btnInfo) btnInfo.classList.add('active');
            container.classList.add('show-info');
        } else if (tab === 'notes') {
            if (btnNotes) btnNotes.classList.add('active');
            container.classList.add('show-notes');
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        if (window.innerWidth <= 768) {
            switchMobileView('chat');
        }
    });
</script>
<?php return; endif; ?>

<!-- GLOBAL DARK MODE SCRIPT -->
<script>
    if (document.cookie.includes('theme=dark')) {
        document.documentElement.classList.add('dark-theme');
    }
</script>

<?php 
    $current_url = $_SERVER['REQUEST_URI']; 
    $clean_title = explode(' - ', $title ?? 'SCPK CRM')[0];

    $pdo = \Core\Database::getInstance();
    $global_user_img = null;
    if(isset($_SESSION['user_id'])) {
        try {
            $stmt = $pdo->prepare("SELECT profile_image FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $g_user = $stmt->fetch(\PDO::FETCH_ASSOC);
            $global_user_img = $g_user['profile_image'] ?? null;
        } catch(\Exception $e) {}
    }
?>
<style>
    html.dark-theme body { background-color: #121212 !important; color: #e0e0e0 !important; }
    html.dark-theme .sidebar { background-color: #1a1a1a !important; box-shadow: 2px 0 10px rgba(0,0,0,0.5); }
    html.dark-theme .global-top-header { background-color: #1a1a1a !important; border-bottom: 1px solid #333 !important; }
    html.dark-theme .header-title { color: #fff !important; }
    html.dark-theme .header-refresh, html.dark-theme .user-profile-link { color: #a0aab5 !important; }
    html.dark-theme .header-right .user-profile-link:hover { background-color: #2d2d2d !important; }
    html.dark-theme .nav-link { color: #a0aab5 !important; }
    html.dark-theme .nav-link:hover, html.dark-theme .nav-link.active { background-color: #2d2d2d !important; color: #60a5fa !important; border-left: 3px solid #60a5fa !important; }
    html.dark-theme .sidebar-bottom { border-top: 1px solid #333 !important; }
    html.dark-theme .card, html.dark-theme .bg-white { background-color: #1e1e1e !important; border-color: #333 !important; color: #fff !important; }
    html.dark-theme table { color: #e0e0e0 !important; border-color: #444 !important; }
    html.dark-theme .modal-content { background-color: #1e1e1e !important; color: #e0e0e0 !important; }
    html.dark-theme .table-hover tbody tr:hover { background-color: #2d2d2d !important; }

    .sidebar { 
        height: 100vh; 
        width: 80px; 
        position: fixed; 
        top: 0; 
        left: 0; 
        background-color: #ffffff; 
        box-shadow: 2px 0 10px rgba(0,0,0,0.05); 
        padding-top: 24px; 
        z-index: 1050; 
        display: flex; 
        flex-direction: column; 
        overflow-x: hidden; 
        transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s ease; 
    }
    
    .sidebar:hover { 
        width: 250px; 
        box-shadow: 5px 0 25px rgba(0,0,0,0.1); 
    }

    .sidebar-brand { 
        font-size: 20px; 
        font-weight: 800; 
        color: #007bff; 
        margin-bottom: 30px; 
        white-space: nowrap; 
        display: flex; 
        align-items: center; 
        padding: 0 20px; 
        text-decoration: none;
        flex-shrink: 0;
    }
    
    .brand-icon { 
        width: 30px; 
        text-align: center; 
        margin-right: 15px; 
        font-size: 24px; 
    }
    
    .brand-text { 
        opacity: 0; 
        transition: opacity 0.2s ease; 
    }
    
    .sidebar:hover .brand-text { 
        opacity: 1; 
        transition-delay: 0.05s; 
    }

    .sidebar-nav-container {
        flex-grow: 1;
        overflow-y: auto;
        overflow-x: hidden;
    }
    
    .sidebar-nav-container::-webkit-scrollbar { width: 4px; }
    .sidebar-nav-container::-webkit-scrollbar-thumb { background: #eee; border-radius: 4px; }

    .sidebar-nav { 
        list-style: none; 
        padding: 0; 
        margin: 0; 
        width: 250px; 
    }
    
    .nav-link { 
        color: #475569; 
        padding: 14px 20px; 
        font-weight: 500; 
        font-size: 14px; 
        transition: all 0.15s ease; 
        border-left: 3px solid transparent; 
        white-space: nowrap; 
        display: flex; 
        align-items: center; 
        text-decoration: none; 
    }
    
    .nav-link:hover, .nav-link.active { 
        background-color: #f8fafc; 
        color: #007bff; 
        border-left: 3px solid #007bff; 
    }
    
    .nav-link i { 
        margin-right: 15px; 
        font-size: 20px; 
        width: 30px; 
        text-align: center; 
    }
    
    .nav-text { 
        opacity: 0; 
        transition: opacity 0.2s ease; 
    }
    
    .sidebar:hover .nav-text { 
        opacity: 1; 
        transition-delay: 0.05s; 
    }
    
    .sidebar-bottom { 
        margin-top: auto; 
        width: 250px; 
        border-top: 1px solid #f1f5f9; 
        padding-top: 10px; 
        padding-bottom: 20px; 
        flex-shrink: 0; 
    }

    .global-top-header {
        position: fixed;
        top: 0;
        right: 0;
        left: 80px;
        height: 70px;
        background: #ffffff;
        border-bottom: 1px solid #e2e8f0;
        z-index: 999;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 30px;
        transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .sidebar:hover ~ .global-top-header {
        left: 250px; 
    }

    .header-left { 
        display: flex; 
        align-items: center; 
        gap: 15px; 
    }
    
    .header-title { 
        margin: 0; 
        font-size: 20px; 
        font-weight: 700; 
        color: #0f172a; 
    }
    
    .header-refresh { 
        font-size: 11px; 
        color: #64748b; 
        display: flex; 
        align-items: center; 
        gap: 5px; 
        font-weight: 500; 
        margin-top: 4px; 
    }

    .header-right .user-profile-link { 
        display: flex; 
        align-items: center; 
        gap: 12px; 
        color: #475569; 
        font-size: 13px; 
        font-weight: 500; 
        text-decoration: none; 
        padding: 6px 12px; 
        border-radius: 8px; 
        transition: 0.2s; 
        cursor: pointer; 
    }
    
    .header-right .user-profile-link:hover { 
        background-color: #f8fafc; 
    }
    
    .header-right .avatar-circle { 
        width: 38px; 
        height: 38px; 
        background: #3b82f6; 
        color: #fff; 
        border-radius: 50%; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        font-weight: bold; 
        font-size: 15px; 
        text-transform: uppercase; 
        border: 2px solid #e2e8f0; 
        object-fit: cover; 
    }

    .main-content { 
        margin-top: 70px !important; 
        margin-left: 80px; 
    }
    
    .main-content .page-header {
        display: none !important;
    }

    .sidebar-overlay {
        display: none;
        position: fixed;
        top: 0; 
        left: 0; 
        right: 0; 
        bottom: 0;
        background: rgba(0,0,0,0.5);
        z-index: 1040;
    }

    @media (max-width: 768px) {
        .sidebar {
            width: 250px;
            transform: translateX(-100%);
            height: 100dvh; 
        }
        .sidebar.show {
            transform: translateX(0);
        }
        .sidebar-overlay.show {
            display: block;
        }
        .brand-text, .nav-text { 
            opacity: 1; 
        } 
        
        .global-top-header {
            left: 0 !important;
            padding: 0 15px;
        }
        .sidebar:hover ~ .global-top-header {
            left: 0 !important;
        }
        
        .main-content {
            margin-left: 0 !important;
        }
        .header-title {
            font-size: 16px;
        }
        .header-refresh {
            display: none;
        }
        .header-right .user-profile-link span {
            display: none;
        }
        .header-right .user-profile-link {
            padding: 0;
        }
        
        .sidebar-bottom {
            padding-bottom: 25px;
        }
    }
</style>

<!-- PWA Manifest Link -->
<link rel="manifest" href="<?= BASE_URL ?>manifest.json">

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="sidebar" id="sidebar">
    <a href="<?= BASE_URL ?>dashboard" class="sidebar-brand">
        <i class="bi bi-hexagon-fill brand-icon"></i>
        <span class="brand-text">SCPK CRM</span>
    </a>

    <div class="sidebar-nav-container">
        <ul class="sidebar-nav">
            <li class="nav-item">
                <a class="nav-link <?= strpos($current_url, 'dashboard') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>dashboard"><i class="bi bi-grid-1x2"></i> <span class="nav-text">Dashboard</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($current_url, 'inbox') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>inbox"><i class="bi bi-whatsapp"></i> <span class="nav-text">Unified Inbox</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($current_url, 'websiteleads') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>websiteleads"><i class="bi bi-globe"></i> <span class="nav-text">Website Leads</span></a>
            </li>
            <li class="nav-item">
                <!-- 🔥 FIX: Lead Management tab highlights when URL contains 'leads' or 'leadprofile' 🔥 -->
                <a class="nav-link <?= ((strpos($current_url, 'leads') !== false || strpos($current_url, 'leadprofile') !== false) && strpos($current_url, 'websiteleads') === false) ? 'active' : '' ?>" href="<?= BASE_URL ?>leads"><i class="bi bi-people"></i> <span class="nav-text">Lead Management</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($current_url, 'tasks') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>tasks"><i class="bi bi-check2-square"></i> <span class="nav-text">Tasks & Follow-ups</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= strpos($current_url, 'assignments') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>assignments"><i class="bi bi-list-task"></i> <span class="nav-text">Team Assignments</span></a>
            </li>
        </ul>
    </div>
    
    <div class="sidebar-bottom">
        <ul class="sidebar-nav">
            <li class="nav-item">
                <a class="nav-link <?= strpos($current_url, 'settings') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>settings/profile"><i class="bi bi-gear"></i> <span class="nav-text">Settings</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-danger" href="<?= BASE_URL ?>auth/logout"><i class="bi bi-box-arrow-left"></i> <span class="nav-text">Logout</span></a>
            </li>
        </ul>
    </div>
</div>

<div class="global-top-header">
    <div class="header-left">
        <button class="d-md-none border-0 bg-transparent me-2 fs-3 text-secondary" id="mobileMenuBtn">
            <i class="bi bi-list"></i>
        </button>
        <h2 class="header-title"><?= htmlspecialchars($clean_title) ?></h2>
        <div class="header-refresh">
            <i class="bi bi-arrow-clockwise"></i> Auto-refresh ON
        </div>
    </div>
    
    <div class="header-right">
        <a href="<?= BASE_URL ?>settings/profile" class="user-profile-link" title="Go to Profile Settings">
            <span>Welcome back, <strong><?= htmlspecialchars($_SESSION['name'] ?? 'User') ?></strong> <span class="badge bg-secondary ms-1"><?= htmlspecialchars($_SESSION['role'] ?? 'SALES') ?></span></span>
            
            <?php if(!empty($global_user_img)): ?>
                <img src="<?= BASE_URL . htmlspecialchars($global_user_img) ?>" class="avatar-circle" alt="Profile">
            <?php else: ?>
                <div class="avatar-circle"><?= strtoupper(substr($_SESSION['name'] ?? 'U', 0, 1)) ?></div>
            <?php endif; ?>
        </a>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const mobileBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if(mobileBtn && sidebar && overlay) {
            mobileBtn.addEventListener('click', function() {
                sidebar.classList.add('show');
                overlay.classList.add('show');
            });

            overlay.addEventListener('click', function() {
                sidebar.classList.remove('show');
                overlay.classList.remove('show');
            });
        }
    });
</script>

<!-- WhatsApp Style In-App Floating Notification Banner -->
<div id="inAppAlertBanner" style="display: none; position: fixed; top: 15px; right: 15px; left: 15px; max-width: 420px; margin: 0 auto; background: #ffffff; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.25); border-left: 5px solid #25d366; padding: 12px 16px; z-index: 999999; animation: slideDown 0.3s ease;">
    <div style="display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <div style="width: 38px; height: 38px; background: #25d366; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px;">
                <i class="bi bi-bell-fill"></i>
            </div>
            <div>
                <strong id="inAppAlertTitle" style="display: block; font-size: 13.5px; color: #111;">New Notification</strong>
                <span id="inAppAlertMsg" style="font-size: 12px; color: #555; display: block; line-height: 1.3;">You have a new alert.</span>
            </div>
        </div>
        <button type="button" onclick="document.getElementById('inAppAlertBanner').style.display='none'" style="border: none; background: transparent; font-size: 18px; color: #888; cursor: pointer;">&times;</button>
    </div>
</div>

<style>
@keyframes slideDown {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
</style>

<!-- =========================================
     PWA SERVICE WORKER & LIVE POLLING ENGINE
     ========================================= -->
<script>
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('<?= BASE_URL ?>sw.js')
            .catch(err => console.log("SW Error:", err));
    }

    function askNotificationPermission() {
        if ("Notification" in window && Notification.permission === "default") {
            Notification.requestPermission();
        }
    }
    document.addEventListener("DOMContentLoaded", askNotificationPermission);

    let lastPushNotificationId = 0;

    function checkLiveUserNotifications() {
        fetch('<?= BASE_URL ?>settings/get_user_alerts?last_id=' + lastPushNotificationId + '&_t=' + Date.now(), {
            method: 'GET',
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            if (lastPushNotificationId === 0 && data.sync_id !== undefined) {
                lastPushNotificationId = parseInt(data.sync_id);
            }

            if (data && data.notifications && data.notifications.length > 0) {
                data.notifications.forEach(notif => {
                    let nId = parseInt(notif.id);
                    
                    if (nId > lastPushNotificationId) {
                        lastPushNotificationId = Math.max(lastPushNotificationId, nId);
                        
                        if (window.Notification && Notification.permission === "granted") {
                            if (navigator.serviceWorker && navigator.serviceWorker.controller) {
                                navigator.serviceWorker.ready.then(reg => {
                                    reg.showNotification(notif.title, {
                                        body: notif.message,
                                        icon: '<?= BASE_URL ?>favicon.png',
                                        badge: '<?= BASE_URL ?>favicon.png',
                                        vibrate: [200, 100, 200],
                                        data: { url: notif.url || '<?= BASE_URL ?>assignments' }
                                    });
                                });
                            } else {
                                new Notification(notif.title, {
                                    body: notif.message,
                                    icon: '<?= BASE_URL ?>favicon.png'
                                });
                            }
                        }

                        let banner = document.getElementById('inAppAlertBanner');
                        let bTitle = document.getElementById('inAppAlertTitle');
                        let bMsg = document.getElementById('inAppAlertMsg');
                        if (banner && bTitle && bMsg) {
                            bTitle.innerText = notif.title;
                            bMsg.innerText = notif.message;
                            banner.style.display = 'block';
                            banner.onclick = function() {
                                window.location.href = notif.url || '<?= BASE_URL ?>assignments';
                            };
                            setTimeout(() => { banner.style.display = 'none'; }, 7000);
                        }

                        try {
                            let audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
                            audio.play().catch(() => {});
                        } catch(e) {}
                    }
                });
            }
        })
        .catch(err => console.log("Alert check error:", err));
    }

    // 15 seconds polling
    setInterval(checkLiveUserNotifications, 15000);
</script>