<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    
    <title><?= htmlspecialchars($title ?? 'Login - SCPK CRM') ?></title>      
    
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">

    <meta property="og:title" content="SCPK CRM">
    <meta property="og:description" content="Welcome to SCPK CRM - Sales & Lead Management">
    <meta property="og:image" content="<?= BASE_URL ?>favicon.png">
    <meta property="og:url" content="<?= BASE_URL ?>">
    <meta property="og:type" content="website">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>          
        body { background-color: #f4f7f6; height: 100vh; display: flex; align-items: center; justify-content: center; }          
        .login-card { max-width: 400px; width: 100%; border: none; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }          
        .login-card .card-header { background: white; border-bottom: none; text-align: center; padding-top: 30px; }          
        .login-card .card-body { padding: 30px; }          
        .btn-primary { background-color: #007bff; border: none; padding: 12px; font-weight: bold; }       
    </style> 
</head> 
<body>      
    <div class="card login-card">          
        <div class="card-header">              
            <h3 class="mb-0 text-primary fw-bold">SCPK CRM</h3>              
            <p class="text-muted small">Sign in to manage your workspace</p>          
        </div>          
        <div class="card-body">                          
            
            <!-- Error Message -->
            <?php if (isset($error)): ?>                  
                <div class="alert alert-danger text-center small"><?= htmlspecialchars($error) ?></div>              
            <?php endif; ?>              

            <!-- Success Message (For Password Reset) -->
            <?php if (isset($success)): ?>                  
                <div class="alert alert-success text-center small"><?= htmlspecialchars($success) ?></div>              
            <?php endif; ?>              

            <form action="<?= BASE_URL ?>auth/login" method="POST">                  
                <div class="mb-3">                      
                    <label class="form-label text-muted small fw-bold">Email Address</label>                      
                    <input type="email" name="email" class="form-control" required placeholder="admin@domain.com">                  
                </div>                  
                <div class="mb-2">
                    <label class="form-label text-muted small fw-bold">Password</label>
                    <div class="input-group">
                        <input type="password" name="password" id="loginPassword" class="form-control" placeholder="........" required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword" style="border-color: #dee2e6; background: #fff;">
                            <i class="bi bi-eye-slash" id="toggleIcon" style="color: #6c757d;"></i>
                        </button>
                    </div>
                </div>                  
                
                <!-- Forgot Password Link -->
                <div class="d-flex justify-content-end mb-4">
                    <a href="#" class="text-decoration-none small text-primary fw-bold" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">Forgot Password?</a>
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-3">Sign In</button>              
            </form>          
        </div>      
    </div> 

    <!-- FORGOT PASSWORD MODAL -->
    <div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form action="<?= BASE_URL ?>auth/forgot_password" method="POST">
                    <div class="modal-header border-0 pb-0">
                        <h5 class="modal-title fw-bold text-dark">Reset Password</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body pt-3">
                        <p class="text-muted small mb-3">Enter your registered email address and we'll send you a link to reset your password.</p>
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-muted">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                        </div>
                    </div>
                    <div class="modal-footer border-0 pt-0">
                        <button type="button" class="btn btn-light border fw-bold text-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary fw-bold px-4">Send Reset Link</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('loginPassword');
            const toggleIcon = document.getElementById('toggleIcon');

            if(togglePassword && passwordInput) {
                togglePassword.addEventListener('click', function () {
                    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                    passwordInput.setAttribute('type', type);
                    
                    if (type === 'text') {
                        toggleIcon.classList.remove('bi-eye-slash');
                        toggleIcon.classList.add('bi-eye');
                        toggleIcon.style.color = '#007bff'; 
                    } else {
                        toggleIcon.classList.remove('bi-eye');
                        toggleIcon.classList.add('bi-eye-slash');
                        toggleIcon.style.color = '#6c757d'; 
                    }
                });
            }
        });
    </script>
</body> 
</html>