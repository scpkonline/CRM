<?php
    $filters = $filters ?? [];
    $hasActiveFilters = (
        (!empty($filters['search'])) ||
        (!empty($filters['status']) && $filters['status'] !== 'active') ||
        (!empty($filters['source'])) ||
        (!empty($filters['agent'])) ||
        (!empty($filters['tag'])) ||
        (!empty($filters['temp'])) ||
        (!empty($filters['start_date'])) ||
        (!empty($filters['end_date']))
    );
    
    function getPaginationUrl($params, $newPage) {
        $params['page'] = $newPage;
        return '?' . http_build_query($params);
    }
?>
<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Tasks & Follow-ups') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <style>          
        body { 
            background-color: #f4f7f6; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; 
            overflow: hidden; 
            margin: 0; 
            padding: 0; 
            width: 100vw; 
            height: 100dvh; 
        }                  
        
        input[type="text"]::-webkit-search-decoration, 
        input[type="text"]::-webkit-search-cancel-button, 
        input[type="text"]::-webkit-search-results-button, 
        input[type="text"]::-webkit-search-results-decoration, 
        input[type="date"]::-webkit-clear-button { 
            display: none !important; 
        }

        .main-content { 
            margin-left: 80px; 
            margin-top: 70px !important; 
            height: calc(100dvh - 70px); 
            display: flex; 
            flex-direction: column; 
            padding: 15px 20px 20px 20px; 
            box-sizing: border-box; 
            overflow: hidden; 
        }          
        
        .page-header { 
            display: none !important; 
        }
        
        .filter-card {
            background: #fff;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 15px;
            flex-shrink: 0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            border: 1px solid #eaedf1;
        }

        .custom-search-wrap {
            display: flex;
            align-items: center;
            border: 1px solid #ced4da;
            border-radius: 6px;
            padding: 0 12px;
            background: #fff;
            width: 260px;
            height: 38px;
        }

        .custom-search-wrap i {
            color: #888;
            font-size: 15px;
        }

        .custom-search-wrap input {
            border: none;
            box-shadow: none;
            outline: none;
            padding: 0 8px;
            font-size: 13.5px;
            width: 100%;
            height: 100%;
            color: #555;
        }

        .btn-search-custom {
            background-color: #5a67d8;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 0 20px;
            font-size: 13.5px;
            font-weight: 700;
            height: 38px;
            transition: 0.2s;
        }

        .btn-search-custom:hover {
            background-color: #434190;
            color: #fff;
        }

        .btn-filters-custom {
            background-color: #e2e8f0;
            color: #4a5568;
            border: none;
            border-radius: 6px;
            padding: 0 16px;
            font-size: 13.5px;
            font-weight: 600;
            height: 38px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }

        .btn-filters-custom:hover {
            background-color: #cbd5e0;
        }

        .btn-filters-custom .badge {
            background-color: #5a67d8;
            color: #fff;
            border-radius: 12px;
            padding: 4px 8px;
            font-size: 11px;
            font-weight: 700;
        }
        
        .filter-panel { 
            display: none; 
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px dashed #eaedf1;
        }
        
        .filter-panel.show { 
            display: block; 
        }
        
        .filter-panel .form-select-sm, 
        .filter-panel .form-control-sm { 
            padding-right: 32px !important; 
            text-overflow: ellipsis; 
            width: 100% !important; 
            font-size: 13px;
            height: 34px;
        }

        .board-container { 
            flex-grow: 1; 
            display: flex; 
            gap: 20px; 
            overflow-x: auto; 
            overflow-y: hidden; 
            min-height: 0; 
            padding-bottom: 10px; 
        }

        .board-container::-webkit-scrollbar { 
            height: 8px; 
        }

        .board-container::-webkit-scrollbar-thumb { 
            background: #cbd2d6; 
            border-radius: 4px; 
        }

        .board-column { 
            flex: 1; 
            min-width: 280px; 
            transition: min-width 0.3s ease, max-width 0.3s ease; 
            background: #f4f5f8; 
            border-radius: 8px; 
            display: flex; 
            flex-direction: column; 
            border: 1px solid #ddd; 
            height: 100%; 
            overflow: hidden; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.03); 
        }

        .board-column.collapsed { 
            min-width: 60px; 
            max-width: 60px; 
            flex: 0 0 60px; 
            background: #fff; 
            cursor: pointer; 
        }

        .board-column.collapsed .column-body, 
        .board-column.collapsed .column-footer { 
            display: none; 
        }

        .board-column.collapsed .column-header { 
            flex-direction: column; 
            height: 100%; 
            justify-content: flex-start; 
            padding: 15px 5px; 
        }

        .board-column.collapsed .header-title { 
            writing-mode: vertical-rl; 
            transform: rotate(180deg); 
            margin-top: 15px; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            font-size: 14px; 
            white-space: nowrap; 
        }

        .board-column.collapsed .badge-count { 
            transform: rotate(90deg); 
        }
        
        .column-header { 
            flex-shrink: 0; 
            padding: 10px 14px; 
            font-weight: 700; 
            font-size: 13px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            background: #fff; 
            border-radius: 8px 8px 0 0; 
            border-bottom: 1px solid #eaedf1; 
            transition: all 0.3s ease;
        }

        .collapse-icon { 
            cursor: pointer; 
            padding: 4px; 
            color: #888; 
            transition: transform 0.3s; 
            font-size: 14px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            width: 24px; 
            height: 24px; 
            border-radius: 4px; 
        }

        .collapse-icon:hover { 
            color: #333; 
            background: #eaedf1; 
        }

        .board-column.collapsed .collapse-icon { 
            transform: rotate(180deg); 
            margin-top: 10px; 
            background: transparent; 
        }

        .hdr-catalog { border-top: 3px solid #4e73df; color: #4e73df; }
        .hdr-followup { border-top: 3px solid #f6c23e; color: #d69d00; }
        .hdr-negotiation { border-top: 3px solid #e74a3b; color: #e74a3b; }
        .hdr-sold { border-top: 3px solid #1cc88a; color: #15a36f; }

        .badge-count { 
            background: #eaedf1; 
            color: #555; 
            font-size: 11px; 
            padding: 3px 8px; 
            border-radius: 20px; 
            font-weight: 700; 
        }

        .column-body { 
            padding: 10px; 
            flex-grow: 1; 
            overflow-y: auto; 
            display: flex; 
            flex-direction: column; 
            gap: 10px; 
            min-height: 0; 
        }

        .column-body::-webkit-scrollbar { 
            width: 5px; 
        }

        .column-body::-webkit-scrollbar-thumb { 
            background: #cbd2d6; 
            border-radius: 4px; 
        }
        
        .column-footer { 
            padding: 10px; 
            background: #fff; 
            border-top: 1px solid #eaedf1; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 0 0 8px 8px; 
            flex-shrink: 0; 
        }

        .btn-col-page { 
            padding: 3px 8px; 
            font-size: 11px; 
            font-weight: 600; 
            display: flex; 
            align-items: center; 
            gap: 4px; 
        }

        .kanban-card { 
            background: #fff; 
            border-radius: 6px; 
            padding: 12px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.05); 
            border: 1px solid #e3e6f0; 
            cursor: pointer; 
            transition: all 0.2s ease; 
            position: relative;
        }

        .kanban-card:hover { 
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); 
            transform: translateY(-1px); 
            border-color: #cbd5e1;
        }

        .kanban-card:active { 
            transform: scale(0.99); 
        }
        
        .card-catalog { border-left: 3px solid #4e73df; }
        .card-followup { border-left: 3px solid #f6c23e; }
        .card-negotiation { border-left: 3px solid #e74a3b; }
        .card-sold { border-left: 3px solid #1cc88a; }

        .card-temp-hot { background-color: #ffeded !important; border-color: #ffcccc !important; }
        .card-temp-warm { background-color: #fff9e6 !important; border-color: #ffeeb0 !important; }
        .card-temp-cold { background-color: #eaf6ff !important; border-color: #bde0ff !important; }

        .temp-dropdown-container { 
            display: none !important; 
        }

        .card-followup .temp-dropdown-container { 
            display: block !important; 
        } 
        
        .temp-dropdown { 
            font-size: 11px; 
            padding: 2px 24px 2px 8px; 
            height: 26px; 
            cursor: pointer; 
            background-color: rgba(255,255,255,0.9); 
            border-color: #ddd; 
            font-weight: 700; 
            border-radius: 4px; 
            display: inline-block; 
            background-position: right 6px center; 
            background-size: 10px 10px; 
        }

        .temp-dropdown:focus { 
            box-shadow: none; 
            border-color: #888; 
        }

        .card-title { 
            font-size: 13px; 
            font-weight: 700; 
            color: #333; 
            margin-bottom: 2px; 
            transition: 0.2s; 
        }

        .kanban-card:hover .card-title { 
            color: #4e73df; 
            text-decoration: underline; 
        }

        .card-contact { 
            font-size: 11px; 
            color: #555; 
            margin-bottom: 4px; 
            display: flex; 
            align-items: center; 
            gap: 6px; 
        }

        .card-contact i { 
            font-size: 10px; 
        }
        
        .agent-badge { 
            font-size: 10px; 
            padding: 3px 6px; 
            background: #f8f9fc; 
            color: #555; 
            border: 1px solid #eaedf1; 
            border-radius: 4px; 
            font-weight: 600; 
            display: inline-flex; 
            align-items: center; 
        }
        
        .card-actions { 
            border-top: 1px dashed #ddd; 
            margin-top: 8px; 
            padding-top: 8px; 
            display: flex; 
            gap: 8px; 
            align-items: center; 
            justify-content: space-between; 
        }

        .form-select-sm { 
            font-size: 11px; 
            padding: 3px 8px; 
            width: auto; 
            flex-grow: 1; 
            border-color: #ddd; 
            box-shadow: none; 
            font-weight: 600; 
            color: #555; 
            cursor: pointer; 
        }

        .btn-chat { 
            font-size: 11px; 
            padding: 4px 10px; 
            background: #f8f9fc; 
            border: 1px solid #ddd; 
            color: #555; 
            border-radius: 4px; 
            text-decoration: none; 
            font-weight: 600; 
            transition: 0.2s; 
            display: flex; 
            align-items: center; 
            gap: 4px; 
            cursor: pointer; 
        }

        .btn-chat:hover { 
            background: #eaedf1; 
            color: #333; 
            border-color: #ccc; 
        }
        
        .card-unqualified { 
            background-color: #fafafa !important; 
            opacity: 0.85; 
            border-color: #f5c2c7 !important; 
        }

        .bg-danger-subtle { 
            background-color: #f8d7da !important; 
            border-color: #f5c2c7 !important; 
            color: #842029 !important; 
        }

        /* RIGHT SIDEBAR */
        .profile-overlay { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100vw; 
            height: 100vh; 
            background: rgba(0,0,0,0.4); 
            z-index: 1040; 
            display: none; 
            opacity: 0; 
            transition: opacity 0.3s; 
        }

        .profile-overlay.show { 
            display: block; 
            opacity: 1; 
        }

        .profile-sidebar { 
            position: fixed; 
            top: 0; 
            right: -1350px; 
            width: 1300px; 
            max-width: 95vw; 
            height: 100vh; 
            background: #fff; 
            z-index: 1050; 
            box-shadow: -5px 0 25px rgba(0,0,0,0.2); 
            transition: right 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
            display: flex; 
            flex-direction: column; 
        }

        .profile-sidebar.show { 
            right: 0; 
        }

        .profile-sidebar-header { 
            padding: 10px 20px; 
            border-bottom: 1px solid #eaedf1; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            background: #f8fafc; 
        }

        .profile-sidebar-content { 
            flex-grow: 1; 
            overflow: hidden; 
            position: relative; 
            background: #f4f7f6; 
        }

        @media (max-width: 768px) {
            .main-content { 
                margin-left: 0 !important; 
                padding: 10px !important; 
                height: calc(100dvh - 70px) !important; 
            }
            .filter-card .d-flex { 
                flex-wrap: wrap; 
                width: 100%; 
            }
            .custom-search-wrap { 
                max-width: 100% !important; 
                flex-grow: 1; 
            }
            .filter-panel .row > div { 
                margin-bottom: 12px; 
            }
            .board-container { 
                scroll-snap-type: x mandatory; 
                padding-bottom: 15px; 
                gap: 15px; 
            }
            .board-column { 
                min-width: 88vw; 
                scroll-snap-align: center; 
            }
            .profile-sidebar { 
                width: 100vw; 
                max-width: 100vw; 
                right: -100vw; 
            }
        }
    </style> 
</head> 
<body>      
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content" id="mainContent">          
        <div class="page-header d-none"></div>

        <form id="filterForm" method="GET" action="<?= BASE_URL ?>tasks">
            <div class="filter-card">
                <div class="d-flex gap-2 align-items-center flex-wrap">
                    
                    <div class="custom-search-wrap shadow-sm">
                        <i class="bi bi-search" style="color:#888;"></i>
                        <input type="text" name="search" id="searchInput" placeholder="Search Number, Name..." value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                    </div>
                    
                    <button type="submit" class="btn-search-custom shadow-sm">Search</button>
                    
                    <button type="button" class="btn-filters-custom shadow-sm" id="toggleFilterBtn">
                        <i class="bi bi-funnel" style="color:#888;"></i> Filters 
                        <span class="badge"><?= $total_leads ?? 0 ?></span>
                    </button>
                    
                    <?php if($hasActiveFilters): ?>
                        <a href="<?= BASE_URL ?>tasks" class="btn btn-light border shadow-sm fw-bold text-danger d-flex align-items-center gap-1" style="font-size: 13px; height: 38px; border-radius: 6px; padding: 0 16px; text-decoration: none;" title="Clear all filters">
                            <i class="bi bi-x-lg"></i> Clear
                        </a>
                    <?php endif; ?>
                    
                </div>
                
                <div class="filter-panel <?= ($hasActiveFilters && empty($filters['search'])) ? 'show' : '' ?>" id="extendedFilters">
                    <div class="row g-2">
                        <div class="col-md">
                            <label class="form-label text-muted" style="font-size:11px; font-weight:600; margin-bottom:4px;">Lead Status</label>
                            <select class="form-select form-select-sm shadow-none border-secondary-subtle fw-bold" name="status" onchange="this.form.submit()">
                                <option value="active" <?= (($filters['status'] ?? 'active') == 'active') ? 'selected' : '' ?>>Active Leads</option>
                                <option value="unqualified" class="text-danger" <?= (($filters['status'] ?? '') == 'unqualified') ? 'selected' : '' ?>>Unqualified (Paused)</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label class="form-label text-muted" style="font-size:11px; font-weight:600; margin-bottom:4px;">Tags (Labels)</label>
                            <select class="form-select form-select-sm shadow-none border-secondary-subtle fw-bold" name="tag" onchange="this.form.submit()">
                                <option value="">All Tags</option>
                                <?php if(!empty($tags)): ?>
                                    <?php foreach($tags as $t): ?>
                                        <option value="<?= htmlspecialchars($t['name']) ?>" <?= (($filters['tag'] ?? '') == $t['name']) ? 'selected' : '' ?>><?= htmlspecialchars($t['name']) ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-md">
                            <label class="form-label text-muted" style="font-size:11px; font-weight:600; margin-bottom:4px;">Temperature</label>
                            <select class="form-select form-select-sm shadow-none border-secondary-subtle fw-bold" name="temp" onchange="this.form.submit()">
                                <option value="">All Temperatures</option>
                                <option value="hot" class="text-danger" <?= (($filters['temp'] ?? '') == 'hot') ? 'selected' : '' ?>>🔥 Hot</option>
                                <option value="warm" class="text-warning" <?= (($filters['temp'] ?? '') == 'warm') ? 'selected' : '' ?>>⭐ Warm</option>
                                <option value="cold" class="text-info" <?= (($filters['temp'] ?? '') == 'cold') ? 'selected' : '' ?>>❄️ Cold</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label class="form-label text-muted" style="font-size:11px; font-weight:600; margin-bottom:4px;">Source</label>
                            <select class="form-select form-select-sm shadow-none border-secondary-subtle" name="source" onchange="this.form.submit()">
                                <option value="">All Sources</option>
                                <option value="website" <?= (($filters['source'] ?? '') == 'website') ? 'selected' : '' ?>>Website</option>
                                <option value="whatsapp" <?= (($filters['source'] ?? '') == 'whatsapp') ? 'selected' : '' ?>>WhatsApp</option>
                                <option value="manual" <?= (($filters['source'] ?? '') == 'manual') ? 'selected' : '' ?>>Manual</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label class="form-label text-muted" style="font-size:11px; font-weight:600; margin-bottom:4px;">Filter by Agent</label>
                            <select class="form-select form-select-sm shadow-none border-secondary-subtle" name="agent" onchange="this.form.submit()">
                                <option value="">All Agents / Unassigned</option>
                                <?php if(!empty($agents)): ?>
                                    <?php foreach($agents as $agent): ?>
                                        <option value="<?= $agent['id'] ?>" <?= (($filters['agent'] ?? '') == $agent['id']) ? 'selected' : '' ?>><?= htmlspecialchars($agent['name']) ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-md">
                            <label class="form-label text-muted" style="font-size:11px; font-weight:600; margin-bottom:4px;">Start Date</label>
                            <input type="date" name="start_date" max="<?= (new \DateTimeImmutable('now', new \DateTimeZone(\Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)))))->format('Y-m-d') ?>" value="<?= htmlspecialchars($filters['start_date'] ?? '') ?>" class="form-control form-control-sm shadow-none border-secondary-subtle text-muted" onchange="this.form.submit()">
                        </div>
                        <div class="col-md">
                            <label class="form-label text-muted" style="font-size:11px; font-weight:600; margin-bottom:4px;">End Date</label>
                            <input type="date" name="end_date" max="<?= (new \DateTimeImmutable('now', new \DateTimeZone(\Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)))))->format('Y-m-d') ?>" value="<?= htmlspecialchars($filters['end_date'] ?? '') ?>" class="form-control form-control-sm shadow-none border-secondary-subtle text-muted" onchange="this.form.submit()">
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <?php 
            $isAdmin = (strtoupper($_SESSION['role'] ?? 'SALES') === 'ADMIN');
            $stagesArr = ['Catalog Sharing', 'Follow Up', 'Negotiation', 'Sold'];

            function getAgentName($id, $agentsArray) {
                if(empty($id)) return 'Unassigned';
                foreach($agentsArray as $ag) {
                    if($ag['id'] == $id) return $ag['name'];
                }
                return 'Unassigned';
            }
        ?>

        <!-- KANBAN BOARD -->
        <div class="board-container" id="kanbanBoardContainer">
            
            <!-- CATALOG SHARING COLUMN -->
            <div class="board-column" onclick="expandColumn(this)">
                <div class="column-header hdr-catalog">
                    <div class="header-title">Catalog Sharing <span class="badge-count" id="count-catalog"><?= $stageCounts['Catalog Sharing'] ?? 0 ?></span></div>
                    <i class="bi bi-chevron-left collapse-icon" onclick="toggleColumn(event, this)"></i>
                </div>
                <div class="column-body" id="col-catalog" ondragover="allowDrop(event)" ondrop="drop(event, 'Catalog Sharing')">
                    <?php foreach($col_leads['cat'] as $lead): ?>
                        <?= renderCard($lead, $agents, 'card-catalog', $stagesArr, $isAdmin) ?>
                    <?php endforeach; ?>
                </div>
                <?php if ($col_pages['cat'] > 1): ?>
                <div class="column-footer">
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'cat', <?= $current_pages['cat'] - 1 ?>)" <?= $current_pages['cat'] <= 1 ? 'disabled' : '' ?>><i class="bi bi-chevron-left"></i> Prev</button>
                    <span style="font-size:11px; font-weight:bold; color:#777;">Pg <?= $current_pages['cat'] ?> of <?= $col_pages['cat'] ?></span>
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'cat', <?= $current_pages['cat'] + 1 ?>)" <?= $current_pages['cat'] >= $col_pages['cat'] ? 'disabled' : '' ?>>Next <i class="bi bi-chevron-right"></i></button>
                </div>
                <?php endif; ?>
            </div>

            <!-- FOLLOW UP COLUMN -->
            <div class="board-column" onclick="expandColumn(this)">
                <div class="column-header hdr-followup">
                    <div class="header-title">Follow Up <span class="badge-count" id="count-followup"><?= $stageCounts['Follow Up'] ?? 0 ?></span></div>
                    <i class="bi bi-chevron-left collapse-icon" onclick="toggleColumn(event, this)"></i>
                </div>
                <div class="column-body" id="col-followup" ondragover="allowDrop(event)" ondrop="drop(event, 'Follow Up')">
                    <?php foreach($col_leads['fol'] as $lead): ?>
                        <?= renderCard($lead, $agents, 'card-followup', $stagesArr, $isAdmin) ?>
                    <?php endforeach; ?>
                </div>
                <?php if ($col_pages['fol'] > 1): ?>
                <div class="column-footer">
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'fol', <?= $current_pages['fol'] - 1 ?>)" <?= $current_pages['fol'] <= 1 ? 'disabled' : '' ?>><i class="bi bi-chevron-left"></i> Prev</button>
                    <span style="font-size:11px; font-weight:bold; color:#777;">Pg <?= $current_pages['fol'] ?> of <?= $col_pages['fol'] ?></span>
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'fol', <?= $current_pages['fol'] + 1 ?>)" <?= $current_pages['fol'] >= $col_pages['fol'] ? 'disabled' : '' ?>>Next <i class="bi bi-chevron-right"></i></button>
                </div>
                <?php endif; ?>
            </div>

            <!-- NEGOTIATION COLUMN -->
            <div class="board-column" onclick="expandColumn(this)">
                <div class="column-header hdr-negotiation">
                    <div class="header-title">Negotiation <span class="badge-count" id="count-negotiation"><?= $stageCounts['Negotiation'] ?? 0 ?></span></div>
                    <i class="bi bi-chevron-left collapse-icon" onclick="toggleColumn(event, this)"></i>
                </div>
                <div class="column-body" id="col-negotiation" ondragover="allowDrop(event)" ondrop="drop(event, 'Negotiation')">
                    <?php foreach($col_leads['neg'] as $lead): ?>
                        <?= renderCard($lead, $agents, 'card-negotiation', $stagesArr, $isAdmin) ?>
                    <?php endforeach; ?>
                </div>
                <?php if ($col_pages['neg'] > 1): ?>
                <div class="column-footer">
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'neg', <?= $current_pages['neg'] - 1 ?>)" <?= $current_pages['neg'] <= 1 ? 'disabled' : '' ?>><i class="bi bi-chevron-left"></i> Prev</button>
                    <span style="font-size:11px; font-weight:bold; color:#777;">Pg <?= $current_pages['neg'] ?> of <?= $col_pages['neg'] ?></span>
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'neg', <?= $current_pages['neg'] + 1 ?>)" <?= $current_pages['neg'] >= $col_pages['neg'] ? 'disabled' : '' ?>>Next <i class="bi bi-chevron-right"></i></button>
                </div>
                <?php endif; ?>
            </div>

            <!-- SOLD COLUMN -->
            <div class="board-column" onclick="expandColumn(this)">
                <div class="column-header hdr-sold">
                    <div class="header-title">Sold <span class="badge-count" id="count-sold"><?= $stageCounts['Sold'] ?? 0 ?></span></div>
                    <i class="bi bi-chevron-left collapse-icon" onclick="toggleColumn(event, this)"></i>
                </div>
                <div class="column-body" id="col-sold" ondragover="allowDrop(event)" ondrop="drop(event, 'Sold')">
                    <?php foreach($col_leads['sol'] as $lead): ?>
                        <?= renderCard($lead, $agents, 'card-sold', $stagesArr, $isAdmin) ?>
                    <?php endforeach; ?>
                </div>
                <?php if ($col_pages['sol'] > 1): ?>
                <div class="column-footer">
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'sol', <?= $current_pages['sol'] - 1 ?>)" <?= $current_pages['sol'] <= 1 ? 'disabled' : '' ?>><i class="bi bi-chevron-left"></i> Prev</button>
                    <span style="font-size:11px; font-weight:bold; color:#777;">Pg <?= $current_pages['sol'] ?> of <?= $col_pages['sol'] ?></span>
                    <button class="btn btn-outline-secondary btn-col-page" onclick="changeColPage(event, 'sol', <?= $current_pages['sol'] + 1 ?>)" <?= $current_pages['sol'] >= $col_pages['sol'] ? 'disabled' : '' ?>>Next <i class="bi bi-chevron-right"></i></button>
                </div>
                <?php endif; ?>
            </div>

        </div>

        <?php 
        function renderCard($lead, $agents, $borderClass, $stagesArr, $isAdmin) {
            $agentName = getAgentName($lead['assigned_to'] ?? null, $agents);
            $phone = htmlspecialchars($lead['phone_number'] ?? $lead['whatsapp_number'] ?? 'N/A');
            $email = htmlspecialchars($lead['email'] ?? '');
            
            // 🔥 FIXED TIMEZONE BUG: Parse DB time strictly as Local Time 🔥
            $dateStr = 'Unknown';
            $targetDateStr = $lead['updated_at'] ?? $lead['created_at'];
            if (!empty($targetDateStr)) {
                $dateStr = \Core\Timezone::formatUtc($targetDateStr, \Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)), 'M d, Y');
            }

            $is_unq = (stripos($lead['lead_stage'] ?? '', 'unqualified') !== false);
            
            $currentStage = $lead['lead_stage'] ?? 'Catalog Sharing';
            if ($is_unq) {
                $currentStage = str_ireplace(['unqualified-', 'unqualified'], '', strtolower($currentStage));
                $currentStage = ucwords(trim($currentStage));
                if(empty($currentStage)) $currentStage = 'Catalog Sharing';
            }

            $statusAttr = $is_unq ? 'unqualified' : 'active';
            
            $leadTemp = strtolower(trim($lead['temperature'] ?? $lead['lead_temperature'] ?? ''));
            $tempClass = '';
            $tempTextClass = '';
            $selHot = ''; 
            $selWarm = ''; 
            $selCold = '';

            if ($leadTemp === 'hot') { $tempClass = 'card-temp-hot'; $tempTextClass = 'text-danger'; $selHot = 'selected'; }
            elseif ($leadTemp === 'warm') { $tempClass = 'card-temp-warm'; $tempTextClass = 'text-warning'; $selWarm = 'selected'; }
            elseif ($leadTemp === 'cold') { $tempClass = 'card-temp-cold'; $tempTextClass = 'text-info'; $selCold = 'selected'; }

            $bgClass = $is_unq ? 'card-unqualified' : $tempClass;
            
            $currIdx = array_search($currentStage, $stagesArr);
            if ($currIdx === false) $currIdx = 0;
            
            $saleAmount = $lead['sale_amount'] ?? null;
            $latestNote = $lead['latest_note'] ?? null;

            ob_start();
            ?>
            <div class="kanban-card <?= $borderClass ?> <?= $bgClass ?>" 
                 draggable="<?= $is_unq ? 'false' : 'true' ?>" 
                 ondragstart="drag(event, <?= $lead['id'] ?>)" 
                 id="card_<?= $lead['id'] ?>"
                 data-status="<?= $statusAttr ?>"
                 data-current-stage="<?= htmlspecialchars($currentStage) ?>"
                 onclick="openProfileSidebar(<?= $lead['id'] ?>)"> 
                
                <div class="d-flex justify-content-between align-items-start mb-1">
                    <div class="card-title text-truncate mb-0" style="max-width: 130px;" title="Click to view Profile">
                        <?= htmlspecialchars($lead['full_name'] ?? 'N/A') ?>
                        <?php if($is_unq): ?>
                            <span class="badge bg-danger mt-1 d-block" style="font-size:9px; width:fit-content;">Unqualified</span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="temp-dropdown-container">
                        <select class="form-select temp-dropdown shadow-none <?= $tempTextClass ?>" onchange="changeTemperature(<?= $lead['id'] ?>, this.value)" onclick="event.stopPropagation()">
                            <option value="" class="text-dark">Temp...</option>
                            <option value="hot" class="text-danger" <?= $selHot ?>>🔥 Hot</option>
                            <option value="warm" class="text-warning" <?= $selWarm ?>>⭐ Warm</option>
                            <option value="cold" class="text-info" <?= $selCold ?>>❄️ Cold</option>
                        </select>
                    </div>
                </div>

                <div class="card-contact"><i class="bi bi-telephone-fill text-success"></i> <?= $phone ?></div>
                <?php if($email): ?>
                    <div class="card-contact"><i class="bi bi-envelope-fill text-primary"></i> <?= str_replace('@', '<span>@</span>', $email) ?></div>
                <?php endif; ?>
                
                <div class="d-flex justify-content-between align-items-center mt-2">
                    <span class="agent-badge"><i class="bi bi-person-fill me-1"></i><?= htmlspecialchars($agentName) ?></span>
                    <small class="text-muted" style="font-size: 10px; font-weight: 600;"><?= $dateStr ?></small>
                </div>

                <div class="mt-2 pt-2" style="border-top: 1px dashed #eaedf1;">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <?php if ($currentStage === 'Sold'): ?>
                            <span class="text-success fw-bold" style="font-size: 10px; text-transform: uppercase;"><i class="bi bi-cash-coin me-1"></i>Sale Details</span>
                        <?php else: ?>
                            <span class="text-muted fw-bold" style="font-size: 10px; text-transform: uppercase;"><i class="bi bi-journal-text me-1"></i>Latest Note</span>
                            <button type="button" class="btn btn-sm btn-light border py-0 px-1 text-primary shadow-sm" style="font-size: 11px; line-height: 1;" onclick="openNoteModal(<?= $lead['id'] ?>); event.stopPropagation();" title="Add Note">
                                <i class="bi bi-plus"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                    
                    <div class="note-content-box">
                        <?php if ($currentStage === 'Sold' && !empty($saleAmount)): ?>
                            <div class="text-success fw-bold" style="font-size: 12px;">
                                Sale Amount: ₹<?= number_format((float)$saleAmount, 2) ?>
                            </div>
                        <?php else: ?>
                            <?php if($latestNote): ?>
                                <div class="text-truncate text-dark" style="max-width: 100%; font-size: 11.5px; cursor: help;" title="<?= htmlspecialchars($latestNote) ?>">
                                    <?= htmlspecialchars($latestNote) ?>
                                </div>
                            <?php else: ?>
                                <div class="text-muted" style="font-style: italic; font-size: 10px;">No notes added...</div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card-actions">
                    <?php if($is_unq): ?>
                        <select class="form-select form-select-sm bg-danger-subtle fw-bold" onchange="changeStage(<?= $lead['id'] ?>, this.value, '<?= htmlspecialchars(addslashes($currentStage)) ?>')" onclick="event.stopPropagation()">
                            <option value="" disabled selected>Currently Unqualified</option>
                            <option value="Restore">⟲ Re-Qualify Lead</option>
                        </select>
                    <?php else: ?>
                        <select class="form-select form-select-sm" onchange="changeStage(<?= $lead['id'] ?>, this.value, '<?= htmlspecialchars(addslashes($currentStage)) ?>')" onclick="event.stopPropagation()">
                            <?php foreach($stagesArr as $idx => $stg): ?>
                                <?php 
                                    $disabledAttr = (!$isAdmin && $idx < $currIdx) ? 'disabled' : ''; 
                                ?>
                                <option value="<?= htmlspecialchars($stg) ?>" <?= $currentStage == $stg ? 'selected' : '' ?> <?= $disabledAttr ?>><?= htmlspecialchars($stg) ?></option>
                            <?php endforeach; ?>
                            <option disabled>──────────</option>
                            <option value="Unqualified" class="text-danger fw-bold">✖ Mark Unqualified</option>
                        </select>
                    <?php endif; ?>
                    
                    <a href="<?= BASE_URL ?>leadprofile/index/<?= $lead['id'] ?>?ref=tasks" class="btn-chat" onclick="event.stopPropagation();"><i class="bi bi-eye"></i> View</a>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }
        ?>
    </div> 

    <div id="profileSidebarOverlay" class="profile-overlay" onclick="closeProfileSidebar()"></div>
    <div id="profileSidebar" class="profile-sidebar">
        <div class="profile-sidebar-header">
            <h5 class="m-0 fw-bold text-dark"><i class="bi bi-person-lines-fill text-primary me-2"></i>Lead Profile</h5>
            <button type="button" class="btn-close" onclick="closeProfileSidebar()"></button>
        </div>
        <div class="profile-sidebar-content">
            <div id="profileLoader" class="text-center mt-5 pt-5">
                <div class="spinner-border text-primary" role="status"></div>
                <div class="mt-2 text-muted fw-bold">Loading Profile...</div>
            </div>
            <iframe id="profileIframe" src="" style="width:100%; height:100%; border:none; display:none;" onload="hideProfileLoader()"></iframe>
        </div>
    </div>

    <div class="modal fade" id="soldModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-light border-bottom-0 pb-3">
              <h5 class="modal-title fw-bold text-success"><i class="bi bi-currency-rupee me-2"></i>Lead Sold Details</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" onclick="cancelSold()"></button>
            </div>
            <div class="modal-body pt-2 pb-4 px-4">
              <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">Sale Date <span class="text-danger">*</span></label>
                  <input type="date" id="sold_date" class="form-control shadow-none border-secondary-subtle" required>
              </div>
              <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">Sale Amount (₹) <span class="text-danger">*</span></label>
                  <input type="number" id="sold_amount" class="form-control shadow-none border-secondary-subtle" required placeholder="e.g. 5000">
              </div>
            </div>
            <div class="modal-footer bg-light border-top-0 pt-0">
              <button type="button" class="btn btn-light border fw-bold text-secondary shadow-sm" data-bs-dismiss="modal" onclick="cancelSold()">Cancel</button>
              <button type="submit" class="btn btn-success fw-bold px-4 shadow-sm" onclick="confirmSold()"><i class="bi bi-check-circle me-1"></i> Save & Move to Sold</button>
            </div>
        </div>
      </div>
    </div>

    <iframe name="hidden_note_iframe" id="hidden_note_iframe" style="display:none;"></iframe>
    <div class="modal fade" id="addNoteModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
          <form action="<?= BASE_URL ?>leadprofile/add_note" method="POST" target="hidden_note_iframe" id="noteForm">
              <div class="modal-header bg-light border-bottom-0 pb-3">
                <h5 class="modal-title fw-bold text-dark"><i class="bi bi-journal-plus text-primary me-2"></i>Add Quick Note</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body pt-2 pb-4 px-4">
                <input type="hidden" name="lead_id" id="note_lead_id">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Note Text <span class="text-danger">*</span></label>
                    <textarea name="note" class="form-control shadow-none border-secondary-subtle" rows="3" required placeholder="Type your note here..."></textarea>
                </div>
              </div>
              <div class="modal-footer bg-light border-top-0 pt-0">
                <button type="button" class="btn btn-light border fw-bold text-secondary shadow-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4 shadow-sm" onclick="handleNoteSubmit()"><i class="bi bi-save me-1"></i> Save Note</button>
              </div>
          </form>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const baseUrl = '<?= rtrim(BASE_URL, '/') ?>/';
        let isDragging = false;
        let noteModalInstance; 
        let isSidebarOpen = false;
        
        const currentUserRole = <?= json_encode(strtoupper($_SESSION['role'] ?? 'SALES')) ?>;
        // Date-only Sold field uses the same company calendar as Preferences.
        const crmTasksTimezone = <?= json_encode(\Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
        function crmTasksToday() {
            const parts = new Intl.DateTimeFormat('en-GB', {
                timeZone: crmTasksTimezone, year:'numeric', month:'2-digit', day:'2-digit'
            }).formatToParts(new Date());
            const part = name => (parts.find(p => p.type === name) || {}).value || '';
            return `${part('year')}-${part('month')}-${part('day')}`;
        }

        
        let pendingSoldLeadId = null;
        let pendingSoldOldStage = null;
        let pendingSoldCard = null;
        
        const stageOrder = {
            'Catalog Sharing': 0,
            'Follow Up': 1,
            'Negotiation': 2,
            'Sold': 3
        };

        window.addEventListener('beforeunload', function() {
            let scrollData = {
                board: document.querySelector('.board-container').scrollLeft,
                columns: {}
            };
            document.querySelectorAll('.column-body').forEach(col => {
                scrollData.columns[col.id] = col.scrollTop;
            });
            sessionStorage.setItem('kanbanScrollState', JSON.stringify(scrollData));
        });

        document.addEventListener("DOMContentLoaded", () => {
            let savedScroll = sessionStorage.getItem('kanbanScrollState');
            if(savedScroll) {
                try {
                    let parsed = JSON.parse(savedScroll);
                    setTimeout(() => {
                        if(parsed.board) document.querySelector('.board-container').scrollLeft = parsed.board;
                        for(let id in parsed.columns) {
                            let col = document.getElementById(id);
                            if(col) col.scrollTop = parsed.columns[id];
                        }
                    }, 100); 
                } catch(e) {}
            }
        });

        document.getElementById('toggleFilterBtn').addEventListener('click', function() {
            document.getElementById('extendedFilters').classList.toggle('show');
        });

        function changeColPage(event, colKey, pageNum) {
            if(event) event.stopPropagation();
            let url = new URL(window.location.href);
            url.searchParams.set('p_' + colKey, pageNum);
            window.location.href = url.toString();
        }

        function openProfileSidebar(leadId) {
            if(isDragging) return; 
            isSidebarOpen = true;
            document.getElementById('profileSidebarOverlay').classList.add('show');
            document.getElementById('profileSidebar').classList.add('show');
            document.getElementById('profileLoader').style.display = 'block';
            let iframe = document.getElementById('profileIframe');
            iframe.style.display = 'none';
            iframe.src = `${baseUrl}leadprofile/index/${leadId}?ref=tasks_sidebar`;
        }

        function closeProfileSidebar() {
            isSidebarOpen = false;
            document.getElementById('profileSidebarOverlay').classList.remove('show');
            document.getElementById('profileSidebar').classList.remove('show');
            document.getElementById('profileIframe').src = 'about:blank'; 
            window.location.reload(); 
        }

        function hideProfileLoader() {
            let loader = document.getElementById('profileLoader');
            let iframe = document.getElementById('profileIframe');
            if (iframe && iframe.src && !iframe.src.includes('about:blank')) {
                if (loader) loader.style.display = 'none';
                iframe.style.display = 'block';
            }
        }

        function openNoteModal(leadId) {
            document.getElementById('note_lead_id').value = leadId;
            document.getElementById('noteForm').reset();
            if(!noteModalInstance) {
                noteModalInstance = new bootstrap.Modal(document.getElementById('addNoteModal'));
            }
            noteModalInstance.show();
        }

        function handleNoteSubmit() {
            setTimeout(() => {
                if(noteModalInstance) noteModalInstance.hide();
                window.location.reload();
            }, 800);
        }

        function toggleColumn(event, iconElement) {
            event.stopPropagation(); 
            let col = iconElement.closest('.board-column');
            col.classList.toggle('collapsed');
        }

        function expandColumn(colElement) {
            if (colElement.classList.contains('collapsed')) {
                colElement.classList.remove('collapsed');
            }
        }

        function changeTemperature(leadId, temp) {
            fetch(`${baseUrl}tasks/update_temperature`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ lead_id: leadId, temperature: temp })
            }).then(() => window.location.reload()).catch(e => {}); 
        }

        function allowDrop(ev) { ev.preventDefault(); }

        function drag(ev, leadId) {
            isDragging = true;
            ev.dataTransfer.setData("lead_id", leadId);
            ev.target.style.opacity = "0.5";
        }

        document.addEventListener("dragend", function(event) {
            isDragging = false;
            if(event.target.classList.contains('kanban-card')) {
                event.target.style.opacity = "1";
            }
        }, false);

        function confirmSold() {
            let amount = document.getElementById('sold_amount').value;
            let date = document.getElementById('sold_date').value;
            
            if(!amount || !date) {
                alert("Please enter both Sale Amount and Date.");
                return;
            }
            
            let modalEl = document.getElementById('soldModal');
            let modalObj = bootstrap.Modal.getInstance(modalEl);
            if(modalObj) modalObj.hide();
            
            let leadId = pendingSoldLeadId;
            let newStage = 'Sold';
            
            saveStageUpdate(leadId, newStage, amount, date);
            
            pendingSoldLeadId = null;
            pendingSoldOldStage = null;
            pendingSoldCard = null;
        }

        function cancelSold() {
            pendingSoldLeadId = null;
            pendingSoldOldStage = null;
            pendingSoldCard = null;
        }

        function drop(ev, newStage) {
            ev.preventDefault();
            isDragging = false; 
            let leadId = ev.dataTransfer.getData("lead_id");
            if (!leadId) return;

            let dropTarget = ev.target;
            while (!dropTarget.classList.contains('column-body') && dropTarget !== document.body) {
                dropTarget = dropTarget.parentElement;
            }

            if (dropTarget.classList.contains('column-body')) {
                let card = document.getElementById("card_" + leadId);
                if(card) {
                    let currentStage = card.getAttribute('data-current-stage') || 'Catalog Sharing';
                    let isUnq = card.getAttribute('data-status') === 'unqualified';
                    
                    if (!isUnq && stageOrder[newStage] < stageOrder[currentStage] && currentUserRole !== 'ADMIN') {
                        alert("Pipeline Rule: Leads can only move forward in the pipeline!");
                        return; 
                    }

                    if (newStage === 'Sold' && !isUnq) {
                        pendingSoldLeadId = leadId;
                        pendingSoldOldStage = currentStage;
                        pendingSoldCard = card;
                        
                        let today = crmTasksToday();
                        document.getElementById('sold_date').value = today;
                        document.getElementById('sold_amount').value = '';
                        
                        let soldModal = new bootstrap.Modal(document.getElementById('soldModal'));
                        soldModal.show();
                        return; 
                    }

                    let stageToSave = isUnq ? 'Unqualified-' + newStage : newStage;
                    saveStageUpdate(leadId, stageToSave);
                }
            }
        }

        function changeStage(leadId, newStage, currentStage) {
            let card = document.getElementById("card_" + leadId);
            if (!card) return;
            
            currentStage = currentStage || card.getAttribute('data-current-stage') || 'Catalog Sharing';
            let stageToSave = newStage;

            if (newStage !== 'Unqualified' && newStage !== 'Restore' && stageOrder[newStage] < stageOrder[currentStage] && currentUserRole !== 'ADMIN') {
                alert("Pipeline Rule: Leads can only move forward in the pipeline!");
                let select = card.querySelector('select:not(.temp-dropdown)');
                if (select) select.value = currentStage;
                return; 
            }

            if (newStage === 'Sold') {
                pendingSoldLeadId = leadId;
                pendingSoldOldStage = currentStage;
                pendingSoldCard = card;
                
                let today = crmTasksToday();
                document.getElementById('sold_date').value = today;
                document.getElementById('sold_amount').value = '';
                
                let select = card.querySelector('select:not(.temp-dropdown)');
                if (select) select.value = currentStage; 
                
                let soldModal = new bootstrap.Modal(document.getElementById('soldModal'));
                soldModal.show();
                return; 
            }

            if (newStage === 'Unqualified') {
                stageToSave = 'Unqualified-' + currentStage;
            } else if (newStage === 'Restore') {
                stageToSave = currentStage;
            }

            saveStageUpdate(leadId, stageToSave);
        }

        function saveStageUpdate(leadId, stageName, amount = null, date = null) {
            let payload = { lead_id: leadId, stage: stageName };
            if(amount !== null) payload.sale_amount = amount;
            if(date !== null) payload.sale_date = date;

            fetch(`${baseUrl}tasks/update_stage`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(() => window.location.reload())
            .catch(error => console.error('Error:', error));
        }

    </script>
</body> 
</html>