<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Notifications') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    
    <style>          
        body { background-color: #f8fafc; font-family: -apple-system, sans-serif; overflow-x: hidden; color: #334155; }                  
        .main-content { margin-left: 250px; padding: 30px 40px; min-height: 100vh; transition: all 0.3s ease; }          
        .settings-container { display: flex; gap: 25px; align-items: flex-start; }
        .settings-menu { width: 260px; background: #fff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 10px 0; flex-shrink: 0; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
        .menu-item { display: flex; align-items: center; padding: 12px 20px; color: #475569; text-decoration: none; font-weight: 500; font-size: 14px; border-left: 3px solid transparent; transition: 0.2s; }
        .menu-item:hover { background-color: #f8fafc; color: #3b82f6; }
        .menu-item.active { background-color: #eff6ff; color: #3b82f6; border-left-color: #3b82f6; font-weight: 600; }
        .menu-item i { font-size: 18px; margin-right: 12px; width: 20px; text-align: center; }
        .settings-panel { flex-grow: 1; background: #fff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
        .panel-title { font-size: 18px; font-weight: 600; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px; margin-bottom: 25px; color: #0f172a; }
        .form-check-input { cursor: pointer; }
        .btn-save { background-color: #5a67d8; color: #fff; border: none; padding: 10px 24px; font-weight: 600; border-radius: 6px; transition: 0.2s; }
        .btn-save:hover { background-color: #4c51bf; }
        
        @media (max-width: 768px) { 
            .main-content { margin-left: 0; padding: 15px; margin-top: 70px; } 
            .settings-container { flex-direction: column; } 
            .settings-menu, .settings-panel { width: 100%; } 
        }
    </style> 

    <!-- DARK MODE SCRIPT & STYLE -->
    <script>
        if (document.cookie.includes('theme=dark')) {
            document.documentElement.classList.add('dark-theme');
        }
    </script>
    <style>
        html.dark-theme body { background-color: #121212 !important; color: #e0e0e0 !important; }
        html.dark-theme .card, html.dark-theme .bg-white, html.dark-theme .settings-menu, html.dark-theme .settings-panel, html.dark-theme .main-content { background-color: #1e1e1e !important; border-color: #333 !important; color: #e0e0e0 !important; }
        html.dark-theme .text-muted, html.dark-theme .text-secondary, html.dark-theme .panel-title { color: #a0aab5 !important; }
        html.dark-theme .menu-item { color: #e0e0e0 !important; }
        html.dark-theme .menu-item:hover, html.dark-theme .menu-item.active { background-color: #2d2d2d !important; color: #60a5fa !important; border-color: #333 !important; }
        html.dark-theme .border-bottom { border-color: #333 !important; }
        html.dark-theme .list-group-item { background-color: transparent !important; border-color: #333 !important; color: #e0e0e0 !important; }
    </style>
</head> 
<body>     
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content">
        
        <?php if(isset($_SESSION['success_msg'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success_msg'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success_msg']); ?>
        <?php endif; ?>

        <div class="settings-container">
            <div class="settings-menu">
                <a href="<?= BASE_URL ?>settings/profile" class="menu-item"><i class="bi bi-person-badge"></i> Edit Profile</a>
                <?php if(($user_role ?? 'SALES') === 'ADMIN'): ?>
                <a href="<?= BASE_URL ?>settings/team" class="menu-item"><i class="bi bi-people"></i> Team Management</a>
                <a href="<?= BASE_URL ?>settings/integrations" class="menu-item"><i class="bi bi-plug"></i> Integrations & API</a>
                <?php endif; ?>
                <a href="<?= BASE_URL ?>settings/notifications" class="menu-item active"><i class="bi bi-bell"></i> Notifications</a>
                <a href="<?= BASE_URL ?>settings/preferences" class="menu-item"><i class="bi bi-palette"></i> Preferences</a>
            </div>

            <div class="settings-panel">
                <h3 class="panel-title text-primary"><i class="bi bi-bell me-2"></i> Notification Settings</h3>
                
                <!-- Yeh Form SettingsController ke update_notifications function ko hit karega -->
                <form action="<?= BASE_URL ?>settings/update_notifications" method="POST">
                    <div class="list-group mb-4 mt-3">
                        
                        <!-- Toggle 1: New Lead Notification -->
                        <div class="list-group-item d-flex justify-content-between align-items-center py-3 border-0 border-bottom rounded-0 px-0">
                            <div>
                                <h6 class="mb-0 fw-bold">New Lead Alerts</h6>
                                <small class="text-muted">Browser push notification when a new lead is assigned to you.</small>
                            </div>
                            <div class="form-check form-switch fs-4">
                                <input class="form-check-input" type="checkbox" name="notify_new_lead" <?= (!isset($_COOKIE['notify_new_lead']) || $_COOKIE['notify_new_lead'] == '1') ? 'checked' : '' ?>>
                            </div>
                        </div>
                        
                        <!-- Toggle 2: Old Lead Reply Notification -->
                        <div class="list-group-item d-flex justify-content-between align-items-center py-3 border-0 rounded-0 px-0">
                            <div>
                                <h6 class="mb-0 fw-bold">Lead Reply Alerts</h6>
                                <small class="text-muted">Browser push notification when an existing lead replies on WhatsApp.</small>
                            </div>
                            <div class="form-check form-switch fs-4">
                                <input class="form-check-input" type="checkbox" name="notify_lead_reply" <?= (!isset($_COOKIE['notify_lead_reply']) || $_COOKIE['notify_lead_reply'] == '1') ? 'checked' : '' ?>>
                            </div>
                        </div>

                    </div>
                    <div class="text-end">
                        <button type="submit" class="btn-save">Save Preferences</button>
                    </div>
                </form>
            </div>
        </div>
    </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body> 
</html>