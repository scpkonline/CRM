<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?></title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f4f7f6; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center; }
        h1 { color: #007bff; margin-top: 0; }
        .status { background: #d4edda; color: #155724; padding: 10px 20px; border-radius: 20px; font-weight: bold; display: inline-block; margin-top: 20px; }
    </style>
</head>
<body>

    <div class="card">
        <h1>Welcome to SCPK CRM</h1>
        <p><?= htmlspecialchars($message) ?></p>
        <p>Ready to manage bulk kurti orders and organize your sales pipeline.</p>
        <div class="status">System Online & Secured 🟢</div>
    </div>

</body>
</html>