<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Set New Password') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <style>          
        body { background-color: #f4f7f6; height: 100vh; display: flex; align-items: center; justify-content: center; }          
        .login-card { max-width: 400px; width: 100%; border: none; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }          
        .login-card .card-header { background: white; border-bottom: none; text-align: center; padding-top: 30px; }          
        .login-card .card-body { padding: 30px; }          
        .btn-primary { background-color: #007bff; border: none; padding: 12px; font-weight: bold; }       
    </style> 
</head> 
<body>      
    <div class="card login-card">          
        <div class="card-header">              
            <h4 class="mb-0 text-dark fw-bold">Set New Password</h4>              
            <p class="text-muted small mt-1">Please enter your new password below.</p>          
        </div>          
        <div class="card-body pt-2">                          
            <form action="<?= BASE_URL ?>auth/reset_password?token=<?= htmlspecialchars($token) ?>" method="POST" id="resetForm">                  
                
                <div class="mb-3">
                    <label class="form-label text-muted small fw-bold">New Password</label>
                    <input type="password" name="password" id="newPassword" class="form-control" required minlength="6">
                </div>                  
                
                <div class="mb-4">
                    <label class="form-label text-muted small fw-bold">Confirm New Password</label>
                    <input type="password" id="confirmPassword" class="form-control" required minlength="6">
                    <div id="passwordError" class="text-danger small fw-bold mt-1" style="display:none;">Passwords do not match!</div>
                </div>                  
                
                <button type="submit" class="btn btn-primary w-100 mb-2">Update Password</button>              
            </form>          
        </div>      
    </div> 

    <script>
        // Simple JS check taaki dono passwords match karein
        document.getElementById('resetForm').addEventListener('submit', function(e) {
            let pass = document.getElementById('newPassword').value;
            let conf = document.getElementById('confirmPassword').value;
            if(pass !== conf) {
                e.preventDefault();
                document.getElementById('passwordError').style.display = 'block';
            }
        });
    </script>
</body> 
</html>