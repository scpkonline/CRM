<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Integrations') ?></title>      
    
    <!-- Favicon Tags Added Here -->
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    <style>          
        body { background-color: #f8fafc; font-family: -apple-system, sans-serif; overflow-x: hidden; color: #334155; }                  
        .main-content { margin-left: 250px; padding: 30px 40px; min-height: 100vh; }      
        .settings-container { display: flex; gap: 25px; align-items: flex-start; }
        .settings-menu { width: 260px; background: #fff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 10px 0; flex-shrink: 0; }
        .menu-item { display: flex; align-items: center; padding: 12px 20px; color: #475569; text-decoration: none; font-weight: 500; font-size: 14px; border-left: 3px solid transparent; }
        .menu-item.active { background-color: #eff6ff; color: #3b82f6; border-left-color: #3b82f6; font-weight: 600; }
        .menu-item i { font-size: 18px; margin-right: 12px; width: 20px; text-align: center; }
        .settings-panel { flex-grow: 1; background: #fff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 30px; }
        .panel-title { font-size: 18px; font-weight: 600; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px; margin-bottom: 25px; }
        .form-label { font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control { border-radius: 6px; border: 1px solid #cbd5e1; padding: 10px 15px; font-size: 14px; box-shadow: none; }
        .btn-save { background-color: #3b82f6; color: #fff; border: none; padding: 10px 24px; font-weight: 600; border-radius: 6px; }
        @media (max-width: 768px) { .main-content { margin-left: 0; padding: 15px; } .settings-container { flex-direction: column; } .settings-menu { width: 100%; } }
    </style> 
    <!-- DARK MODE SCRIPT -->
    <script>
        if (document.cookie.includes('theme=dark')) {
            document.documentElement.classList.add('dark-theme');
        }
    </script>
    <style>
        html.dark-theme body { background-color: #121212 !important; color: #e0e0e0 !important; }
        html.dark-theme .card, html.dark-theme .bg-white, html.dark-theme .settings-menu, html.dark-theme .settings-panel, html.dark-theme .main-content { background-color: #1e1e1e !important; border-color: #333 !important; color: #e0e0e0 !important; }
        html.dark-theme .form-control { background-color: #2d2d2d !important; border-color: #444 !important; color: #fff !important; }
        html.dark-theme .text-muted, html.dark-theme .text-secondary { color: #a0aab5 !important; }
        html.dark-theme .menu-item { color: #e0e0e0 !important; }
        html.dark-theme .menu-item:hover, html.dark-theme .menu-item.active { background-color: #2d2d2d !important; color: #60a5fa !important; border-color: #333 !important; }
        html.dark-theme .border-bottom { border-color: #333 !important; }
    </style>
</head> 
<body>     
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content">
        <?php if(isset($_SESSION['success_msg'])): ?>
            <div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($_SESSION['success_msg'], ENT_QUOTES, 'UTF-8') ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
            <?php unset($_SESSION['success_msg']); ?>
        <?php endif; ?>

        <?php if(isset($_SESSION['error_msg'])): ?>
            <div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($_SESSION['error_msg'], ENT_QUOTES, 'UTF-8') ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
            <?php unset($_SESSION['error_msg']); ?>
        <?php endif; ?>

        <div class="settings-container">
            <div class="settings-menu">
                <a href="<?= BASE_URL ?>settings/profile" class="menu-item"><i class="bi bi-person-badge"></i> Edit Profile</a>
                <a href="<?= BASE_URL ?>settings/team" class="menu-item"><i class="bi bi-people"></i> Team Management</a>
                <a href="<?= BASE_URL ?>settings/integrations" class="menu-item active"><i class="bi bi-plug"></i> Integrations & API</a>
                <a href="<?= BASE_URL ?>settings/notifications" class="menu-item"><i class="bi bi-bell"></i> Notifications</a>
                <a href="<?= BASE_URL ?>settings/preferences" class="menu-item"><i class="bi bi-palette"></i> Preferences</a>
            </div>

            <div class="settings-panel">
                <h3 class="panel-title text-primary"><i class="bi bi-plug me-2"></i> Integrations & API Settings</h3>
                
                <?php if (empty($secure_env_ready)): ?>
                <div class="alert alert-warning" role="alert">
                    <strong>Private credential storage not ready.</strong>
                    Move your existing <code>app/Config/.env</code> to <code>crm_private/.env</code> OUTSIDE <code>public_html</code> before saving here. Existing credentials continue working using the legacy read-only fallback until migration.
                </div>
                <?php endif; ?>
                <form action="<?= BASE_URL ?>settings/update_integrations" method="POST" autocomplete="off">
                    <input type="hidden" name="integrations_csrf" value="<?= htmlspecialchars($integrations_csrf ?? '', ENT_QUOTES, 'UTF-8') ?>">
                    
                    <h6 class="mt-2 mb-3 text-secondary border-bottom pb-2">WhatsApp API Configuration</h6>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Meta App ID</label>
                            <input type="text" class="form-control" name="wa_app_id" value="<?= htmlspecialchars($wa_app_id ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Enter App ID">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone Number ID</label>
                            <input type="text" class="form-control" name="wa_phone_id" value="<?= htmlspecialchars($wa_phone_id ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Enter Phone ID">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">WhatsApp Business Account ID (WABA ID)</label>
                            <input type="text" class="form-control" name="wa_waba_id" value="<?= htmlspecialchars($wa_waba_id ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Enter WhatsApp Business Account ID">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Webhook Verify Token</label>
                            <input type="password" class="form-control" name="wa_verify_token" value="" autocomplete="new-password" placeholder="Leave blank to keep current token">
                            <small class="text-muted"><?= !empty($wa_verify_token_configured) ? 'Configured (hidden).' : 'Not configured.' ?> Leave blank to keep existing. Changing this requires updating the Meta webhook setup.</small>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Permanent Access Token</label>
                            <input type="password" class="form-control" name="wa_access_token" value="" autocomplete="new-password" placeholder="Leave blank to keep current access token">
                            <small class="text-muted"><?= !empty($wa_access_token_configured) ? 'Configured (hidden).' : 'Not configured.' ?> Leave blank to preserve the existing token.</small>
                        </div>
                    </div>

                    <!-- META ADS INTEGRATION SECTION -->
                    <h6 class="mt-4 mb-3 text-secondary border-bottom pb-2">Meta Ads Configuration</h6>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Meta Ad Account ID</label>
                            <input type="text" class="form-control" name="meta_ad_account_id" value="<?= htmlspecialchars($meta_ad_account_id ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="e.g. act_348291905848390">
                            <small class="text-muted mt-1 d-block">Enter your Ad Account ID starting with 'act_' (e.g., act_348291905848390).</small>
                        </div>
                    </div>

                    <!-- WHATSAPP WEBHOOK URL SECTION -->
                    <h6 class="mt-4 mb-3 text-secondary border-bottom pb-2">WhatsApp Webhook Setup</h6>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Callback URL (For Meta App Dashboard)</label>
                            <input type="text" class="form-control bg-light" value="<?= BASE_URL ?>webhook/whatsapp" readonly>
                            <small class="text-muted mt-1 d-block">Paste this URL in your Meta App Dashboard under WhatsApp > Configuration > Edit Webhook.</small>
                        </div>
                    </div>

                    <h6 class="mt-4 mb-3 text-secondary border-bottom pb-2">Website Leads Webhook</h6>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">System Webhook URL (For Pabbly/G-Sheets)</label>
                            <input type="text" class="form-control bg-light" value="<?= BASE_URL ?>webhook/website_leads" readonly>
                            <small class="text-muted mt-1 d-block">Paste this URL in your website builder or Pabbly.</small>
                        </div>
                    </div>

                    <div class="text-end mt-4">
                        <button type="submit" class="btn-save" <?= empty($secure_env_ready) ? 'disabled title="Move .env to private folder first"' : '' ?>>Save Integrations</button>
                    </div>
                </form>
            </div>
        </div>
    </div> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body> 
</html>