<?php $profileDisplayTimezone = isset($crm_timezone) ? $crm_timezone : \Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)); ?>
<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Lead Profile') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    
    <style>          
        body { background-color: #f4f7f6; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; overflow: hidden; margin: 0; padding: 0; height: 100dvh; width: 100vw; }                 
        .main-content { margin-left: 80px; height: calc(100dvh - 70px); display: flex; flex-direction: column; padding: 0; background: #fff; overflow: hidden; }          
        .content-area { display: flex; flex-grow: 1; overflow: hidden; width: 100%; height: 100%; }

        .left-col { width: 280px; flex-shrink: 0; background: #fff; border-right: 1px solid #ddd; padding: 20px; overflow-y: auto; height: 100%; }
        .left-col::-webkit-scrollbar { width: 5px; }
        .left-col::-webkit-scrollbar-thumb { background: #ddd; border-radius: 5px; }
        
        .back-btn { border: 1px solid #ddd; padding: 6px 12px; border-radius: 6px; color: #555; text-decoration: none; font-size: 13px; font-weight: 600; display: block; text-align: center; margin-bottom: 20px; transition: 0.2s; background: #fdfdfd; }
        .back-btn:hover { background: #f0f2f5; color: #000; }
        .info-title { font-size: 13px; font-weight: 700; color: #333; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
        .i-label { font-size: 11px; font-weight: 700; color: #888; text-transform: uppercase; margin-bottom: 4px; }
        .i-value { font-size: 13px; color: #333; margin-bottom: 15px; font-weight: 500; }
        
        .src-badge { font-size: 11px; padding: 4px 8px; border-radius: 4px; font-weight: 700; display: inline-block; margin-bottom: 15px; background: #6c757d; color: #fff; text-transform: uppercase; }
        .src-website { background-color: #ffc107; color: #000; }
        .src-whatsapp { background-color: #198754; color: #fff; }
        .tag-badge { background: #eef2ff; color: #4f46e5; font-size: 12px; padding: 4px 10px; border-radius: 6px; display: inline-flex; align-items: center; margin: 2px 2px 4px 0; font-weight: 500; border: 1px solid #c7d2fe; }
        .tag-badge i { font-size: 14px; margin-left: 6px; cursor: pointer; color: #818cf8; transition: 0.2s; }
        .tag-badge i:hover { color: #ef4444; transform: scale(1.1); }
        .btn-tag-toggle { background: #fff; border: 1px solid #ddd; color: #555; font-size: 12px; border-radius: 4px; padding: 6px 12px; cursor: pointer;}
        .btn-tag-toggle.active { font-weight: bold; color: #000; border-color: #ccc; background: #f8f9fa; }

        .middle-col { flex-grow: 1; background: #efeae2; display: flex; flex-direction: column; position: relative; height: 100%; border-right: 1px solid #ddd; }
        .chat-top { flex-shrink: 0; background: #f0f2f5; height: 65px; display: flex; align-items: center; justify-content: space-between; padding: 0 20px; border-bottom: 1px solid #ddd; }
        .chat-circle { width: 40px; height: 40px; background: #198754; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: bold; margin-right: 15px; }
        .badge-new { background-color: #4e73df; color: white; padding: 3px 8px; font-size: 10px; border-radius: 4px; margin-left: 10px; vertical-align: middle; }
        #wa-window-alert { flex-shrink: 0; }
        .chat-body { flex-grow: 1; padding: 20px; overflow-y: auto; background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png'); display: flex; flex-direction: column; scroll-behavior: smooth; }         
        
        .chat-footer { background: #f0f2f5; position: relative; border-top: 1px solid #ddd; flex-shrink: 0; }
        .chat-footer-inner { padding: 10px 15px; display: flex; gap: 12px; align-items: flex-end; width: 100%; }
        
        .msg-wrapper { display: flex; width: 100%; margin-bottom: 8px; align-items: center; }
        .msg-wrapper-sent { justify-content: flex-end; }
        .msg-wrapper-received { justify-content: flex-start; }
        
        .reply-action-btn { opacity: 0; transition: 0.2s; background: #f0f2f5; border-radius: 50%; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: #54656f; margin: 0 8px; flex-shrink: 0; }
        .msg-wrapper:hover .reply-action-btn { opacity: 1; }
        .reply-action-btn:hover { background: #d1d7db; }

        .msg-bubble { display: inline-block; max-width: 75%; padding: 6px 8px 8px 10px; border-radius: 8px; font-size: 14px; box-shadow: 0 1px 1px rgba(0,0,0,0.1); word-wrap: break-word; color: #111b21; }
        .msg-received { background: #fff; border-top-left-radius: 0; }
        .msg-sent { background: #dcf8c6; border-top-right-radius: 0; }
        .msg-internal { background: #fff3cd; border-top-right-radius: 0; border: 1px solid #ffe69c; }
        .msg-text { white-space: pre-wrap; }
        .msg-time { font-size: 10.5px; color: #667781; float: right; margin-top: 10px; margin-left: 15px; margin-bottom: -4px; }
        .msg-bubble::after { content: ""; display: table; clear: both; }

        #slashCommands { display: none; position: absolute; bottom: 100%; left: 15px; right: 15px; width: auto !important; max-height: 250px; overflow-y: auto; background: white; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 -4px 15px rgba(0,0,0,0.1); z-index: 1050; padding: 8px; margin-bottom: 10px; }
        #emojiPicker { display: none; position: absolute; bottom: 100%; left: 15px; width: 315px; max-height: 230px; overflow-y: auto; background: white; border: 1px solid #d1d7db; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.15); z-index: 1050; padding: 12px; grid-template-columns: repeat(7, 1fr); gap: 6px; margin-bottom: 10px; }
        .slash-item { padding: 10px 14px; cursor: pointer; border-bottom: 1px solid #f1f5f9; font-size: 13px; background: #f8fafc; border-radius: 6px; margin-bottom: 4px; border: 1px solid #e2e8f0; }
        .slash-item:hover { background: #eff6ff; border-color: #93c5fd; }
        .slash-cmd { font-weight: bold; color: #2563eb; display: block; margin-bottom: 2px; }
        .slash-text { color: #475569; font-size: 12px; display: block; line-height: 1.3; }
        .emoji-btn { cursor: pointer; font-size: 22px; text-align: center; padding: 4px; border-radius: 4px; display: flex; align-items: center; justify-content: center; }
        .emoji-btn:hover { background: #eee; }
        .attachment-preview { max-width: 250px; border-radius: 8px; margin-bottom: 5px; display: block; cursor: pointer; }

        #imageLightbox { display: none; position: fixed; z-index: 999999; top: 0; left: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.85); align-items: center; justify-content: center; backdrop-filter: blur(5px); overflow: hidden; }
        #imageLightbox img { max-width: 90%; max-height: 90vh; border-radius: 8px; object-fit: contain; transition: transform 0.2s ease-out; transform-origin: center center; cursor: grab; }
        #imageLightbox .close-btn { position: absolute; top: 20px; right: 30px; color: white; font-size: 40px; font-weight: bold; cursor: pointer; z-index: 1000000; }
        .zoom-controls { position: absolute; bottom: 40px; left: 50%; transform: translateX(-50%); display: flex; gap: 15px; z-index: 1000000; background: rgba(255, 255, 255, 0.2); padding: 10px 20px; border-radius: 30px; backdrop-filter: blur(10px); }
        .zoom-controls button { background: #fff; border: none; border-radius: 50%; width: 40px; height: 40px; font-size: 18px; cursor: pointer; display: flex; align-items: center; justify-content: center; color: #333; transition: 0.2s; box-shadow: 0 4px 6px rgba(0,0,0,0.2); }
        .zoom-controls button:hover { background: #4e73df; color: #fff; }

        .right-col { width: 320px; flex-shrink: 0; background: #fff; display: flex; flex-direction: column; height: 100%; border-left: 1px solid #ddd; overflow: hidden; }
        #crmToolsWrapper { display: flex; flex-direction: column; flex-grow: 1; height: 100%; min-height: 0; overflow: hidden; }
        
        .tabs { display: flex; border-bottom: 1px solid #ddd; flex-shrink: 0; }
        .tab-btn { flex: 1; padding: 15px; text-align: center; background: #fff; border: none; font-weight: 600; font-size: 13px; color: #666; cursor: pointer; transition: 0.2s; border-bottom: 3px solid transparent; }
        .tab-btn.active { background: #4e73df; color: #fff; border-bottom: 3px solid #3a5bba; }
        .notes-area { padding: 15px; border-bottom: 1px solid #eee; background: #fafafa; flex-shrink: 0; }
        
        #pendingTasksList { max-height: 250px; overflow-y: auto; padding-right: 5px; }
        #pendingTasksList::-webkit-scrollbar { width: 4px; }
        #pendingTasksList::-webkit-scrollbar-thumb { background: #ccc; border-radius: 4px; }
        
        .timeline-container { padding: 20px; overflow-y: auto; flex: 1 1 0; min-height: 0; height: 0; }
        .timeline-container::-webkit-scrollbar { width: 5px; }
        .timeline-container::-webkit-scrollbar-thumb { background: #ddd; border-radius: 5px; }

        .timeline-title { font-size: 12px; font-weight: 700; color: #888; text-transform: uppercase; margin-bottom: 20px; letter-spacing: 0.5px; }
        .tl-item { position: relative; padding-left: 20px; margin-bottom: 20px; }
        .tl-item::before { content: ''; position: absolute; left: 0; top: 4px; width: 10px; height: 10px; background: #4e73df; border-radius: 50%; z-index: 2; border: 2px solid #fff; box-shadow: 0 0 0 1px #4e73df; }
        .tl-item::after { content: ''; position: absolute; left: 4px; top: 14px; width: 2px; height: 100%; background: #e0e0e0; z-index: 1; }
        .tl-item:last-child::after { display: none; }
        .t-date { font-size: 11px; color: #888; margin-bottom: 2px; }
        .t-title { font-size: 13px; font-weight: 700; color: #333; }
        .t-desc { font-size: 12px; color: #666; margin-top: 2px; line-height: 1.4; }
        
        .task-list { list-style: none; padding: 0; margin: 0; }
        .task-list li { border: 1px solid #eee; padding: 10px; margin-bottom: 10px; border-radius: 6px; background: #fff; font-size: 12px; position: relative;}
        .task-time { font-size: 11px; color: #dc3545; font-weight: bold; display: block; margin-top: 5px; }
        .task-del { position: absolute; right: 10px; top: 10px; color: #999; cursor: pointer; transition: 0.2s; }
        .task-del:hover { color: #198754; transform: scale(1.1); }
        .reminder-chip { font-size: 11px; padding: 3px 8px; background: #e2e8f0; border-radius: 4px; border: none; cursor: pointer; font-weight: 600; color: #334155; transition: 0.2s; }
        .reminder-chip:hover { background: #cbd5e1; color: #0f172a; }
        
        .mobile-top-tabs { display: none; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0 !important; margin-top: 70px !important; height: calc(100dvh - 70px) !important; display: flex; flex-direction: column; }
            .mobile-top-tabs { display: flex !important; background: #fff; border-bottom: 1px solid #ddd; height: 48px; flex-shrink: 0; width: 100%; }
            .m-tab-btn { flex: 1; border: none; background: transparent; font-size: 13px; font-weight: 600; color: #64748b; display: flex; align-items: center; justify-content: center; gap: 6px; border-bottom: 3px solid transparent; cursor: pointer; }
            .m-tab-btn.active { color: #0d6efd; border-bottom: 3px solid #0d6efd; background: #f8fafc; }
            .content-area { display: flex !important; flex-direction: column !important; flex: 1 !important; min-height: 0 !important; width: 100vw !important; overflow: hidden !important; position: relative; }
            .left-col, .middle-col, .right-col { display: none !important; width: 100% !important; flex: 1 !important; min-height: 0 !important; flex-shrink: 0; border: none !important; }
            .left-col.mobile-active { display: block !important; overflow-y: auto !important; padding: 15px 20px 20px 20px !important; }
            .middle-col.mobile-active { display: flex !important; flex-direction: column !important; background: #efeae2 !important; }
            .right-col.mobile-active { display: flex !important; flex-direction: column !important; }
            .left-col .mobile-toggle-header { display: none !important; }
            .left-col .mobile-collapse-wrapper { display: block !important; }
            .middle-col .chat-top { height: 60px !important; min-height: 60px !important; flex-shrink: 0 !important; }
            .middle-col .chat-body { flex: 1 !important; min-height: 0 !important; overflow-y: auto !important; padding: 10px !important; }
            .middle-col .chat-footer { flex-shrink: 0 !important; padding: 0 !important; background: #f0f2f5 !important; border-top: 1px solid #ddd !important; z-index: 50 !important; padding-bottom: calc(10px + env(safe-area-inset-bottom)) !important; }
            .chat-footer-inner { padding: 10px !important; }
            .right-col .mobile-toggle-header { display: none !important; }
            #crmToolsWrapper { display: flex !important; flex-direction: column !important; height: 100% !important; flex: 1 !important; min-height: 0 !important; overflow: hidden !important; }
            .right-col .timeline-container { flex: 1 !important; min-height: 0 !important; overflow-y: auto !important; padding: 15px 15px 20px 15px !important; }
            #slashCommands, #emojiPicker { width: calc(100vw - 30px) !important; left: 15px !important; bottom: calc(100% + 5px) !important;}
        }
        /* Lead Profile-only incremental chat history controls. */
        .crm-profile-older { align-self: center; padding: 6px 14px; margin: 6px auto 16px;
            background: #fff; color: #176f62; border: 1px solid #bcd8d1; border-radius: 18px;
            cursor: pointer; font-size: 12px; flex-shrink: 0; }
        .crm-profile-older:hover { background: #e8f7ef; }
        .crm-profile-older:disabled { opacity: .65; cursor: wait; }
        .crm-profile-chat-error { align-self: center; margin: 15px auto; background: #fff3cd;
            color: #6b4b00; padding: 10px; border-radius: 8px; font-size: 12px; }
        .crm-quote-link, .crm-quote-unavailable { display:flex; align-items:center; gap:8px; width:100%;
            border:0; border-left:4px solid #00a884; border-radius:6px; background:rgba(255,255,255,.75);
            padding:6px 8px; margin:0 0 7px; text-align:left; color:#41525d; font-size:12px; }
        .crm-quote-link { cursor:pointer; }
        .crm-quote-copy { min-width:0; flex:1; display:flex; flex-direction:column; }
        .crm-quote-copy strong { color:#008069; }
        .crm-quote-copy span { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .crm-quote-thumb { width:44px; height:44px; object-fit:cover; border-radius:4px; }
        .crm-quote-highlight .msg-bubble { outline:3px solid #00a884; outline-offset:2px; }
        /* Quote navigation must never move the CRM page/header; only chat body scrolls. */
        html { overflow: hidden; }
        .main-content, .content-area, .middle-col { min-height: 0; }
        .middle-col { min-width: 0; }
        #messageContainer { min-height: 0; min-width: 0; overscroll-behavior-y: contain; }
        #messageContainer .msg-bubble { overflow-wrap: anywhere; }
        #messageContainer .crm-quote-link { max-width: 100%; min-width: 0; }
        /* Responsive adjustments stay scoped to this Lead Profile view. */
        @media (max-width: 768px) {
            html, body { width: 100%; max-width: 100%; overflow: hidden; }
            .main-content { width: 100% !important; max-width: 100% !important; }
            .content-area { width: 100% !important; max-width: 100% !important; }
            .middle-col.mobile-active { min-width: 0 !important; max-width: 100% !important; }
            .middle-col .chat-top { padding: 0 10px !important; gap: 8px; min-width: 0; }
            .chat-top > .d-flex:first-child { flex: 1 1 auto; min-width: 0; overflow: hidden; }
            .chat-top > .d-flex:first-child > div:last-child { min-width: 0; overflow: hidden; }
            .chat-top > .d-flex:first-child > div:last-child > div:first-child {
                overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
            }
            .chat-top > .d-flex:last-child { flex: 0 0 auto; }
            #headerAgentTransfer { width: 112px !important; max-width: 112px; }
            .middle-col .chat-body { min-width: 0; min-height: 0; padding: 10px !important; }
            #messageContainer .msg-bubble { max-width: 87%; }
            #messageContainer .attachment-preview { max-width: 100%; height: auto; }
            #messageContainer .reply-action-btn { opacity: 1; margin: 0 3px; width: 26px; height: 26px; }
            .chat-footer-inner { min-width: 0; gap: 6px !important; padding: 8px !important; }
            .chat-footer-inner > .d-flex:first-child { gap: 9px !important; padding-left: 0 !important; padding-right: 0 !important; flex: 0 0 auto; }
            #inputWrapper { min-width: 0; }
            #msgInput { min-width: 0; font-size: 16px !important; }
            #imageLightbox .zoom-controls { bottom: calc(12px + env(safe-area-inset-bottom)); }
            #imageLightbox img { max-width: 94vw; max-height: 75dvh; }
        }
        @media (max-width: 380px) {
            .middle-col .chat-top { padding: 0 7px !important; gap: 5px; }
            .chat-circle { width: 32px; height: 32px; min-width: 32px; margin-right: 7px; font-size: 15px; }
            #headerAgentTransfer { width: 90px !important; max-width: 90px; }
            .chat-footer-inner { gap: 4px !important; padding: 6px !important; }
            .chat-footer-inner > .d-flex:first-child { gap: 6px !important; }
            #messageContainer .msg-bubble { max-width: 89%; }
            #sendBtn { width: 38px !important; height: 38px !important; }
        }


        /* Lead Profile parity: multi-photo compose + Meta ad creative preview. */
        #attachmentPreview.crm-multi-preview { display:none; position:absolute; bottom:100%; left:10px;
            right:10px; max-height:190px; overflow:auto; flex-wrap:wrap; gap:8px; padding:10px;
            background:#fff; border:1px solid #d1d7db; border-radius:10px;
            box-shadow:0 -4px 14px rgba(0,0,0,.12); z-index:60; margin-bottom:8px; }
        .crm-attachment-tile { position:relative; display:flex; flex-direction:column; width:86px;
            gap:3px; font-size:10px; color:#596b75; min-width:0; }
        .crm-attachment-tile img { width:78px; height:75px; object-fit:cover; border-radius:6px; background:#edf1f4; }
        .crm-attachment-tile button { position:absolute; right:0; top:0; width:24px; height:24px;
            background:#fff; color:#bc2835; border:1px solid #e6b3b8; border-radius:50%; cursor:pointer; }
        .crm-attachment-tile small { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .crm-profile-upload-status { font-size:12px; padding:6px 12px; background:#fff8e2;
            border-top:1px solid #ebdfbb; color:#674f1a; }
        .crm-profile-first-ad { margin:6px 0 8px; padding:8px; background:#f5f8ff;
            border-left:3px solid #6876cc; border-radius:7px; max-width:240px; }
        .crm-profile-first-ad-title { display:block; font-size:11px; font-weight:700;
            color:#4a5c91; margin-bottom:5px; }
        .crm-profile-ad-open { display:flex; align-items:center; gap:9px; padding:5px;
            border:1px solid #d5dce8; border-radius:7px; background:white; text-align:left;
            cursor:pointer; max-width:100%; }
        .crm-profile-ad-open img { width:94px; max-height:98px; object-fit:cover; border-radius:4px; }
        .crm-profile-ad-open span { font-size:12px; color:#253848; }
        #profileAdMediaModalBody video, #profileAdMediaModalBody img {
            max-height:65dvh; max-width:100%; width:auto; border-radius:7px; }
        @media (max-width:768px) {
            #attachmentPreview.crm-multi-preview { left:5px; right:5px; max-height:150px; }
            .crm-profile-first-ad { max-width:100%; }
            #profileAdMediaModalBody iframe { min-height:270px!important; }
        }
    </style> 
</head> 
<body>      
    <?php include __DIR__ . '/sidebar.php'; ?>
    <div class="main-content">
        <div class="mobile-top-tabs">
            <a href="javascript:void(0);" class="m-tab-btn active" id="mTabChat" onclick="switchMobileTab('chat')">
                <i class="bi bi-chat-dots-fill"></i> Chat
            </a>
            <a href="javascript:void(0);" class="m-tab-btn" id="mTabInfo" onclick="switchMobileTab('info')">
                <i class="bi bi-person-lines-fill"></i> Info
            </a>
            <a href="javascript:void(0);" class="m-tab-btn" id="mTabNotes" onclick="switchMobileTab('notes')">
                <i class="bi bi-journal-text"></i> Notes
            </a>
        </div>

        <div class="content-area">
            <!-- LEFT COLUMN -->
            <div class="left-col" id="colInfo">
                <?php 
                    $backText = 'Back to Leads';
                    if (isset($_GET['ref'])) {
                        if ($_GET['ref'] === 'tasks') {
                            $backText = 'Back to Tasks';
                        } else if ($_GET['ref'] === 'website_leads') {
                            $backText = 'Back to Website Leads';
                        }
                    }
                ?>
                <a href="javascript:void(0);" onclick="window.history.back();" class="back-btn shadow-sm d-none d-md-block">
                    <i class="bi bi-arrow-left me-2"></i> <?= $backText ?>
                </a>

                <div class="info-title mobile-toggle-header" onclick="toggleMobilePanel('leadInfoWrapper', this)">
                    <span>Lead Information</span> <i class="bi bi-chevron-down d-md-none fs-5 text-muted"></i>
                </div>

                <div id="leadInfoWrapper" class="mobile-collapse-wrapper">
                    <div class="i-label">Phone / WhatsApp</div>
                    <div class="i-value"><i class="bi bi-whatsapp text-success me-1"></i> <?= htmlspecialchars($lead['phone_number'] ?? $lead['whatsapp_number'] ?? 'N/A') ?></div>

                    <div class="i-label">Email Address</div>
                    <div class="i-value"><?= htmlspecialchars($lead['email'] ?? 'N/A') ?></div>

                    <?php if(!empty($lead['company_name'])): ?>
                        <div class="i-label">Company Name</div>
                        <div class="i-value"><?= htmlspecialchars($lead['company_name']) ?></div>
                    <?php endif; ?>

                    <div class="i-label">Location</div>
                    <div class="i-value">
                        <?= htmlspecialchars($lead['city'] ?? '') ?>, <?= htmlspecialchars($lead['state'] ?? '') ?><br>
                        <?= htmlspecialchars($lead['postal_code'] ?? '') ?><br>
                        <?= htmlspecialchars($lead['country'] ?? '') ?>
                    </div>

                    <div class="i-label">Source</div>
                    <?php 
                        $src = strtolower($lead['lead_source'] ?? 'manual');
                        $bc = ($src == 'website') ? 'src-website' : (($src == 'whatsapp') ? 'src-whatsapp' : '');
                    ?>
                    <div class="src-badge <?= $bc ?>"><?= htmlspecialchars($lead['lead_source'] ?? 'Website') ?></div>

                    <div class="i-label" id="infoAdLabel" style="display: <?= !empty($lead['meta_ad_name']) ? 'block' : 'none' ?>;">Meta Ad Clicked</div>
                    <div class="i-value text-primary fw-bold" id="infoAdName" style="display: <?= !empty($lead['meta_ad_name']) ? 'block' : 'none' ?>;">
                        <?= htmlspecialchars($lead['meta_ad_name'] ?? '') ?>
                    </div>

                    <div class="i-label">Interested In</div>
                    <div class="i-value" style="line-height: 1.5;">
                        <?php 
                            $raw = str_replace([' - $0.00', '&#36;0.00'], '', html_entity_decode($lead['products_of_interest'] ?? ''));
                            echo !empty(trim($raw)) ? nl2br(htmlspecialchars($raw)) : 'N/A';
                        ?>
                    </div>

                    <div class="i-label">Date Added</div>
                    <?php
                        // 🔥 FIXED TIMEZONE BUG: Parse DB time strictly as Local Time 🔥
                        $dateStr = \Core\Timezone::formatUtc($lead['created_at'], $profileDisplayTimezone, 'F d, Y h:i A');
                    ?>
                    <div class="i-value"><?= $dateStr ?></div>

                    <div class="i-label mt-4 border-top pt-3 mb-2">Lead Stage</div>
                    <select id="profileLeadStage" class="form-select form-select-sm shadow-none border-secondary-subtle fw-bold mb-3" onchange="updateLeadStage(this.value)">
                        <?php
                            $stages = ['New', 'Qualified', 'Catalog Sharing', 'Follow Up', 'Negotiation', 'Sold', 'Unqualified'];
                            $currentStage = trim($lead['lead_stage'] ?? 'New');
                            foreach($stages as $stg) {
                                $selected = (strcasecmp($currentStage, $stg) == 0) ? 'selected' : '';
                                echo "<option value=\"$stg\" $selected>$stg</option>";
                            }
                        ?>
                    </select>

                    <div class="i-label mt-3 border-top pt-3">Tags</div>
                    <div id="infoTags" class="mb-2">
                        <?php 
                            $current_tags = !empty($lead['tags']) ? array_map('trim', explode(',', $lead['tags'])) : [];
                            if(!empty($current_tags)): 
                                foreach($current_tags as $tag): 
                                    if(empty($tag)) continue;
                        ?>
                                <span class="tag-badge" data-tag-name="<?= htmlspecialchars($tag) ?>">
                                    <?= htmlspecialchars($tag) ?> 
                                    <i class="bi bi-x" title="Remove Tag" onclick="removeTag('<?= htmlspecialchars(addslashes($tag)) ?>')"></i>
                                </span>
                        <?php 
                                endforeach; 
                            else: 
                        ?>
                                <small class="text-muted" id="noTagsText">No tags yet</small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="d-flex gap-2 mt-3 mb-2">
                        <button type="button" id="tab-select-tag" class="btn-tag-toggle active flex-grow-1" onmousedown="event.preventDefault(); toggleTagTab('select')">Select Tag</button>
                        <button type="button" id="tab-create-tag" class="btn-tag-toggle flex-grow-1" onmousedown="event.preventDefault(); toggleTagTab('create')">New Tag</button>
                    </div>

                    <div id="selectTagView" class="input-group input-group-sm mt-2">
                        <select id="existingTagSelect" class="form-select shadow-none border-secondary-subtle" style="font-size: 13px;">
                            <option value="" disabled selected>Select a tag...</option>
                            <?php foreach(($all_company_tags ?? []) as $ctag): ?>
                                <?php if(!in_array($ctag, $current_tags)): ?>
                                    <option value="<?= htmlspecialchars($ctag) ?>"><?= htmlspecialchars($ctag) ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                        <button type="button" class="btn btn-outline-secondary px-3" style="border-color: #ddd;" onmousedown="event.preventDefault(); addTagFromDropdown()"><i class="bi bi-plus fs-5"></i></button>
                    </div>

                    <div id="createTagView" class="input-group input-group-sm mt-2" style="display: none;">
                        <input type="text" id="newTagInput" class="form-control shadow-none border-secondary-subtle" placeholder="Type new tag..." style="font-size: 13px;" autocomplete="off" onkeypress="if(event.key==='Enter') { event.preventDefault(); createNewTag(); }">
                        <button type="button" class="btn btn-outline-secondary px-3" style="border-color: #ddd;" onmousedown="event.preventDefault(); createNewTag()"><i class="bi bi-plus fs-5"></i></button>
                    </div>
                </div>
            </div>

            <!-- MIDDLE COLUMN -->
            <div class="middle-col mobile-active" id="colChat">
                <div class="chat-top">
                    <div class="d-flex align-items-center">
                        <a href="javascript:void(0);" onclick="window.history.back();" class="d-md-none btn btn-link text-dark p-0 me-3"><i class="bi bi-arrow-left fs-4"></i></a>
                        <div class="chat-circle"><?= strtoupper(substr($lead['full_name'], 0, 1)) ?></div>
                        <div>
                            <div style="font-weight: 700; color: #111; font-size: 15px;"><?= htmlspecialchars($lead['full_name']) ?> <span class="badge-new">#LD-<?= str_pad($lead['id'], 4, '0', STR_PAD_LEFT) ?></span></div>
                            <div style="font-size: 12px; color: #666;"><i class="bi bi-link"></i> WhatsApp Active</div>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2">
                        <select id="headerAgentTransfer" class="form-select form-select-sm shadow-none border-secondary" style="font-size: 12px; width: 140px; cursor: pointer;" onchange="transferLeadProfile(this.value)">
                            <option value="">Transfer Lead...</option>
                            <?php foreach(($agents ?? []) as $ag): ?>
                                <option value="<?= $ag['id'] ?>" <?= ($lead['assigned_to'] == $ag['id']) ? 'selected' : '' ?>><?= htmlspecialchars($ag['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="chat-body" id="messageContainer">
                    <div class="text-center text-muted mt-5"><div class="spinner-border spinner-border-sm text-success"></div> Connecting to chat...</div>
                </div>

                <div id="wa-window-alert" style="display: none; text-align: center; padding: 10px 20px; background: #efeae2;">
                    <div style="background-color: #ebd1d1; border: 1px solid #dcaaa9; color: #5c0000; padding: 8px 12px; border-radius: 5px; font-weight: bold; font-size: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                        <i class="bi bi-lock-fill text-dark me-1"></i> 
                        The 24-hour WhatsApp messaging window is closed (or Website Lead). You can only send templates.
                    </div>
                </div>

                <div class="chat-footer" style="flex-direction: column; align-items: stretch; gap: 0;">
                    
                    <div id="replyContextBox" style="display: none; background: #f5f6f6; border-left: 4px solid #00a884; padding: 8px 12px; margin-bottom: 8px; border-radius: 8px; position: relative;">
                        <input type="hidden" id="replyToMessageId" value="">
                        <div style="font-weight: bold; color: #00a884; font-size: 13px;" id="replyToName">Name</div>
                        <div style="color: #667781; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 90%;" id="replyToText">Message text...</div>
                        <button type="button" onclick="closeReply()" style="position: absolute; right: 8px; top: 10px; background: none; border: none; font-size: 16px; color: #8696a0; cursor: pointer;">&times;</button>
                    </div>

                    <div id="attachmentPreview" class="crm-multi-preview" aria-live="polite"></div>
                    <div id="profileSendStatus" class="crm-profile-upload-status" role="status" style="display:none;"></div>

                    <div id="slashCommands" style="z-index: 1050 !important;"></div>
                    <div id="emojiPicker"></div>

                    <div class="d-flex align-items-end w-100 gap-2">
                        <div class="d-flex align-items-center gap-3 mb-1 text-secondary px-1 pb-1">
                            <i class="bi bi-emoji-smile fs-4" style="cursor:pointer" onclick="toggleEmoji()"></i>
                            <input type="file" id="attachFile" accept="image/*,video/*,audio/*,.pdf,.doc,.docx" multiple style="display:none;" onchange="handleFileSelect(event)">
                            <label for="attachFile" class="m-0" style="cursor: pointer;" title="Attach File">
                                <i class="bi bi-paperclip fs-4"></i>
                            </label>
                        </div>
                        
                        <div id="inputWrapper" class="flex-grow-1 bg-white border d-flex align-items-end" style="border-radius: 24px; padding: 2px 8px; box-shadow: 0 1px 1px rgba(0,0,0,0.05); transition: background 0.3s;">
                            <textarea id="msgInput" class="form-control border-0 shadow-none m-0" rows="1" placeholder="Message..." autocomplete="off" oninput="handleInput(this)" onkeydown="handleKeydown(event)" style="resize: none; max-height: 100px; font-size: 14px; background: transparent; padding: 10px 5px; overflow-y: auto; line-height: 20px;"></textarea>
                            <i class="bi bi-journal-text fs-5 text-secondary p-2 mb-0 pb-1" id="internalToggleBtn" onclick="toggleInternalNote()" style="cursor:pointer; align-self: flex-end;" title="Toggle Internal Note"></i>
                        </div>
                        
                        <div class="mb-0 pb-1 d-flex align-items-end">
                            <button type="button" id="sendBtn" class="btn btn-success rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width: 42px; height: 42px; background-color: #00a884; border-color: #00a884; flex-shrink: 0;" onclick="sendMessage()">
                                <i class="bi bi-send-fill fs-5" style="margin-left: 2px;"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN -->
            <div class="right-col" id="colNotes">
                <div class="info-title d-md-none" style="padding: 15px; margin: 0; background: #fff; border-bottom: 1px solid #ddd;">Notes & Tasks</div>
                
                <div id="crmToolsWrapper">
                    <div class="tabs">
                        <button class="tab-btn active" id="tabNotesBtn" onclick="switchRightTab('notes')">Notes</button>
                        <button class="tab-btn" id="tabTasksBtn" onclick="switchRightTab('tasks')">Tasks</button>
                    </div>
                    
                    <div id="notesSection" class="notes-area">
                        <!-- 🔥 FORMS NOW SUBMIT SILENTLY TO IFRAME 🔥 -->
                        <form action="<?= BASE_URL ?>leadprofile/add_note" method="POST" target="hidden_note_iframe" onsubmit="setTimeout(() => { this.reset(); refreshProfileDataSilently(); }, 800);">
                            <input type="hidden" name="lead_id" value="<?= $lead['id'] ?>">
                            <textarea name="note" class="form-control mb-2" rows="2" placeholder="Add a note about this lead..." required style="font-size:13px; resize:none; box-shadow:none;"></textarea>
                            <button type="submit" class="btn btn-primary w-100 fw-bold py-2">Save Note</button>
                        </form>
                    </div>

                    <div id="tasksSection" class="notes-area" style="display: none; background: #eef2f5;">
                        <input type="text" id="taskTitleInput" class="form-control mb-2" placeholder="Task description..." style="font-size:13px;">
                        <input type="datetime-local" id="taskTimeInput" class="form-control mb-2" style="font-size:13px;">
                        
                        <div class="d-flex flex-wrap gap-1 mb-2">
                            <button type="button" class="reminder-chip" onclick="setQuickReminder(1)">+1 Hour</button>
                            <button type="button" class="reminder-chip" onclick="setQuickReminder(3)">+3 Hours</button>
                            <button type="button" class="reminder-chip" onclick="setQuickReminder(6)">+6 Hours</button>
                            <button type="button" class="reminder-chip" onclick="setQuickReminder(24)">Tomorrow</button>
                            <button type="button" class="reminder-chip" onclick="setQuickReminder(48)">Day After</button>
                            <button type="button" class="reminder-chip" onclick="setQuickReminder(168)">1 Week</button>
                        </div>

                        <button class="btn btn-warning w-100 fw-bold py-2 shadow-sm" onclick="saveTask()"><i class="bi bi-bell-fill me-1"></i> Set Reminder</button>
                        
                        <div class="mt-3">
                            <h6 style="font-size: 11px; color:#888; text-transform:uppercase; font-weight:bold;">Pending Tasks</h6>
                            <ul class="task-list" id="pendingTasksList">
                                <!-- Tasks will load here automatically via JS -->
                            </ul>
                        </div>
                    </div>

                    <div class="timeline-container">
                        <div class="timeline-title">Customer Journey</div>
                        
                        <?php if(!empty($timeline)): ?>
                            <?php foreach($timeline as $item): ?>
                                <div class="tl-item">
                                    <?php
                                        // 🔥 FIXED TIMEZONE BUG: Parse DB time strictly as Local Time 🔥
                                        $tdate = \Core\Timezone::formatUtc($item['created_at'], $profileDisplayTimezone, 'M d, Y h:i A');
                                    ?>
                                    <div class="t-date"><?= $tdate ?></div>
                                    <div class="t-title"><?= htmlspecialchars($item['note_type']) ?></div>
                                    <div class="t-desc"><?= nl2br(htmlspecialchars($item['note_text'])) ?> <br><span class="text-primary fw-bold" style="font-size:11px;">By: <?= htmlspecialchars($item['created_by']) ?></span></div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <div class="tl-item">
                            <div class="t-date"><?= $dateStr ?></div>
                            <div class="t-title">Lead Created</div>
                            <div class="t-desc">Captured via <?= htmlspecialchars($lead['lead_source'] ?? 'Website') ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 

    <!-- ADVANCED IMAGE LIGHTBOX -->
    <div id="imageLightbox" onclick="if(event.target.id === 'imageLightbox') closeImagePopup()">
        <span class="close-btn" onclick="closeImagePopup()">&times;</span>
        <div class="zoom-controls">
            <button onclick="zoomImage(0.2)" title="Zoom In"><i class="bi bi-zoom-in"></i></button>
            <button onclick="zoomImage(-0.2)" title="Zoom Out"><i class="bi bi-zoom-out"></i></button>
            <button onclick="resetZoom()" title="Reset Zoom"><i class="bi bi-arrow-counterclockwise"></i></button>
        </div>
        <img id="lightboxImg" src="">
    </div>

    <!-- Original Meta Ad creative. Uses the existing read-only Inbox preview endpoint. -->
    <div class="modal fade" id="profileAdMediaModal" tabindex="-1" aria-labelledby="profileAdMediaModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-fullscreen-sm-down">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="profileAdMediaModalTitle">Original Meta Ad</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center" id="profileAdMediaModalBody"></div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Push Notification Sound & Hidden iFrame -->
    <audio id="notificationSound" preload="auto"><source src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3" type="audio/mpeg"></audio>
    <iframe name="hidden_note_iframe" id="hidden_note_iframe" style="display:none;"></iframe>

    <script>
    const baseUrl = '<?= rtrim(BASE_URL, '/') ?>/';
    const activeLeadId = <?= $lead['id'] ?>;
    const leadSource = '<?= strtolower($lead['lead_source'] ?? '') ?>';
    const contactName = "<?= addslashes($lead['full_name'] ?? 'Customer') ?>";
    const metaAdName = <?= json_encode($lead['meta_ad_name'] ?? '', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>; 

    // Stage 7 correction: chat database timestamps represent UTC instants.
    // Selected company timezone is used ONLY for rendering. The existing
    // safeParseDate() / 24-72h messaging rules below are not modified.
    const crmProfileTimezone = <?= json_encode($profileDisplayTimezone, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
    const crmProfileMessageTime = new Intl.DateTimeFormat('en-IN', {
        timeZone: crmProfileTimezone, hour: '2-digit', minute: '2-digit', hour12: true
    });
    const crmProfileMessageFullTime = new Intl.DateTimeFormat('en-IN', {
        timeZone: crmProfileTimezone, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    });
    const crmProfileMessageDate = new Intl.DateTimeFormat('en-IN', {
        timeZone: crmProfileTimezone, day: '2-digit', month: '2-digit', year: 'numeric'
    });
    const crmProfileLocalParts = new Intl.DateTimeFormat('en-GB', {
        timeZone: crmProfileTimezone, year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
    });

    function crmParseUtcMessageTimestamp(value) {
        if (!value) return new Date(NaN);
        const timestamp = String(value).trim().replace(/\s+/, 'T');
        // MySQL DATETIME has no suffix; in this CRM it represents UTC.
        const withZone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(timestamp) ? timestamp : timestamp + 'Z';
        return new Date(withZone);
    }

    function crmCompanyDateParts(date) {
        const parts = crmProfileLocalParts.formatToParts(date);
        const part = name => (parts.find(p => p.type === name) || {}).value || '';
        return {year:part('year'), month:part('month'), day:part('day'),
                hour:part('hour'), minute:part('minute')};
    }
    function crmCompanyToday() {
        const p = crmCompanyDateParts(new Date());
        return `${p.year}-${p.month}-${p.day}`;
    }
    function crmCompanyDateTimeInput(date) {
        const p = crmCompanyDateParts(date);
        return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
    }
    // Legacy reminder due_date comes from a datetime-local input and stores a
    // company-local wall time, not a UTC instant. Never apply +05:30 again.
    function crmReminderWallTimeLabel(value) {
        if (!value) return '-';
        const raw = String(value).trim().replace(' ', 'T');
        if (/(?:Z|[+-]\d{2}:?\d{2})$/i.test(raw)) {
            const actual = new Date(raw);
            return isNaN(actual.getTime()) ? '-' : new Intl.DateTimeFormat('en-IN', {
                timeZone: crmProfileTimezone, month:'short', day:'numeric',
                hour:'2-digit', minute:'2-digit', hour12:true
            }).format(actual);
        }
        const wall = new Date(raw + 'Z');
        return isNaN(wall.getTime()) ? '-' : new Intl.DateTimeFormat('en-IN', {
            timeZone:'UTC', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit', hour12:true
        }).format(wall);
    }
    
    let activeConvoId = <?= !empty($lead['conversation_id']) ? $lead['conversation_id'] : 'null' ?>;
    let currentMessageCount = -1;
    let isWindowClosed = false;
    let isInternalNote = false;
    let selectedFilesArray = [];
    let profileSending = false; 
    let cachedTemplates = null;
    let cannedResponses = []; 
    let currentChatData = { created_at: null, current_agent: "<?= htmlspecialchars($lead['assigned_to_name'] ?? '') ?>" };

    const emojis = ["😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","🙃","😉","😌","😍","🥰","😘","😗","😙","😚","😋","😛","😝","😜","🤪","🤨","🧐","🤓","😎","🤩","🥳","😏","😒","😞","😔","😟","😕","🙁","😣","😖","😫","😩","🥺","😢","😭","😮","😤","😠","😡","🤬","🤯","😳","🥵","🥶","😱","😨","😰","😥","😓","🤗","🤔","🤭","🤫","🤥","😶","😐","😑","😬","🙄","😯","😦","😧","😮","😲","🥱","😴","🤤","😪","😵","🤐","🥴","🤢","🤮","🤧","😷","🤒","🤕","🤑","🤠","😈","👿","👹","👺","🤡","💩","👻","💀","☠️","👽","👾","🤖","🎃","😺","😸","😹","😻","😼","😽","🙀","😿","😾","👋","🤚","🖐️","✋","🖖","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","🖕","👇","☝️","👍","👎","✊","👊","🤛","🤜","👏","🙌","👐","🤲","🤝","🙏","✍️","💅","🤳","💪","🦾","🦵","🦶","👂","🦻","👃","🧠","👁️","👅","👄","💋","❤️","🧡","💛","💚","💙","💜","🖤","🤎","🤍","💔","❤️‍🔥","❤️‍🩹","❣️","💕","💞","💓","💗","💖","💘","💝","💟","🔥","✨","🌟","🎉"];

    // ==========================================
    // 🔥 NEW: SILENT PROFILE UPDATE ENGINE 🔥
    // ==========================================
    window.refreshProfileDataSilently = function(updateDropdown = false) {
        fetch(window.location.href)
        .then(response => response.text())
        .then(html => {
            let parser = new DOMParser(); 
            let doc = parser.parseFromString(html, 'text/html');
            
            let oldTimeline = document.querySelector('.timeline-container'); 
            let newTimeline = doc.querySelector('.timeline-container');
            if (oldTimeline && newTimeline) { 
                oldTimeline.innerHTML = newTimeline.innerHTML; 
            }

            if(updateDropdown) {
                let oldDropdown = document.getElementById('profileLeadStage');
                let newDropdown = doc.getElementById('profileLeadStage');
                if (oldDropdown && newDropdown) { oldDropdown.value = newDropdown.value; }
            }
        });
    }

    // ==========================================
    // 🔥 SILENT LEAD STAGE UPDATE 🔥
    // ==========================================
    window.updateLeadStage = function(newStage) {
        let amount = null;
        let saleDate = null;

        if (newStage === 'Sold') {
            amount = prompt("Enter Sale Amount (₹):", "0");
            if (amount === null) {
                refreshProfileDataSilently(true); // User cancelled, silently revert dropdown
                return;
            }
            saleDate = crmCompanyToday();
        }

        fetch(`${baseUrl}leadprofile/update_stage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lead_id: activeLeadId, stage: newStage, sale_amount: amount, sale_date: saleDate })
        })
        .then(r => r.json())
        .then(res => {
            if(res.status === 'success') {
                refreshProfileDataSilently(); // ✅ Updates timeline silently!
            } else {
                alert('Error updating stage: ' + res.message);
                refreshProfileDataSilently(true); // Revert on error
            }
        });
    }

    // ==========================================
    // IMAGE ZOOM & LIGHTBOX LOGIC
    // ==========================================
    let currentZoom = 1;
    let lightboxImg = document.getElementById('lightboxImg');

    window.openImagePopup = function(url) {
        document.getElementById('imageLightbox').style.display = 'flex';
        lightboxImg.src = url;
        resetZoom();
    }

    window.closeImagePopup = function() {
        document.getElementById('imageLightbox').style.display = 'none';
        lightboxImg.src = '';
    }

    window.zoomImage = function(step) {
        currentZoom += step;
        if (currentZoom < 0.2) currentZoom = 0.2; 
        if (currentZoom > 5) currentZoom = 5; 
        lightboxImg.style.transform = `scale(${currentZoom})`;
    }

    window.resetZoom = function() {
        currentZoom = 1;
        lightboxImg.style.transform = `scale(${currentZoom})`;
    }

    if (lightboxImg) {
        lightboxImg.addEventListener('wheel', function(e) {
            e.preventDefault();
            if (e.deltaY < 0) { zoomImage(0.1); } 
            else { zoomImage(-0.1); } 
        });
    }

    // ==========================================
    // TABS & TASKS FUNCTIONALITY
    // ==========================================
    window.switchRightTab = function(tab) {
        document.getElementById('tabNotesBtn').classList.remove('active');
        document.getElementById('tabTasksBtn').classList.remove('active');
        document.getElementById('notesSection').style.display = 'none';
        document.getElementById('tasksSection').style.display = 'none';

        if(tab === 'notes') {
            document.getElementById('tabNotesBtn').classList.add('active');
            document.getElementById('notesSection').style.display = 'block';
        } else {
            document.getElementById('tabTasksBtn').classList.add('active');
            document.getElementById('tasksSection').style.display = 'block';
            loadTasks(); 
        }
    }

    window.setQuickReminder = function(hours) {
        // Quick reminder input follows the company timezone, not the device timezone.
        document.getElementById('taskTimeInput').value = crmCompanyDateTimeInput(new Date(Date.now() + hours * 3600000));
    }

    window.saveTask = function() {
        let title = document.getElementById('taskTitleInput').value.trim();
        let time = document.getElementById('taskTimeInput').value;
        
        if(!title || !time) {
            alert('Please enter both Task Description and Time.');
            return;
        }

        fetch(`${baseUrl}leadprofile/add_task`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lead_id: activeLeadId, title: title, due_date: time })
        }).then(r => r.json()).then(res => {
            if(res.status === 'success') {
                document.getElementById('taskTitleInput').value = '';
                document.getElementById('taskTimeInput').value = '';
                loadTasks();
                refreshProfileDataSilently(); // SILENT TIMELINE UPDATE
                
                let audio = document.getElementById('notificationSound');
                if(audio) audio.play().catch(e=>{});
            } else {
                alert("Database Error: " + res.message); 
            }
        }).catch(err => {
            alert("Network error while setting reminder.");
        });
    }

    window.loadTasks = function() {
        fetch(`${baseUrl}leadprofile/get_tasks/${activeLeadId}`)
        .then(r => r.json())
        .then(res => {
            if(res.status === 'success') {
                let list = document.getElementById('pendingTasksList');
                list.innerHTML = '';
                if(res.data.length === 0) {
                    list.innerHTML = '<li class="text-muted text-center border-0 bg-transparent" style="box-shadow:none;">No pending tasks</li>';
                    return;
                }
                res.data.forEach(task => {
                    let timeStr = crmReminderWallTimeLabel(task.due_date);
                    
                    list.innerHTML += `
                        <li>
                            <strong style="font-size: 13px; color:#333;">${task.task_title}</strong>
                            <span class="task-time"><i class="bi bi-clock"></i> ${timeStr}</span>
                            <i class="bi bi-check-circle-fill task-del text-success fs-5" onclick="completeTask(${task.id})" title="Mark as Done"></i>
                        </li>
                    `;
                });
            }
        });
    }

    window.completeTask = function(taskId) {
        fetch(`${baseUrl}leadprofile/complete_task`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ task_id: taskId })
        }).then(r => r.json()).then(res => {
            if(res.status === 'success') {
                loadTasks(); 
                refreshProfileDataSilently(); // Update timeline silently
            }
        });
    }

    window.toggleTagTab = function(tab) {
        if (tab === 'select') {
            document.getElementById('tab-select-tag').classList.add('active');
            document.getElementById('tab-create-tag').classList.remove('active');
            document.getElementById('selectTagView').style.display = 'flex';
            document.getElementById('createTagView').style.display = 'none';
        } else {
            document.getElementById('tab-create-tag').classList.add('active');
            document.getElementById('tab-select-tag').classList.remove('active');
            document.getElementById('selectTagView').style.display = 'none';
            document.getElementById('createTagView').style.display = 'flex';
        }
    }

    window.addTagFromDropdown = function() {
        let select = document.getElementById('existingTagSelect');
        if(select && select.value) { saveTagToLead(select.value); } else { alert("Please select a tag first."); }
    }

    window.createNewTag = function() {
        let input = document.getElementById('newTagInput');
        if(input && input.value.trim()) { saveTagToLead(input.value.trim()); } else { alert("Please type a tag name."); }
    }

    window.saveTagToLead = function(tag) {
        if(!tag || !activeLeadId) return;
        fetch(`${baseUrl}leadprofile/add_tag`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lead_id: activeLeadId, tag: tag })
        }).then(r => r.json()).then(data => {
            if(data.status === 'success') {
                let newTagInput = document.getElementById('newTagInput'); if(newTagInput) newTagInput.value = '';
                let existingTagSelect = document.getElementById('existingTagSelect'); if(existingTagSelect) existingTagSelect.value = '';
                let noTagsText = document.getElementById('noTagsText'); if (noTagsText) noTagsText.remove();
                
                let existingTags = document.querySelectorAll('#infoTags .tag-badge');
                let tagExists = false;
                existingTags.forEach(el => { if (el.getAttribute('data-tag-name') === tag) tagExists = true; });
                
                if (!tagExists) {
                    document.getElementById('infoTags').innerHTML += `<span class="tag-badge" data-tag-name="${tag}">${tag} <i class="bi bi-x" title="Remove Tag" onclick="removeTag('${tag}')"></i></span>`;
                }
                refreshProfileDataSilently(); // Silently update timeline
            } else { alert("Failed to save tag."); }
        }).catch(err => { console.error("Tag error:", err); });
    }

    window.removeTag = function(tag) {
        if(!activeLeadId) return;
        document.querySelectorAll('#infoTags .tag-badge').forEach(badge => {
            if(badge.getAttribute('data-tag-name') === tag) badge.remove();
        });
        if(document.querySelectorAll('#infoTags .tag-badge').length === 0) {
            document.getElementById('infoTags').innerHTML = '<small class="text-muted" id="noTagsText">No tags</small>';
        }
        fetch(`${baseUrl}leadprofile/remove_tag`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lead_id: activeLeadId, tag: tag }) }).then(() => {
            refreshProfileDataSilently();
        });
    }

    window.setReply = function(msgId, senderName, text) {
        if(isWindowClosed && !isInternalNote) { alert("WhatsApp Policy: The messaging window is closed! You cannot reply to old messages right now. Please use a template."); return; }
        document.getElementById('replyContextBox').style.display = 'block'; document.getElementById('replyToMessageId').value = msgId; document.getElementById('replyToName').innerText = senderName; document.getElementById('replyToText').innerText = text.length > 50 ? text.substring(0, 50) + '...' : text; document.getElementById('msgInput').focus();
    }

    window.closeReply = function() { document.getElementById('replyContextBox').style.display = 'none'; document.getElementById('replyToMessageId').value = ''; }

    window.switchMobileTab = function(tabName) {
        if (window.innerWidth > 768) return;
        document.querySelectorAll('.m-tab-btn').forEach(i => i.classList.remove('active'));
        document.getElementById('colInfo').classList.remove('mobile-active');
        document.getElementById('colChat').classList.remove('mobile-active');
        document.getElementById('colNotes').classList.remove('mobile-active');

        if(tabName === 'chat') {
            document.getElementById('mTabChat').classList.add('active'); document.getElementById('colChat').classList.add('mobile-active');
            let chatBox = document.getElementById('messageContainer'); if(chatBox) setTimeout(() => { chatBox.scrollTop = chatBox.scrollHeight; }, 100);
        } else if(tabName === 'info') {
            document.getElementById('mTabInfo').classList.add('active'); document.getElementById('colInfo').classList.add('mobile-active');
        } else if(tabName === 'notes') {
            document.getElementById('mTabNotes').classList.add('active'); document.getElementById('colNotes').classList.add('mobile-active');
        }
    }

    document.addEventListener("DOMContentLoaded", function() { if (window.innerWidth <= 768) switchMobileTab('chat'); });

    document.addEventListener('click', function(e) {
        let emojiPicker = document.getElementById('emojiPicker'); let slashCommands = document.getElementById('slashCommands');
        if (emojiPicker && emojiPicker.style.display === 'grid') { if (!emojiPicker.contains(e.target) && !e.target.classList.contains('bi-emoji-smile')) emojiPicker.style.display = 'none'; }
        if (slashCommands && slashCommands.style.display === 'block') { if (!slashCommands.contains(e.target) && e.target.id !== 'msgInput') slashCommands.style.display = 'none'; }
    });

    window.toggleMobilePanel = function(panelId, headerElement) {
        if (window.innerWidth > 768) return;
        let panel = document.getElementById(panelId); let isShowing = panel.classList.contains('show');
        document.querySelectorAll('.mobile-collapse-wrapper').forEach(p => p.classList.remove('show'));
        document.querySelectorAll('.mobile-toggle-header').forEach(h => h.classList.remove('open'));
        if (!isShowing) { panel.classList.add('show'); headerElement.classList.add('open'); }
    };

    function transferLeadProfile(agentId) {
        if(!agentId) return;
        fetch(`${baseUrl}leads/assign_lead`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ lead_id: activeLeadId, agent_id: agentId }) })
        .then(r => r.json()).then(res => { 
            if(res.status === 'success') { 
                alert('Lead transferred successfully!'); 
                refreshProfileDataSilently(); // 🔥 SILENT UPDATE INSTEAD OF RELOAD 🔥
            } 
        });
    }

    // 🔥 TIMEZONE BUG FIXED: Parses Database string as Local Time (IST) 🔥
    function safeParseDate(dateString) {
        if (!dateString) return new Date(0); 
        let localString = dateString.replace('Z', ''); 
        if (localString.includes(' ') && !localString.includes('T')) { localString = localString.replace(' ', 'T'); }
        let d = new Date(localString); if (!isNaN(d.getTime())) return d;
        d = new Date(dateString.replace(/-/g, '/')); if (!isNaN(d.getTime())) return d;
        return new Date(0); 
    }

    function check24HourWindow(lastCustomerDate) {
        let alertBox = document.getElementById('wa-window-alert'); let msgInput = document.getElementById('msgInput');
        if (leadSource === 'website') {
            isWindowClosed = true; 
        } else {
            let targetDateString = lastCustomerDate ? lastCustomerDate : (currentChatData ? currentChatData.created_at : null);
            if (!targetDateString) {
                isWindowClosed = true;
            } else {
                const now = new Date(); const targetDate = safeParseDate(targetDateString); const diffInHours = (now.getTime() - targetDate.getTime()) / (1000 * 60 * 60);
                const isMetaAdLead = (typeof metaAdName !== 'undefined' && metaAdName !== 'null' && metaAdName.trim() !== '');
                const maxWindowHours = isMetaAdLead ? 72 : 24; isWindowClosed = (diffInHours > maxWindowHours);
            }
        }
        
        if(alertBox) alertBox.style.display = isWindowClosed ? 'block' : 'none';
        
        if (msgInput) {
            if (isWindowClosed && !isInternalNote) {
                msgInput.placeholder = "Chat locked. Type '//' for templates...";
                msgInput.oninput = function() {
                    let val = this.value;
                    if (val.length > 0 && !val.startsWith('/')) { alert("WhatsApp Policy: The messaging window is closed! \nYou can ONLY send Template messages. \n\nType '//' to select a template."); this.value = ''; } 
                    else { handleInput(this); }
                };
            } else if (isInternalNote) {
                msgInput.placeholder = "Type an internal note (hidden from customer)..."; msgInput.oninput = function() { handleInput(this); };
            } else {
                msgInput.placeholder = "Message..."; msgInput.oninput = function() { handleInput(this); };
            }
        }
    }

    document.getElementById('msgInput').addEventListener('focus', function() { if (isWindowClosed && !isInternalNote && this.value === '') { this.value = '//'; handleInput(this); } });

    // Parity with Inbox: select multiple files and resize large photos before upload.
    // Keep files visible if API explicitly rejects one of the messages.
    window.handleFileSelect = async function(e) {
        if (isWindowClosed && !isInternalNote) {
            alert('WhatsApp Policy: The messaging window is closed! You cannot send attachments.');
            e.target.value = ''; return;
        }
        const items = Array.from(e.target.files || []);
        e.target.value = '';
        if (!items.length) return;
        if (profileSending) { alert('Current photos are sending. Select more after it finishes.'); return; }
        const status = document.getElementById('profileSendStatus');
        status.style.display = 'block';
        status.textContent = `Preparing ${items.length} attachment(s)…`;
        const prepared = await Promise.all(items.map(async file => {
            try {
                if (file.type.startsWith('image/') && file.type !== 'image/gif') {
                    // JPEG conversion matches Inbox's established 1200px/70% approach.
                    const original = await new Promise((resolve, reject) => {
                        const reader = new FileReader();
                        reader.onload = () => resolve(reader.result);
                        reader.onerror = () => reject(new Error('Photo read failed'));
                        reader.readAsDataURL(file);
                    });
                    const img = await new Promise((resolve,reject) => {
                        const image = new Image();
                        image.onload = () => resolve(image);
                        image.onerror = () => reject(new Error('Photo decode failed'));
                        image.src = original;
                    });
                    const scale = Math.min(1, 1200 / img.width, 1200 / img.height);
                    const canvas = document.createElement('canvas');
                    canvas.width = Math.max(1,Math.round(img.width * scale));
                    canvas.height = Math.max(1,Math.round(img.height * scale));
                    canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
                    return {data: canvas.toDataURL('image/jpeg',.7),
                        name:file.name, type:'image/jpeg', state:'ready'};
                }
                const data = await new Promise((resolve,reject) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.onerror = () => reject(new Error('Attachment read failed'));
                    reader.readAsDataURL(file);
                });
                return {data,name:file.name,type:file.type || 'application/octet-stream',state:'ready'};
            } catch (error) {
                return {name:file.name,type:file.type || '',state:'error',error:String(error.message || error)};
            }
        }));
        selectedFilesArray.push(...prepared);
        renderAttachmentPreviews();
        const failures = prepared.filter(f => f.state === 'error').length;
        status.textContent = failures
            ? `${items.length - failures} attachment(s) ready, ${failures} could not be prepared.`
            : `${items.length} attachment(s) added. ${selectedFilesArray.filter(f=>f.state==='ready').length} ready to send.`;
    };

    window.renderAttachmentPreviews = function() {
        const box = document.getElementById('attachmentPreview');
        box.replaceChildren();
        box.style.display = selectedFilesArray.length ? 'flex' : 'none';
        selectedFilesArray.forEach((file,index) => {
            const tile = document.createElement('div');
            tile.className = 'crm-attachment-tile';
            const pic = document.createElement('img');
            pic.alt = file.name;
            if (file.type.startsWith('image/') && file.data) pic.src = file.data;
            else pic.src = 'https://cdn-icons-png.flaticon.com/512/2965/2965335.png';
            const remove = document.createElement('button');
            remove.type = 'button'; remove.textContent = '×'; remove.title = 'Remove attachment';
            remove.disabled = profileSending;
            remove.addEventListener('click', () => removeAttachmentIndex(index));
            const title = document.createElement('small'); title.textContent = file.name;
            title.title = file.name;
            tile.append(pic,remove,title);
            if (file.state !== 'ready') {
                const note = document.createElement('small');
                note.textContent = file.state === 'uncertain' ? 'Unconfirmed — check WhatsApp' : 'Failed — remove or retry';
                note.style.color = file.state === 'uncertain' ? '#916315' : '#b42332';
                tile.appendChild(note);
                if (file.state === 'error' && file.data) {
                    const retry = document.createElement('button');
                    retry.type = 'button'; retry.textContent = '↻'; retry.title = 'Retry explicitly rejected file';
                    retry.style.cssText='position:static;width:25px;height:24px;border-radius:5px;color:#325c8b;';
                    retry.addEventListener('click',()=> { if(!profileSending){file.state='ready';renderAttachmentPreviews();}});
                    tile.appendChild(retry);
                }
            }
            box.appendChild(tile);
        });
    };
    window.removeAttachmentIndex = function(index) {
        if (profileSending) return;
        selectedFilesArray.splice(index,1);
        renderAttachmentPreviews();
    };
    window.removeAttachment = function() {
        if (profileSending) return;
        selectedFilesArray = [];
        const input = document.getElementById('attachFile');
        if (input) input.value = '';
        renderAttachmentPreviews();
        const status = document.getElementById('profileSendStatus');
        if (status) status.style.display = 'none';
    };

    window.toggleEmoji = function() { let p = document.getElementById('emojiPicker'); p.style.display = p.style.display === 'grid' ? 'none' : 'grid'; }
    window.insertEmoji = function(emoji) { let input = document.getElementById('msgInput'); if (input) { input.value += emoji; toggleEmoji(); input.focus(); } }

    window.handleInput = function(el) {
        el.style.height = '20px'; let newHeight = el.scrollHeight;
        if (newHeight > 100) newHeight = 100; el.style.height = newHeight + 'px'; handleSlashMenu(el.value);
    }

    function handleSlashMenu(val) {
        let popup = document.getElementById('slashCommands');
        if (val.startsWith('//')) {
            let searchVal = val.toLowerCase().replace('//', ''); popup.innerHTML = ''; let hasItems = false;
            if (cachedTemplates && cachedTemplates.length > 0) {
                let filtered = cachedTemplates.filter(t => t.name.toLowerCase().includes(searchVal));
                filtered.forEach(template => {
                    popup.innerHTML += `<div class="slash-item" onmousedown="event.preventDefault(); sendTemplate('${template.name}');"><span class="slash-cmd"><i class="bi bi-whatsapp text-success me-1"></i> ${template.name}</span><span class="slash-text" style="white-space: normal;">Template Message</span></div>`;
                });
                hasItems = filtered.length > 0;
            } else { popup.innerHTML = `<div class="p-2 text-muted small text-center">Loading Templates...</div>`; hasItems = true; }
            popup.style.display = hasItems ? 'block' : 'none';
        } else if (val.startsWith('/')) {
            let searchVal = val.toLowerCase().replace('/', ''); popup.innerHTML = ''; let hasItems = false;
            let filtered = cannedResponses.filter(r => r.cmd.toLowerCase().includes('/'+searchVal) || r.text.toLowerCase().includes(searchVal));
            filtered.forEach(res => {
                popup.innerHTML += `<div class="slash-item" onmousedown="event.preventDefault(); applyMacroCommand('${res.cmd}');"><span class="slash-cmd">${res.cmd}</span><span class="slash-text" style="white-space: normal; padding-top: 4px; color: #555;">${res.text.length > 150 ? res.text.substring(0, 150) + '...' : res.text}</span></div>`;
            });
            hasItems = filtered.length > 0; popup.style.display = hasItems ? 'block' : 'none';
        } else { popup.style.display = 'none'; }
    }

    window.handleKeydown = function(e) { let popup = document.getElementById('slashCommands'); if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (popup.style.display !== 'block') { sendMessage(); } } }

    window.applyMacroCommand = function(cmd) {
        let macro = cannedResponses.find(m => m.cmd === cmd);
        if(macro) {
            let input = document.getElementById('msgInput'); input.value = macro.text; document.getElementById('slashCommands').style.display = 'none'; input.focus();
            input.style.height = '20px'; let newHeight = input.scrollHeight; if (newHeight > 100) newHeight = 100; input.style.height = newHeight + 'px';
        }
    }

    window.sendTemplate = function(name) {
        fetch(`${baseUrl}inbox/send_message`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversation_id: activeConvoId, message: "[Template: "+name+"]", is_template: 1, template_name: name })
        }).then(r => r.json()).then(data => { if(data.status === 'error') { alert(data.message); } else { document.getElementById('msgInput').value = ''; document.getElementById('slashCommands').style.display = 'none'; fetchMessages(activeConvoId); } });
    }

    window.toggleInternalNote = function() {
        isInternalNote = !isInternalNote; let input = document.getElementById('msgInput'); let btn = document.getElementById('internalToggleBtn'); let wrapper = document.getElementById('inputWrapper');
        if(isInternalNote) { wrapper.style.backgroundColor = '#fff3cd'; btn.classList.remove('text-secondary'); btn.classList.add('text-warning'); input.placeholder = "Type an internal note (hidden from customer)..."; input.oninput = function() { handleInput(this); }; 
        } else { wrapper.style.backgroundColor = '#fff'; btn.classList.remove('text-warning'); btn.classList.add('text-secondary'); check24HourWindow(currentChatData.created_at); }
    }

    // First customer message: show actual clicked ad creative, not an unrelated video.
    // Uses Inbox's read-only Meta Ad lookup + official preview fallback.
    let profileFirstCustomerMessageId = null;
    const profileAdCreativeCache = new Map();
    function profileAdSafeUrl(raw, allowMetaPreview=false) {
        try {
            const url = new URL(String(raw || ''));
            if (url.protocol !== 'https:') return '';
            if (allowMetaPreview &&
                (!['www.facebook.com','facebook.com','business.facebook.com'].includes(url.hostname) ||
                 url.pathname !== '/ads/api/preview_iframe.php')) return '';
            return url.href;
        } catch (_) { return ''; }
    }
    function profileAdLoad(slot) {
        if (!slot || !slot.isConnected || !metaAdName.trim()) return;
        if (slot.dataset.mediaLoaded === '1') return;
        slot.dataset.mediaLoaded = '1';
        const name = metaAdName.trim();
        let req = profileAdCreativeCache.get(name);
        if (!req) {
            const params = new URLSearchParams({ad_name:name});
            req = fetch(`${baseUrl}inbox/get_meta_ad_media?${params}`, {credentials:'same-origin'})
                .then(r => r.ok ? r.json() : {status:'unavailable',message:`HTTP ${r.status}`})
                .catch(() => ({status:'unavailable',message:'Ad media lookup unavailable'}));
            profileAdCreativeCache.set(name,req);
        }
        req.then(media => {
            if (!slot.isConnected) return;
            slot.replaceChildren();
            if (!media || media.status !== 'success' || !(media.thumbnail_url || media.video_url)) {
                const info = document.createElement('small');
                info.textContent = 'Original ad preview unavailable';
                info.title = (media && media.message) || 'Ad creative not available';
                slot.appendChild(info); return;
            }
            const button = document.createElement('button');
            button.type = 'button'; button.className = 'crm-profile-ad-open';
            if (media.thumbnail_url && profileAdSafeUrl(media.thumbnail_url)) {
                const img = document.createElement('img');
                img.src = profileAdSafeUrl(media.thumbnail_url);
                img.loading = 'lazy'; img.alt = 'Clicked ad thumbnail';
                button.appendChild(img);
            }
            const label = document.createElement('span');
            label.textContent = media.kind === 'video' ? '▶ View ad video' : 'View ad image';
            button.appendChild(label);
            button.addEventListener('click', () => profileAdOpen(media));
            slot.appendChild(button);
        });
    }
    function profileAdOpen(media) {
        const modal = document.getElementById('profileAdMediaModal');
        const body = document.getElementById('profileAdMediaModalBody');
        if (!modal || !body || !window.bootstrap) return;
        const instance = window.bootstrap.Modal.getOrCreateInstance(modal);
        const seq = Number(modal.dataset.requestSeq || 0) + 1;
        modal.dataset.requestSeq = String(seq);
        body.replaceChildren();
        document.getElementById('profileAdMediaModalTitle').textContent =
            media.kind === 'video' ? 'Original Meta Ad Video' : 'Original Meta Ad Image';
        if (modal.dataset.cleanupInstalled !== '1') {
            modal.dataset.cleanupInstalled = '1';
            modal.addEventListener('hidden.bs.modal',() => {
                modal.dataset.requestSeq = String(Number(modal.dataset.requestSeq || 0)+1);
                const video = body.querySelector('video');
                if (video) video.pause();
                body.replaceChildren(); // also stop preview iframe
            });
        }
        instance.show();
        if (media.kind !== 'video') {
            const url = profileAdSafeUrl(media.thumbnail_url);
            if (url) { const img=document.createElement('img'); img.src=url; img.alt='Ad image'; body.appendChild(img); }
            else body.textContent='Ad image unavailable';
            return;
        }
        const direct = profileAdSafeUrl(media.video_url);
        if (direct) {
            const video=document.createElement('video');
            video.controls=true; video.autoplay=true; video.playsInline=true; video.preload='metadata';
            video.src=direct;
            video.poster=profileAdSafeUrl(media.thumbnail_url);
            video.onerror=()=> { const msg=document.createElement('p');
                msg.textContent='Meta video URL expired or playback blocked. Reopen the preview.'; body.appendChild(msg); };
            body.appendChild(video); return;
        }
        const loading=document.createElement('p');
        loading.textContent='Loading official Meta ad preview…'; body.appendChild(loading);
        fetch(`${baseUrl}inbox/get_meta_ad_media?${new URLSearchParams({ad_id:String(media.ad_id||''),preview:'1'})}`,{credentials:'same-origin'})
            .then(r=>r.ok?r.json():{status:'unavailable',message:'Preview HTTP '+r.status})
            .then(preview=>{
                if (modal.dataset.requestSeq!==String(seq) || !modal.classList.contains('show')) return;
                body.replaceChildren();
                const url=preview && preview.status==='success' ? profileAdSafeUrl(preview.preview_url,true) : '';
                if (url) {
                    const iframe=document.createElement('iframe');
                    iframe.title='Original Meta Ad Video'; iframe.src=url;
                    iframe.allow='autoplay; encrypted-media; fullscreen; picture-in-picture';
                    iframe.allowFullscreen=true;
                    iframe.style.cssText='width:100%;height:min(65dvh,600px);min-height:330px;border:0;border-radius:8px;';
                    body.appendChild(iframe);
                    const external=document.createElement('a');
                    external.href=url; external.target='_blank'; external.rel='noopener noreferrer';
                    external.className='btn btn-sm btn-outline-primary mt-2';
                    external.textContent='Open Meta preview in new tab'; body.appendChild(external);
                } else {
                    const imgUrl=profileAdSafeUrl(media.thumbnail_url);
                    if (imgUrl) {const img=document.createElement('img'); img.src=imgUrl; img.alt='Ad thumbnail'; body.appendChild(img);}
                    const note=document.createElement('p'); note.className='text-muted small mt-2';
                    note.textContent=(preview && preview.message) || 'Meta did not provide playable ad preview';
                    body.appendChild(note);
                }
            }).catch(()=>{
                if (modal.dataset.requestSeq===String(seq)) loading.textContent='Unable to load Meta preview';
            });
    }

    // Fast profile chat: first page is recent 80; older messages load while scrolling up.
    // Polls fetch only messages after the latest rendered ID. No full-history reload loop.
    const profileHistoryUrl = `${baseUrl}leadprofile/chat_history/${activeLeadId}`;
    let profileOldestId = null;
    let profileNewestId = null;
    let profileMoreOlder = false;
    let profileLoading = false;
    let profileInitialLoaded = false;
    let profilePendingRefresh = false;
    const profileSeenIds = new Set();
    const profileByWaId = new Map();
    let profileLastCustomerAt = null;

    function profileEscape(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
            '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
        })[c]);
    }
    function profileSafeMediaUrl(value) {
        const url = String(value || '').trim();
        return /^(https?:\/\/|\/(?!\/))/i.test(url) ? url : '';
    }
    function profileQuoteMarkup(msg) {
        const refId = msg.reply_to_wa_message_id;
        if (!refId) return '';
        const original = msg.quoted_reference || profileByWaId.get(String(refId));
        if (!original) return '<div class="crm-quote-unavailable">Reply to earlier message</div>';
        const url = profileSafeMediaUrl(original.media_url);
        const kind = String(original.message_type || '');
        const mime = String(original.mime_type || '');
        const isImage = !!url && (kind === 'image' || mime.startsWith('image/'));
        const label = isImage ? 'Photo' : (kind === 'video' ? 'Video' :
            (kind === 'document' ? 'Document' : (original.message_body || 'Message')));
        const from = original.sender_type === 'agent' ? 'SCPK / Agent' : 'Customer';
        const thumb = isImage ? `<img class="crm-quote-thumb" src="${profileEscape(url)}" loading="lazy" alt="Quoted photo">` : '';
        return `<button type="button" class="crm-quote-link" data-quoted-target="${profileEscape(refId)}" data-quoted-id="${profileEscape(original.id || '')}">
            <span class="crm-quote-copy"><strong>${profileEscape(from)}</strong><span>${profileEscape(String(label).slice(0,100))}</span></span>${thumb}</button>`;
    }
    function profileRenderBubble(msg) {
        const isSent = msg.sender_type === 'agent';
        const rawText = String(msg.message_body || '').replace(/\s+$/g, '');
        const isInternal = msg.is_internal == 1 || (isSent && rawText.startsWith('[INTERNAL]'));
        const displayText = (isInternal && rawText.startsWith('[INTERNAL]'))
            ? rawText.replace('[INTERNAL]', '').trim() : rawText;
        const date = crmParseUtcMessageTimestamp(msg.created_at);
        const timeStr = Number.isNaN(date.getTime()) ? '--:--' : crmProfileMessageTime.format(date).toUpperCase();
        const hoverDate = Number.isNaN(date.getTime()) ? '-' : crmProfileMessageDate.format(date);
        const hoverTime = Number.isNaN(date.getTime()) ? '-' : crmProfileMessageFullTime.format(date).toUpperCase();
        let sender = isSent ? (msg.agent_name || currentChatData.current_agent || 'Agent') : contactName;
        if (rawText.startsWith('[Bot]')) sender = 'SCPK Bot';
        const tooltip = `Sent by: ${sender}\nDate: ${hoverDate}\nTime: ${hoverTime}`;
        const cls = isSent ? (isInternal ? 'msg-internal' : 'msg-sent') : 'msg-received';
        const wrapperCls = isSent ? 'msg-wrapper-sent' : 'msg-wrapper-received';
        let ticks = '';
        if (isSent) {
            if (isInternal) ticks = '<i class="bi bi-lock-fill text-muted ms-1"></i>';
            else if (msg.delivery_status === 'read') ticks = '<i class="bi bi-check2-all text-primary ms-1"></i>';
            else if (msg.delivery_status === 'delivered') ticks = '<i class="bi bi-check2-all text-muted ms-1"></i>';
            else ticks = '<i class="bi bi-check2 text-muted ms-1"></i>';
        }
        const mediaUrl = profileSafeMediaUrl(msg.media_url);
        const mime = String(msg.mime_type || '');
        let mediaHtml = '';
        if (mediaUrl) {
            const url = profileEscape(mediaUrl);
            if (mime.includes('video') || msg.message_type === 'video') mediaHtml = `<div class="mb-1"><video controls preload="none" style="max-width:100%; max-height:250px; border-radius:6px;"><source src="${url}" type="${profileEscape(mime || 'video/mp4')}"></video></div>`;
            else if (mime.includes('audio')) mediaHtml = `<div class="mb-1"><audio controls preload="none" style="max-width:250px;"><source src="${url}" type="${profileEscape(mime)}"></audio></div>`;
            else if (mime.includes('pdf') || mime.includes('document')) mediaHtml = `<div class="mb-1"><a href="${url}" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-light border w-100">Download Document</a></div>`;
            else mediaHtml = `<div class="mb-1"><img src="${url}" loading="lazy" data-profile-image="${url}" class="attachment-preview" style="max-width:100%;max-height:250px;border-radius:6px;display:block;object-fit:cover;"></div>`;
        }
        const waId = String(msg.wa_message_id || '');
        const replyId = waId.startsWith('wamid.') ? waId : '';
        const replyHtml = replyId ? `<button type="button" class="reply-action-btn" data-profile-reply="${profileEscape(replyId)}" title="Reply" style="border:0;"><i class="bi bi-reply-fill"></i></button>` : '';
        const wrapper = document.createElement('div');
        wrapper.className = `msg-wrapper ${wrapperCls} msg-hover-wrap position-relative`;
        wrapper.dataset.profileMessageId = String(msg.id);
        wrapper.dataset.waMessageId = waId;
        const originalAd = !isSent && metaAdName.trim() &&
            profileFirstCustomerMessageId !== null && String(msg.id) === String(profileFirstCustomerMessageId)
                ? `<div class="crm-profile-first-ad"><span class="crm-profile-first-ad-title">Ad clicked · Original creative</span><span data-profile-ad-creative="1">Loading ad preview…</span></div>` : '';
        wrapper.innerHTML = `${isSent ? replyHtml : ''}<div class="msg-bubble ${cls}" title="${profileEscape(tooltip)}">
            ${profileQuoteMarkup(msg)}${mediaHtml}${originalAd}<span class="msg-text">${profileEscape(displayText)}</span><span class="msg-time">${profileEscape(timeStr)} ${ticks}</span>
            </div>${!isSent ? replyHtml : ''}`;
        return wrapper;
    }
    function profileOlderControl() {
        const box = document.getElementById('messageContainer');
        if (!box) return;
        let btn = document.getElementById('profileLoadOlder');
        if (profileMoreOlder) {
            if (!btn) {
                btn = document.createElement('button');
                btn.type = 'button'; btn.id = 'profileLoadOlder';
                btn.className = 'crm-profile-older'; btn.textContent = '↑ Load earlier messages';
                btn.addEventListener('click', () => profileLoadHistory('older'));
                box.insertBefore(btn, box.firstChild);
            }
            btn.disabled = profileLoading;
        } else if (btn) btn.remove();
    }
    function profileAppendMessages(messages, mode) {
        const box = document.getElementById('messageContainer');
        if (!box) return;
        const wasAtBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
        const oldHeight = box.scrollHeight;
        const oldTop = box.scrollTop;
        for (const msg of messages) {
            if (msg.wa_message_id) profileByWaId.set(String(msg.wa_message_id), msg);
        }
        const fragment = document.createDocumentFragment();
        for (const msg of messages) {
            const id = Number(msg.id);
            if (!Number.isFinite(id) || profileSeenIds.has(id)) continue;
            profileSeenIds.add(id);
            profileOldestId = profileOldestId === null ? id : Math.min(profileOldestId, id);
            profileNewestId = profileNewestId === null ? id : Math.max(profileNewestId, id);
            fragment.appendChild(profileRenderBubble(msg));
        }
        if (mode === 'older') {
            const button = document.getElementById('profileLoadOlder');
            box.insertBefore(fragment, button ? button.nextSibling : box.firstChild);
            box.scrollTop = oldTop + (box.scrollHeight - oldHeight);
        } else {
            box.appendChild(fragment);
            if (mode === 'initial' || wasAtBottom) {
                // CSS smooth scrolling of thousands of pixels is slow; use instant positioning.
                const oldBehavior = box.style.scrollBehavior;
                box.style.scrollBehavior = 'auto';
                box.scrollTop = box.scrollHeight;
                box.style.scrollBehavior = oldBehavior;
            }
        }
        box.querySelectorAll('[data-profile-ad-creative]:not([data-media-loaded])').forEach(profileAdLoad);
    }
    async function profileLoadHistory(mode = 'new') {
        if (profileLoading) { if (mode === 'new') profilePendingRefresh = true; return; }
        if (mode === 'older' && (!profileMoreOlder || profileOldestId === null)) return;
        if (mode === 'new' && !profileInitialLoaded) return;
        if (mode === 'new' && profileNewestId === null) mode = 'initial';
        if (mode === 'new' && document.hidden) return;
        profileLoading = true;
        const box = document.getElementById('messageContainer');
        profileOlderControl();
        try {
            const query = mode === 'older' ? `?before=${profileOldestId}` :
                          mode === 'new' ? `?after=${profileNewestId || 0}` : '';
            const response = await fetch(profileHistoryUrl + query, {
                credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json' }
            });
            if (!response.ok) throw new Error('HTTP ' + response.status);
            const result = await response.json();
            if (result.status !== 'success' || !Array.isArray(result.messages))
                throw new Error(result.message || 'Unexpected chat data');
            if (result.conversation_id && String(result.conversation_id) !== String(activeConvoId)) {
                // Index and endpoint agree on the newest conversation. Never mix messages from two chats.
                activeConvoId = Number(result.conversation_id);
                profileSeenIds.clear(); profileByWaId.clear();
                profileOldestId = null; profileNewestId = null;
                profileInitialLoaded = false;
                if (box) box.innerHTML = '';
                profileLoading = false;
                await profileLoadHistory('initial');
                return;
            }
            if (mode === 'initial' && box) box.innerHTML = '';
            if (mode === 'initial') profileFirstCustomerMessageId = result.first_customer_message_id || null;
            const rows = result.messages;
            profileAppendMessages(rows, mode);
            if (mode === 'initial' || mode === 'older') profileMoreOlder = Boolean(result.has_more);
            if (mode === 'initial') profileInitialLoaded = true;
            if (result.last_customer_at) profileLastCustomerAt = result.last_customer_at;
            check24HourWindow(profileLastCustomerAt);
            if (mode === 'initial' && rows.length === 0 && box)
                box.innerHTML = '<div class="text-center text-muted mt-5">No messages yet. Send a template to start.</div>';
            if (mode === 'new' && result.has_more) profilePendingRefresh = true;
        } catch (error) {
            if (mode === 'initial' && box) {
                box.innerHTML = '<div class="crm-profile-chat-error">Chat load failed. <button type="button" class="btn btn-sm btn-outline-dark" id="profileRetry">Retry</button></div>';
                const retry = document.getElementById('profileRetry');
                if (retry) retry.addEventListener('click', () => profileLoadHistory('initial'));
            }
            console.error('Profile chat loading failed:', error);
        } finally {
            profileLoading = false;
            profileOlderControl();
            if (profilePendingRefresh) {
                profilePendingRefresh = false;
                if (profileInitialLoaded && !document.hidden) profileLoadHistory('new');
            }
        }
    }
    // Existing send-template and send-message flows continue calling fetchMessages().
    function fetchMessages(convoId) {
        if (convoId && String(convoId) !== String(activeConvoId)) return;
        return profileLoadHistory(profileInitialLoaded ? 'new' : 'initial');
    }
    function profileChatHandlers() {
        const box = document.getElementById('messageContainer');
        if (!box || box.dataset.profileHandlers === '1') return;
        box.dataset.profileHandlers = '1';
        box.addEventListener('click', function(event) {
            const image = event.target.closest('[data-profile-image]');
            if (image && box.contains(image)) { openImagePopup(image.dataset.profileImage); return; }
            const quote = event.target.closest('[data-quoted-target]');
            if (quote && box.contains(quote)) {
                event.preventDefault();
                // Do not keep focus on a quote button while older pages are prepended.
                // Browser focus scrolling could shift the fixed CRM header.
                quote.blur();
                const id = quote.dataset.quotedTarget;
                const goToOriginal = async () => {
                    let original = Array.from(box.querySelectorAll('[data-wa-message-id]'))
                        .find(el => el.dataset.waMessageId === id);
                    const quotedDbId = Number(quote.dataset.quotedId || 0);
                    // Reply may reference a catalog image older than the latest 80 messages.
                    // Load only as many earlier pages as needed, with an upper bound per click.
                    let attempts = 0;
                    while (!original && profileMoreOlder && attempts < 12 &&
                           (!quotedDbId || profileOldestId > quotedDbId)) {
                        const cursor = profileOldestId;
                        await profileLoadHistory('older');
                        if (profileOldestId === cursor) break;
                        original = Array.from(box.querySelectorAll('[data-wa-message-id]'))
                            .find(el => el.dataset.waMessageId === id);
                        attempts++;
                    }
                    if (original) {
                        // scrollIntoView scrolls ALL scrollable ancestors, including the
                        // document. That was moving the header and columns off-screen.
                        // Compute the target solely relative to #messageContainer.
                        const boxRect = box.getBoundingClientRect();
                        const targetRect = original.getBoundingClientRect();
                        const position = box.scrollTop + targetRect.top - boxRect.top
                            - Math.max(0, (box.clientHeight - targetRect.height) / 2);
                        const maxScroll = Math.max(0, box.scrollHeight - box.clientHeight);
                        const top = Math.max(0, Math.min(maxScroll, position));
                        const reduceMotion = window.matchMedia &&
                            window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                        box.scrollTo({top: top, behavior: reduceMotion ? 'auto' : 'smooth'});
                        original.classList.add('crm-quote-highlight');
                        setTimeout(() => original.classList.remove('crm-quote-highlight'), 2000);
                    } else if (profileMoreOlder) {
                        const button = document.getElementById('profileLoadOlder');
                        if (button) button.focus({preventScroll:true});
                    }
                };
                goToOriginal();
                return;
            }
            const reply = event.target.closest('[data-profile-reply]');
            if (reply && box.contains(reply)) {
                const msg = profileByWaId.get(reply.dataset.profileReply);
                if (msg) {
                    let name = msg.sender_type === 'agent' ? 'SCPK / Agent' : contactName;
                    setReply(reply.dataset.profileReply, name, String(msg.message_body || ''));
                }
            }
        });
        box.addEventListener('scroll', function() {
            if (profileMoreOlder && profileInitialLoaded && !profileLoading && box.scrollTop < 75)
                profileLoadHistory('older');
        }, {passive:true});
    }

    window.sendMessage = async function() {
        const input = document.getElementById('msgInput');
        const text = input.value.trim();
        if (profileSending || (!text && !selectedFilesArray.some(f=>f.state==='ready')) || !activeConvoId) return;
        const isTemp = text.match(/^\[Template:\s*(.+?)\]$/i);
        if (isWindowClosed && !isTemp && !isInternalNote) {
            alert('WhatsApp Policy: The messaging window is closed! You can only send templates.');
            return;
        }
        const unconfirmed = selectedFilesArray.filter(f=>f.state==='uncertain').length;
        if (unconfirmed) {
            // Do not silently resend an ambiguous timeout; Meta may already have delivered.
            alert(`${unconfirmed} photo(s) have unconfirmed status. Check WhatsApp before removing and selecting them again.`);
        }
        const ready = selectedFilesArray.filter(f=>f.state==='ready');
        if (!ready.length && !text) return;
        profileSending = true;
        const status = document.getElementById('profileSendStatus');
        const sendBtn = document.getElementById('sendBtn');
        if (sendBtn) sendBtn.disabled = true;
        const replyTo = document.getElementById('replyToMessageId').value;
        let successful=0, rejected=0, uncertain=0, firstCaptionSent=false, firstReplySent=false;
        const filesToSend = ready.length ? ready : [null];
        renderAttachmentPreviews();
        try {
            for (let index=0; index<filesToSend.length; index++) {
                const file = filesToSend[index];
                status.style.display='block';
                status.textContent = `Sending ${index+1} / ${filesToSend.length}… ${successful} accepted, ${rejected} rejected, ${uncertain} unconfirmed`;
                const payload = {
                    conversation_id:activeConvoId,
                    message:firstCaptionSent?'':text,
                    is_internal:isInternalNote?1:0,
                    attachment_base64:file?file.data:null,
                    reply_to_message_id:firstReplySent?'':replyTo
                };
                try {
                    const response = await fetch(`${baseUrl}inbox/send_message`,{
                        method:'POST',credentials:'same-origin',
                        headers:{'Content-Type':'application/json'},
                        body:JSON.stringify(payload)
                    });
                    let result;
                    try { result=await response.json(); }
                    catch (_) { throw new Error('Non-JSON server response'); }
                    if (!response.ok || !result || result.status !== 'success') {
                        rejected++;
                        if (file) {file.state='error';file.error=(result&&result.message)||'Request rejected';}
                        else alert('Send failed: '+((result&&result.message)||'Server rejected'));
                        continue;
                    }
                    successful++;
                    if (text && !firstCaptionSent) {firstCaptionSent=true;input.value='';input.style.height='auto';}
                    if (file) {
                        const pos = selectedFilesArray.indexOf(file);
                        if (pos !== -1) selectedFilesArray.splice(pos,1);
                    }
                    if (replyTo && !firstReplySent) { firstReplySent=true; closeReply(); }
                    await fetchMessages(activeConvoId);
                } catch (error) {
                    // Unknown network error is NOT safe to retry automatically.
                    uncertain++;
                    if (file) {file.state='uncertain';file.error=String(error.message||error);}
                    else alert('Send result unconfirmed. Check WhatsApp before retrying.');
                }
                renderAttachmentPreviews();
                // Small per-recipient gap avoids firing a multi-photo burst in one instant.
                // This improves reliability but does not guarantee Meta delivery.
                if (file && index < filesToSend.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1200));
                }
            }
        } finally {
            profileSending=false;
            if(sendBtn) sendBtn.disabled=false;
            renderAttachmentPreviews();
            status.style.display='block';
            status.textContent = `Finished: ${successful} accepted, ${rejected} rejected, ${uncertain} unconfirmed. Meta acceptance is not final delivery.`;
            // Retain text if no request was successful. Never discard rejected attachments.
            if(successful && isInternalNote) toggleInternalNote();
            if(successful) fetchMessages(activeConvoId);
        }
    };

    function initProfileChat() {
        document.getElementById('emojiPicker').innerHTML = emojis.map(e => `<span class="emoji-btn" onclick="insertEmoji('${e}')">${e}</span>`).join('');
        profileChatHandlers();
        // Profile-specific history endpoint also handles an absent/stale conversation id.
        profileLoadHistory('initial');
        // Incremental checks only; no full history downloads on each poll.
        setInterval(() => { if (profileInitialLoaded && !document.hidden) profileLoadHistory('new'); }, 8000);
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && profileInitialLoaded) profileLoadHistory('new');
        });

        fetch(`${baseUrl}leadprofile/get_macros`).then(r => r.json()).then(res => { if(res.status === 'success' && res.data) { cannedResponses = res.data; } }).catch(e => {});
        fetch(`${baseUrl}inbox/get_templates`).then(res => res.json()).then(json => { if (json.data && json.data.length > 0) { cachedTemplates = json.data.filter(t => t.status === 'APPROVED'); } }).catch(e => {});
        
        if (document.getElementById('tabTasksBtn').classList.contains('active')) { loadTasks(); }
    }

    document.addEventListener("DOMContentLoaded", initProfileChat);
    </script>
</body> 
</html>