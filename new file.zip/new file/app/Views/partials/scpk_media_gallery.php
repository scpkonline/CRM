<?php // Reusable SCPK Media Library popup. Include once on any CRM chat page. ?>
<!-- Private SCPK media gallery; independent overlay so it can open over the template modal. -->
        <div id="scpkGalleryOverlay" class="scpk-gallery-overlay" hidden role="dialog" aria-modal="true" aria-label="SCPK Media Library">
            <div class="scpk-gallery-dialog">
                <header class="scpk-gallery-header">
                    <div><h5 class="mb-1">Media Library</h5><small id="scpkGalleryHint">Uploaded images and videos</small></div>
                    <button type="button" class="btn-close" aria-label="Close gallery" onclick="scpkMediaLibraryClose()"></button>
                </header>
                <div class="scpk-gallery-toolbar">
                    <input class="form-control form-control-sm" id="scpkGallerySearch" placeholder="Search media" oninput="scpkMediaLibraryRender()">
                    <select class="form-select form-select-sm" id="scpkGalleryFilter" onchange="scpkMediaLibraryRender()"><option value="all">All media</option><option value="image">Images</option><option value="video">Videos</option></select>
                    <input id="scpkGalleryUploadInput" type="file" accept="image/jpeg,image/png,video/mp4" class="form-control form-control-sm" aria-label="Choose JPG, PNG or MP4 file">
                    <button type="button" class="btn btn-primary btn-sm" id="scpkGalleryUploadBtn" onclick="scpkMediaLibraryUpload()">Upload</button>
                </div>
                <div id="scpkGalleryMessage" class="small px-3 py-2" role="status" aria-live="polite">Choose JPG/PNG (max 5MB) or MP4 (max 16MB).</div>
                <div id="scpkGalleryGrid" class="scpk-gallery-grid"></div>
                <footer class="scpk-gallery-footer">
                    <span id="scpkGallerySelection" class="small text-muted">No media selected</span>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-secondary btn-sm" onclick="scpkMediaLibraryClose()">Close</button>
                        <button type="button" class="btn btn-success btn-sm" id="scpkGalleryUseBtn" onclick="scpkMediaLibraryUseSelected()" disabled>Use selected media</button>
                    </div>
                </footer>
            </div>
        </div>
