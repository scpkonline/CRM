<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Team Management') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    
    <!-- Dark Theme Support -->
    <script>
        if (document.cookie.includes('theme=dark')) {
            document.documentElement.classList.add('dark-theme');
        }
    </script>
    
    <style>          
        body { 
            background-color: #f8fafc; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif; 
            overflow-x: hidden; 
            color: #334155; 
        }                  
        
        .main-content { 
            margin-left: 250px; 
            padding: 30px 40px; 
            transition: all 0.3s ease; 
            min-height: 100vh; 
        }          
        
        .main-content.expanded { 
            margin-left: 80px; 
        }
        
        /* Sleek Page Header */
        .page-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 25px; 
        }
        .page-title { 
            margin: 0; 
            font-size: 22px; 
            font-weight: 600; 
            color: #0f172a; 
            letter-spacing: -0.5px; 
        }
        .user-profile { 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            color: #475569; 
            font-size: 13px; 
            font-weight: 500; 
        }
        .avatar-circle { 
            width: 36px; 
            height: 36px; 
            background: #3b82f6; 
            color: #fff; 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-weight: bold; 
            font-size: 14px; 
            text-transform: uppercase;
        }

        /* Settings Layout */
        .settings-container { 
            display: flex; 
            gap: 25px; 
            align-items: flex-start; 
        }
        
        /* Left Menu Tab */
        .settings-menu { 
            width: 260px; 
            background: #fff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.02); 
            padding: 10px 0; 
            flex-shrink: 0; 
        }
        .menu-item { 
            display: flex; 
            align-items: center; 
            padding: 12px 20px; 
            color: #475569; 
            text-decoration: none; 
            font-weight: 500; 
            font-size: 14px; 
            border-left: 3px solid transparent; 
            transition: 0.2s; 
        }
        .menu-item:hover { 
            background-color: #f8fafc; 
            color: #3b82f6; 
        }
        .menu-item.active { 
            background-color: #eff6ff; 
            color: #3b82f6; 
            border-left-color: #3b82f6; 
            font-weight: 600; 
        }
        .menu-item i { 
            font-size: 18px; 
            margin-right: 12px; 
            width: 20px; 
            text-align: center;
        }

        /* Right Content Panel */
        .settings-panel { 
            flex-grow: 1; 
            background: #fff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.02); 
            overflow: hidden; 
        }
        .panel-header { 
            padding: 20px 30px; 
            border-bottom: 1px solid #e2e8f0; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            background: #fff; 
        }
        .panel-title { 
            margin: 0; 
            font-size: 18px; 
            font-weight: 600; 
            color: #0f172a; 
        }
        
        .btn-add { 
            background: #3b82f6; 
            color: #fff; 
            border: none; 
            border-radius: 6px; 
            padding: 8px 16px; 
            font-size: 13px; 
            font-weight: 600; 
            display: flex; 
            align-items: center; 
            gap: 6px; 
            transition: all 0.2s; 
        }
        .btn-add:hover { 
            background: #2563eb; 
            color: #fff; 
        }

        .table { margin-bottom: 0; }
        .table th { 
            background-color: #f8fafc; 
            color: #475569; 
            font-weight: 600; 
            font-size: 12px; 
            padding: 14px 30px; 
            border-bottom: 1px solid #e2e8f0; 
            text-transform: uppercase; 
            letter-spacing: 0.5px; 
            border-top: none; 
            white-space: nowrap;
        }
        .table td { 
            vertical-align: middle; 
            padding: 16px 30px; 
            border-bottom: 1px solid #f1f5f9; 
            font-size: 14px; 
            color: #334155; 
            white-space: nowrap;
        }
        .table tbody tr:hover { background-color: #f8fafc; }
        
        .role-badge { font-size: 11px; padding: 4px 10px; border-radius: 4px; font-weight: 700; }
        .role-admin { background-color: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
        .role-sales { background-color: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; }
        
        .leads-badge { background-color: #f1f5f9; color: #475569; font-size: 11px; padding: 4px 10px; border-radius: 4px; font-weight: 600; border: 1px solid #e2e8f0; }
        
        /* Edit Button */
        .btn-edit { color: #3b82f6; border: 1px solid #3b82f6; background: transparent; padding: 4px 16px; border-radius: 4px; font-size: 12px; font-weight: 600; transition: 0.2s; }
        .btn-edit:hover { background: #3b82f6; color: #fff; }

        /* Premium Rules Button (Indigo) */
        .btn-rule { color: #4f46e5; border: 1px solid #4f46e5; background: transparent; padding: 4px 16px; border-radius: 4px; font-size: 12px; font-weight: 600; transition: 0.2s; }
        .btn-rule:hover { background: #4f46e5; color: #fff; }

        /* Premium Toggle Switch Color */
        .form-check-input:checked { background-color: #4f46e5; border-color: #4f46e5; }

        /* Mobile specific hamburger button */
        .settings-mobile-toggle {
            display: none;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px 20px;
            font-weight: 600;
            color: #0f172a;
            cursor: pointer;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
                margin-top: 70px !important;
                padding: 15px !important;
            }
            .settings-container {
                flex-direction: column;
                gap: 15px;
            }
            .settings-menu {
                width: 100%; 
                border: none;
                box-shadow: none;
                background: transparent;
                padding: 0;
            }
            .settings-mobile-toggle {
                display: flex;
            }
            .settings-nav-links {
                display: none;
                background: #fff;
                border-radius: 8px;
                border: 1px solid #e2e8f0;
                margin-top: 8px;
                overflow: hidden;
                box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            }
            .settings-nav-links.show {
                display: block;
            }
            .settings-panel {
                width: 100%; 
            }
            .panel-header {
                padding: 15px;
            }
            .table-responsive {
                border-top: 1px solid #e2e8f0;
            }
            .btn-add span {
                display: none;
            }
        }

        /* Dark Theme CSS Overrides */
        html.dark-theme body { background-color: #121212 !important; color: #e0e0e0 !important; }
        html.dark-theme .card, html.dark-theme .bg-white, html.dark-theme .settings-menu, html.dark-theme .settings-panel, html.dark-theme .panel-header, html.dark-theme .main-content, html.dark-theme .settings-nav-links, html.dark-theme .settings-mobile-toggle { background-color: #1e1e1e !important; border-color: #333 !important; color: #e0e0e0 !important; }
        html.dark-theme .table th { background-color: #252525 !important; color: #a0aab5 !important; border-color: #333 !important; }
        html.dark-theme .table td { border-color: #2a2a2a !important; color: #e0e0e0 !important; }
        html.dark-theme .table tbody tr:hover { background-color: #282828 !important; }
        html.dark-theme .menu-item { color: #e0e0e0 !important; }
        html.dark-theme .menu-item:hover, html.dark-theme .menu-item.active { background-color: #2d2d2d !important; color: #60a5fa !important; border-color: #333 !important; }
        html.dark-theme .panel-title { color: #fff !important; }
    </style> 
</head> 
<body>     
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content" id="mainContent">         
        
        <!-- Page Header -->
        <div class="page-header d-none">
            <h2 class="page-title">Settings</h2>
            <div class="user-profile">
                <span>Logged in as <strong><?= htmlspecialchars($user_name ?? 'User') ?></strong> <span class="badge bg-secondary ms-1"><?= htmlspecialchars($user_role ?? 'SALES') ?></span></span>
                <div class="avatar-circle"><?= substr($user_name ?? 'U', 0, 1) ?></div>
            </div>
        </div>

        <?php if(isset($_SESSION['success_msg'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success_msg'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['success_msg']); ?>
        <?php endif; ?>

        <?php if(isset($_SESSION['error_msg'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $_SESSION['error_msg'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['error_msg']); ?>
        <?php endif; ?>

        <div class="settings-container">
            <!-- Left Navigation (With Mobile Toggle) -->
            <div class="settings-menu">
                <!-- Visible only on Mobile -->
                <div class="settings-mobile-toggle" onclick="toggleSettingsMenu()">
                    <span><i class="bi bi-gear text-primary me-2"></i> Settings Menu</span>
                    <i class="bi bi-list fs-5 text-secondary"></i>
                </div>

                <!-- Synchronized Navigation Links -->
                <div class="settings-nav-links" id="settingsNavLinks">
                    <a href="<?= BASE_URL ?>settings/profile" class="menu-item">
                        <i class="bi bi-person-badge me-2"></i> Edit Profile
                    </a>
                    
                    <?php if(($user_role ?? 'SALES') === 'ADMIN'): ?>
                    <a href="<?= BASE_URL ?>settings/team" class="menu-item active">
                        <i class="bi bi-people me-2"></i> Team Management
                    </a>
                    <a href="<?= BASE_URL ?>settings/integrations" class="menu-item">
                        <i class="bi bi-plug me-2"></i> Integrations & API
                    </a>
                    <?php endif; ?>

                    <a href="<?= BASE_URL ?>settings/notifications" class="menu-item">
                        <i class="bi bi-bell me-2"></i> Notifications
                    </a>
                    <a href="<?= BASE_URL ?>settings/preferences" class="menu-item">
                        <i class="bi bi-palette me-2"></i> Preferences
                    </a>
                </div>
            </div>

            <!-- Right Content Panel (The Table Area) -->
            <div class="settings-panel">
                <div class="panel-header">
                    <h3 class="panel-title">Sales Team Overview</h3>
                    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                        <button class="btn-add" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                            <i class="bi bi-person-plus-fill"></i> <span>Add Member</span>
                        </button>
                    <?php endif; ?>
                </div>
                
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Role</th>
                                <th>Assigned Leads</th>
                                <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                    <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($team)): ?>
                                <?php foreach($team as $member): ?>
                                    <tr>
                                        <td class="fw-bold">
                                            <i class="bi bi-person-circle text-muted me-2"></i><?= htmlspecialchars($member['name']) ?>
                                        </td>
                                        <td><?= htmlspecialchars($member['email']) ?></td>
                                        <td><?= htmlspecialchars($member['phone'] ?? 'N/A') ?></td>
                                        <td>
                                            <?php $roleClass = strtoupper($member['role']) === 'ADMIN' ? 'role-admin' : 'role-sales'; ?>
                                            <span class="role-badge <?= $roleClass ?>"><?= strtoupper($member['role']) ?></span>
                                        </td>
                                        <td><span class="leads-badge"><?= $member['assigned_leads'] ?> Leads</span></td>
                                        
                                        <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <button class="btn-edit" onclick="openEditModal(<?= $member['id'] ?>, '<?= htmlspecialchars(addslashes($member['name'])) ?>', '<?= htmlspecialchars(addslashes($member['email'])) ?>', '<?= htmlspecialchars(addslashes($member['phone'] ?? '')) ?>', '<?= strtoupper($member['role']) ?>')">Edit</button>
                                                    
                                                    <!-- PREMIUM RULE BUTTON (Hidden for Admins) -->
                                                    <?php if (strtoupper($member['role']) !== 'ADMIN'): ?>
                                                        <button class="btn-rule d-flex align-items-center gap-1" onclick="openRulesModal(<?= $member['id'] ?>, '<?= htmlspecialchars(addslashes($member['name'])) ?>', <?= $member['is_auto_assign'] ?? 1 ?>, <?= $member['daily_lead_limit'] ?? 9999 ?>, <?= $member['assign_weight'] ?? 1 ?>, <?= $member['priority_level'] ?? 1 ?>)">
                                                            <i class="bi bi-sliders"></i> Rules
                                                        </button>
                                                    <?php else: ?>
                                                        <div style="width: 80px;"></div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="<?= (($user_role ?? 'SALES') === 'ADMIN') ? '6' : '5' ?>" class="text-center py-5 text-muted">No team members found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> 

    <!-- Only render Modals if user is ADMIN -->
    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
        
        <!-- ADD MEMBER MODAL -->
        <div class="modal fade" id="addMemberModal" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content border-0 shadow">
              <form action="<?= BASE_URL ?>settings/add_team" method="POST">
                  <div class="modal-header border-bottom px-4 py-3 bg-light">
                    <h5 class="modal-title fw-bold" style="color: #1e293b; font-size: 16px;">Add New Team Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Full Name</label>
                        <input type="text" name="name" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Email Address</label>
                        <input type="email" name="email" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Phone Number</label>
                        <input type="text" name="phone" class="form-control form-control-sm">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Password</label>
                        <input type="password" name="password" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Role</label>
                        <select name="role" class="form-select form-select-sm" required>
                            <option value="SALES">Sales Executive</option>
                            <option value="ADMIN">Administrator</option>
                        </select>
                    </div>
                  </div>
                  <div class="modal-footer border-top-0 px-4 pb-4 pt-0">
                    <button type="button" class="btn btn-light btn-sm px-4 fw-bold text-secondary border" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm px-4 fw-bold text-white" style="background-color: #3b82f6; border-color: #3b82f6;">Save Member</button>
                  </div>
              </form>
            </div>
          </div>
        </div>

        <!-- EDIT MEMBER MODAL -->
        <div class="modal fade" id="editMemberModal" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content border-0 shadow">
              <form action="<?= BASE_URL ?>settings/edit_team" method="POST">
                  <input type="hidden" name="user_id" id="editUserId">
                  <div class="modal-header border-bottom px-4 py-3 bg-light">
                    <h5 class="modal-title fw-bold" style="color: #1e293b; font-size: 16px;">Edit Team Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Full Name</label>
                        <input type="text" name="name" id="editName" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Email Address</label>
                        <input type="email" name="email" id="editEmail" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Phone Number</label>
                        <input type="text" name="phone" id="editPhone" class="form-control form-control-sm">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Role</label>
                        <select name="role" id="editRole" class="form-select form-select-sm" required>
                            <option value="SALES">Sales Executive</option>
                            <option value="ADMIN">Administrator</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">New Password <small class="text-muted fw-normal">(Leave blank to keep current)</small></label>
                        <input type="password" name="password" class="form-control form-control-sm">
                    </div>
                  </div>
                  <div class="modal-footer border-top-0 px-4 pb-4 pt-0">
                    <button type="button" class="btn btn-light btn-sm px-4 fw-bold text-secondary border" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm px-4 fw-bold text-white" style="background-color: #3b82f6; border-color: #3b82f6;">Update Member</button>
                  </div>
              </form>
            </div>
          </div>
        </div>
        
        <!-- LEAD ROUTING RULES MODAL -->
        <div class="modal fade" id="rulesModal" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content border-0 shadow">
              <form action="<?= BASE_URL ?>settings/update_routing" method="POST">
                  <input type="hidden" name="user_id" id="ruleUserId">
                  
                  <div class="modal-header border-bottom px-4 py-3 bg-light">
                    <h5 class="modal-title fw-bold" style="color: #1e293b; font-size: 16px;">
                        <i class="bi bi-sliders me-2" style="color: #4f46e5;"></i>Assignment Rules: <span id="ruleUserName" style="color: #4f46e5;"></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  
                  <div class="modal-body p-4">
                    <div class="form-check form-switch mb-4 pb-4 border-bottom">
                      <input class="form-check-input" type="checkbox" id="isAutoAssign" name="is_auto_assign" style="transform: scale(1.3); margin-right: 10px; cursor: pointer;">
                      <label class="form-check-label fw-bold text-dark" for="isAutoAssign" style="padding-top: 2px;">
                          Receive Auto-Assigned Leads
                          <div class="text-danger fw-bold mt-1" style="font-size: 12px;"><i class="bi bi-info-circle"></i> OFF karne par is agent ko nayi leads assign nahi hongi.</div>
                      </label>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 mb-3">
                            <label class="form-label fw-bold text-dark" style="font-size: 13px;">Priority Level (1 is Highest)</label>
                            <select name="priority_level" id="priorityLevel" class="form-select">
                                <option value="1">Level 1 (Highest Priority)</option>
                                <option value="2">Level 2</option>
                                <option value="3">Level 3</option>
                                <option value="4">Level 4</option>
                                <option value="5">Level 5</option>
                                <option value="6">Level 6</option>
                                <option value="7">Level 7</option>
                                <option value="8">Level 8</option>
                                <option value="9">Level 9</option>
                                <option value="10">Level 10 (Lowest Priority)</option>
                            </select>
                            <div class="text-muted mt-1" style="font-size: 11px;">System pehle Level 1 walo ko leads baantega. Jab unki limit poori hogi, tabhi Level 2 par jayega.</div>
                        </div>

                        <div class="col-sm-6 mb-3">
                            <label class="form-label fw-bold text-dark" style="font-size: 13px;">Daily Lead Limit</label>
                            <input type="number" name="daily_limit" id="dailyLimit" class="form-control" min="0" required>
                            <div class="text-muted mt-1" style="font-size: 11px;">Set 9999 for Unlimited.</div>
                        </div>
                        
                        <div class="col-sm-6 mb-3">
                            <label class="form-label fw-bold text-dark" style="font-size: 13px;">Assign Ratio (Speed)</label>
                            <select name="weight" id="assignWeight" class="form-select">
                                <option value="1">1:1 (Normal)</option>
                                <option value="2">1:2 (Half Leads)</option>
                                <option value="3">1:3 (One-Third)</option>
                                <option value="4">1:4 (Quarter)</option>
                                <option value="5">1:5 (Minimum)</option>
                            </select>
                            <div class="text-muted mt-1" style="font-size: 11px;">Same priority walo ke beech leads baatne ka ratio.</div>
                        </div>
                    </div>
                  </div>
                  
                  <div class="modal-footer border-top-0 px-4 pb-4 pt-0">
                    <button type="button" class="btn btn-light btn-sm px-4 fw-bold text-secondary border" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm px-4 fw-bold text-white" style="background-color: #4f46e5; border-color: #4f46e5; box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2);">Save Rules</button>
                  </div>
              </form>
            </div>
          </div>
        </div>

        <script>
            function openEditModal(id, name, email, phone, role) {
                document.getElementById('editUserId').value = id;
                document.getElementById('editName').value = name;
                document.getElementById('editEmail').value = email;
                document.getElementById('editPhone').value = phone;
                document.getElementById('editRole').value = role;
                
                var myModal = new bootstrap.Modal(document.getElementById('editMemberModal'));
                myModal.show();
            }

            function openRulesModal(id, name, is_auto_assign, daily_limit, weight, priority) {
                document.getElementById('ruleUserId').value = id;
                document.getElementById('ruleUserName').innerText = name.toUpperCase();
                
                document.getElementById('isAutoAssign').checked = (is_auto_assign == 1);
                document.getElementById('dailyLimit').value = daily_limit;
                document.getElementById('assignWeight').value = weight;
                document.getElementById('priorityLevel').value = priority ? priority : 1;
                
                var ruleModal = new bootstrap.Modal(document.getElementById('rulesModal'));
                ruleModal.show();
            }
        </script>

    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleSettingsMenu() {
            var navLinks = document.getElementById('settingsNavLinks');
            navLinks.classList.toggle('show');
        }
    </script>
</body> 
</html>