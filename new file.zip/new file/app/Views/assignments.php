<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">      
    <title><?= htmlspecialchars($title ?? 'Team Assignments') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <style>          
        body { background-color: #f4f7f6; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; overflow-x: hidden; }                  
        .main-content { margin-left: 250px; padding: 15px 20px; transition: all 0.3s ease; min-height: 100vh; display: flex; flex-direction: column; }          
        .card-custom { flex-grow: 1; display: flex; flex-direction: column; background: #fff; border-radius: 8px; border: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); overflow: hidden; }
        
        .card-header-custom { flex-shrink: 0; background: #fff; border-bottom: 2px solid #eaedf1; padding: 0; }
        .nav-tabs { border-bottom: none; display: flex; gap: 10px; padding-left: 20px; }
        .nav-tabs .nav-link { 
            border: none; color: #64748b; font-weight: 600; padding: 15px 20px; font-size: 15px; 
            position: relative; background: transparent; transition: 0.2s; cursor: pointer;
        }
        .nav-tabs .nav-link:hover { color: #4e73df; }
        .nav-tabs .nav-link.active { color: #4e73df; background: transparent; }
        .nav-tabs .nav-link.active::after { 
            content: ''; position: absolute; bottom: -2px; left: 0; width: 100%; height: 3px; 
            background-color: #4e73df; border-radius: 3px 3px 0 0; 
        }

        .tab-content { flex-grow: 1; display: flex; flex-direction: column; }
        .tab-pane { height: 100%; display: flex; flex-direction: column; }

        .table-responsive { width: 100%; overflow-x: auto !important; -webkit-overflow-scrolling: touch; }
        .table-responsive::-webkit-scrollbar { width: 6px; height: 6px; }
        .table-responsive::-webkit-scrollbar-track { background: #f1f1f1; }
        .table-responsive::-webkit-scrollbar-thumb { background: #ccc; border-radius: 4px; }

        .table { margin-bottom: 0; width: 100%; }
        .table th { position: sticky; top: 0; background-color: #f8fafc; color: #475569; font-weight: 600; font-size: 12px; text-transform: uppercase; padding: 14px 12px; border-bottom: none; z-index: 10; white-space: nowrap; }
        .table td { vertical-align: middle; padding: 14px 12px; border-bottom: 1px solid #f8f9fa; font-size: 14px; }
        
        .task-details-col { white-space: normal !important; min-width: 200px; }
        
        .priority-high { color: #dc3545; background: #f8d7da; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .priority-medium { color: #fd7e14; background: #ffe5d0; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .priority-low { color: #198754; background: #d1e7dd; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        
        .task-title { font-weight: 600; color: #333; margin-bottom: 2px; line-height: 1.4; }
        .task-desc { font-size: 12px; color: #6c757d; line-height: 1.4; }
        
        .task-completed .task-title { text-decoration: line-through; color: #adb5bd; }
        
        .btn-add-task { background: #4e73df; color: #fff; border: none; border-radius: 6px; padding: 8px 18px; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px; transition: 0.2s; }
        .btn-add-task:hover { background: #3a5bba; color: #fff; }
        
        .form-check-input { width: 1.4em; height: 1.4em; cursor: pointer; }

        /* DESKTOP MODAL */
        @media (min-width: 769px) {
            #approvalChatModal .modal-dialog {
                max-width: 820px !important;
                margin: 1.75rem auto;
            }
            #approvalChatModal .modal-content {
                border-radius: 12px !important;
                height: 650px !important;
                display: flex !important;
                flex-direction: column !important;
            }
            #approvalChatModal .modal-header {
                padding: 14px 20px !important;
                background-color: #243441 !important;
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
            }
            #approvalChatModal .modal-body {
                flex: 1 1 auto !important;
                display: flex !important;
                flex-direction: column !important;
                overflow: hidden !important;
            }
            .wa-chat-container {
                flex: 1 1 auto !important;
                height: calc(100% - 65px) !important;
                overflow-y: auto !important;
                padding: 20px !important;
            }
            .chat-desktop-header-left {
                display: flex;
                align-items: center;
                gap: 12px;
                max-width: 55%;
                overflow: hidden;
            }
            .chat-action-btn-group {
                display: flex;
                align-items: center;
                gap: 8px;
                flex-shrink: 0;
            }
        }

        /* WHATSAPP CHAT BUBBLES */
        .wa-chat-container {
            background-color: #efeae2;
            background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .wa-msg-bubble {
            max-width: 78%;
            padding: 8px 12px;
            border-radius: 8px;
            font-size: 13.5px;
            line-height: 1.4;
            box-shadow: 0 1px 1.5px rgba(0,0,0,0.15);
            position: relative;
            word-wrap: break-word;
        }
        .wa-msg-sent {
            align-self: flex-end;
            background-color: #dcf8c6;
            border-top-right-radius: 0;
        }
        .wa-msg-received {
            align-self: flex-start;
            background-color: #ffffff;
            border-top-left-radius: 0;
        }
        .wa-first-desc-bubble {
            align-self: flex-start;
            background-color: #fff9e6;
            border: 1px solid #ffeeba;
            border-left: 4px solid #ffc107;
            max-width: 85%;
        }
        .wa-msg-sender {
            font-size: 11px;
            font-weight: 700;
            margin-bottom: 2px;
            color: #198754;
        }
        .wa-msg-time {
            font-size: 10px;
            color: #888;
            float: right;
            margin-left: 10px;
            margin-top: 4px;
        }

        /* MOBILE RESPONSIVE CARD VIEW */
        @media (max-width: 768px) {
            body { overflow-y: auto !important; height: auto !important; }
            .main-content { margin-left: 0 !important; padding: 10px !important; min-height: 100vh !important; height: auto !important; }
            .card-custom { overflow: visible !important; height: auto !important; }
            .card-header-custom { flex-direction: column !important; align-items: stretch !important; }
            .nav-tabs { padding-left: 0; justify-content: center; }
            .btn-add-task { width: 100%; justify-content: center; padding: 10px; margin-top: 10px; }

            .table-responsive { overflow: visible !important; }
            .table, .table thead, .table tbody, .table tr, .table th, .table td { display: block !important; width: 100% !important; }
            .table thead { display: none !important; }
            .table tr {
                background: #fff;
                margin-bottom: 12px;
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                padding: 12px;
            }
            .table td {
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
                padding: 6px 0 !important;
                border-bottom: 1px solid #f1f5f9 !important;
                text-align: right !important;
            }
            .table td:last-child { border-bottom: none !important; padding-top: 10px !important; }
            
            .table td:nth-child(1):before { content: "Status:"; font-weight: 600; color: #64748b; }
            .table td:nth-child(2):before { content: "Details:"; font-weight: 600; color: #64748b; display: none; }
            .table td:nth-child(3):before { content: "Priority:"; font-weight: 600; color: #64748b; }
            .table td:nth-child(4):before { content: "Requested By:"; font-weight: 600; color: #64748b; }
            .table td:nth-child(5):before { content: "Date & Time:"; font-weight: 600; color: #64748b; }
            .table td:nth-child(6):before { content: "Action:"; font-weight: 600; color: #64748b; }

            .table td.task-details-col {
                display: block !important;
                text-align: left !important;
                max-width: 100% !important;
                padding: 8px 0 !important;
                border-bottom: 1px solid #f1f5f9 !important;
            }

            #approvalChatModal .modal-dialog {
                margin: 0 !important;
                max-width: 100% !important;
                width: 100% !important;
                height: 100% !important;
            }
            #approvalChatModal .modal-content {
                height: 100vh !important;
                height: 100dvh !important;
                border-radius: 0 !important;
                display: flex !important;
                flex-direction: column !important;
            }
            #approvalChatModal .modal-header {
                padding: 10px 12px !important;
                flex-direction: column !important;
                align-items: stretch !important;
                gap: 8px !important;
                background-color: #243441 !important;
                flex-shrink: 0 !important;
            }
            #approvalChatModal .modal-body {
                flex: 1 1 auto !important;
                display: flex !important;
                flex-direction: column !important;
                height: calc(100dvh - 120px) !important;
                overflow: hidden !important;
            }
            .wa-chat-container {
                flex: 1 1 auto !important;
                overflow-y: auto !important;
                padding: 12px 10px !important;
            }
            .chat-footer-mobile {
                flex-shrink: 0 !important;
                background-color: #f0f2f5 !important;
                padding: 8px 10px !important;
                position: sticky !important;
                bottom: 0 !important;
                z-index: 1055 !important;
            }
            .chat-mobile-header-top {
                width: 100%;
                display: flex;
                align-items: center;
                justify-content: space-between;
            }
            .chat-action-btn-group {
                width: 100%;
                display: flex;
                justify-content: space-between;
                gap: 6px;
                padding-top: 6px;
                border-top: 1px solid rgba(255,255,255,0.15);
            }
            .chat-action-btn-group button {
                flex: 1;
                font-size: 11px !important;
                padding: 6px 0 !important;
                display: flex;
                align-items: center;
                justify-content: center;
            }
        }
    </style> 
</head> 
<body>     
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <?php 
        $current_tab = $_GET['tab'] ?? 'tasks';
        $sales_tasks = [];
        $approval_requests = [];
        $pending_sales_task_count = 0;
        $pending_approval_count = 0;

        if (!empty($tasks)) {
            foreach($tasks as $t) {
                $is_approval = (strpos($t['title'], 'APPROVAL_REQ:') === 0);
                $t['display_title'] = trim(str_replace('APPROVAL_REQ:', '', $t['title']));
                
                $t['extracted_party'] = 'N/A';
                if (preg_match('/Party Name:\s*([^\n\r]+)/i', $t['description'], $matches)) {
                    $t['extracted_party'] = trim($matches[1]);
                }

                $t['unique_app_id'] = '#APP-' . str_pad($t['id'], 4, '0', STR_PAD_LEFT);

                if ($is_approval) {
                    $approval_requests[] = $t;
                    if ($t['status'] === 'In Progress' || $t['status'] === 'On Hold') $pending_approval_count++;
                } else {
                    $sales_tasks[] = $t;
                    if ($t['status'] === 'Pending') $pending_sales_task_count++;
                }
            }
        }
    ?>

    <div class="main-content">         
        <div class="card card-custom mt-5 mt-md-0">
            <div class="card-header-custom d-flex flex-column flex-md-row justify-content-between align-items-md-end">
                
                <ul class="nav nav-tabs" id="taskTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link <?= $current_tab === 'tasks' ? 'active' : '' ?>" id="assigned-tab" data-bs-toggle="tab" data-bs-target="#assigned-pane" type="button" role="tab" onclick="switchMainTab('tasks')">
                            Sales Task
                            <span id="salesTaskBadge" class="badge bg-danger ms-1 rounded-pill <?= $pending_sales_task_count == 0 ? 'd-none' : '' ?>">
                                <?= $pending_sales_task_count ?>
                            </span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link <?= $current_tab === 'approvals' ? 'active' : '' ?>" id="approvals-tab" data-bs-toggle="tab" data-bs-target="#approvals-pane" type="button" role="tab" onclick="switchMainTab('approvals')">
                            Approvals
                            <span id="approvalBadge" class="badge bg-danger ms-1 rounded-pill <?= $pending_approval_count == 0 ? 'd-none' : '' ?>">
                                <?= $pending_approval_count ?>
                            </span>
                        </button>
                    </li>
                </ul>

                <div class="p-3 pt-2 pb-2 d-flex gap-2">
                    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                        <button id="btnAssignTask" class="btn-add-task shadow-sm <?= $current_tab === 'approvals' ? 'd-none' : '' ?>" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                            <i class="bi bi-person-plus"></i> Assign Task
                        </button>
                    <?php endif; ?>
                    
                    <button id="btnNewApproval" class="btn-add-task shadow-sm <?= $current_tab === 'tasks' ? 'd-none' : '' ?>" data-bs-toggle="modal" data-bs-target="#requestApprovalModal" style="background-color: #6366f1; border-color: #6366f1;">
                        <i class="bi bi-shield-plus"></i> New Approval
                    </button>
                </div>
            </div>

            <div class="tab-content w-100">
                
                <!-- TAB 1: SALES TASKS -->
                <div class="tab-pane fade <?= $current_tab === 'tasks' ? 'show active' : '' ?>" id="assigned-pane" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 50px;" class="text-center">Status</th>
                                    <th>Task Details</th>
                                    <th style="width: 120px;">Priority</th>
                                    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                        <th style="width: 160px;">Assigned To</th>
                                    <?php else: ?>
                                        <th style="width: 160px;">Assigned By</th>
                                    <?php endif; ?>
                                    <th style="width: 130px;">Due Date</th>
                                    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                        <th style="width: 80px;" class="text-center">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody id="assignedTbody">
                                <?php if (empty($sales_tasks)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="bi bi-check2-circle fs-1 d-block mb-2 text-success"></i>
                                            No pending tasks. Great job!
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($sales_tasks as $task): ?>
                                        <?php 
                                            $is_completed = ($task['status'] === 'Completed');
                                            $row_class = $is_completed ? 'task-completed bg-light' : '';
                                            
                                            $priority_class = 'priority-medium';
                                            if($task['priority'] === 'High') $priority_class = 'priority-high';
                                            if($task['priority'] === 'Low') $priority_class = 'priority-low';
                                        ?>
                                        <tr class="<?= $row_class ?>">
                                            <td class="text-center">
                                                <input class="form-check-input mt-2 task-check" type="checkbox" 
                                                    <?= $is_completed ? 'checked' : '' ?> 
                                                    onchange="handleTaskCheckbox(<?= $task['id'] ?>, this)">
                                            </td>
                                            <td class="task-details-col">
                                                <div class="task-title"><?= htmlspecialchars($task['display_title']) ?></div>
                                                <?php if(!empty($task['description'])): ?>
                                                    <div class="task-desc"><?= nl2br(htmlspecialchars($task['description'])) ?></div>
                                                <?php endif; ?>
                                                
                                                <?php if(!empty($task['completion_notes']) && $is_completed): ?>
                                                    <div class="mt-2 p-2 rounded task-completion-notes-ui" style="background-color: #f8f9fa; border: 1px dashed #ced4da; font-size: 11px;">
                                                        <strong class="text-success"><i class="bi bi-check2-circle me-1"></i>Completed Notes:</strong><br>
                                                        <span class="text-muted"><?= nl2br(htmlspecialchars($task['completion_notes'])) ?></span>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="<?= $priority_class ?>"><i class="bi bi-flag-fill me-1"></i><?= $task['priority'] ?></span>
                                            </td>
                                            
                                            <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                                <td class="fw-bold text-primary" style="font-size: 13px;">
                                                    <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($task['assignee_name'] ?? 'Unknown') ?>
                                                </td>
                                            <?php else: ?>
                                                <td class="fw-bold text-secondary" style="font-size: 13px;">
                                                    <?php if($task['assigner_name'] == $_SESSION['name']): ?>
                                                        <span class="badge bg-secondary">Created by You</span>
                                                    <?php else: ?>
                                                        <i class="bi bi-person-badge me-1"></i> Admin (<?= htmlspecialchars($task['assigner_name'] ?? '') ?>)
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>

                                            <td style="font-size: 13px; font-weight: 500;" class="<?= (strtotime($task['due_date']) < time() && !$is_completed) ? 'text-danger' : 'text-dark' ?>">
                                                <?php 
                                                    if(!empty($task['due_date'])) {
                                                        echo date('d M Y', strtotime($task['due_date']));
                                                    } else {
                                                        echo '<span class="text-muted">No Deadline</span>';
                                                    }
                                                ?>
                                            </td>
                                            
                                            <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                                                <td class="text-center">
                                                    <a href="<?= BASE_URL ?>assignments/delete/<?= $task['id'] ?>" class="text-danger" onclick="return confirm('Delete this task?');">
                                                        <i class="bi bi-trash-fill"></i>
                                                    </a>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- TAB 2: APPROVALS -->
                <div class="tab-pane fade <?= $current_tab === 'approvals' ? 'show active' : '' ?>" id="approvals-pane" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 140px;">Approval Status</th>
                                    <th>Title & Party Name</th>
                                    <th style="width: 110px;">Priority</th>
                                    <th style="width: 150px;">Requested By</th>
                                    <th style="width: 160px;">Date & Time</th>
                                    <th style="width: 120px;" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="approvalsTbody">
                                <?php if (empty($approval_requests)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="bi bi-shield-check fs-1 d-block mb-2" style="color: #cbd5e1;"></i>
                                            No approvals found.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($approval_requests as $task): ?>
                                        <?php 
                                            $priority_class = 'priority-medium';
                                            if($task['priority'] === 'High') $priority_class = 'priority-high';
                                            if($task['priority'] === 'Low') $priority_class = 'priority-low';
                                            
                                            $app_badge = '';
                                            $curr_status = trim($task['status']);
                                            
                                            if ($curr_status === 'Completed') {
                                                $app_badge = '<span class="badge bg-success border shadow-sm" style="font-size: 11px; padding: 6px 10px;"><i class="bi bi-check-circle me-1"></i> Approved</span>';
                                            } elseif ($curr_status === 'On Hold') {
                                                $app_badge = '<span class="badge bg-warning border shadow-sm text-dark" style="font-size: 11px; padding: 6px 10px; background-color: #ffc107 !important;"><i class="bi bi-pause-circle me-1"></i> On Hold</span>';
                                            } elseif ($curr_status === 'Rejected') {
                                                $app_badge = '<span class="badge bg-danger border shadow-sm" style="font-size: 11px; padding: 6px 10px;"><i class="bi bi-x-circle me-1"></i> Rejected</span>';
                                            } else {
                                                $app_badge = '<span class="badge bg-warning text-dark border shadow-sm" style="font-size: 11px; padding: 6px 10px;"><i class="bi bi-hourglass-split me-1"></i> Waiting</span>';
                                            }
                                        ?>
                                        <tr>
                                            <td><?= $app_badge ?></td>
                                            <td class="task-details-col">
                                                <div class="d-flex align-items-center gap-2 mb-1">
                                                    <span class="badge bg-light text-secondary border font-monospace" style="font-size: 11px;"><?= $task['unique_app_id'] ?></span>
                                                    <span class="fw-bold text-dark" style="font-size: 14px;"><?= htmlspecialchars($task['display_title']) ?></span>
                                                </div>
                                                <div class="text-muted" style="font-size: 12.5px;">
                                                    Party: <strong class="text-secondary"><?= htmlspecialchars($task['extracted_party']) ?></strong>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="<?= $priority_class ?>"><i class="bi bi-flag-fill me-1"></i><?= $task['priority'] ?></span>
                                            </td>
                                            
                                            <td class="fw-bold text-primary" style="font-size: 13px;">
                                                <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($task['assignee_name'] ?? 'Unknown') ?>
                                            </td>

                                            <td style="font-size: 12.5px; font-weight: 500; color: #475569;">
                                                <i class="bi bi-calendar-event me-1"></i> <?= \Core\Timezone::formatUtc($task['created_at'], \Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)), 'd M Y') ?><br>
                                                <span class="text-muted" style="font-size: 11.5px;"><i class="bi bi-clock me-1"></i> <?= \Core\Timezone::formatUtc($task['created_at'], \Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)), 'h:i A') ?></span>
                                            </td>
                                            
                                            <td class="text-center">
                                                <div class="d-flex gap-2 justify-content-center align-items-center">
                                                    <button onclick="openApprovalChat(<?= $task['id'] ?>, '<?= htmlspecialchars(addslashes($task['display_title'])) ?>', '<?= htmlspecialchars(addslashes($task['extracted_party'])) ?>', '<?= $task['unique_app_id'] ?>', '<?= $curr_status ?>')" class="btn btn-sm btn-outline-success fw-bold shadow-sm" style="font-size: 11.5px; padding: 5px 12px;">
                                                        <i class="bi bi-chat-dots-fill me-1"></i> View
                                                    </button>

                                                    <a href="<?= BASE_URL ?>assignments/delete/<?= $task['id'] ?>" class="text-danger" style="font-size:14px; text-decoration:none;" onclick="return confirm('Delete this record?');" title="Delete">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> 

    <!-- ASSIGN TASK MODAL -->
    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
    <div class="modal fade" id="addTaskModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg">
          <form action="<?= BASE_URL ?>assignments/add" method="POST">
              <div class="modal-header bg-light border-bottom-0 pb-3">
                <h5 class="modal-title fw-bold text-dark"><i class="bi bi-person-plus text-primary me-2"></i>Assign Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body pt-2 pb-4 px-4">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Assign To <span class="text-danger">*</span></label>
                    <select name="assigned_to" class="form-select shadow-none" required>
                        <option value="" disabled selected>Select Sales Executive...</option>
                        <option value="all" class="fw-bold text-primary">👥 All Sales Executives</option>
                        <option disabled>────────────────────</option>
                        <?php foreach($agents as $agent): ?>
                            <option value="<?= $agent['id'] ?>"><?= htmlspecialchars($agent['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Task Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control shadow-none" required placeholder="e.g. Call 10 pending leads">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Description & Details</label>
                    <textarea name="description" class="form-control shadow-none" rows="3" placeholder="Provide extra instructions..."></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold small text-muted">Priority</label>
                        <select name="priority" class="form-select shadow-none">
                            <option value="High" class="text-danger fw-bold">High</option>
                            <option value="Medium" selected class="text-warning fw-bold">Medium</option>
                            <option value="Low" class="text-success fw-bold">Low</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold small text-muted">Due Date</label>
                        <input type="date" name="due_date" class="form-control shadow-none" min="<?= (new \DateTimeImmutable('now', new \DateTimeZone(\Core\Timezone::get(\Core\Database::getInstance(), (int)($_SESSION['company_id'] ?? 1)))))->format('Y-m-d') ?>">
                    </div>
                </div>
              </div>
              <div class="modal-footer bg-light border-top-0 pt-0">
                <button type="button" class="btn btn-light border fw-bold text-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4 shadow-sm">Assign Task</button>
              </div>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- NEW APPROVAL MODAL -->
    <div class="modal fade" id="requestApprovalModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg">
          <form action="<?= BASE_URL ?>assignments/request_approval" method="POST">
              <div class="modal-header bg-light border-bottom-0 pb-3">
                <h5 class="modal-title fw-bold text-dark"><i class="bi bi-shield-plus text-primary me-2"></i>New Approval</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body pt-2 pb-4 px-4">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Subject <span class="text-danger">*</span></label>
                    <input type="text" name="subject" class="form-control shadow-none" required placeholder="e.g. International Shipping rate">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Party Name <span class="text-danger">*</span></label>
                    <input type="text" name="party_name" class="form-control shadow-none" required placeholder="e.g. Sara Devi">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Description (Reason & Details) <span class="text-danger">*</span></label>
                    <textarea name="description" class="form-control shadow-none" rows="5" required placeholder="Reason: actual weight - 16.2 kg&#10;previous parcel rate charged to client- 325&#10;sir rate kya lagana hai?"></textarea>
                </div>
              </div>
              <div class="modal-footer bg-light border-top-0 pt-0">
                <button type="button" class="btn btn-light border fw-bold text-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary fw-bold px-4 shadow-sm" style="background-color: #6366f1; border-color: #6366f1;">Send for Approval</button>
              </div>
          </form>
        </div>
      </div>
    </div>

    <!-- TASK COMPLETION MODAL -->
    <div class="modal fade" id="taskCompletionModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-light border-bottom-0 pb-3">
              <h5 class="modal-title fw-bold text-dark"><i class="bi bi-check2-square text-success me-2"></i>Complete Task</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" onclick="revertCheckbox()"></button>
            </div>
            <div class="modal-body pt-2 pb-4 px-4">
              <input type="hidden" id="complete_task_id">
              <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">Task Update / Remarks <span class="text-danger">*</span></label>
                  <textarea id="completion_notes" class="form-control shadow-none border-secondary-subtle" rows="4" required placeholder="What was done? Please provide details..."></textarea>
              </div>
            </div>
            <div class="modal-footer bg-light border-top-0 pt-0">
              <button type="button" class="btn btn-light border fw-bold text-secondary shadow-sm" data-bs-dismiss="modal" onclick="revertCheckbox()">Cancel</button>
              <button type="button" class="btn btn-success fw-bold px-4 shadow-sm" onclick="submitTaskCompletion()">Submit Completion</button>
            </div>
        </div>
      </div>
    </div>

    <!-- CHAT MODAL -->
    <div class="modal fade" id="approvalChatModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg overflow-hidden">
            
            <!-- HEADER -->
            <div class="modal-header text-white border-0">
                <div class="chat-mobile-header-top d-md-none">
                    <div class="d-flex align-items-center gap-2 overflow-hidden flex-grow-1">
                        <button type="button" class="btn btn-link text-white p-0 me-1" data-bs-dismiss="modal">
                            <i class="bi bi-arrow-left fs-4"></i>
                        </button>
                        <div class="overflow-hidden">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-light text-dark font-monospace flex-shrink-0" id="chatModalAppIdMob" style="font-size: 10px;">#APP-0000</span>
                                <h6 class="modal-title fw-bold mb-0 text-white text-truncate" id="chatModalTitleMob" style="font-size: 14px;">Title</h6>
                            </div>
                            <small class="text-white-50 text-truncate d-block" style="font-size: 11.5px;">Party: <strong class="text-white" id="chatModalPartyMob">Party Name</strong></small>
                        </div>
                    </div>
                </div>

                <div class="chat-desktop-header-left d-none d-md-flex">
                    <i class="bi bi-whatsapp text-success fs-3 flex-shrink-0"></i>
                    <div class="overflow-hidden">
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-light text-dark font-monospace flex-shrink-0" id="chatModalAppId" style="font-size: 11px;">#APP-0000</span>
                            <h6 class="modal-title fw-bold mb-0 text-white text-truncate" id="chatModalTitle" style="font-size: 15px;">Title</h6>
                        </div>
                        <small class="text-white-50 text-truncate d-block" style="font-size: 12.5px;">Party: <strong class="text-white" id="chatModalParty">Party Name</strong></small>
                    </div>
                </div>

                <div class="d-flex align-items-center gap-3">
                    <?php if (($user_role ?? 'SALES') === 'ADMIN'): ?>
                    <div class="chat-action-btn-group">
                        <button onclick="actionApprovalDirect('Completed')" class="btn btn-sm btn-success fw-bold shadow-sm px-3">
                            <i class="bi bi-check-lg me-1"></i> Approve
                        </button>
                        <button onclick="actionApprovalDirect('On Hold')" class="btn btn-sm btn-warning fw-bold shadow-sm text-dark px-3" style="background-color: #ffc107;">
                            <i class="bi bi-pause-circle me-1"></i> On Hold
                        </button>
                        <button onclick="actionApprovalDirect('Rejected')" class="btn btn-sm btn-danger fw-bold shadow-sm px-3">
                            <i class="bi bi-x-lg me-1"></i> Reject
                        </button>
                    </div>
                    <?php endif; ?>

                    <button type="button" class="btn-close btn-close-white shadow-none d-none d-md-block" data-bs-dismiss="modal"></button>
                </div>
            </div>
            
            <!-- BODY -->
            <div class="modal-body p-0">
                <div class="wa-chat-container" id="waChatContainer"></div>
                
                <!-- FOOTER WITH ALWAYS VISIBLE INPUT BOX -->
                <div class="chat-footer-mobile border-top d-flex gap-2 align-items-center">
                    <input type="text" id="waChatInput" class="form-control shadow-none bg-white border" placeholder="Type a message to discuss..." onkeypress="if(event.key==='Enter') sendApprovalChatMessage()" style="font-size: 14px; border-radius: 20px; padding: 8px 15px;">
                    <button class="btn btn-success rounded-circle shadow-sm d-flex align-items-center justify-content-center flex-shrink-0" style="width: 40px; height: 40px; background-color: #00a884; border:none;" onclick="sendApprovalChatMessage()">
                        <i class="bi bi-send-fill fs-6"></i>
                    </button>
                </div>
            </div>
        </div>
      </div>
    </div>

    <!-- AIRY SOCIAL MEDIA CHIME AUDIO SOURCE -->
    <audio id="notifSound" preload="auto" src="https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c3683a48.mp3?filename=airy-social-media-chime-102553.mp3"></audio>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const baseUrl = '<?= rtrim(BASE_URL, '/') ?>/';
        const currentUserId = <?= (int)($_SESSION['user_id'] ?? 0) ?>;

        function switchMainTab(tab) {
            let newUrl = new URL(window.location.href);
            newUrl.searchParams.set('tab', tab);
            newUrl.searchParams.delete('open_chat');
            window.history.replaceState({}, '', newUrl);

            let btnAssign = document.getElementById('btnAssignTask');
            let btnApproval = document.getElementById('btnNewApproval');

            if (tab === 'tasks') {
                if (btnAssign) btnAssign.classList.remove('d-none');
                if (btnApproval) btnApproval.classList.add('d-none');
            } else {
                if (btnAssign) btnAssign.classList.add('d-none');
                if (btnApproval) btnApproval.classList.remove('d-none');
            }
        }

        let currentCheckbox = null;
        let isTaskSaved = false;
        let completionModalInstance = null;

        function handleTaskCheckbox(taskId, checkbox) {
            if (checkbox.checked) {
                currentCheckbox = checkbox;
                isTaskSaved = false;
                
                document.getElementById('complete_task_id').value = taskId;
                document.getElementById('completion_notes').value = '';
                
                if (!completionModalInstance) {
                    completionModalInstance = new bootstrap.Modal(document.getElementById('taskCompletionModal'));
                }
                completionModalInstance.show();
                
            } else {
                updateTaskStatusDirect(taskId, 'Pending');
                let row = checkbox.closest('tr');
                row.classList.remove('task-completed', 'bg-light');
                let notesDiv = row.querySelector('.task-completion-notes-ui');
                if(notesDiv) notesDiv.remove();
            }
        }

        function revertCheckbox() {
            if (!isTaskSaved && currentCheckbox) {
                currentCheckbox.checked = false;
            }
        }

        function submitTaskCompletion() {
            let taskId = document.getElementById('complete_task_id').value;
            let notes = document.getElementById('completion_notes').value;
            
            if (notes.trim() === '') {
                alert('Please enter task completion remarks.');
                return;
            }

            isTaskSaved = true;
            let newStatus = 'Completed';
            
            let row = currentCheckbox.closest('tr');
            row.classList.add('task-completed', 'bg-light');
            
            if(completionModalInstance) completionModalInstance.hide();
            
            fetch(`${baseUrl}assignments/update_status`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ task_id: taskId, status: newStatus, completion_notes: notes })
            })
            .then(r => r.json())
            .then(data => {
                if (data.status === 'success') {
                    refreshSilently(true); 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Connection error.');
            });
        }

        function updateTaskStatusDirect(taskId, newStatus) {
            fetch(`${baseUrl}assignments/update_status`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ task_id: taskId, status: newStatus })
            })
            .then(r => r.json())
            .then(data => {
                if (data.status === 'success') {
                    refreshSilently(true);
                }
            })
            .catch(error => {
                console.error('Error updating status:', error);
                alert('Connection error. Could not update task.');
            });
        }

        let activeChatTaskId = null;
        let chatModalInstance = null;
        let chatInterval = null;

        function openApprovalChat(taskId, title, party, appId, status) {
            activeChatTaskId = taskId;
            if (title) {
                document.getElementById('chatModalTitle').innerText = title;
                let mob = document.getElementById('chatModalTitleMob');
                if (mob) mob.innerText = title;
            }
            if (party) {
                document.getElementById('chatModalParty').innerText = party;
                let mob = document.getElementById('chatModalPartyMob');
                if (mob) mob.innerText = party;
            }
            if (appId) {
                document.getElementById('chatModalAppId').innerText = appId;
                let mob = document.getElementById('chatModalAppIdMob');
                if (mob) mob.innerText = appId;
            }
            
            if (!chatModalInstance) {
                chatModalInstance = new bootstrap.Modal(document.getElementById('approvalChatModal'));
            }
            
            loadApprovalChatMessages();
            chatModalInstance.show();
            
            if (chatInterval) clearInterval(chatInterval);
            chatInterval = setInterval(loadApprovalChatMessages, 3000);
        }

        document.getElementById('approvalChatModal').addEventListener('hidden.bs.modal', function () {
            if (chatInterval) clearInterval(chatInterval);
            activeChatTaskId = null;

            let cleanUrl = new URL(window.location.href);
            cleanUrl.searchParams.delete('open_chat');
            window.history.replaceState({}, '', cleanUrl);
        });

        function loadApprovalChatMessages() {
            if (!activeChatTaskId) return;

            fetch(`${baseUrl}assignments/get_chat_messages?task_id=${activeChatTaskId}`)
            .then(r => r.json())
            .then(data => {
                if (data.status === 'success') {
                    let container = document.getElementById('waChatContainer');
                    let html = '';
                    
                    if (data.task_details) {
                        document.getElementById('chatModalTitle').innerText = data.task_details.title;
                        document.getElementById('chatModalParty').innerText = data.task_details.party;
                        document.getElementById('chatModalAppId').innerText = data.task_details.app_id;

                        let mobT = document.getElementById('chatModalTitleMob');
                        if(mobT) mobT.innerText = data.task_details.title;
                        let mobP = document.getElementById('chatModalPartyMob');
                        if(mobP) mobP.innerText = data.task_details.party;
                        let mobA = document.getElementById('chatModalAppIdMob');
                        if(mobA) mobA.innerText = data.task_details.app_id;

                        html += `
                            <div class="wa-msg-bubble wa-first-desc-bubble">
                                <div class="wa-msg-sender text-dark"><i class="bi bi-pin-angle-fill text-warning me-1"></i> Original Request By ${data.task_details.requester_name}</div>
                                <div class="wa-msg-text mt-1">${data.task_details.description.replace(/\n/g, '<br>')}</div>
                                <div class="wa-msg-time">${data.task_details.time}</div>
                            </div>
                        `;
                    }

                    if (data.messages && data.messages.length > 0) {
                        data.messages.forEach(msg => {
                            let isSent = (parseInt(msg.user_id) === currentUserId);
                            let bubbleType = isSent ? 'wa-msg-sent' : 'wa-msg-received';
                            let senderName = isSent ? 'You' : msg.user_name;
                            
                            html += `
                                <div class="wa-msg-bubble ${bubbleType}">
                                    <div class="wa-msg-sender">${senderName}</div>
                                    <div class="wa-msg-text">${msg.message.replace(/\n/g, '<br>')}</div>
                                    <div class="wa-msg-time">${msg.time}</div>
                                </div>
                            `;
                        });
                    }
                    
                    let shouldScroll = (container.scrollTop + container.clientHeight >= container.scrollHeight - 50) || container.innerHTML === '';
                    container.innerHTML = html;
                    if (shouldScroll) container.scrollTop = container.scrollHeight;
                }
            })
            .catch(e => console.error(e));
        }

        function sendApprovalChatMessage() {
            let input = document.getElementById('waChatInput');
            let text = input.value.trim();
            if (!text || !activeChatTaskId) return;

            input.value = '';
            
            fetch(`${baseUrl}assignments/send_chat_message`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ task_id: activeChatTaskId, message: text })
            })
            .then(r => r.json())
            .then(data => {
                if (data.status === 'success') {
                    loadApprovalChatMessages();
                }
            })
            .catch(e => console.error(e));
        }

        function actionApprovalDirect(newStatus) {
            if (!activeChatTaskId) return;
            
            updateTaskStatusDirect(activeChatTaskId, newStatus);
            if (chatModalInstance) chatModalInstance.hide();
        }

        document.addEventListener("DOMContentLoaded", function() {
            let urlParams = new URLSearchParams(window.location.search);
            let targetTaskId = urlParams.get('open_chat');

            if (targetTaskId) {
                let approvalsTabEl = document.getElementById('approvals-tab');
                if (approvalsTabEl && !approvalsTabEl.classList.contains('active')) {
                    let tab = new bootstrap.Tab(approvalsTabEl);
                    tab.show();
                    switchMainTab('approvals');
                }

                setTimeout(() => {
                    openApprovalChat(parseInt(targetTaskId));
                }, 400);
            }
        });

        // ===============================================
        // SINGLE-FIRE NOTIFICATION SYSTEM (SERVICE WORKER DISABLER)
        // ===============================================
        let lastNotifId = 0;
        let lastSoundPlayedAt = 0;

        function playSoftNotificationSound() {
            let now = Date.now();
            if (now - lastSoundPlayedAt < 4000) return;
            lastSoundPlayedAt = now;

            let sound = document.getElementById('notifSound');
            if (sound) {
                sound.volume = 0.6;
                sound.currentTime = 0;
                sound.play().catch(e => {});
            }
        }

        function showSystemNotification(title, message, targetUrl, notifId) {
            if (!("Notification" in window)) return;

            // Prevent duplicate triggers if already shown in session storage
            let lockKey = 'notif_sent_' + notifId;
            if (sessionStorage.getItem(lockKey)) return;
            sessionStorage.setItem(lockKey, 'true');

            if (Notification.permission === "granted") {
                // EXCLUSIVELY use standard browser window notification to avoid service worker double push
                try {
                    let n = new Notification(title, {
                        body: message,
                        icon: `${baseUrl}favicon.png`,
                        tag: 'crm-single-' + notifId
                    });
                    n.onclick = function(e) {
                        e.preventDefault();
                        window.focus();
                        if (targetUrl) window.location.href = targetUrl;
                    };
                } catch(e) {}
            } else if (Notification.permission !== "denied") {
                Notification.requestPermission().then(permission => {
                    if (permission === "granted") {
                        showSystemNotification(title, message, targetUrl, notifId);
                    }
                });
            }
        }

        function checkRealtimeNotifications() {
            fetch(`${baseUrl}settings/get_user_alerts?last_id=${lastNotifId}`)
            .then(r => r.json())
            .then(data => {
                if (data.sync_id !== undefined) {
                    lastNotifId = data.sync_id;
                    return;
                }
                
                if (data.notifications && data.notifications.length > 0) {
                    let shouldPlaySound = false;

                    data.notifications.forEach(n => {
                        let nId = parseInt(n.id);
                        lastNotifId = Math.max(lastNotifId, nId);
                        shouldPlaySound = true;
                        showSystemNotification(n.title, n.message, n.url || `${baseUrl}assignments?tab=approvals`, nId);
                    });

                    if (shouldPlaySound) {
                        playSoftNotificationSound();
                    }

                    refreshSilently(true);
                }
            })
            .catch(e => {});
        }

        function refreshSilently(force = false) {
            let isAnyModalOpen = document.querySelector('.modal.show') !== null;
            if (!force && isAnyModalOpen) return;

            fetch(window.location.href)
            .then(response => response.text())
            .then(html => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(html, 'text/html');
                
                let oldAssigned = document.getElementById('assignedTbody');
                let newAssigned = doc.getElementById('assignedTbody');
                if (oldAssigned && newAssigned && oldAssigned.innerHTML !== newAssigned.innerHTML) {
                    oldAssigned.innerHTML = newAssigned.innerHTML;
                }

                let oldApprovals = document.getElementById('approvalsTbody');
                let newApprovals = doc.getElementById('approvalsTbody');
                if (oldApprovals && newApprovals && oldApprovals.innerHTML !== newApprovals.innerHTML) {
                    oldApprovals.innerHTML = newApprovals.innerHTML;
                }

                let oldSalesBadge = document.getElementById('salesTaskBadge');
                let newSalesBadge = doc.getElementById('salesTaskBadge');
                if (oldSalesBadge && newSalesBadge) oldSalesBadge.outerHTML = newSalesBadge.outerHTML;

                let oldAppBadge = document.getElementById('approvalBadge');
                let newAppBadge = doc.getElementById('approvalBadge');
                if (oldAppBadge && newAppBadge) oldAppBadge.outerHTML = newAppBadge.outerHTML;
            })
            .catch(error => console.log('Auto-refresh paused'));
        }

        if ("Notification" in window && Notification.permission !== "granted" && Notification.permission !== "denied") {
            Notification.requestPermission();
        }

        setInterval(checkRealtimeNotifications, 3000);
        setInterval(() => refreshSilently(), 5000);
    </script>
</body> 
</html>