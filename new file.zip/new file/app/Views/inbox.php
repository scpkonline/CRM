<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Live Chat') ?></title>      
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/inbox.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/scpk_media_gallery.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/scpk_campaign_wizard.css?v=<?= time() ?>">
</head> 
<body>     
    
    <!-- Mobile Overlay Background -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Left Sidebar -->
    <div class="sidebar">          
        <ul class="nav flex-column w-100 flex-md-column flex-row">              
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>dashboard">
                    <i class="bi bi-grid-1x2"></i><span>Dashboard</span>
                </a>
            </li>              
            <li class="nav-item">
                <a class="nav-link active" id="navLiveChat" href="#" onclick="switchAppMode(event, 'live')">
                    <i class="bi bi-chat-left-dots"></i><span>Live Chat</span>
                </a>
            </li>              
            <li class="nav-item">
                <a class="nav-link" id="navHistory" href="#" onclick="switchAppMode(event, 'history')">
                    <i class="bi bi-clock-history"></i><span>History</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="navAllChats" href="#" onclick="switchAppMode(event, 'all_chats')">
                    <i class="bi bi-collection"></i><span>All Chats</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="navMacros" href="#" onclick="switchAppMode(event, 'macros')">
                    <i class="bi bi-lightning-charge"></i><span>Quick Replies</span>
                </a>
            </li>        
            <li class="nav-item">
                <a class="nav-link" id="navTags" href="#" onclick="switchAppMode(event, 'tags')">
                    <i class="bi bi-tags"></i><span>Manage Tags</span>
                </a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" id="navTemplates" href="#" onclick="switchAppMode(event, 'templates')">
                    <i class="bi bi-whatsapp"></i><span>WA Templates</span>
                </a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" id="navMetaAds" href="#" onclick="switchAppMode(event, 'meta_ads')">
                    <i class="bi bi-megaphone"></i><span>Meta Ads</span>
                </a>
            </li>
            <?php if (in_array(strtolower((string)($_SESSION['role'] ?? '')), ['admin','super_admin','superadmin','administrator','owner'], true)): ?>
            <li class="nav-item">
                <a class="nav-link" id="navBroadcasts" href="#" onclick="switchAppMode(event, 'broadcasts')">
                    <i class="bi bi-send-check"></i><span>Campaigns</span>
                </a>
            </li>
            <?php endif; ?> 
        </ul>      
    </div>    
    
    <div class="main-content">          
        <!-- INBOX MAIN VIEW -->
        <div class="inbox-container w-100" id="inboxMainView">              
            
            <!-- Chat List Panel -->
            <div class="chat-list">                 
                <div class="chat-top-tabs" id="liveChatTabsContainer">
                    <div class="chat-tab active" onclick="switchTab('ACTIVE', this)">ACTIVE (<span id="count-active">0</span>)</div>
                    <div class="chat-tab" onclick="switchTab('INTERVENED', this)">INTERVENED (<span id="count-intervened">0</span>)</div>
                    <span id="count-requesting" style="display: none;">0</span>
                </div>
                
                <div class="chat-top-tabs" id="historyTabsContainer" style="display: none;">
                    <div class="chat-tab active" onclick="switchTab('EXPIRED', this)">EXPIRED HISTORY (<span id="count-expired">0</span>)</div>
                </div>

                <div class="chat-top-tabs" id="allChatsTabsContainer" style="display: none;">
                    <div class="chat-tab active" onclick="switchTab('ALL_CHATS', this)">ALL WHATSAPP LEADS (<span id="count-all">0</span>)</div>
                </div>

                <div class="chat-list-header d-flex gap-2 align-items-center">                      
                    <button class="d-md-none btn btn-light border shadow-sm text-secondary" id="mobileMenuBtn" style="padding: 6px 10px;">
                        <i class="bi bi-list fs-5"></i>
                    </button>
                    <div class="search-filter-box shadow-sm flex-grow-1">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" id="chatSearch" class="form-control" placeholder="Fast Omni Search...">
                        <button class="btn-filter" id="toggleFilterBtn" type="button">
                            <i class="bi bi-funnel"></i> Filters 
                        </button>
                    </div>
                </div>                 
                
                <div class="filter-popup" id="chatFilterPopup">
                    <h6 class="fw-bold mb-3" style="font-size: 13px;"><i class="bi bi-sliders me-1"></i> Filter Chats</h6>
                    
                    <div class="mb-2">
                        <label class="form-label text-muted mb-1" style="font-size:11px; font-weight:700;">Show Only</label>
                        <select id="filterUnread" class="form-select form-select-sm shadow-none" style="font-size: 12px; border-color: #ddd;" onchange="applyChatFilters()">
                            <option value="">All Chats</option>
                            <option value="unread">Unread Messages</option>
                        </select>
                    </div>
                    
                    <div class="mb-2">
                        <label class="form-label text-muted mb-1" style="font-size:11px; font-weight:700;">By Tag</label>
                        <select id="filterTag" class="form-select form-select-sm shadow-none" style="font-size: 12px; border-color: #ddd;" onchange="applyChatFilters()">
                            <option value="">All Tags</option>
                        </select>
                    </div>

                    <div class="mb-2">
                        <label class="form-label text-muted mb-1" style="font-size:11px; font-weight:700;">By Agent</label>
                        <select id="filterAgent" class="form-select form-select-sm shadow-none" style="font-size: 12px; border-color: #ddd;" onchange="applyChatFilters()">
                            <option value="">All Agents / Unassigned</option>
                            <?php if(!empty($agents)): foreach($agents as $agent): ?>
                                <option value="<?= strtolower($agent['name']) ?>"><?= htmlspecialchars($agent['name']) ?></option>
                            <?php endforeach; endif; ?>
                        </select>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label text-muted mb-1" style="font-size:11px; font-weight:700;">Start Date</label>
                            <input type="date" id="filterStartDate" class="form-control form-control-sm shadow-none" style="font-size: 12px; border-color: #ddd;" onchange="applyChatFilters()">
                        </div>
                        <div class="col-6">
                            <label class="form-label text-muted mb-1" style="font-size:11px; font-weight:700;">End Date</label>
                            <input type="date" id="filterEndDate" class="form-control form-control-sm shadow-none" style="font-size: 12px; border-color: #ddd;" onchange="applyChatFilters()">
                        </div>
                    </div>

                    <button class="btn w-100 text-white fw-bold btn-sm shadow-sm" style="background-color: #00d284;" onclick="document.getElementById('chatFilterPopup').style.display='none';">Close Filters</button>
                </div>

                <div class="chat-items" id="chatListContainer">                      
                    <!-- Populated by AJAX -->
                </div>
                <!-- Only the requested 50-per-page Previous/Next navigation -->
                <div class="chat-pagination" id="chatPagination">
                    <button type="button" class="chat-page-button" id="chatPagePrevious" onclick="changeChatPage(-1)" disabled>
                        <i class="bi bi-chevron-left"></i> Previous
                    </button>
                    <div class="chat-pagination-label">
                        <strong id="chatPaginationPageText">Page 1 of 1</strong>
                        <small id="chatPaginationRange">0 of 0</small>
                    </div>
                    <button type="button" class="chat-page-button" id="chatPageNext" onclick="changeChatPage(1)" disabled>
                        Next <i class="bi bi-chevron-right"></i>
                    </button>
                </div>               
            </div>               
            
            <!-- Chat Window Panel -->
            <div class="chat-window" id="chatWindowArea">                 
                <div class="d-flex flex-column align-items-center justify-content-center h-100 bg-light text-muted">                      
                    <i class="bi bi-whatsapp mb-3" style="font-size: 48px; color: #00d284;"></i>                      
                    <h5>Select a conversation</h5>                 
                </div>               
            </div>   
            
            <!-- Lead Profile / Info Panel -->
            <div class="lead-info-panel" id="leadInfoPanel">
                <button class="d-md-none btn btn-light w-100 mb-4 border shadow-sm fw-bold text-secondary" onclick="closeLeadInfoMobile()">
                    <i class="bi bi-arrow-right"></i> Back to Chat
                </button>

                <div class="text-center mb-4">
                    <div class="avatar mx-auto mb-2" style="width:70px;height:70px;font-size:24px;" id="infoAvatar">U</div>
                    <h5 class="fw-bold mb-0" id="infoName">User Name</h5>
                    <span class="text-muted d-block mb-1" id="infoLeadId" style="font-size: 12px; font-weight: bold; letter-spacing: 0.5px;">#LD-0000</span>
                    <span class="badge bg-success" id="infoStatus">Active</span>
                </div>
                
                <div class="info-label">WhatsApp Number</div>
                <div class="info-value" id="infoPhone">+91 00000 00000</div>
                
                <div class="info-label">Date Added</div>
                <div class="info-value" id="infoDate">-</div>

                <div class="info-label">Lead Source</div>
                <div class="info-value" id="infoSource">WhatsApp</div>

                <!-- HIDDEN META AD SECTION -->
                <div class="info-label" id="infoAdLabel" style="display: none;">Meta Ad Clicked</div>
                <div class="info-value text-primary fw-bold" id="infoAdName" style="display: none;">-</div>

                <div class="info-label">Assigned Agent</div>
                <div class="info-value text-dark fw-bold" id="infoAssignedAgent">Unassigned</div>

                <div class="info-label">Lead Stage</div>
                <select id="infoLeadStatus" class="form-select form-select-sm shadow-none mb-3" style="font-size: 13px; border-color: #ddd; background-color: #f8f9fa; font-weight: 600;" onchange="updateLeadStatus(this.value)">
                    <option value="New Lead">New Lead</option>
                    <option value="Catalog Sharing">Catalog Sharing</option>
                    <option value="Follow Up">Follow Up</option>
                    <option value="Negotiation">Negotiation</option>
                    <option value="Sold">Sold</option>
                    <option value="Lost">Lost</option>
                </select>
                
                <div class="info-label">Tags</div>
                <div id="infoTags" class="mb-2"></div>
                
                <div class="d-flex gap-2 mt-3 mb-2">
                    <button id="tab-select-tag" class="btn-tag-toggle active flex-grow-1" onclick="toggleTagTab('select')">Select Tag</button>
                    <button id="tab-create-tag" class="btn-tag-toggle flex-grow-1" onclick="toggleTagTab('create')">New Tag</button>
                </div>

                <div id="selectTagView" class="input-group input-group-sm mt-2">
                    <select id="existingTagSelect" class="form-select shadow-none" style="font-size: 12px; border-color: #ddd;">
                        <option value="">Select a tag...</option>
                    </select>
                    <button class="btn btn-outline-secondary px-3" style="border-color: #ddd;" onclick="addTagFromDropdown()"><i class="bi bi-plus"></i></button>
                </div>

                <div id="createTagView" class="input-group input-group-sm mt-2" style="display: none;">
                    <input type="text" id="newTagInput" class="form-control shadow-none" placeholder="Type new tag..." style="font-size: 12px; border-color: #ddd;" autocomplete="off" onkeypress="if(event.key==='Enter') createNewTag()">
                    <button class="btn btn-outline-secondary px-3" style="border-color: #ddd;" onclick="createNewTag()"><i class="bi bi-plus"></i></button>
                </div>

                <!-- INBOX NOTES / REMINDERS: same lead_notes + lead_tasks used by Lead Profile. -->
                <section class="inbox-crm-tools" id="inboxCrmTools" aria-label="Lead notes and reminders">
                    <div class="inbox-crm-tool-tabs" role="tablist" aria-label="Notes and Tasks">
                        <button type="button" id="inboxCrmNotesTab" role="tab" aria-selected="true" aria-controls="inboxCrmNotesPanel" class="active" onclick="inboxCrmSwitchTab('notes')">Notes</button>
                        <button type="button" id="inboxCrmTasksTab" role="tab" aria-selected="false" aria-controls="inboxCrmTasksPanel" onclick="inboxCrmSwitchTab('tasks')">Tasks</button>
                    </div>
                    <div class="inbox-crm-tool-content" id="inboxCrmNotesPanel" role="tabpanel" aria-labelledby="inboxCrmNotesTab">
                        <form id="inboxCrmNoteForm" onsubmit="inboxCrmSaveNote(event)">
                            <textarea id="inboxCrmNoteInput" rows="2" maxlength="5000" placeholder="Add a note about this lead..." aria-label="Lead note" required></textarea>
                            <button type="submit" id="inboxCrmSaveNoteBtn" class="inbox-crm-note-save">Save Note</button>
                        </form>
                        <div id="inboxCrmNoteStatus" class="inbox-crm-tool-status" role="status" aria-live="polite"></div>
                        <div id="inboxCrmNotesList" class="inbox-crm-notes-list" aria-label="Recent notes"></div>
                    </div>
                    <div class="inbox-crm-tool-content" id="inboxCrmTasksPanel" role="tabpanel" aria-labelledby="inboxCrmTasksTab" hidden>
                        <form id="inboxCrmTaskForm" onsubmit="inboxCrmSaveTask(event)">
                            <input type="text" id="inboxCrmTaskTitle" maxlength="500" required placeholder="Task description..." aria-label="Task description">
                            <input type="datetime-local" id="inboxCrmTaskTime" required aria-label="Reminder date and time">
                            <div class="inbox-crm-quick-times" aria-label="Quick reminder times">
                                <button type="button" onclick="inboxCrmQuickReminder(1)">+1 Hour</button>
                                <button type="button" onclick="inboxCrmQuickReminder(3)">+3 Hours</button>
                                <button type="button" onclick="inboxCrmQuickReminder(6)">+6 Hours</button>
                                <button type="button" onclick="inboxCrmQuickReminder(24)">Tomorrow</button>
                                <button type="button" onclick="inboxCrmQuickReminder(48)">Day After</button>
                                <button type="button" onclick="inboxCrmQuickReminder(168)">1 Week</button>
                            </div>
                            <button type="submit" id="inboxCrmSaveTaskBtn" class="inbox-crm-reminder-save"><i class="bi bi-bell-fill" aria-hidden="true"></i> Set Reminder</button>
                        </form>
                        <div id="inboxCrmTaskStatus" class="inbox-crm-tool-status" role="status" aria-live="polite"></div>
                        <div class="inbox-crm-pending-heading">Pending Tasks</div>
                        <ul id="inboxCrmTaskList" class="inbox-crm-tasks-list"></ul>
                    </div>
                </section>

                <div class="info-label mt-4 border-top pt-3">Customer Journey <small class="text-muted" style="font-size: 10px;">(<?= htmlspecialchars($crm_timezone ?? 'Asia/Kolkata', ENT_QUOTES, 'UTF-8') ?>)</small></div>
                <div class="journey-timeline" id="infoJourney"></div>
            </div>
        </div>
        <!-- END INBOX MAIN VIEW -->

        <!-- MACROS MANAGER VIEW -->
        <div id="macrosManagerArea" style="display: none;">
            <div class="p-3 p-md-4 border-bottom bg-white d-flex justify-content-between align-items-center flex-shrink-0 shadow-sm flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <button class="d-md-none btn btn-light border shadow-sm text-secondary p-2" onclick="switchAppMode(event, 'live')" title="Back to Chat">
                        <i class="bi bi-arrow-left fs-5"></i>
                    </button>
                    <div>
                        <h4 class="mb-1 fw-bold text-dark fs-5 fs-md-4"><i class="bi bi-lightning-charge-fill text-warning me-2"></i> Quick Replies</h4>
                        <span class="text-muted d-none d-md-block" style="font-size: 13px;">Manage your custom slash (/) commands for fast typing.</span>
                    </div>
                </div>
                <button class="btn text-white fw-bold shadow-sm btn-sm btn-md-regular" style="background-color: #00d284;" onclick="openMacroModal()"><i class="bi bi-plus-lg me-1"></i> Add New Reply</button>
            </div>
            
            <div class="manager-scroll-body">
                <div class="card border-0 shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 bg-white">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%" class="ps-4">#</th>
                                    <th width="20%">Shortcut</th>
                                    <th width="40%">Message Content</th>
                                    <th width="15%">Created By</th>
                                    <th width="20%" class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="macrosTableBody">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END MACROS MANAGER -->

        <!-- TAGS MANAGER VIEW -->
        <div id="tagsManagerArea" style="display: none;">
            <div class="p-3 p-md-4 border-bottom bg-white d-flex justify-content-between align-items-center flex-shrink-0 shadow-sm flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <button class="d-md-none btn btn-light border shadow-sm text-secondary p-2" onclick="switchAppMode(event, 'live')" title="Back to Chat">
                        <i class="bi bi-arrow-left fs-5"></i>
                    </button>
                    <div>
                        <h4 class="mb-1 fw-bold text-dark fs-5 fs-md-4"><i class="bi bi-tags-fill text-primary me-2"></i> Manage Global Tags</h4>
                        <span class="text-muted d-none d-md-block" style="font-size: 13px;">Create and manage tags that can be applied to leads.</span>
                    </div>
                </div>
                <button class="btn text-white fw-bold shadow-sm btn-sm btn-md-regular" style="background-color: #0d6efd;" onclick="openTagModal()"><i class="bi bi-plus-lg me-1"></i> Add New Tag</button>
            </div>
            
            <div class="manager-scroll-body">
                <div class="card border-0 shadow-sm" style="max-width: 900px; margin: 0 auto;">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 bg-white">
                            <thead class="table-light">
                                <tr>
                                    <th width="10%" class="ps-4">#</th>
                                    <th width="45%">Tag Name</th>
                                    <th width="25%">Created By</th>
                                    <th class="text-end pe-4" width="20%">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="tagsTableBody">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END TAGS MANAGER -->

        <!-- TEMPLATES MANAGER VIEW -->
        <div id="templatesManagerArea" style="display: none;">
            <div class="p-3 p-md-4 border-bottom bg-white d-flex justify-content-between align-items-center flex-shrink-0 shadow-sm flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <button class="d-md-none btn btn-light border shadow-sm text-secondary p-2" onclick="switchAppMode(event, 'live')" title="Back to Chat">
                        <i class="bi bi-arrow-left fs-5"></i>
                    </button>
                    <div>
                        <h4 class="mb-1 fw-bold text-dark fs-5 fs-md-4"><i class="bi bi-whatsapp text-success me-2"></i> WhatsApp Templates</h4>
                        <span class="text-muted d-none d-md-block" style="font-size: 13px;">Sync and view your Approved Meta WhatsApp Templates.</span>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary btn-sm fw-bold" onclick="scpkMediaLibraryOpen('manage')"><i class="bi bi-images me-1"></i> Upload / Media Library</button>
                    <a href="https://business.facebook.com/wa/manage/message-templates/" target="_blank" class="btn btn-outline-secondary fw-bold shadow-sm btn-sm"><i class="bi bi-box-arrow-up-right me-1"></i> Dashboard</a>
                    <button class="btn text-white fw-bold shadow-sm btn-sm" style="background-color: #00d284;" onclick="forceSyncTemplates()"><i class="bi bi-arrow-repeat me-1"></i> Sync</button>
                </div>
            </div>
            
            <div class="manager-scroll-body">
                <div class="alert alert-info border-info shadow-sm" style="font-size: 13px;">
                    <i class="bi bi-info-circle-fill me-1"></i> <strong>Note:</strong> WhatsApp templates support Images, Buttons, and Variables. Design new templates directly in your Meta WhatsApp Manager and click "Sync" here.
                </div>
                <div class="card border-0 shadow-sm mt-3">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 bg-white">
                            <thead class="table-light">
                                <tr>
                                    <th width="25%" class="ps-4">Template Name</th>
                                    <th width="15%">Language</th>
                                    <th width="20%">Category</th>
                                    <th width="20%">Status</th>
                                    <th width="20%" class="text-end pe-4">Trigger Command</th>
                                </tr>
                            </thead>
                            <tbody id="templatesTableBody">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END TEMPLATES MANAGER -->
        <!-- Template inspector / send, isolated from all existing chat modals. -->
        <div class="modal fade" id="crmTemplateDetailModal" tabindex="-1" aria-labelledby="crmTemplateDetailTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header bg-light">
                        <div><h5 class="modal-title fw-bold" id="crmTemplateDetailTitle">Template details</h5>
                            <small id="crmTemplateMetaInfo" class="text-muted"></small></div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div id="crmTemplatePreview" class="crm-template-preview mb-3"></div>
                        <form id="crmTemplateSendForm" onsubmit="crmTemplateSend(event)">
                            <h6 class="fw-bold">Send approved template to existing CRM lead</h6>
                            <label for="crmTemplatePhone" class="form-label">Customer WhatsApp number</label>
                            <input id="crmTemplatePhone" class="form-control mb-2" type="tel" inputmode="tel" autocomplete="off" required placeholder="e.g. 919876543210" maxlength="18">
                            <div id="crmTemplateVariableFields" class="crm-template-fields"></div>
                            <p class="small text-muted mb-2">Only existing CRM chats can be selected. Variables and media must match the approved Meta template.</p>
                            <div id="crmTemplateSendStatus" class="crm-template-status" role="status" aria-live="polite"></div>
                            <div class="d-flex gap-2 justify-content-end mt-3">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                <button id="crmTemplateSendButton" class="btn btn-success" type="submit">Send Template</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!-- Shared Media Library popup; reusable on Inbox and future Lead Profile pages. -->
        <?php require __DIR__ . '/partials/scpk_media_gallery.php'; ?>

        <!-- SCPK Campaign Builder v2: separate from chat, bot, and gallery. -->
        <div id="broadcastManagerArea" style="display:none;flex-direction:column;overflow:auto;min-height:0;width:100%;height:100%;background:#f7f8fb;">
            <div class="p-3 p-md-4 bg-white border-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <h4 class="mb-1 fw-bold fs-5"><i class="bi bi-send-check me-2 text-primary"></i>Campaigns</h4>
                    <small class="text-muted">Audience → Approved Template → Test → Send → Analytics</small>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <button type="button" class="btn btn-outline-secondary btn-sm" onclick="scpkBroadcastRefresh()">Refresh</button>
                    <button type="button" class="btn btn-primary btn-sm" onclick="scpkWizardNew()">+ New campaign</button>
                </div>
            </div>
            <div class="scpk-wizard-body p-3 p-md-4">
                <div class="alert alert-warning small mb-3">Only existing CRM leads with documented, active WhatsApp Marketing opt-in are eligible. Drafts never send automatically. Each final send explicitly confirms up to 2 recipients. Leave this page at any time: saved drafts and send progress remain in the database.</div>
                <div id="scpkBroadcastStatus" class="alert alert-secondary small" role="status" aria-live="polite">Select New campaign or resume a saved draft.</div>

                <section class="card border-0 shadow-sm mb-3" id="scpkCampaignOverview">
                    <div class="card-body">
                        <h6 class="fw-bold">Saved campaigns</h6>
                        <div class="table-responsive"><table class="table table-sm align-middle scpk-wizard-table">
                            <thead><tr><th>Campaign</th><th>Template</th><th>State</th><th>Meta accepted</th><th>Actions</th></tr></thead>
                            <tbody id="scpkCampaignRows"><tr><td colspan="5" class="text-muted">Loading campaigns…</td></tr></tbody>
                        </table></div>
                    </div>
                </section>

                <section id="scpkWizardEditor" class="card border-0 shadow-sm" hidden>
                    <div class="card-body p-3 p-md-4">
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2">
                            <h5 class="fw-bold mb-0" id="scpkWizardHeading">New campaign</h5>
                            <small class="text-muted" id="scpkWizardSavedLabel">Not saved yet</small>
                        </div>
                        <div class="scpk-wizard-steps mb-4" id="scpkWizardSteps" aria-label="Campaign creation steps">
                            <button type="button" onclick="scpkWizardGoto(1)" data-step="1">1. Name</button>
                            <button type="button" onclick="scpkWizardGoto(2)" data-step="2">2. Audience</button>
                            <button type="button" onclick="scpkWizardGoto(3)" data-step="3">3. Template</button>
                            <button type="button" onclick="scpkWizardGoto(4)" data-step="4">4. Test</button>
                            <button type="button" onclick="scpkWizardGoto(5)" data-step="5">5. Send</button>
                            <button type="button" onclick="scpkWizardGoto(6)" data-step="6">6. Analytics</button>
                        </div>
                        <div class="scpk-wizard-panel" data-step-panel="1">
                            <h6 class="fw-bold">Campaign name</h6>
                            <label class="form-label small" for="scpkWizardName">Name</label>
                            <input class="form-control" id="scpkWizardName" maxlength="120" placeholder="e.g. SCPK Winter Wholesale Collection" autocomplete="off">
                            <p class="small text-muted mt-2">This name is internal to your CRM. Saving the name creates a draft, not a WhatsApp send.</p>
                        </div>
                        <div class="scpk-wizard-panel" data-step-panel="2" hidden>
                            <h6 class="fw-bold">Choose campaign audience</h6>
                            <div class="d-flex gap-3 flex-wrap mb-3">
                                <label><input type="radio" name="scpkAudienceSource" value="filters" checked onchange="scpkWizardAudienceSource()"> CRM filters</label>
                                <label><input type="radio" name="scpkAudienceSource" value="csv" onchange="scpkWizardAudienceSource()"> Upload CSV</label>
                            </div>
                            <div id="scpkWizardCSVPanel" hidden>
                                <label class="form-label small" for="scpkWizardCsvInput">CSV containing WhatsApp numbers including country code</label>
                                <input class="form-control" id="scpkWizardCsvInput" type="file" accept=".csv,text/csv,text/plain" onchange="scpkWizardCSVFileChanged(event)">
                                <div class="form-text">Columns: whatsapp_number, phone, mobile, number, wa_number. Max 2,000 unique numbers. No message is sent during import.</div>
                                <div id="scpkWizardCSVStatus" class="small mt-2"></div>
                            </div>
                            <p class="small text-muted mt-2">These filters can also narrow a CSV audience. Leave blank to include all CRM contacts with verified marketing opt-in.</p>
                            <div class="row g-3">
                                <div class="col-12 col-sm-6"><label for="scpkWizardTag" class="form-label small">Tag</label><select id="scpkWizardTag" class="form-select"><option value="">All tags</option></select></div>
                                <div class="col-12 col-sm-6"><label for="scpkWizardStage" class="form-label small">Lead stage</label><select id="scpkWizardStage" class="form-select"><option value="">All stages</option></select></div>
                                <div class="col-12 col-sm-6"><label for="scpkWizardStatusFilter" class="form-label small">Lead status</label><select id="scpkWizardStatusFilter" class="form-select"><option value="">All statuses</option></select></div>
                                <div class="col-12 col-sm-6"><label for="scpkWizardTemperature" class="form-label small">Lead temperature</label><select id="scpkWizardTemperature" class="form-select"><option value="">All temperatures</option></select><small id="scpkWizardTempHint" class="text-muted"></small></div>
                                <div class="col-12 col-sm-6"><label for="scpkWizardAgent" class="form-label small">Assigned agent</label><select id="scpkWizardAgent" class="form-select"><option value="0">All agents</option></select></div>
                            </div>
                            <div class="d-flex flex-wrap gap-2 mt-3"><button type="button" class="btn btn-outline-primary btn-sm" onclick="scpkWizardPreviewAudience()">Preview eligible audience</button><strong id="scpkWizardAudienceCount" class="small align-self-center"></strong></div>
                            <div class="table-responsive mt-2"><table class="table table-sm"><tbody id="scpkWizardAudiencePreview"></tbody></table></div>
                            <details class="mt-3"><summary class="fw-semibold text-primary">Record verified marketing consent for a customer</summary>
                                <form class="mt-2 border rounded p-3" onsubmit="scpkBroadcastSaveConsent(event)">
                                    <input id="scpkConsentPhone" type="tel" class="form-control form-control-sm mb-2" required placeholder="WhatsApp number with country code">
                                    <select id="scpkConsentSource" class="form-select form-select-sm mb-2" required><option value="">Actual consent source</option><option value="website_form">Website opt-in</option><option value="whatsapp_chat">Explicit WhatsApp opt-in</option><option value="signed_form">Signed consent</option><option value="other">Other documented proof</option></select>
                                    <textarea class="form-control form-control-sm mb-2" id="scpkConsentEvidence" rows="2" minlength="8" maxlength="500" required placeholder="Reference/evidence, not assumed opt-in"></textarea>
                                    <button class="btn btn-primary btn-sm" type="submit">Record consent</button>
                                    <button class="btn btn-outline-danger btn-sm" type="button" onclick="scpkBroadcastRevokeConsent()">Mark opted out</button>
                                </form>
                            </details>
                        </div>
                        <div class="scpk-wizard-panel" data-step-panel="3" hidden>
                            <h6 class="fw-bold">Select an approved MARKETING template</h6>
                            <select class="form-select mb-2" id="scpkCampaignTemplate" onchange="scpkBroadcastTemplateChanged()"><option value="">Loading templates…</option></select>
                            <div class="scpk-wizard-preview border rounded p-3 mb-3" id="scpkCampaignTemplatePreview" aria-label="Template preview">Select template to see approved content.</div>
                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="scpkBroadcastChooseMedia()"><i class="bi bi-images"></i> Choose header image/video from gallery</button>
                            <div class="small mt-2" id="scpkCampaignMediaLabel">No media header required</div>
                            <p class="small text-muted mt-2">Only Meta-approved static Marketing templates are supported for bulk sends. The gallery remains a separate reusable module.</p>
                        </div>
                        <div class="scpk-wizard-panel" data-step-panel="4" hidden>
                            <h6 class="fw-bold">Send one test template first</h6>
                            <p class="small text-muted">The test number must be an existing CRM lead with valid marketing opt-in. Test sends are real, may be paid, and do not turn off the human-agent bot rule.</p>
                            <label for="scpkWizardTestNumber" class="form-label small">Test WhatsApp number (country code required)</label>
                            <input class="form-control mb-3" id="scpkWizardTestNumber" type="tel" inputmode="tel" placeholder="91XXXXXXXXXX">
                            <button type="button" class="btn btn-primary" onclick="scpkWizardSendTest()">Send single test to this number</button>
                            <div class="small mt-3" id="scpkWizardTestStatus">No test has been attempted yet.</div>
                        </div>
                        <div class="scpk-wizard-panel" data-step-panel="5" hidden>
                            <h6 class="fw-bold">Final review and sending</h6>
                            <div id="scpkWizardReview" class="border rounded p-3 mb-3 small">Save audience and template, then prepare the final campaign.</div>
                            <div class="d-flex gap-2 flex-wrap mb-3">
                                <button type="button" class="btn btn-outline-primary" onclick="scpkWizardPrepare()">Confirm &amp; prepare final audience</button>
                                <button type="button" class="btn btn-success" id="scpkWizardSendBtn" onclick="scpkWizardSendBatch()">Send next 2</button>
                                <button type="button" class="btn btn-primary" id="scpkWizardAutoSendBtn" onclick="scpkWizardStartRun()">Send up to 40 (keep tab open)</button>
                                <button type="button" class="btn btn-outline-secondary" onclick="scpkWizardStopRun()">Stop sending</button>
                                <button type="button" class="btn btn-outline-danger" onclick="scpkWizardPause()">Pause</button>
                                <button type="button" class="btn btn-outline-secondary" onclick="scpkWizardResume()">Resume paused</button>
                            </div>
                            <div class="small text-muted">Final sending begins only after explicit confirmation. <b>Send up to 40</b> processes controlled 2-person batches while this page remains active; navigating away stops after any in-flight batch. No background or Cron sending. Never press send twice if a request was interrupted—check analytics first.</div>
                        </div>
                        <div class="scpk-wizard-panel" data-step-panel="6" hidden>
                            <div class="d-flex justify-content-between flex-wrap gap-2"><h6 class="fw-bold">Campaign analytics</h6><button class="btn btn-outline-secondary btn-sm" type="button" onclick="scpkWizardAnalytics()">Refresh statuses</button></div>
                            <div class="scpk-wizard-metrics" id="scpkWizardMetrics"><div class="text-muted">Select a saved campaign.</div></div>
                            <div class="mt-3 border rounded p-3">
                                <label class="form-label small" for="scpkWizardEstimatedRate">Optional estimated Marketing rate per delivered message (₹, manually entered)</label>
                                <input class="form-control form-control-sm" style="max-width:250px" id="scpkWizardEstimatedRate" type="number" step="0.00001" min="0" max="100" placeholder="No rate supplied">
                                <button type="button" class="btn btn-outline-primary btn-sm mt-2" onclick="scpkWizardSaveRate()">Save estimate rate</button>
                                <p class="small text-muted mb-0 mt-2">Estimated spend = known delivered messages × your rate. This is not the Meta invoice; actual pricing varies. Read receipts may be unavailable.</p>
                            </div>
                        </div>
                        <div class="border-top mt-4 pt-3 d-flex justify-content-between gap-2 flex-wrap">
                            <div class="d-flex gap-2">
                                <button class="btn btn-outline-secondary btn-sm" type="button" onclick="scpkWizardPrev()">Back</button>
                                <button class="btn btn-outline-primary btn-sm" type="button" onclick="scpkWizardSaveClick()">Save draft</button>
                                <button class="btn btn-outline-secondary btn-sm" type="button" onclick="scpkWizardOverview()">Campaign list</button>
                            </div>
                            <button class="btn btn-primary btn-sm" type="button" onclick="scpkWizardNext()">Save &amp; Next</button>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <!-- META ADS MANAGER VIEW -->
        <div id="metaAdsManagerArea" style="display: none;">
            <div class="p-3 p-md-4 border-bottom bg-white d-flex justify-content-between align-items-center flex-shrink-0 shadow-sm flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <button class="d-md-none btn btn-light border shadow-sm text-secondary p-2" onclick="switchAppMode(event, 'live')" title="Back to Chat">
                        <i class="bi bi-arrow-left fs-5"></i>
                    </button>
                    <div>
                        <h4 class="mb-1 fw-bold text-dark fs-5 fs-md-4"><i class="bi bi-megaphone text-primary me-2"></i> Meta Ads</h4>
                        <span class="text-muted d-none d-md-block" style="font-size: 13px;">Sync and view your active Click-to-WhatsApp Ads from Meta.</span>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-primary fw-bold shadow-sm btn-sm" onclick="forceSyncMetaAds()"><i class="bi bi-arrow-repeat me-1"></i> Sync Ads from Meta</button>
                </div>
            </div>
            
            <div class="manager-scroll-body">
                <div class="alert alert-info border-info shadow-sm" style="font-size: 13px;">
                    <i class="bi bi-info-circle-fill me-1"></i> <strong>Note:</strong> Make sure you have updated the Ad Account ID and the token with "ads_read" permission in settings.
                </div>
                <div class="card border-0 shadow-sm mt-3">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 bg-white">
                            <thead class="table-light">
                                <tr>
                                    <th width="14%" class="ps-4">Video / Image</th>
                                    <th width="16%">Ad ID</th>
                                    <th width="25%">Campaign Name</th>
                                    <th width="30%">Ad Name</th>
                                    <th width="15%" class="text-end pe-4">Status</th>
                                </tr>
                            </thead>
                            <tbody id="metaAdsTableBody">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- END META ADS MANAGER -->

    </div> 

    <!-- Lightbox -->
    <div id="imageLightbox" onclick="this.style.display='none'">
        <span class="close-btn">&times;</span>
        <img id="lightboxImg" src="">
    </div>

    <!-- Meta ad creative media viewer: read-only; separate from chat image lightbox. -->
    <div class="modal fade" id="crmAdMediaModal" tabindex="-1" aria-labelledby="crmAdMediaTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="crmAdMediaTitle">Meta Ad Creative</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center" id="crmAdMediaModalBody"></div>
            </div>
        </div>
    </div>

    <!-- MACRO MODAL -->
    <div class="modal fade" id="macroModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold" id="macroModalTitle"><i class="bi bi-pencil-square text-primary me-2"></i> Add Quick Reply</h5>
                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <input type="hidden" id="macroId">
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Shortcut Command</label>
                        <input type="text" class="form-control shadow-none" id="macroShortcut" placeholder="e.g. /kurti">
                        <div class="form-text" style="font-size: 11px;">Must start with a single slash (/).</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold" style="font-size: 13px;">Full Message</label>
                        <textarea class="form-control shadow-none" id="macroMessage" rows="4" placeholder="Type the complete message here..."></textarea>
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold" style="font-size: 13px;">Attach Image (Optional)</label>
                        <input type="file" class="form-control shadow-none form-control-sm" id="macroImageInput" accept="image/*" onchange="handleMacroImage(event)">
                        
                        <div id="macroImagePreviewContainer" style="display:none; margin-top: 10px; position: relative; width: 120px;">
                            <img id="macroImagePreview" src="" style="width: 100%; height: 100px; border-radius: 6px; border: 1px solid #ddd; object-fit: cover;">
                            <i class="bi bi-x-circle-fill text-danger bg-white rounded-circle shadow-sm" style="position: absolute; top: -8px; right: -8px; cursor: pointer; font-size: 1.2rem; line-height: 1;" onclick="removeMacroImage()"></i>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light border-top-0">
                    <button type="button" class="btn btn-secondary btn-sm px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary btn-sm px-4" onclick="saveMacro()">Save Reply</button>
                </div>
            </div>
        </div>
    </div>

    <!-- TAG MODAL -->
    <div class="modal fade" id="tagModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold" id="tagModalTitle"><i class="bi bi-tag text-primary me-2"></i> Add Tag</h5>
                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <input type="hidden" id="tagId">
                    <div class="mb-0">
                        <label class="form-label fw-bold" style="font-size: 13px;">Tag Name</label>
                        <input type="text" class="form-control shadow-none" id="tagName" placeholder="e.g. High Priority" onkeypress="if(event.key==='Enter') saveGlobalTag()">
                    </div>
                </div>
                <div class="modal-footer bg-light border-top-0">
                    <button type="button" class="btn btn-secondary btn-sm px-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary btn-sm px-4" onclick="saveGlobalTag()">Save Tag</button>
                </div>
            </div>
        </div>
    </div>

    <?php
        // Scoped to new gallery/broadcast POST actions; no changes to legacy forms.
        if (empty($_SESSION['scpk_action_csrf'])) {
            $_SESSION['scpk_action_csrf'] = bin2hex(random_bytes(24));
        }
    ?>
    <script>
        const APP_CONFIG = {
            baseUrl: '<?= rtrim(BASE_URL, '/') ?>/',
            currentAgentName: '<?= htmlspecialchars(addslashes($_SESSION['name'] ?? "Admin")) ?>',
            currentUserRole: '<?= strtolower($_SESSION['role'] ?? "admin") ?>',
            scpkActionToken: <?= json_encode($_SESSION['scpk_action_csrf'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>,
            crmAgents: <?= json_encode($agents ?? []) ?>,
            appMode: '<?= $app_mode ?? "live" ?>',
            // Stage 5: display formatting only; AJAX timestamps remain in UTC.
            crmTimezone: <?= json_encode($crm_timezone ?? 'Asia/Kolkata', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>
        };
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= BASE_URL ?>assets/js/inbox.js?v=<?= time() ?>"></script>
    <script src="<?= BASE_URL ?>assets/js/scpk_media_gallery.js?v=<?= time() ?>"></script>
    <script src="<?= BASE_URL ?>assets/js/scpk_broadcasts.js?v=<?= time() ?>"></script>
</body> 
</html>