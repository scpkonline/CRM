<?php
// Preferences are now saved centrally by SettingsController::preferences().
// Keep existing session handling for direct view compatibility.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Preferences') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    
    <!-- DARK MODE SCRIPT -->
    <script>
        // Check cookie directly via JS to avoid screen flash
        if (document.cookie.includes('theme=dark')) {
            document.documentElement.classList.add('dark-theme');
        }
    </script>

    <style>          
        body { 
            background-color: #f8fafc; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif; 
            overflow-x: hidden; 
            color: #334155; 
        }                   
        .main-content { 
            margin-left: 250px; 
            padding: 30px 40px; 
            min-height: 100vh; 
            transition: all 0.3s ease; 
        }          
        .settings-container { 
            display: flex; 
            gap: 25px; 
            align-items: flex-start; 
        }
        .settings-menu { 
            width: 260px; 
            background: #fff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0; 
            padding: 10px 0; 
            flex-shrink: 0; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.02); 
        }
        .menu-item { 
            display: flex; 
            align-items: center; 
            padding: 12px 20px; 
            color: #475569; 
            text-decoration: none; 
            font-weight: 500; 
            font-size: 14px; 
            border-left: 3px solid transparent; 
            transition: 0.2s;
        }
        .menu-item:hover { 
            background-color: #f8fafc; 
            color: #3b82f6; 
        }
        .menu-item.active { 
            background-color: #eff6ff; 
            color: #3b82f6; 
            border-left-color: #3b82f6; 
            font-weight: 600; 
        }
        .menu-item i { 
            font-size: 18px; 
            margin-right: 12px; 
            width: 20px; 
            text-align: center; 
        }
        .settings-panel { 
            flex-grow: 1; 
            background: #fff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0; 
            padding: 30px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.02); 
        }
        .panel-title { 
            font-size: 18px; 
            font-weight: 600; 
            border-bottom: 1px solid #e2e8f0; 
            padding-bottom: 15px; 
            margin-bottom: 25px; 
            color: #0f172a; 
        }
        .form-label { 
            font-size: 13px; 
            font-weight: 600; 
            color: #475569; 
            margin-bottom: 6px; 
        }
        .form-control, .form-select { 
            border-radius: 6px; 
            border: 1px solid #cbd5e1; 
            padding: 10px 15px; 
            font-size: 14px; 
            box-shadow: none; 
        }
        .form-control:focus, .form-select:focus { 
            border-color: #3b82f6; 
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); 
        }
        .btn-save { 
            background-color: #3b82f6; 
            color: #fff; 
            border: none; 
            padding: 10px 24px; 
            font-weight: 600; 
            border-radius: 6px; 
            transition: 0.2s; 
        }
        .btn-save:hover { 
            background-color: #2563eb; 
        }

        .settings-mobile-toggle {
            display: none;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px 20px;
            font-weight: 600;
            color: #0f172a;
            cursor: pointer;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }

        @media (max-width: 768px) { 
            .main-content { 
                margin-left: 0 !important; 
                margin-top: 70px !important;
                padding: 15px !important; 
            } 
            .settings-container { 
                flex-direction: column; 
                gap: 15px;
            } 
            .settings-menu { 
                width: 100%; 
                border: none;
                box-shadow: none;
                background: transparent;
                padding: 0;
            } 
            .settings-mobile-toggle {
                display: flex;
            }
            .settings-nav-links {
                display: none;
                background: #fff;
                border-radius: 8px;
                border: 1px solid #e2e8f0;
                margin-top: 8px;
                overflow: hidden;
                box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            }
            .settings-nav-links.show {
                display: block;
            }
            .settings-panel { 
                width: 100%; 
            } 
        }

        html.dark-theme body { background-color: #121212 !important; color: #e0e0e0 !important; }
        html.dark-theme .card, html.dark-theme .bg-white, html.dark-theme .settings-menu, html.dark-theme .settings-panel, html.dark-theme .main-content, html.dark-theme .settings-nav-links, html.dark-theme .settings-mobile-toggle { background-color: #1e1e1e !important; border-color: #333 !important; color: #e0e0e0 !important; }
        html.dark-theme .form-control, html.dark-theme .form-select { background-color: #2d2d2d !important; border-color: #444 !important; color: #fff !important; }
        html.dark-theme .text-muted, html.dark-theme .text-secondary, html.dark-theme .panel-title { color: #a0aab5 !important; }
        html.dark-theme .menu-item { color: #e0e0e0 !important; }
        html.dark-theme .menu-item:hover, html.dark-theme .menu-item.active { background-color: #2d2d2d !important; color: #60a5fa !important; border-color: #333 !important; }
        html.dark-theme .border-bottom { border-color: #333 !important; }
    </style> 
</head> 
<body>     
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content">
        
        <?php if(isset($_SESSION['success_msg'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success_msg'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success_msg']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_msg'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?= htmlspecialchars((string)$_SESSION['error_msg'], ENT_QUOTES, 'UTF-8') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error_msg']); ?>
        <?php endif; ?>

        <div class="settings-container">
            <div class="settings-menu">
                <div class="settings-mobile-toggle" onclick="toggleSettingsMenu()">
                    <span><i class="bi bi-gear text-primary me-2"></i> Settings Menu</span>
                    <i class="bi bi-list fs-5 text-secondary"></i>
                </div>

                <div class="settings-nav-links" id="settingsNavLinks">
                    <a href="<?= BASE_URL ?>settings/profile" class="menu-item">
                        <i class="bi bi-person-badge me-2"></i> Edit Profile
                    </a>
                    
                    <?php if(strtoupper($user_role ?? 'SALES') === 'ADMIN'): ?>
                    <a href="<?= BASE_URL ?>settings/team" class="menu-item">
                        <i class="bi bi-people me-2"></i> Team Management
                    </a>
                    <a href="<?= BASE_URL ?>settings/integrations" class="menu-item">
                        <i class="bi bi-plug me-2"></i> Integrations & API
                    </a>
                    <?php endif; ?>

                    <a href="<?= BASE_URL ?>settings/notifications" class="menu-item">
                        <i class="bi bi-bell me-2"></i> Notifications
                    </a>
                    <a href="<?= BASE_URL ?>settings/preferences" class="menu-item active">
                        <i class="bi bi-palette me-2"></i> Preferences
                    </a>
                </div>
            </div>

            <div class="settings-panel">
                <h3 class="panel-title text-primary"><i class="bi bi-palette me-2"></i> System Preferences</h3>
                
                <!-- Action blank chhod diya hai taaki isi page par submit ho -->
                <form action="" method="POST">
                    <input type="hidden" name="preferences_csrf" value="<?= htmlspecialchars($preferences_csrf ?? '', ENT_QUOTES, 'UTF-8') ?>">
                    <div class="row mt-3">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Timezone</label>
                            <select class="form-select" name="timezone" <?= empty($can_change_timezone) ? 'disabled' : '' ?>>
                                <option value="Asia/Kolkata" <?= (($preferences_timezone ?? 'Asia/Kolkata') === 'Asia/Kolkata') ? 'selected' : '' ?>>Asia/Kolkata (IST)</option>
                                <option value="UTC" <?= (($preferences_timezone ?? 'Asia/Kolkata') === 'UTC') ? 'selected' : '' ?>>UTC (Standard)</option>
                            </select>
                            <div class="form-text">Company-wide timezone (set by Admin). The database stays in UTC; other CRM screens will use this setting as their timezone updates are installed.</div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">UI Theme</label>
                            <select class="form-select" name="theme">
                                <option value="light" <?= (!isset($_COOKIE['theme']) || $_COOKIE['theme'] === 'light') ? 'selected' : '' ?>>Light Mode (Default)</option>
                                <option value="dark" <?= (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') ? 'selected' : '' ?>>Dark Mode</option>
                            </select>
                        </div>
                    </div>
                    <div class="text-end">
                        <button type="submit" class="btn-save">Apply Changes</button>
                    </div>
                </form>

                <!-- ========================================== -->
                <!-- NAYA CACHE CLEAR SECTION YAHAN ADD KIYA HAI  -->
                <!-- ========================================== -->
                <div class="mt-5 border-top pt-4">
                    <h5 class="text-danger fw-bold mb-3"><i class="bi bi-exclamation-triangle-fill me-2"></i> System Troubleshooting</h5>
                    <p class="text-muted" style="font-size: 13px;">
                        Agar aapko purana data dikh raha hai, tags update nahi ho rahe, ya inbox mein naye agents assign nahi ho rahe, toh is button ka use karein. Yeh poore CRM ka kachra (cache) saaf karke naya data layega.
                    </p>
                    <button class="btn btn-warning fw-bold shadow-sm text-dark" onclick="globalHardReset()">
                        <i class="bi bi-arrow-clockwise me-1"></i> Clear Entire CRM Cache & Sync
                    </button>
                </div>

            </div>
        </div>
    </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleSettingsMenu() {
            var navLinks = document.getElementById('settingsNavLinks');
            navLinks.classList.toggle('show');
        }

        // ==========================================
        // DEEP CRM CACHE CLEAR ENGINE (NAYA CODE)
        // ==========================================
        window.globalHardReset = function() {
            if(confirm("Kya aap poore CRM ka cache clear karna chahte hain? Isse system ekdum fresh state mein aa jayega aur latest data fetch karega.")) {
                
                // 1. Saara Local aur Session Storage uda do
                localStorage.clear();
                sessionStorage.clear();
                
                // 2. Deep Browser Cache clear karo
                if ('caches' in window) {
                    caches.keys().then(function(names) {
                        for (let name of names) {
                            caches.delete(name);
                        }
                    });
                }
                
                alert("CRM Cache poori tarah saaf ho gaya hai! System ab reload hoga.");
                
                // 3. Poore CRM ko force reload karo
                window.location.href = window.location.pathname + '?v=' + new Date().getTime();
            }
        }
    </script>
</body> 
</html>