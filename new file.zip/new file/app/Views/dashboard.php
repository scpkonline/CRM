<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Dashboard') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    
    <style>          
        body { 
            background-color: #f8fafc; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif; 
            overflow-x: hidden; 
            color: #334155; 
        }          
        
        .main-content { 
            margin-left: 250px; 
            padding: 30px 40px; 
            transition: all 0.3s ease; 
            min-height: 100vh; 
        }          
        
        .main-content.expanded { 
            margin-left: 80px; 
        }
        
        .page-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 25px; 
        }
        
        .page-title { 
            margin: 0; 
            font-size: 22px; 
            font-weight: 600; 
            color: #0f172a; 
            letter-spacing: -0.5px; 
        }
        
        .user-profile { 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            color: #475569; 
            font-size: 13px; 
            font-weight: 500; 
        }
        
        .avatar-circle { 
            width: 36px; 
            height: 36px; 
            background: #3b82f6; 
            color: #fff; 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-weight: bold; 
            font-size: 14px; 
        }

        /* Professional Metric Cards */
        .metric-card { 
            background: #fff; 
            border-radius: 8px; 
            padding: 22px; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.05); 
            border: 1px solid #e2e8f0; 
            display: flex; 
            align-items: center; 
            gap: 18px; 
        }
        
        .metric-icon { 
            width: 48px; 
            height: 48px; 
            border-radius: 8px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-size: 22px; 
            flex-shrink: 0; 
        }
        
        .bg-purple-light { background-color: #f5f3ff; color: #6366f1; }
        .bg-green-light { background-color: #f0fdf4; color: #22c55e; }
        .bg-orange-light { background-color: #fffbeb; color: #eab308; }
        .bg-blue-light { background-color: #eff6ff; color: #3b82f6; }

        .metric-title { 
            font-size: 12px; 
            font-weight: 600; 
            color: #64748b; 
            text-transform: uppercase; 
            letter-spacing: 0.5px; 
            margin-bottom: 4px; 
        }
        
        .metric-value { 
            font-size: 28px; 
            font-weight: 700; 
            color: #0f172a; 
            line-height: 1; 
        }

        /* Analytics Widget Styling */
        .widget-card {
            background: #fff;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .widget-header {
            padding: 16px 20px;
            border-bottom: 1px solid #f1f5f9;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            border-radius: 8px 8px 0 0;
        }
        .widget-title {
            font-size: 14px;
            font-weight: 700;
            color: #1e293b;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .widget-body {
            padding: 12px 18px;
            overflow-y: auto;
            max-height: 330px;
            flex-grow: 1;
        }
        .widget-body.p-0 { padding: 0 !important; }
        
        .widget-body::-webkit-scrollbar { width: 4px; }
        .widget-body::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 4px; }

        .widget-list-item {
            padding: 10px 0;
            border-bottom: 1px solid #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .widget-list-item:last-child {
            border-bottom: none;
        }

        /* Modern Matrix Table */
        .card-custom { 
            background: #fff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.05); 
            overflow: hidden; 
        }
        
        .card-header-custom { 
            padding: 20px 24px; 
            border-bottom: 1px solid #e2e8f0; 
            background: #fff; 
        }
        
        .card-title-custom { 
            margin: 0; 
            font-size: 16px; 
            font-weight: 600; 
            color: #0f172a; 
        }
        
        .table { margin-bottom: 0; }
        
        .table th { 
            background-color: #f8fafc; color: #475569; font-weight: 600; 
            font-size: 12px; padding: 14px 20px; border-bottom: 1px solid #e2e8f0; 
            text-transform: uppercase; letter-spacing: 0.5px; border-top: none; white-space: nowrap;
        }
        
        .table td { 
            vertical-align: middle; padding: 16px 20px; border-bottom: 1px solid #f1f5f9; 
            font-size: 14px; white-space: nowrap;
        }
        
        .table tbody tr:hover { background-color: #f8fafc; }
        
        .contact-name { font-weight: 600; color: #1e293b; display: flex; align-items: center; gap: 10px; font-size: 13px; }
        .contact-name i { color: #94a3b8; font-size: 16px; }
        
        .count-val { font-weight: 600; font-size: 14px; color: #0f172a; }
        .count-zero { color: #cbd5e1; font-weight: 400; }

        @media (max-width: 768px) {
            .main-content { margin-left: 0 !important; padding: 15px !important; }
            .metric-card { padding: 16px; gap: 12px; flex-direction: column; text-align: center; }
            .metric-value { font-size: 24px; }
            .metric-icon { width: 40px; height: 40px; font-size: 18px; }
            .card-header-custom { padding: 15px; }
        }
    </style>
</head>
<body>     
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content" id="mainContent">         
        
        <!-- Page Header -->
        <div class="page-header">
            <div class="d-flex align-items-center gap-3">
                <h2 class="page-title">Overview</h2>
                <div class="text-muted" style="font-size: 11px; display: flex; align-items: center; gap: 5px;">
                    <i class="bi bi-arrow-clockwise"></i> Auto-refresh ON
                </div>
            </div>
            <div class="user-profile">
                <span>Welcome back, <strong><?= htmlspecialchars($user_name ?? 'User') ?></strong> <span class="badge bg-secondary ms-1"><?= htmlspecialchars($user_role ?? 'SALES') ?></span></span>
                <div class="avatar-circle"><?= strtoupper(substr($user_name ?? 'U', 0, 1)) ?></div>
            </div>
        </div>

        <!-- 1. Top 4 Metric Cards -->
        <div class="row g-3 mb-4" id="topMetrics">
            <div class="col-6 col-md-3">
                <div class="metric-card h-100">
                    <div class="metric-icon bg-purple-light"><i class="bi bi-globe"></i></div>
                    <div>
                        <div class="metric-title">Website Leads</div>
                        <div class="metric-value"><?= $website_leads ?? 0 ?></div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="metric-card h-100">
                    <div class="metric-icon bg-green-light"><i class="bi bi-whatsapp"></i></div>
                    <div>
                        <div class="metric-title">WhatsApp Leads</div>
                        <div class="metric-value"><?= $whatsapp_leads ?? 0 ?></div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="metric-card h-100">
                    <div class="metric-icon bg-orange-light"><i class="bi bi-activity"></i></div>
                    <div>
                        <div class="metric-title">Active Leads</div>
                        <div class="metric-value"><?= $active_leads ?? 0 ?></div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="metric-card h-100">
                    <div class="metric-icon bg-blue-light"><i class="bi bi-people-fill"></i></div>
                    <div>
                        <div class="metric-title">Total Leads</div>
                        <div class="metric-value"><?= $total_leads ?? 0 ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. Middle Section: 3 Powerful Analytics Widgets -->
        <div class="row g-3 mb-4" id="middleWidgets">
            
            <!-- WIDGET 1: PENDING LEADS BREAKDOWN -->
            <div class="col-12 col-lg-4">
                <div class="widget-card">
                    <div class="widget-header">
                        <h6 class="widget-title">
                            <i class="bi bi-hourglass-split text-danger"></i> Pending Leads (Lead Mgt)
                        </h6>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill px-2 py-1" style="font-size: 11px; font-weight: 700;">
                            <?= $totalPendingLeads ?? 0 ?> Total
                        </span>
                    </div>
                    
                    <div class="widget-body p-0">
                        <?php if(empty($pendingBreakdown)): ?>
                            <div class="text-center text-muted py-4">
                                <i class="bi bi-check2-circle text-success fs-2 d-block mb-2"></i>
                                <span class="small fw-bold">All caught up! No pending leads. 🎉</span>
                            </div>
                        <?php else: ?>
                            <!-- Column Headers -->
                            <div class="d-flex justify-content-between text-muted px-3 py-2 border-bottom" style="font-size: 10.5px; font-weight: 700; text-transform: uppercase; background: #f8fafc;">
                                <div style="width: 45%;">Agent</div>
                                <div class="d-flex justify-content-between" style="width: 55%;">
                                    <span class="text-center" style="width: 30%;" title="WhatsApp"><i class="bi bi-whatsapp text-success"></i> WA</span>
                                    <span class="text-center" style="width: 30%;" title="Website"><i class="bi bi-globe text-primary"></i> WEB</span>
                                    <span class="text-center" style="width: 40%;">TOTAL</span>
                                </div>
                            </div>

                            <!-- Agent Rows -->
                            <?php foreach($pendingBreakdown as $agent): ?>
                                <?php 
                                    $agentName = htmlspecialchars($agent['agent_name']); 
                                    $initial = strtoupper(substr($agentName, 0, 1));
                                ?>
                                <div class="widget-list-item px-3">
                                    <div class="d-flex align-items-center gap-2" style="width: 45%;">
                                        <div class="bg-light text-primary fw-bold rounded-circle d-flex align-items-center justify-content-center border" style="width: 26px; height: 26px; font-size: 11px; flex-shrink: 0;">
                                            <?= $initial ?>
                                        </div>
                                        <span class="fw-bold text-dark text-truncate" style="font-size: 13px;">
                                            <?= $agentName ?>
                                        </span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center" style="width: 55%; font-size: 12.5px; font-weight: 700;">
                                        <span class="text-center text-success" style="width: 30%;">
                                            <?= $agent['wa'] > 0 ? $agent['wa'] : '<span class="text-muted fw-normal" style="opacity:0.5;">-</span>' ?>
                                        </span>
                                        <span class="text-center text-primary" style="width: 30%;">
                                            <?= $agent['web'] > 0 ? $agent['web'] : '<span class="text-muted fw-normal" style="opacity:0.5;">-</span>' ?>
                                        </span>
                                        <span class="text-center" style="width: 40%;">
                                            <span class="badge bg-light text-dark border px-2 py-1" style="font-size: 11px;">
                                                <?= $agent['total'] ?> Leads
                                            </span>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- WIDGET 2: LAST 10 DAYS INTAKE -->
            <div class="col-12 col-lg-4">
                <div class="widget-card">
                    <div class="widget-header">
                        <h6 class="widget-title">
                            <i class="bi bi-calendar3 text-primary"></i> Last 10 Days Intake
                            <small class="text-muted" style="font-size: 10px;">(<?= htmlspecialchars($displayTimezone ?? 'Asia/Kolkata') ?>)</small>
                        </h6>
                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-2 py-1" style="font-size: 11px; font-weight: 700;">
                            <?= $total10DaysLeads ?? 0 ?> Total
                        </span>
                    </div>
                    
                    <div class="widget-body">
                        <?php if(!empty($dailyLeadsList)): ?>
                            <?php foreach($dailyLeadsList as $idx => $day): ?>
                                <div class="widget-list-item" style="gap: 8px;">
                                    <div class="d-flex align-items-center gap-1" style="min-width: 110px;">
                                        <span class="text-muted fw-bold" style="font-size: 11px; width: 16px;">
                                            <?= ($idx + 1) ?>.
                                        </span>
                                        <span class="fw-bold text-secondary" style="font-size: 12px;">
                                            <i class="bi bi-calendar-event me-1 text-muted"></i> <?= $day['date'] ?>
                                        </span>
                                    </div>
                                    
                                    <div class="d-flex align-items-center gap-1">
                                        <span class="badge bg-success-subtle text-success border border-success-subtle px-1.5 py-1" style="font-size: 10.5px; font-weight: 700;" title="WhatsApp Leads">
                                            WA: <?= $day['whatsapp'] ?>
                                        </span>
                                        <span class="badge bg-purple-subtle text-purple border border-purple-subtle px-1.5 py-1" style="font-size: 10.5px; font-weight: 700; background-color: #f5f3ff; color: #6366f1;" title="Website Leads">
                                            WB: <?= $day['website'] ?>
                                        </span>
                                        <span class="badge bg-blue-subtle text-primary border border-primary-subtle px-1.5 py-1" style="font-size: 10.5px; font-weight: 700; background-color: #eff6ff; color: #3b82f6;" title="Total Leads">
                                            Tot: <?= $day['total'] ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- WIDGET 3: SALES EXECUTIVE PERFORMANCE LEADERBOARD -->
            <div class="col-12 col-lg-4">
                <div class="widget-card">
                    <div class="widget-header">
                        <h6 class="widget-title">
                            <i class="bi bi-trophy-fill text-warning"></i> Top Sales Performers
                        </h6>
                        <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle rounded-pill px-2 py-1" style="font-size: 11px; font-weight: 700;">
                            Rankings
                        </span>
                    </div>
                    
                    <div class="widget-body">
                        <?php if(empty($performanceRank)): ?>
                            <div class="text-center text-muted py-4">No team data available.</div>
                        <?php else: ?>
                            <?php foreach($performanceRank as $idx => $p): ?>
                                <?php 
                                    $rankIcon = '';
                                    if ($idx === 0) $rankIcon = '🥇';
                                    elseif ($idx === 1) $rankIcon = '🥈';
                                    elseif ($idx === 2) $rankIcon = '🥉';
                                    else $rankIcon = '#' . ($idx + 1);

                                    $soldPercentage = ($maxSold > 0) ? round(($p['sold'] / $maxSold) * 100) : 0;
                                ?>
                                <div class="widget-list-item">
                                    <div class="d-flex align-items-center gap-2" style="min-width: 140px;">
                                        <span style="font-size: 14px; font-weight: bold; width: 22px; text-align: center;">
                                            <?= $rankIcon ?>
                                        </span>
                                        <div>
                                            <span class="fw-bold text-dark d-block" style="font-size: 13px;">
                                                <?= htmlspecialchars($p['name']) ?>
                                            </span>
                                            <small class="text-muted" style="font-size: 10.5px;">
                                                <?= $p['active'] ?> in Pipeline
                                            </small>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="progress" style="width: 50px; height: 6px;" title="<?= $p['sold'] ?> Sold">
                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?= max($soldPercentage, 8) ?>%;"></div>
                                        </div>
                                        <span class="badge <?= $p['sold'] > 0 ? 'bg-success text-white' : 'bg-light text-muted border' ?> px-2 py-1" style="font-size: 11px; font-weight: 700; min-width: 55px; text-align: center;">
                                            <?= $p['sold'] ?> Sold
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>

        <!-- 3. Team Pipeline Matrix Table -->
        <div class="card-custom" id="pipelineMatrix">
            <div class="card-header-custom">
                <h3 class="card-title-custom">Sales Team Performance & Pipeline Matrix</h3>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 20%;"><i class="bi bi-person-vcard me-1"></i> Sales Executive</th>
                            <th class="text-center">1. Pending Leads</th>
                            <th class="text-center">2. Catalog Sharing</th>
                            <th class="text-center">3. Follow Up</th>
                            <th class="text-center">4. Negotiation</th>
                            <th class="text-center">5. Sold</th>
                            <th class="text-center">Unqualified</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($team_stats)): ?>
                            <?php foreach($team_stats as $stat): ?>
                                <tr>
                                    <td>
                                        <div class="contact-name">
                                            <i class="bi bi-person-circle"></i>
                                            <?= htmlspecialchars($stat['name']) ?>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="<?= $stat['pending'] > 0 ? 'count-val' : 'count-zero' ?>"><?= $stat['pending'] ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="<?= $stat['catalog'] > 0 ? 'count-val' : 'count-zero' ?>"><?= $stat['catalog'] ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="<?= $stat['followup'] > 0 ? 'count-val' : 'count-zero' ?>"><?= $stat['followup'] ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="<?= $stat['negotiation'] > 0 ? 'count-val' : 'count-zero' ?>"><?= $stat['negotiation'] ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="<?= $stat['sold'] > 0 ? 'count-val text-success' : 'count-zero' ?>"><?= $stat['sold'] ?></span>
                                    </td>
                                    <td class="text-center">
                                        <span class="<?= $stat['unqualified'] > 0 ? 'count-val text-danger' : 'count-zero' ?>"><?= $stat['unqualified'] ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">No sales team data available.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function refreshDashboardSilently() {
            if (document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'SELECT' || document.activeElement.tagName === 'TEXTAREA')) {
                return;
            }

            const currentWinScrollY = window.scrollY || document.documentElement.scrollTop;
            const widgetScrolls = {};
            document.querySelectorAll('.widget-body').forEach((wb, i) => {
                widgetScrolls[i] = wb.scrollTop;
            });

            fetch(window.location.href)
            .then(response => response.text())
            .then(html => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(html, 'text/html');
                let hasChanged = false;
                
                let oldMetrics = document.getElementById('topMetrics');
                let newMetrics = doc.getElementById('topMetrics');
                if(oldMetrics && newMetrics && oldMetrics.innerHTML.trim() !== newMetrics.innerHTML.trim()) {
                    oldMetrics.innerHTML = newMetrics.innerHTML;
                    hasChanged = true;
                }

                let oldMiddle = document.getElementById('middleWidgets');
                let newMiddle = doc.getElementById('middleWidgets');
                if(oldMiddle && newMiddle && oldMiddle.innerHTML.trim() !== newMiddle.innerHTML.trim()) {
                    oldMiddle.innerHTML = newMiddle.innerHTML;
                    hasChanged = true;
                }

                let oldMatrix = document.getElementById('pipelineMatrix');
                let newMatrix = doc.getElementById('pipelineMatrix');
                if(oldMatrix && newMatrix && oldMatrix.innerHTML.trim() !== newMatrix.innerHTML.trim()) {
                    oldMatrix.innerHTML = newMatrix.innerHTML;
                    hasChanged = true;
                }

                if (hasChanged) {
                    window.scrollTo(0, currentWinScrollY);
                    document.querySelectorAll('.widget-body').forEach((wb, i) => {
                        if (widgetScrolls[i] !== undefined) {
                            wb.scrollTop = widgetScrolls[i];
                        }
                    });
                }
            })
            .catch(error => console.log('Auto-refresh paused: Connection issue'));
        }

        // OPTIMIZATION: Slowed down from 5s to 30s to prevent visual/server lag
        setInterval(refreshDashboardSilently, 30000); 
    </script>
</body> 
</html>