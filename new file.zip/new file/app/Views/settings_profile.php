<!DOCTYPE html> 
<html lang="en"> 
<head>      
    <meta charset="UTF-8">      
    <meta name="viewport" content="width=device-width, initial-scale=1.0">      
    <title><?= htmlspecialchars($title ?? 'Settings') ?></title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">          
    
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    <link rel="shortcut icon" type="image/png" href="<?= BASE_URL ?>favicon.png">
    
    <style>          
        body { 
            background-color: #f8fafc; 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif; 
            overflow-x: hidden; 
            color: #334155; 
        }                  
        
        .main-content { 
            margin-left: 250px; 
            padding: 30px 40px; 
            transition: all 0.3s ease; 
            min-height: 100vh; 
        }          
        
        .main-content.expanded { 
            margin-left: 80px; 
        }
        
        /* Sleek Page Header */
        .page-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 25px; 
        }
        
        .page-title { 
            margin: 0; 
            font-size: 22px; 
            font-weight: 600; 
            color: #0f172a; 
            letter-spacing: -0.5px; 
        }
        
        .user-profile { 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            color: #475569; 
            font-size: 13px; 
            font-weight: 500; 
        }
        
        .avatar-circle { 
            width: 36px; 
            height: 36px; 
            background: #3b82f6; 
            color: #fff; 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-weight: bold; 
            font-size: 14px; 
            text-transform: uppercase;
        }

        /* Settings Layout */
        .settings-container { 
            display: flex; 
            gap: 25px; 
            align-items: flex-start; 
        }
        
        /* Left Menu Tab */
        .settings-menu { 
            width: 260px; 
            background: #fff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.02); 
            padding: 10px 0; 
            flex-shrink: 0; 
        }
        
        .menu-item { 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            padding: 12px 20px; 
            color: #475569; 
            text-decoration: none; 
            font-weight: 500; 
            font-size: 14px; 
            border-left: 3px solid transparent; 
            transition: 0.2s; 
        }
        
        .menu-item:hover { 
            background-color: #f8fafc; 
            color: #3b82f6; 
        }
        
        .menu-item.active { 
            background-color: #eff6ff; 
            color: #3b82f6; 
            border-left-color: #3b82f6; 
            font-weight: 600; 
        }
        
        .menu-item i { 
            font-size: 18px; 
            margin-right: 12px; 
            width: 20px; 
            text-align: center;
        }

        /* Right Content Panel */
        .settings-panel { 
            flex-grow: 1; 
            background: #fff; 
            border-radius: 8px; 
            border: 1px solid #e2e8f0; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.02); 
            padding: 30px; 
        }
        
        .panel-title { 
            font-size: 18px; 
            font-weight: 600; 
            color: #0f172a; 
            border-bottom: 1px solid #e2e8f0; 
            padding-bottom: 15px; 
            margin-bottom: 25px; 
        }

        /* Form Styling */
        .form-label { 
            font-size: 13px; 
            font-weight: 600; 
            color: #475569; 
            margin-bottom: 6px; 
        }
        
        .form-control { 
            border-radius: 6px; 
            border: 1px solid #cbd5e1; 
            padding: 10px 15px; 
            font-size: 14px; 
            box-shadow: none; 
            transition: 0.2s; 
        }
        
        .form-control:focus { 
            border-color: #3b82f6; 
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); 
        }
        
        .text-hint { 
            font-size: 12px; 
            color: #94a3b8; 
            margin-top: 4px; 
        }
        
        .btn-save { 
            background-color: #3b82f6; 
            color: #fff; 
            border: none; 
            padding: 10px 24px; 
            font-weight: 600; 
            border-radius: 6px; 
            transition: 0.2s; 
        }
        
        .btn-save:hover { 
            background-color: #2563eb; 
        }

        /* Profile Image Upload UI */
        .profile-img-wrapper { 
            width: 100px; 
            height: 100px; 
            border-radius: 50%; 
            border: 3px solid #eff6ff; 
            position: relative; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            background: #e2e8f0; 
            overflow: hidden; 
            flex-shrink: 0; 
        }
        
        .profile-img-preview { 
            width: 100%; 
            height: 100%; 
            object-fit: cover; 
        }
        
        .profile-img-letter { 
            font-size: 32px; 
            font-weight: bold; 
            color: #64748b; 
        }
        
        .upload-btn-overlay { 
            position: absolute; 
            bottom: 0; 
            left: 0; 
            width: 100%; 
            height: 35%; 
            background: rgba(0,0,0,0.6); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            color: #fff; 
            font-size: 14px; 
            cursor: pointer; 
            transition: 0.2s; 
            opacity: 0; 
        }
        
        .profile-img-wrapper:hover .upload-btn-overlay { 
            opacity: 1; 
        }
        
        /* Locked field styling */
        .form-control:read-only { 
            background-color: #f8fafc; 
            color: #64748b; 
            cursor: not-allowed; 
            border-style: dashed; 
        }

        /* Mobile specific hamburger button - Hidden on desktop */
        .settings-mobile-toggle {
            display: none;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px 20px;
            font-weight: 600;
            color: #0f172a;
            cursor: pointer;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }

        /* =========================================
           MOBILE RESPONSIVENESS TWEAKS
           ========================================= */
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0 !important;
                margin-top: 70px !important; /* Push content below global header */
                padding: 15px !important;
            }
            .settings-container {
                flex-direction: column; /* Stack menu and form on mobile */
                gap: 15px;
            }
            
            /* Mobile settings menu logic */
            .settings-menu {
                width: 100%; 
                border: none;
                box-shadow: none;
                background: transparent;
                padding: 0;
            }
            .settings-mobile-toggle {
                display: flex; /* Show the toggle button */
            }
            .settings-nav-links {
                display: none; /* Hide links by default on mobile */
                background: #fff;
                border-radius: 8px;
                border: 1px solid #e2e8f0;
                margin-top: 8px;
                overflow: hidden;
                box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            }
            .settings-nav-links.show {
                display: block; /* Class to show links when toggled */
            }

            .settings-panel {
                width: 100%; 
                padding: 20px;
            }
            .d-flex.align-items-center.gap-4.mb-4 {
                flex-direction: column;
                text-align: center;
                gap: 15px !important;
            }
            .btn-save {
                width: 100%; /* Full width save button on mobile */
            }
        }
    </style> 
</head> 
<body>     
    
    <?php include __DIR__ . '/sidebar.php'; ?>
    
    <div class="main-content" id="mainContent">         
        
        <!-- Page Header -->
        <div class="page-header d-none">
            <h2 class="page-title">Settings</h2>
            <div class="user-profile">
                <span>Logged in as <strong><?= htmlspecialchars($user_name ?? 'User') ?></strong> <span class="badge bg-secondary ms-1"><?= htmlspecialchars($user_role ?? 'SALES') ?></span></span>
                
                <?php if(!empty($user_data['profile_image'])): ?>
                    <img src="<?= BASE_URL . htmlspecialchars($user_data['profile_image']) ?>" class="avatar-circle" style="object-fit: cover;">
                <?php else: ?>
                    <div class="avatar-circle"><?= substr($user_name ?? 'U', 0, 1) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if(isset($_SESSION['success_msg'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success_msg'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['success_msg']); ?>
        <?php endif; ?>

        <?php if(isset($_SESSION['error_msg'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $_SESSION['error_msg'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['error_msg']); ?>
        <?php endif; ?>

        <div class="settings-container">
            
            <!-- Left Navigation (With Mobile Toggle) -->
            <div class="settings-menu">
                <!-- Visible only on Mobile -->
                <div class="settings-mobile-toggle" onclick="toggleSettingsMenu()">
                    <span><i class="bi bi-gear text-primary me-2"></i> Settings Menu</span>
                    <i class="bi bi-list fs-5 text-secondary"></i>
                </div>

                <!-- The Actual Links -->
                <div class="settings-nav-links" id="settingsNavLinks">
                    <a href="<?= BASE_URL ?>settings/profile" class="menu-item active">
                        <div><i class="bi bi-person-badge"></i> Edit Profile</div>
                    </a>
                    
                    <?php if(($user_role ?? 'SALES') === 'ADMIN'): ?>
                    <a href="<?= BASE_URL ?>settings/team" class="menu-item">
                        <div><i class="bi bi-people"></i> Team Management</div>
                    </a>
                    
                    <a href="<?= BASE_URL ?>settings/integrations" class="menu-item">
                        <div><i class="bi bi-plug"></i> Integrations & API</div>
                    </a>
                    <?php endif; ?>

                    <!-- YE BUTTONS AB 100% CLICKABLE HAIN -->
                    <a href="<?= BASE_URL ?>settings/notifications" class="menu-item">
                        <div><i class="bi bi-bell"></i> Notifications</div>
                    </a>
                    <a href="<?= BASE_URL ?>settings/preferences" class="menu-item">
                        <div><i class="bi bi-palette"></i> Preferences</div>
                    </a>
                </div>
            </div>

            <!-- Right Profile Content -->
            <div class="settings-panel">
                <h3 class="panel-title">My Profile Information</h3>
                
                <form action="<?= BASE_URL ?>settings/update_profile" method="POST" enctype="multipart/form-data">
                    
                    <div class="d-flex align-items-center gap-4 mb-4 pb-4 border-bottom border-light">
                        <div class="profile-img-wrapper">
                            <?php if(!empty($user_data['profile_image'])): ?>
                                <img src="<?= BASE_URL . htmlspecialchars($user_data['profile_image']) ?>" class="profile-img-preview" id="imagePreview">
                            <?php else: ?>
                                <span class="profile-img-letter" id="imageLetter"><?= substr($user_name ?? 'U', 0, 1) ?></span>
                                <img src="" class="profile-img-preview d-none" id="imagePreview">
                            <?php endif; ?>
                            
                            <label for="profileImage" class="upload-btn-overlay">
                                <i class="bi bi-camera-fill"></i>
                            </label>
                            <input type="file" id="profileImage" name="profile_image" class="d-none" accept="image/jpeg, image/png, image/jpg, image/webp" onchange="previewProfileImage(event)">
                        </div>
                        <div>
                            <h4 class="mb-1 fw-bold" style="color: #0f172a; font-size: 22px;">
                                <?= htmlspecialchars($user_data['full_name'] ?? $user_data['name'] ?? '') ?>
                            </h4>
                            <p class="text-muted mb-0" style="font-size: 14px;">
                                <i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($user_data['email'] ?? '') ?>
                            </p>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($user_data['full_name'] ?? $user_data['name'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user_data['email'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user_data['phone'] ?? '') ?>" placeholder="+91">
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Current Role <i class="bi bi-lock-fill text-muted ms-1" title="Contact Admin to change role"></i></label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars(strtoupper($user_data['role'] ?? 'SALES')) ?>" readonly>
                        </div>
                    </div>

                    <h4 class="panel-title mt-5 mb-3" style="font-size: 16px; color: #475569; border: none;">Change Password</h4>
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label">New Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Leave blank to keep current password">
                            <div class="text-hint">Only type here if you want to change your password.</div>
                        </div>
                    </div>

                    <div class="mt-4 pt-3 border-top text-end">
                        <button type="submit" class="btn-save"><i class="bi bi-save me-1"></i> Save Changes</button>
                    </div>

                </form>
            </div>
        </div>

    </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle Settings Menu on Mobile
        function toggleSettingsMenu() {
            var navLinks = document.getElementById('settingsNavLinks');
            navLinks.classList.toggle('show');
        }

        // Preview Profile Image before upload
        function previewProfileImage(event) {
            var reader = new FileReader();
            reader.onload = function(){
                var output = document.getElementById('imagePreview');
                var letter = document.getElementById('imageLetter');
                output.src = reader.result;
                output.classList.remove('d-none');
                if(letter) { letter.classList.add('d-none'); }
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
</body> 
</html>