<?php
// SCPK CRM: PHP / MySQL timestamps use UTC. Preferences controls presentation later.
date_default_timezone_set('UTC');

// Hostinger account layout:
// <account_home>/crm_private/.env   (preferred; outside public_html)
// <account_home>/public_html/app/Config/.env (legacy migration fallback ONLY)
$privateEnvPath = dirname(__DIR__, 3) . '/crm_private/.env';
$legacyEnvPath = __DIR__ . '/.env';

$envFilePath = null;
if (is_file($privateEnvPath)) {
    $envFilePath = $privateEnvPath;
} elseif (is_file($legacyEnvPath)) {
    // Transitional compatibility: old server continues working until safe migration.
    $envFilePath = $legacyEnvPath;
}

if ($envFilePath !== null) {
    if (!is_readable($envFilePath)) {
        error_log('CRM environment configuration is unreadable.');
        http_response_code(503);
        exit('CRM configuration temporarily unavailable.');
    }
    // Same parser behavior as the original CRM: preserve current .env semantics.
    $envVars = parse_ini_file($envFilePath);
    if (!is_array($envVars)) {
        error_log('CRM environment configuration could not be parsed.');
        http_response_code(503);
        exit('CRM configuration temporarily unavailable.');
    }
    foreach ($envVars as $key => $value) {
        $_ENV[$key] = $value;
    }
}

// Credentials must remain server-side. Do not return these values in HTML or JSON.
define('BASE_URL', $_ENV['BASE_URL'] ?? 'https://crm.scpkonline.com/');
define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_NAME', $_ENV['DB_NAME'] ?? '');
define('DB_USER', $_ENV['DB_USER'] ?? '');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');
define('WA_APP_ID', $_ENV['WA_APP_ID'] ?? '');
define('WA_PHONE_NUMBER_ID', $_ENV['WA_PHONE_NUMBER_ID'] ?? '');
define('WA_ACCESS_TOKEN', $_ENV['WA_ACCESS_TOKEN'] ?? '');
define('WA_VERIFY_TOKEN', $_ENV['WA_VERIFY_TOKEN'] ?? '');
define('WA_WABA_ID', $_ENV['WA_WABA_ID'] ?? '');
define('META_AD_ACCOUNT_ID', $_ENV['META_AD_ACCOUNT_ID'] ?? '');
?>
