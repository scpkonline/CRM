<?php

declare(strict_types=1);

// ==========================================
// SESSION TIMEOUT SETTINGS (1 WEEK = 7 DAYS)
// ==========================================
$timeout = 604800; // 7 days in seconds

// Server garbage collection time update (7 days)
ini_set('session.gc_maxlifetime', (string)$timeout);

// Browser cookie life update (7 days)
session_set_cookie_params([
    'lifetime' => $timeout,
    'path' => '/',
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on', // Automatically checks for HTTPS
    'httponly' => true,
    'samesite' => 'Lax'
]);

// Start the session with new parameters
session_start();

// Define core paths
define('ROOT_DIR', __DIR__ . DIRECTORY_SEPARATOR);
define('APP_DIR', ROOT_DIR . 'app' . DIRECTORY_SEPARATOR);

// Custom Autoloader for Hostinger
spl_autoload_register(function ($className) {
    $className = str_replace('\\', DIRECTORY_SEPARATOR, $className);
    $file = APP_DIR . $className . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
}); // <-- THIS CLOSING BRACKET WAS MISSING

// Load App Configuration
require_once APP_DIR . 'Config/config.php';

// Boot the Router
$router = new Core\Router();
$router->dispatch($_GET['url'] ?? '');
?>