const baseUrl = APP_CONFIG.baseUrl;
const currentAgentName = (APP_CONFIG.currentAgentName || '').trim().toLowerCase();
const currentUserRole = (APP_CONFIG.currentUserRole || '').trim().toLowerCase();
const crmAgents = APP_CONFIG.crmAgents || [];
// Stage 5: company-wide display timezone from Settings > Preferences.
// Never alter original UTC timestamps or WhatsApp 24/72-hour duration calculations.
const crmTimezone = (APP_CONFIG.crmTimezone === 'UTC') ? 'UTC' : 'Asia/Kolkata';
const crmDateFormatter = new Intl.DateTimeFormat('en-IN', {
    timeZone: crmTimezone, day: '2-digit', month: '2-digit', year: 'numeric'
});
const crmTimeFormatter = new Intl.DateTimeFormat('en-IN', {
    timeZone: crmTimezone, hour: '2-digit', minute: '2-digit', hour12: true
});
const crmTimeWithSecondsFormatter = new Intl.DateTimeFormat('en-IN', {
    timeZone: crmTimezone, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
});
const crmDatePartsFormatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: crmTimezone, year: 'numeric', month: '2-digit', day: '2-digit'
});

function crmDisplayDate(date) {
    return crmDateFormatter.format(date);
}
function crmDisplayTime(date, withSeconds = false) {
    return (withSeconds ? crmTimeWithSecondsFormatter : crmTimeFormatter).format(date);
}
// YYYY-MM-DD in the selected company timezone (for the existing date filters).
function crmDateKey(utcTimestamp) {
    const date = safeParseDate(utcTimestamp);
    if (!date.getTime() || isNaN(date.getTime())) return '';
    const parts = crmDatePartsFormatter.formatToParts(date);
    const get = name => (parts.find(p => p.type === name) || {}).value || '';
    return `${get('year')}-${get('month')}-${get('day')}`;
}

let appMode = APP_CONFIG.appMode || 'live'; 
let urlParams = new URLSearchParams(window.location.search);
let activeConvoId = urlParams.get('chat') || null; 
let activeTab = urlParams.get('tab') || (appMode === 'history' ? 'EXPIRED' : (appMode === 'all_chats' ? 'ALL_CHATS' : 'ACTIVE')); 

let isInitialLoad = true;
let initLoadAttempts = 0; 

// Only Inbox list pagination is new; other Inbox flows are unchanged.
let chatPage = 1;
let chatDisplayedPage = 1;
let chatTotalPages = 1;
let chatFilteredTotal = 0;
let chatListFetchController = null;
let chatPageLoading = false;
// Show Loading only for an explicit page/filter/tab change, not silent polling.
let chatPageShowLoading = false;
let chatListLastRequestAt = 0;
let chatListLastErrorAt = 0;
let chatPaginationError = '';
let chatListQuerySignature = '';

let activeLeadId = null;
let currentMessageCount = 0;
let currentMessagesHash = ''; 
let currentChatListHash = ''; 

let isWindowClosed = false;
let isInternalNote = false;

// MULTIPLE IMAGES ARRAY
let selectedFilesArray = []; 

let cachedTemplates = null;
let cachedMetaAds = null;
let currentChatData = null;
let convoCustomerDates = {}; 

let allKnownTags = new Set(); 
let globalTagsList = []; 
let cannedResponses = []; 

localStorage.removeItem('myTakenChats');

const emojis = ["😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","🙃","😉","😌","😍","🥰","😘","😗","😙","😚","😋","😛","😝","😜","🤪","🤨","🧐","🤓","😎","🤩","🥳","😏","😒","😞","😔","😟","😕","🙁","😣","😖","😫","😩","🥺","😢","😭","😮","‍💨","😤","😠","😡","🤬","🤯","😳","🥵","🥶","😱","😨","😰","😥","😓","🤗","🤔","🤭","🤫","🤥","😶","😐","😑","😬","🙄","😯","😦","😧","😮","😲","🥱","😴","🤤","😪","😵","🤐","🥴","🤢","🤮","🤧","😷","🤒","🤕","🤑","🤠","😈","👿","👹","👺","🤡","💩","👻","💀","☠️","👽","👾","🤖","🎃","😺","😸","😹","😻","😼","😽","🙀","😿","😾","👋","🤚","🖐️","✋","🖖","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","🖕","👇","☝️","👍","👎","✊","👊","🤛","🤜","👏","🙌","👐","🤲","🤝","🙏","✍️","💅","🤳","💪","🦾","🦿","🦵","🦶","👂","🦻","👃","🧠","🫀","🫁","🦷","🦴","👀","👁️","👅","👄","💋","🩸","❤️","🧡","💛","💚","💙","💜","🖤","🤎","🤍","💔","❤️‍🔥","❤️‍🩹","❣️","💕","💞","💓","💗","💖","💘","💝","💟","☮️","✝️","☪️","🕉️","☸️","✡️"," símbolos","🔥","✨","🌟","🎉"];

function updateURL() {
    let modeSegment = 'live_chat';
    if (appMode === 'history') modeSegment = 'history';
    if (appMode === 'all_chats') modeSegment = 'all_chats';
    if (appMode === 'macros') modeSegment = 'macros';
    if (appMode === 'tags') modeSegment = 'tags';
    if (appMode === 'templates') modeSegment = 'templates';
    if (appMode === 'broadcasts') modeSegment = 'broadcasts';
    if (appMode === 'meta_ads') modeSegment = 'meta_ads';
    
    let newUrl = new URL(baseUrl + 'inbox/' + modeSegment);
    
    if (appMode === 'live' || appMode === 'history' || appMode === 'all_chats') {
        newUrl.searchParams.set('tab', activeTab);
        if (activeConvoId) {
            newUrl.searchParams.set('chat', activeConvoId);
        }
    }
    
    window.history.pushState({path: newUrl.href}, '', newUrl.href);
}

document.getElementById('toggleFilterBtn').addEventListener('click', function() {
    let popup = document.getElementById('chatFilterPopup');
    popup.style.display = popup.style.display === 'block' ? 'none' : 'block';
});

function applyChatFilters() {
    // Search/filter across the full authorized list, not just visible 50.
    chatPage = 1;
    chatDisplayedPage = 1;
    currentChatListHash = '';
    fetchChatList(false, true);
}

let chatSearchTimeout;
document.getElementById('chatSearch').addEventListener('keyup', function() {
    clearTimeout(chatSearchTimeout);
    chatSearchTimeout = setTimeout(applyChatFilters, 250);
});

async function fetchLiveTemplates() {
    let localTemps = localStorage.getItem('wa_templates_cache');
    if (localTemps) {
        cachedTemplates = JSON.parse(localTemps);
        if (appMode === 'templates') renderTemplatesTable();
        if (appMode === 'broadcasts' && typeof scpkBroadcastPopulateTemplates === 'function') scpkBroadcastPopulateTemplates();
    }
    
    try {
        let res = await fetch(`${baseUrl}inbox/get_templates`);
        let json = await res.json();
        if (json.data && json.data.length > 0) {
            cachedTemplates = json.data; 
            localStorage.setItem('wa_templates_cache', JSON.stringify(json.data));
            if (appMode === 'templates') renderTemplatesTable();
            if (appMode === 'broadcasts' && typeof scpkBroadcastPopulateTemplates === 'function') scpkBroadcastPopulateTemplates();
        }
    } catch(e) {}
}

window.switchAppMode = function(e, mode, isInitLoad = false) {
    if(e) e.preventDefault();
    if (appMode === mode && !isInitLoad) return;
    
    appMode = mode;
    if(!isInitLoad) updateURL();
    
    document.getElementById('navLiveChat').classList.toggle('active', appMode === 'live');
    document.getElementById('navHistory').classList.toggle('active', appMode === 'history');
    if(document.getElementById('navAllChats')) document.getElementById('navAllChats').classList.toggle('active', appMode === 'all_chats');
    if(document.getElementById('navMacros')) document.getElementById('navMacros').classList.toggle('active', appMode === 'macros');
    if(document.getElementById('navTags')) document.getElementById('navTags').classList.toggle('active', appMode === 'tags');
    if(document.getElementById('navTemplates')) document.getElementById('navTemplates').classList.toggle('active', appMode === 'templates');
    if(document.getElementById('navBroadcasts')) document.getElementById('navBroadcasts').classList.toggle('active', appMode === 'broadcasts');
    if(document.getElementById('navMetaAds')) document.getElementById('navMetaAds').classList.toggle('active', appMode === 'meta_ads');
    
    let inboxView = document.getElementById('inboxMainView');
    let macrosView = document.getElementById('macrosManagerArea');
    let tagsView = document.getElementById('tagsManagerArea');
    let tempView = document.getElementById('templatesManagerArea');
    let metaAdsView = document.getElementById('metaAdsManagerArea');
    let broadcastsView = document.getElementById('broadcastManagerArea');
    if(broadcastsView) broadcastsView.style.setProperty('display', appMode === 'broadcasts' ? 'flex' : 'none', 'important');
    
    if (appMode === 'macros') {
        if(inboxView) inboxView.style.setProperty('display', 'none', 'important');
        if(tagsView) tagsView.style.setProperty('display', 'none', 'important');
        if(tempView) tempView.style.setProperty('display', 'none', 'important');
        if(metaAdsView) metaAdsView.style.setProperty('display', 'none', 'important');
        if(macrosView) macrosView.style.setProperty('display', 'flex', 'important');
        fetchMacros(); 
    } else if (appMode === 'tags') {
        if(inboxView) inboxView.style.setProperty('display', 'none', 'important');
        if(macrosView) macrosView.style.setProperty('display', 'none', 'important');
        if(tempView) tempView.style.setProperty('display', 'none', 'important');
        if(metaAdsView) metaAdsView.style.setProperty('display', 'none', 'important');
        if(tagsView) tagsView.style.setProperty('display', 'flex', 'important');
        fetchGlobalTags(); 
    } else if (appMode === 'templates') {
        if(inboxView) inboxView.style.setProperty('display', 'none', 'important');
        if(macrosView) macrosView.style.setProperty('display', 'none', 'important');
        if(tagsView) tagsView.style.setProperty('display', 'none', 'important');
        if(metaAdsView) metaAdsView.style.setProperty('display', 'none', 'important');
        if(tempView) tempView.style.setProperty('display', 'flex', 'important');
        renderTemplatesTable();
    } else if (appMode === 'broadcasts') {
        if(inboxView) inboxView.style.setProperty('display','none','important');
        if(macrosView) macrosView.style.setProperty('display','none','important');
        if(tagsView) tagsView.style.setProperty('display','none','important');
        if(tempView) tempView.style.setProperty('display','none','important');
        if(metaAdsView) metaAdsView.style.setProperty('display','none','important');
        if(typeof scpkBroadcastRefresh === 'function') scpkBroadcastRefresh();
    } else if (appMode === 'meta_ads') {
        if(inboxView) inboxView.style.setProperty('display', 'none', 'important');
        if(macrosView) macrosView.style.setProperty('display', 'none', 'important');
        if(tagsView) tagsView.style.setProperty('display', 'none', 'important');
        if(tempView) tempView.style.setProperty('display', 'none', 'important');
        if(metaAdsView) metaAdsView.style.setProperty('display', 'flex', 'important');
        fetchMetaAds();
    } else {
        if(inboxView) inboxView.style.setProperty('display', 'flex', 'important');
        if(macrosView) macrosView.style.setProperty('display', 'none', 'important');
        if(tagsView) tagsView.style.setProperty('display', 'none', 'important');
        if(tempView) tempView.style.setProperty('display', 'none', 'important');
        if(metaAdsView) metaAdsView.style.setProperty('display', 'none', 'important');
        
        if(!isInitLoad) {
            chatPage = 1; chatDisplayedPage = 1; chatTotalPages = 1;
            activeTab = 'ACTIVE';
            if(mode === 'history') activeTab = 'EXPIRED';
            if(mode === 'all_chats') activeTab = 'ALL_CHATS';
            activeConvoId = null; 
            currentChatListHash = '';
        }
        
        document.getElementById('liveChatTabsContainer').style.display = appMode === 'live' ? 'flex' : 'none';
        document.getElementById('historyTabsContainer').style.display = appMode === 'history' ? 'flex' : 'none';
        if(document.getElementById('allChatsTabsContainer')) {
            document.getElementById('allChatsTabsContainer').style.display = appMode === 'all_chats' ? 'flex' : 'none';
        }
        
        document.querySelectorAll('.chat-tab').forEach(el => el.classList.remove('active'));
        if (activeTab === 'ACTIVE') {
            let tabs = document.querySelectorAll('#liveChatTabsContainer .chat-tab');
            if(tabs.length > 0) tabs[0].classList.add('active');
        }
        if (activeTab === 'INTERVENED') {
            let tabs = document.querySelectorAll('#liveChatTabsContainer .chat-tab');
            if(tabs.length > 1) tabs[1].classList.add('active');
        }
        if (activeTab === 'EXPIRED') {
            let tabs = document.querySelectorAll('#historyTabsContainer .chat-tab');
            if(tabs.length > 0) tabs[0].classList.add('active');
        }
        if (activeTab === 'ALL_CHATS') {
            let tabs = document.querySelectorAll('#allChatsTabsContainer .chat-tab');
            if(tabs.length > 0) tabs[0].classList.add('active');
        }
        
        if(!isInitLoad || !activeConvoId) {
            document.getElementById('chatWindowArea').innerHTML = `
                <div class="d-flex flex-column align-items-center justify-content-center h-100 bg-light text-muted">     
                    <i class="bi bi-whatsapp mb-3" style="font-size: 48px; color: #00d284;"></i>     
                    <h5>Select a conversation</h5>     
                </div>
            `;
            document.getElementById('chatWindowArea').classList.remove('active-mobile'); 
            document.getElementById('leadInfoPanel').style.display = 'none';
        }
        
        if(!isInitLoad) updateURL();
        fetchLiveTemplates();
        fetchChatList(isInitLoad, true);
    }
}

window.switchTab = function(tabName, element) {
    document.querySelectorAll('.chat-tab').forEach(el => el.classList.remove('active'));
    element.classList.add('active');
    activeTab = tabName;
    chatPage = 1; chatDisplayedPage = 1; chatTotalPages = 1;
    currentChatListHash = ''; 
    updateURL();
    fetchChatList(false, true); 
}

function safeParseDate(dateString) {
    if (!dateString) return new Date(0); 
    let utcString = dateString;
    if (dateString.includes(' ') && !dateString.includes('T')) {
        utcString = dateString.replace(' ', 'T') + 'Z'; 
    }
    let d = new Date(utcString);
    if (!isNaN(d.getTime())) return d;
    d = new Date(dateString.replace(/-/g, '/'));
    if (!isNaN(d.getTime())) return d;
    return new Date(0); 
}

function check24HourWindow(lastCustomerDate) {
    let alertBox = document.getElementById('wa-window-alert');
    let targetDateString = lastCustomerDate ? lastCustomerDate : (currentChatData ? currentChatData.created_at : null);
    
    // Dynamic 72h / 24h check
    let maxHours = (currentChatData && currentChatData.meta_ad_name && currentChatData.meta_ad_name !== 'null' && currentChatData.meta_ad_name !== '') ? 72 : 24;

    if (!targetDateString) {
        isWindowClosed = true;
    } else {
        const now = new Date();
        const targetDate = safeParseDate(targetDateString);
        const diffInHours = (now.getTime() - targetDate.getTime()) / (1000 * 60 * 60);
        isWindowClosed = (diffInHours > maxHours);
    }

    if(alertBox) {
        alertBox.style.display = isWindowClosed ? 'block' : 'none';
        if(isWindowClosed) {
            alertBox.innerHTML = `
                <div style="background-color: #ebd1d1; border: 1px solid #dcaaa9; color: #5c0000; padding: 8px 12px; border-radius: 5px; font-weight: bold; font-size: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <i class="bi bi-lock-fill text-dark me-1"></i> 
                    The ${maxHours}-hour WhatsApp messaging window has closed. You can only send template messages.
                </div>
            `;
        }
    }
    
    let inputArea = document.getElementById('msgInput');
    if (inputArea) {
        if (isWindowClosed && !isInternalNote) {
            inputArea.placeholder = "Chat locked. Use '//' for templates";
        } else if (isInternalNote) {
            inputArea.placeholder = "Internal note (hidden from customer)...";
        } else {
            inputArea.placeholder = "Message...";
        }
    }
}

window.transferLead = function(agentId, agentNameText) {
    if(!agentId && agentNameText !== 'Unassigned') return; 
    let actualName = agentId === "" ? "" : agentNameText;

    fetch(`${baseUrl}inbox/assign_chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversation_id: activeConvoId, agent_id: agentId, agent_name: actualName })
    }).then(() => {
        if(currentChatData) currentChatData.current_agent = actualName;
        document.getElementById('infoAssignedAgent').innerText = actualName ? actualName.toUpperCase() : 'Unassigned';
        currentChatListHash = '';
        fetchChatList();
    });
}

window.closeChatMobile = function() {
    document.getElementById('chatWindowArea').classList.remove('active-mobile');
}
window.closeLeadInfoMobile = function() {
    let panel = document.getElementById('leadInfoPanel');
    panel.classList.remove('active-mobile');
    setTimeout(() => { panel.style.display = 'none'; }, 300);
}

window.updateLeadStatus = function(status) {
    if(!activeLeadId) return;
    fetch(`${baseUrl}inbox/update_status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead_id: activeLeadId, status: status })
    }).then(r => r.json()).then(data => {
        if(data.status === 'success') {
            let activeItem = document.querySelector('.chat-item.active');
            if (activeItem) activeItem.setAttribute('data-status', status);
        }
    });
}

window.loadChat = function(element) {
    document.querySelectorAll('.chat-item').forEach(el => el.classList.remove('active'));
    element.classList.add('active');

    activeConvoId = String(element.getAttribute('data-convo-id'));
    updateURL();

    let chatWindow = document.getElementById('chatWindowArea');
    chatWindow.classList.add('active-mobile');

    activeLeadId = element.getAttribute('data-lead-id');
    let contactName = element.getAttribute('data-name');
    let phone = element.getAttribute('data-phone');
    let source = element.getAttribute('data-source');
    let dateAdded = element.getAttribute('data-date');
    let tags = element.getAttribute('data-tags');
    let metaAdName = element.getAttribute('data-ad-name'); 
    let leadStatus = element.getAttribute('data-status') || 'New Lead';
    
    let chatAgent = element.getAttribute('data-agent');
    if (chatAgent === 'null' || !chatAgent) chatAgent = '';
    
    let agentReplies = parseInt(element.getAttribute('data-replies') || '0');
    let leadIdFormatted = String(activeLeadId).padStart(4, '0');

    // Isme meta_ad_name pass kar diya gaya hai
    currentChatData = { created_at: dateAdded, full_name: contactName, current_agent: chatAgent, meta_ad_name: metaAdName };
    
    currentMessagesHash = ''; 
    isWindowClosed = false;
    isInternalNote = false;
    
    let badgeEl = element.querySelector('.unread-badge');
    if (badgeEl) badgeEl.remove();

    removeAttachment(); 

    document.getElementById('chatWindowArea').innerHTML = `
        <div class="chat-header">
            <div class="d-flex align-items-center">
                <button class="d-md-none btn btn-link text-white p-0 me-2" onclick="closeChatMobile()"><i class="bi bi-arrow-left fs-4"></i></button>
                <div class="avatar bg-white text-dark me-3" style="width: 35px; height: 35px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                    ${contactName.charAt(0).toUpperCase()}
                </div>
                <div>
                    <h6 class="mb-0 fw-bold">${contactName.toUpperCase()}</h6>
                    <small class="text-white-50">(${phone})</small>
                </div>
            </div>
            <div class="d-flex align-items-center">
                <select id="chatAssignDropdown" class="form-select form-select-sm border-secondary me-2 shadow-none" style="width: auto; max-width: 150px; font-size: 12px; background: #243441; color: white; cursor:pointer;" onchange="transferLead(this.value, this.options[this.selectedIndex].text)">
                    <option value="" style="background:#fff; color:#333;">Unassigned</option>
                    ${crmAgents.map(a => `<option value="${a.id}" style="background:#fff; color:#333;" ${a.name.toLowerCase() === chatAgent.toLowerCase() ? 'selected' : ''}>${a.name}</option>`).join('')}
                </select>
                <button class="btn btn-sm btn-outline-light" onclick="toggleLeadInfo()"><i class="bi bi-info-circle"></i> Profile</button>
            </div>
        </div>
        
        <div class="chat-body d-flex flex-column" id="messageContainer"></div>
        
        <div id="wa-window-alert" style="display: none; text-align: center; padding: 10px 20px; background: #efeae2;">
            <div style="background-color: #ebd1d1; border: 1px solid #dcaaa9; color: #5c0000; padding: 8px 12px; border-radius: 5px; font-weight: bold; font-size: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <i class="bi bi-lock-fill text-dark me-1"></i> 
                The 24-hour WhatsApp messaging window has closed. You can only send template messages.
            </div>
        </div>

        <div class="chat-footer" id="chatFooterBox">
            
            <div id="attachmentPreview" style="display: none; position: absolute; bottom: 100%; left: 15px; background: #fff; padding: 10px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 -4px 15px rgba(0,0,0,0.1); margin-bottom: 10px; z-index: 50; max-width: calc(100% - 30px); overflow-x: auto;">
            </div>

            <div id="slashCommands"></div>

            <div id="emojiPicker">
                ${emojis.map(e => `<span class="emoji-btn" onclick="insertEmoji('${e}')">${e}</span>`).join('')}
            </div>

            <div class="d-flex align-items-center gap-3 mb-1 text-secondary px-1 pb-1">
                <i class="bi bi-emoji-smile fs-4" style="cursor:pointer" onclick="toggleEmoji()"></i>
                <input type="file" id="attachFile" accept="image/*,video/*,audio/*,.pdf,.doc,.docx" multiple style="display:none;" onchange="handleFileSelect(event)">
                <label for="attachFile" class="m-0" style="cursor: pointer;" title="Attach File">
                    <i class="bi bi-paperclip fs-4"></i>
                </label>
            </div>
            
            <div id="inputWrapper" class="flex-grow-1 bg-white border d-flex align-items-end" style="border-radius: 24px; padding: 2px 8px; box-shadow: 0 1px 1px rgba(0,0,0,0.05); transition: background 0.3s;">
                <textarea id="msgInput" class="form-control border-0 shadow-none m-0" rows="1" placeholder="Message..." autocomplete="off" oninput="handleInput(this)" onkeydown="handleKeydown(event)" style="resize: none; max-height: 100px; font-size: 14px; background: transparent; padding: 10px 5px; overflow-y: auto; line-height: 20px;"></textarea>
                
                <i class="bi bi-journal-text fs-5 text-secondary p-2 mb-0 pb-1" id="internalToggleBtn" onclick="toggleInternalNote()" style="cursor:pointer; align-self: flex-end;" title="Toggle Internal Note"></i>
            </div>
            
            <div class="mb-0 pb-1 d-flex align-items-end">
                <button type="button" class="btn btn-success rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width: 42px; height: 42px; background-color: #00a884; border-color: #00a884; flex-shrink: 0;" onclick="sendMessage()">
                    <i class="bi bi-send-fill fs-5" style="margin-left: 2px;"></i>
                </button>
            </div>
        </div>
    `;

    document.getElementById('infoAvatar').innerText = contactName.charAt(0).toUpperCase();
    document.getElementById('infoName').innerText = contactName;
    document.getElementById('infoLeadId').innerText = '#LD-' + leadIdFormatted; 
    document.getElementById('infoAssignedAgent').innerText = chatAgent ? chatAgent.toUpperCase() : 'Unassigned'; 
    document.getElementById('infoPhone').innerText = phone;
    
    let adLabel = document.getElementById('infoAdLabel');
    let adNameEl = document.getElementById('infoAdName');
    if (metaAdName && metaAdName !== 'null' && metaAdName.trim() !== '') {
        adLabel.style.display = 'block';
        adNameEl.style.display = 'block';
        adNameEl.innerText = metaAdName;
    } else {
        adLabel.style.display = 'none';
        adNameEl.style.display = 'none';
    }

    let statusDropdown = document.getElementById('infoLeadStatus');
    if (statusDropdown) {
        let optionExists = Array.from(statusDropdown.options).some(opt => opt.value === leadStatus);
        if (!optionExists && leadStatus) {
            statusDropdown.add(new Option(leadStatus, leadStatus));
        }
        statusDropdown.value = leadStatus;
    }

    let pd = safeParseDate(dateAdded);
    document.getElementById('infoDate').innerText = (pd.getTime() > 0) ? crmDisplayDate(pd) : '-';
    
    let tagsHtml = '';
    if(tags && tags.trim() !== '') {
        tags.split(',').forEach(tag => {
            if(tag.trim()) tagsHtml += `<span class="tag-badge" data-tag-name="${tag.trim()}">${tag.trim()} <i class="bi bi-x" title="Remove Tag" onclick="removeTag('${tag.trim()}')"></i></span>`;
        });
    } else {
        tagsHtml = '<small class="text-muted" id="noTagsText">No tags</small>';
    }
    document.getElementById('infoTags').innerHTML = tagsHtml;
    
    updateCustomerJourney(null, chatAgent);
    fetchMessages(activeConvoId);
    inboxCrmOpenLead(activeLeadId);
    
    if (window.innerWidth > 768) {
        document.getElementById('leadInfoPanel').style.display = 'block';
    }
}

window.openImagePopup = function(imgSrc) {
    document.getElementById('lightboxImg').src = imgSrc;
    document.getElementById('imageLightbox').style.display = 'flex';
}

// ==========================================
// SMART IMAGE COMPRESSION & MULTIPLE ATTACHMENT
// ==========================================
window.handleFileSelect = function(e) {
    let files = e.target.files;
    if(!files || files.length === 0) return;

    let promises = [];
    for(let i=0; i<files.length; i++) {
        promises.push(new Promise((resolve) => {
            let file = files[i];
            
            // Image Auto Compression (Like WhatsApp)
            if (file.type.startsWith('image/')) {
                let reader = new FileReader();
                reader.onload = function(event) {
                    let img = new Image();
                    img.onload = function() {
                        let canvas = document.createElement('canvas');
                        let ctx = canvas.getContext('2d');
                        
                        let MAX_WIDTH = 1200; // Resize large images
                        let MAX_HEIGHT = 1200;
                        let width = img.width;
                        let height = img.height;

                        if (width > height) {
                            if (width > MAX_WIDTH) {
                                height *= MAX_WIDTH / width;
                                width = MAX_WIDTH;
                            }
                        } else {
                            if (height > MAX_HEIGHT) {
                                width *= MAX_HEIGHT / height;
                                height = MAX_HEIGHT;
                            }
                        }
                        
                        canvas.width = width;
                        canvas.height = height;
                        ctx.drawImage(img, 0, 0, width, height);
                        
                        // Compress Quality to 70% (Greatly reduces MBs to KBs)
                        let compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);
                        
                        resolve({
                            data: compressedDataUrl,
                            type: 'image/jpeg',
                            name: file.name
                        });
                    };
                    img.src = event.target.result;
                };
                reader.readAsDataURL(file);
            } 
            // PDF, Video, Audio
            else {
                let reader = new FileReader();
                reader.onload = function(event) {
                    resolve({
                        data: event.target.result,
                        type: file.type,
                        name: file.name
                    });
                };
                reader.readAsDataURL(file);
            }
        }));
    }

    Promise.all(promises).then(results => {
        selectedFilesArray = selectedFilesArray.concat(results);
        renderAttachmentPreviews();
        document.getElementById('attachFile').value = '';
    });
}

window.renderAttachmentPreviews = function() {
    let previewBox = document.getElementById('attachmentPreview');
    if (!previewBox) return;

    if (selectedFilesArray.length === 0) {
        previewBox.style.display = 'none';
        previewBox.innerHTML = '';
        return;
    }

    previewBox.style.display = 'flex';
    previewBox.style.flexWrap = 'wrap';
    previewBox.style.gap = '10px';

    let html = '';
    selectedFilesArray.forEach((file, index) => {
        let imgSrc = file.type.startsWith('image/') ? file.data : 'https://cdn-icons-png.flaticon.com/512/2965/2965335.png';
        html += `
            <div style="position: relative; display: inline-block;">
                <img src="${imgSrc}" style="height: 65px; width: 65px; border-radius: 6px; object-fit: cover; border: 1px solid #ddd;">
                <i class="bi bi-x-circle-fill text-danger bg-white rounded-circle shadow-sm" style="position: absolute; top: -8px; right: -8px; cursor: pointer; font-size: 1.1rem; line-height: 1;" onclick="removeAttachmentIndex(${index})"></i>
            </div>
        `;
    });
    previewBox.innerHTML = html;
}

window.removeAttachmentIndex = function(index) {
    selectedFilesArray.splice(index, 1);
    renderAttachmentPreviews();
}

window.removeAttachment = function() {
    selectedFilesArray = [];
    let attachInput = document.getElementById('attachFile');
    if (attachInput) attachInput.value = '';
    renderAttachmentPreviews();
}

window.toggleEmoji = function() {
    let p = document.getElementById('emojiPicker');
    if (p) {
        p.style.display = p.style.display === 'grid' ? 'none' : 'grid';
    }
}

window.insertEmoji = function(emoji) {
    let input = document.getElementById('msgInput');
    if (input) {
        input.value += emoji;
        input.focus();
    }
}

window.handleInput = function(el) {
    el.style.height = '20px'; 
    let newHeight = el.scrollHeight;
    if (newHeight > 100) newHeight = 100;
    el.style.height = newHeight + 'px';
    
    handleSlashMenu(el.value);
}

function handleSlashMenu(val) {
    let popup = document.getElementById('slashCommands');
    if(!popup) return;
    
    if (val.startsWith('//')) {
        let searchVal = val.toLowerCase().replace('//', '');
        popup.innerHTML = '';
        let hasItems = false;

        if (cachedTemplates && cachedTemplates.length > 0) {
            let approvedTemps = cachedTemplates.filter(t => t.status === 'APPROVED');
            let filtered = approvedTemps.filter(t => t.name.toLowerCase().includes(searchVal));
            
            filtered.forEach(template => {
                const index = cachedTemplates.indexOf(template);
                const item = document.createElement('button');
                item.type = 'button'; item.className = 'slash-item scpk-slash-template-item';
                const title = document.createElement('span'); title.className = 'slash-cmd';
                title.textContent = '◉ ' + template.name;
                const detail = document.createElement('span'); detail.className = 'slash-text text-muted';
                detail.textContent = 'Open preview · ' + (template.category || 'TEMPLATE') + ' · ' + (template.language || 'en_US');
                item.append(title, detail);
                item.addEventListener('click', () => crmTemplateOpenFromChat(index));
                popup.appendChild(item);
            });
            hasItems = filtered.length > 0;
            if(!hasItems) popup.innerHTML = `<div class="p-2 text-muted small text-center">No matching templates found</div>`;
        } else {
            popup.innerHTML = `<div class="p-2 text-muted small text-center">Loading Templates... Please wait.</div>`;
            hasItems = true;
        }
        popup.style.display = 'block';

    } else if (val.startsWith('/')) {
        let searchVal = val.toLowerCase().replace('/', '');
        popup.innerHTML = '';
        let hasItems = false;
        
        let filtered = cannedResponses.filter(r => r.cmd.toLowerCase().includes('/'+searchVal) || r.text.toLowerCase().includes(searchVal));
        filtered.forEach(res => {
            let mediaIcon = res.media_url ? '<i class="bi bi-image text-primary ms-1" title="Includes Image"></i>' : '';
            let shortText = res.text.length > 90 ? res.text.substring(0, 90) + '...' : res.text;
            popup.innerHTML += `
                <div class="slash-item" onclick="applyMacroCommand('${res.id}')">
                    <span class="slash-cmd">${res.cmd} ${mediaIcon}</span>
                    <span class="slash-text">${shortText.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</span>
                </div>
            `;
        });
        hasItems = filtered.length > 0;
        popup.style.display = hasItems ? 'block' : 'none';
        
    } else {
        popup.style.display = 'none';
    }
}

window.handleKeydown = function(e) {
    let popup = document.getElementById('slashCommands');
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (popup && popup.style.display === 'block' && popup.querySelector('.slash-item')) {
            popup.querySelector('.slash-item').click();
        } else {
            sendMessage();
        }
    }
}

window.applyMacroCommand = function(id) {
    let macro = cannedResponses.find(m => m.id == id);
    if(macro) {
        let input = document.getElementById('msgInput');
        input.value = macro.text;
        document.getElementById('slashCommands').style.display = 'none';
        input.focus();
        handleInput(input);

        if (macro.media_url) {
            fetch(macro.media_url)
            .then(res => res.blob())
            .then(blob => {
                let reader = new FileReader();
                reader.onload = function() {
                    selectedFilesArray = [{
                        data: reader.result,
                        type: blob.type,
                        name: 'macro_image.jpg'
                    }];
                    renderAttachmentPreviews();
                };
                reader.readAsDataURL(blob);
            }).catch(err => console.error("Error loading macro image:", err));
        } else {
            removeAttachment();
        }
    }
}

window.applyCommand = function(text) {
    let input = document.getElementById('msgInput');
    input.value = text;
    document.getElementById('slashCommands').style.display = 'none';
    input.focus();
    handleInput(input);
}

window.toggleInternalNote = function() {
    isInternalNote = !isInternalNote;
    let input = document.getElementById('msgInput');
    let btn = document.getElementById('internalToggleBtn');
    let wrapper = document.getElementById('inputWrapper');
    
    if(isInternalNote) {
        wrapper.style.backgroundColor = '#fff3cd';
        btn.classList.remove('text-secondary');
        btn.classList.add('text-warning');
        input.placeholder = "Type an internal note (hidden from customer)...";
    } else {
        wrapper.style.backgroundColor = '#fff';
        btn.classList.remove('text-warning');
        btn.classList.add('text-secondary');
        input.placeholder = isWindowClosed ? "Chat locked. Use '//' for templates" : "Message...";
    }
}

function updateCustomerJourney(lastCustomerDate, agentName = null) {
    let journeyContainer = document.getElementById('infoJourney');
    if(!journeyContainer || !currentChatData) return;

    const startDate = safeParseDate(currentChatData.created_at);
    const startTime = crmDisplayTime(startDate);
    const startDay = crmDisplayDate(startDate);

    let journeyHtml = `
        <div class="journey-item system-event">
            <span class="journey-title">Chat Initiated</span>
            <span class="journey-text">Lead captured via WhatsApp</span>
            <span class="journey-time">${startDay} at ${startTime}</span>
        </div>
    `;

    let usedAgent = agentName || currentChatData.current_agent;
    
    if (usedAgent) {
        journeyHtml += `
            <div class="journey-item system-event">
                <span class="journey-title">Agent Assigned</span>
                <span class="journey-text"><strong class="text-dark">${usedAgent.toUpperCase()}</strong> took over the chat</span>
                <span class="journey-time">Assignment Status</span>
            </div>
        `;
    }

    if (lastCustomerDate) {
        const interactDate = safeParseDate(lastCustomerDate);
        const interactTime = crmDisplayTime(interactDate);
        
        journeyHtml += `
            <div class="journey-item">
                <span class="journey-title">Customer Engaged</span>
                <span class="journey-text">${currentChatData.full_name} sent a message</span>
                <span class="journey-time">${crmDisplayDate(interactDate)} at ${interactTime}</span>
            </div>
        `;
    }

    let maxHours = (currentChatData && currentChatData.meta_ad_name && currentChatData.meta_ad_name !== 'null' && currentChatData.meta_ad_name !== '') ? 72 : 24;
    
    if (isWindowClosed) {
        journeyHtml += `
            <div class="journey-item closed-event">
                <span class="journey-title">Window Expired</span>
                <span class="journey-text">${maxHours} hours passed since last reply</span>
                <span class="journey-time">Closed</span>
            </div>
        `;
    } else {
        journeyHtml += `
            <div class="journey-item">
                <span class="journey-title">Active Window</span>
                <span class="journey-text">Agent can send standard messages</span>
                <span class="journey-time">Currently Open</span>
            </div>
        `;
    }

    journeyContainer.innerHTML = journeyHtml;
}

window.toggleLeadInfo = function() {
    let panel = document.getElementById('leadInfoPanel');
    if (window.innerWidth <= 768) {
        panel.style.display = 'block';
        setTimeout(() => panel.classList.add('active-mobile'), 10);
    } else {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
}

window.removeTag = function(tag) {
    if(!activeLeadId) return;

    let badgeElements = document.querySelectorAll('#infoTags .tag-badge');
    badgeElements.forEach(badge => {
        if(badge.getAttribute('data-tag-name') === tag) {
            badge.remove();
        }
    });

    let remaining = document.querySelectorAll('#infoTags .tag-badge');
    if(remaining.length === 0) {
        document.getElementById('infoTags').innerHTML = '<small class="text-muted" idnoTagsText">No tags</small>';
    }

    let activeItem = document.querySelector('.chat-item.active');
    if (activeItem) {
        let currentTags = activeItem.getAttribute('data-tags') || '';
        let newTags = currentTags.split(',').filter(t => t.trim().toLowerCase() !== tag.toLowerCase()).join(',');
        activeItem.setAttribute('data-tags', newTags);
    }

    fetch(`${baseUrl}inbox/remove_tag`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead_id: activeLeadId, tag: tag })
    }).then(() => {
        currentChatListHash = '';
        fetchChatList();
    });
}

window.toggleTagTab = function(tab) {
    if (tab === 'select') {
        document.getElementById('tab-select-tag').classList.add('active');
        document.getElementById('tab-create-tag').classList.remove('active');
        document.getElementById('selectTagView').style.display = 'flex';
        document.getElementById('createTagView').style.display = 'none';
    } else {
        document.getElementById('tab-create-tag').classList.add('active');
        document.getElementById('tab-select-tag').classList.remove('active');
        document.getElementById('selectTagView').style.display = 'none';
        document.getElementById('createTagView').style.display = 'flex';
    }
}

window.addTagFromDropdown = function() {
    let select = document.getElementById('existingTagSelect');
    if(select && select.value) {
        saveTagToLead(select.value);
    }
}

window.createNewTag = function() {
    let input = document.getElementById('newTagInput');
    if(input && input.value.trim()) {
        saveTagToLead(input.value.trim());
    }
}

function saveTagToLead(tag) {
    if(!tag || !activeLeadId) return;

    let existingBadges = Array.from(document.querySelectorAll('#infoTags .tag-badge')).map(b => b.getAttribute('data-tag-name').toLowerCase());
    if (existingBadges.includes(tag.toLowerCase())) {
        document.getElementById('newTagInput').value = '';
        document.getElementById('existingTagSelect').value = '';
        return;
    }

    fetch(`${baseUrl}inbox/add_tag`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead_id: activeLeadId, tag: tag })
    }).then(r => r.json()).then(data => {
        if(data.status === 'success') {
            document.getElementById('newTagInput').value = '';
            document.getElementById('existingTagSelect').value = '';
            
            let noTagsText = document.getElementById('noTagsText');
            if (noTagsText) noTagsText.remove();
            
            document.getElementById('infoTags').innerHTML += `<span class="tag-badge" data-tag-name="${tag}">${tag} <i class="bi bi-x" title="Remove Tag" onclick="removeTag('${tag}')"></i></span>`;
            
            let activeItem = document.querySelector('.chat-item.active');
            if (activeItem) {
                let currentTags = activeItem.getAttribute('data-tags') || '';
                activeItem.setAttribute('data-tags', currentTags ? currentTags + ',' + tag : tag);
            }
            
            fetchGlobalTags();
            currentChatListHash = '';
            fetchChatList(); 
        }
    });
}

function updateTagDropdown() {
    let selectHtml = '<option value="">Select a tag...</option>';
    let filterHtml = '<option value="">All Tags</option>';
    
    let mergedTags = new Set(globalTagsList.map(t => t.name));
    allKnownTags.forEach(t => mergedTags.add(t));
    
    Array.from(mergedTags).sort().forEach(t => {
        selectHtml += `<option value="${t}">${t}</option>`;
        filterHtml += `<option value="${t}">${t}</option>`;
    });
    
    let select = document.getElementById('existingTagSelect');
    if (select) {
        let currentVal = select.value;
        select.innerHTML = selectHtml;
        select.value = currentVal; 
    }
    
    let filterSelect = document.getElementById('filterTag');
    if (filterSelect) {
        let currentFilterVal = filterSelect.value;
        filterSelect.innerHTML = filterHtml;
        filterSelect.value = currentFilterVal;
    }
}

// ===============================================
// SMART INVISIBLE BACKGROUND LIST ENGINE
// ===============================================
function updateChatPagination() {
    const previous = document.getElementById('chatPagePrevious');
    const next = document.getElementById('chatPageNext');
    const label = document.getElementById('chatPaginationPageText');
    const range = document.getElementById('chatPaginationRange');
    if (label) label.textContent = (chatPageLoading && chatPageShowLoading) ? 'Loading...' : `Page ${chatDisplayedPage} of ${chatTotalPages}`;
    const first = chatFilteredTotal ? (chatDisplayedPage - 1) * 50 + 1 : 0;
    const last = chatFilteredTotal ? Math.min(chatDisplayedPage * 50, chatFilteredTotal) : 0;
    if (range) range.textContent = chatPaginationError || `${first}–${last} of ${chatFilteredTotal.toLocaleString('en-IN')}`;
    if (previous) previous.disabled = (chatPageLoading && chatPageShowLoading) || chatDisplayedPage <= 1;
    if (next) next.disabled = (chatPageLoading && chatPageShowLoading) || chatDisplayedPage >= chatTotalPages;
}

window.changeChatPage = function(direction) {
    // A user click takes priority over a silent refresh; the fetch below aborts it.
    if (chatPageLoading && chatPageShowLoading) return;
    const target = chatDisplayedPage + direction;
    if (target < 1 || target > chatTotalPages) return;
    chatPage = target;
    fetchChatList(false, true);
};

// Same frontend chat-item attributes, chat rules and loadChat() as before.
// The PHP endpoint now does classification/filtering BEFORE paging 50 rows.
function fetchChatList(isInitLoad = false, force = false) {
    const signature = [activeTab, document.getElementById('chatSearch')?.value || '',
        document.getElementById('filterUnread')?.value || '',
        document.getElementById('filterTag')?.value || '',
        document.getElementById('filterAgent')?.value || '',
        document.getElementById('filterStartDate')?.value || '',
        document.getElementById('filterEndDate')?.value || ''].join('|');
    if (signature !== chatListQuerySignature) {
        chatListQuerySignature = signature;
        chatPage = 1; chatDisplayedPage = 1;
        currentChatListHash = '';
    }
    if (!force && (chatPageLoading || (currentChatListHash !== '' && Date.now() - chatListLastRequestAt < 30000) || Date.now() - chatListLastErrorAt < 12000)) return;
    if (chatListFetchController) chatListFetchController.abort();
    const controller = new AbortController();
    chatListFetchController = controller;
    chatPageLoading = true;
    chatPageShowLoading = Boolean(force || isInitLoad);
    chatListLastRequestAt = Date.now();
    updateChatPagination();

    const params = new URLSearchParams({
        page: String(chatPage), tab: activeTab,
        search: (document.getElementById('chatSearch')?.value || '').trim(),
        unread: document.getElementById('filterUnread')?.value || '',
        tag: document.getElementById('filterTag')?.value || '',
        agent: document.getElementById('filterAgent')?.value || '',
        start_date: document.getElementById('filterStartDate')?.value || '',
        end_date: document.getElementById('filterEndDate')?.value || ''
    });
    if (isInitLoad && activeConvoId) params.set('focus', activeConvoId);

    fetch(`${baseUrl}inbox/load_chat_list_paged?${params.toString()}`, {
        credentials: 'same-origin', signal: controller.signal
    })
    .then(async response => {
        if (!response.ok) throw new Error(`Chat paging HTTP ${response.status}`);
        return response.json();
    })
    .then(data => {
        if (controller !== chatListFetchController) return;
        if (data.status !== 'success' || !Array.isArray(data.chats)) {
            throw new Error(data.message || 'Invalid chat paging response');
        }
        const container = document.getElementById('chatListContainer');
        if (!container) return;
        chatDisplayedPage = Math.max(1, parseInt(data.page, 10) || 1);
        chatPage = chatDisplayedPage;
        chatFilteredTotal = parseInt(data.filtered_total, 10) || 0;
        chatTotalPages = Math.max(1, parseInt(data.total_pages, 10) || 1);
        chatPaginationError = '';
        const counters = data.counts || {};
        for (const [key, id] of Object.entries({ACTIVE:'count-active',INTERVENED:'count-intervened',EXPIRED:'count-expired',ALL_CHATS:'count-all'})) {
            const element = document.getElementById(id);
            if (element && counters[key] !== undefined) element.innerText = counters[key];
        }
        const chatList = data.chats;
        const newHash = `page${chatDisplayedPage}|` + chatList.map(chat =>
            `${chat.conversation_id}_${chat.unread_count}_${chat.agent_replies}_${chat.last_customer_msg_at}_${chat.agent_name || ''}_${chat.last_message_at || ''}`).join('|');
        const pageChanged = chatDisplayedPage !== parseInt(container.dataset.loadedPage || '0', 10);
        const shouldRender = newHash !== currentChatListHash || isInitLoad || pageChanged;
        let html = '';
        chatList.forEach(chat => {
            if (chat.tags && chat.tags.trim() !== '') {
                chat.tags.split(',').forEach(tag => { if (tag.trim()) allKnownTags.add(tag.trim()); });
            }
            // Existing agent-based frontend check remains; backend checks too.
            const assignedAgentClean = (chat.agent_name || '').trim().toLowerCase();
            if (currentUserRole !== 'admin' && assignedAgentClean !== currentAgentName) return;
            const agentRepliesNum = parseInt(chat.agent_replies || 0, 10);
            const unreadCountNum = parseInt(chat.unread_count || 0, 10);
            const metaAdName = chat.meta_ad_name || '';
            const isCurrentlyActive = String(chat.conversation_id) === String(activeConvoId);
            const activeClass = isCurrentlyActive ? 'active' : '';
            const showBadge = unreadCountNum > 0 && !isCurrentlyActive;
            const badge = showBadge ? `<span class="unread-badge">${unreadCountNum}</span>` : '';
            const lastMsgText = chat.last_message ? chat.last_message : 'No messages yet';
            const statusText = showBadge ? '<strong>New Message</strong>' : lastMsgText;
            const searchString = ((chat.full_name || '') + ' ' + (chat.whatsapp_number || '')).toLowerCase();
            const leadStatus = chat.status || 'New Lead';
            const initial = chat.full_name && chat.full_name.trim() ? chat.full_name.trim().charAt(0).toUpperCase() : 'U';
            html += `
                <div class="chat-item ${activeClass}"
                     data-convo-id="${chat.conversation_id}"
                     data-lead-id="${chat.lead_id}"
                     data-name="${chat.full_name}"
                     data-phone="${chat.whatsapp_number}"
                     data-source="${chat.lead_source || 'WhatsApp'}"
                     data-date="${chat.created_at}"
                     data-tags="${chat.tags || ''}"
                     data-status="${leadStatus}"
                     data-agent="${chat.agent_name || ''}"
                     data-replies="${agentRepliesNum}"
                     data-ad-name="${metaAdName}"
                     data-search="${searchString}"
                     onclick="loadChat(this)">
                    <div class="avatar">${initial}</div>
                    <div class="flex-grow-1 overflow-hidden">
                        <h6 class="mb-0 fw-bold text-truncate contact-name">${chat.full_name}</h6>
                        <small class="text-muted d-block text-truncate">${statusText}</small>
                    </div>
                    ${badge}
                </div>`;
        });
        if (shouldRender) {
            currentChatListHash = newHash;
            container.innerHTML = html || '<div class="text-center text-muted p-3">No chats found.</div>';
            container.dataset.loadedPage = String(chatDisplayedPage);
            if (pageChanged) container.scrollTop = 0;
        }
        // Existing direct ?chat=ID links still open, even for older pages.
        if (isInitLoad && activeConvoId) {
            const selected = Array.from(document.querySelectorAll('.chat-item')).find(
                el => el.getAttribute('data-convo-id') === String(activeConvoId));
            if (selected) loadChat(selected);
        }
        isInitialLoad = false;
        chatListLastErrorAt = 0;
    })
    .catch(error => {
        if (error.name === 'AbortError' || controller !== chatListFetchController) return;
        console.error('Inbox 50/page navigation error:', error);
        chatListLastErrorAt = Date.now();
        chatPaginationError = `Load failed — retry Next/Previous`;
        chatPage = chatDisplayedPage;
        const container = document.getElementById('chatListContainer');
        if (container && !container.querySelector('.chat-item')) {
            container.innerHTML = '<div class="p-3 text-danger small">Unable to load chats. Check browser Network response and PHP error log.</div>';
        }
        // Keep this error visible until the next successful load.
    })
    .finally(() => {
        if (controller === chatListFetchController) {
            chatPageLoading = false;
            chatPageShowLoading = false;
            chatListFetchController = null;
            updateChatPagination();
        }
    });
}


// WhatsApp quoted-message preview. Text/URL is escaped; messages stay in their own conversation.
function crmQuoteEscape(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[c]);
}
function crmQuoteMarkup(message, messagesByWaId) {
    const quotedId = message.reply_to_wa_message_id;
    if (!quotedId) return '';
    const original = messagesByWaId.get(String(quotedId));
    if (!original) {
        return '<div class="crm-quote-unavailable"><i class="bi bi-reply-fill"></i> Reply to message not available in this chat</div>';
    }
    const from = original.sender_type === 'agent' ? 'SCPK / Agent' : 'Customer';
    const mediaUrl = String(original.media_url || '');
    const kind = String(original.message_type || '');
    const mime = String(original.mime_type || '');
    const image = Boolean(mediaUrl) && (kind === 'image' || mime.startsWith('image/'));
    const video = kind === 'video' || mime.startsWith('video/');
    const label = image ? 'Photo' : video ? 'Video' : (kind === 'document' ? 'Document' : (original.message_body || 'Message'));
    const cleanLabel = String(label).replace(/\s+/g, ' ').slice(0, 90);
    const safeThumbnailUrl = /^(https?:\/\/|\/)/i.test(mediaUrl) ? mediaUrl : '';
    const thumb = image && safeThumbnailUrl
        ? '<img class="crm-quote-thumb" src="' + crmQuoteEscape(safeThumbnailUrl) + '" alt="Original photo thumbnail" loading="lazy">'
        : '';
    return '<button type="button" class="crm-quote-link" data-quoted-target="' + crmQuoteEscape(String(quotedId)) +
        '" title="Jump to original message"><span class="crm-quote-copy"><strong>' + crmQuoteEscape(from) +
        '</strong><span>' + crmQuoteEscape(cleanLabel) + '</span></span>' + thumb + '</button>';
}
function crmQuoteInstallJump() {
    const container = document.getElementById('messageContainer');
    if (!container || container.dataset.crmQuoteJumpAttached === '1') return;
    container.dataset.crmQuoteJumpAttached = '1';
    container.addEventListener('click', function(event) {
        const control = event.target.closest('.crm-quote-link');
        if (!control || !container.contains(control)) return;
        const targetId = control.dataset.quotedTarget;
        const target = Array.from(container.querySelectorAll('[data-wa-message-id]'))
            .find(el => el.dataset.waMessageId === targetId);
        if (!target) return;
        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        target.classList.remove('crm-quote-highlight');
        void target.offsetWidth;
        target.classList.add('crm-quote-highlight');
        setTimeout(() => target.classList.remove('crm-quote-highlight'), 2000);
    });
}

// ===============================================
// SMART INVISIBLE MESSAGES ENGINE
// ===============================================
function fetchMessages(convoId) {
    if (!convoId) return;

    fetch(`${baseUrl}inbox/load_messages/${convoId}`)
        .then(r => r.json())
        .then(data => {
            let msgContainer = document.getElementById('messageContainer');
            if(!msgContainer) return;
            
            let msgs = data.messages || [];
            const firstInboundMessage = msgs.find(m => m.sender_type !== 'agent');
            const firstInboundMessageId = firstInboundMessage ? String(firstInboundMessage.id) : null;
            const messagesByWaId = new Map(msgs.filter(m => m.wa_message_id).map(m => [String(m.wa_message_id), m]));
            crmQuoteInstallJump();
            let newHash = msgs.map(m => m.id + '_' + m.delivery_status).join('|');

            if (newHash !== currentMessagesHash) {
                currentMessagesHash = newHash;
                currentMessageCount = msgs.length;
                msgContainer.innerHTML = ''; 
                
                let lastCustomerDateString = null;
                
                if (msgs.length === 0) {
                    msgContainer.innerHTML = `<div class="text-center text-muted mt-5"><i class="bi bi-chat-dots fs-1"></i><p>No messages yet.</p></div>`;
                } else {
                    msgs.forEach(msg => {
                        let isSent = (msg.sender_type === 'agent');
                        if (!isSent) {
                            lastCustomerDateString = msg.created_at; 
                        }

                        let msgDateObj = safeParseDate(msg.created_at);
                        let timeStr = crmDisplayTime(msgDateObj);
                        
                        let hoverDateStr = crmDisplayDate(msgDateObj);
                        let hoverTimeStr = crmDisplayTime(msgDateObj, true); 
                        let senderHover = isSent ? (msg.agent_name || currentChatData?.current_agent || 'Agent') : (currentChatData?.full_name || 'Customer');
                        
                        senderHover = senderHover.replace(/"/g, '&quot;'); 
                        let hoverText = `Sent by: ${senderHover}&#10;Date: ${hoverDateStr}&#10;Time: ${hoverTimeStr} (${crmTimezone})`;

                        let isMsgInternal = false;
                        let rawText = msg.message_body ? msg.message_body.replace(/\s+$/g, '') : ''; 
                        
                        if (msg.is_internal == 1 || msg.is_internal === true) {
                            isMsgInternal = true;
                        } else if (isSent && rawText.startsWith('[INTERNAL]')) {
                            isMsgInternal = true;
                            rawText = rawText.replace('[INTERNAL]', '').trim();
                        }
                        
                        let ticks = '';
                        let bubbleClass = 'msg-received';
                        let wrapperClass = 'msg-wrapper-received';
                        
                        if (isSent) {
                            bubbleClass = isMsgInternal ? 'msg-internal' : 'msg-sent';
                            wrapperClass = 'msg-wrapper-sent';
                            
                            let tickBlue = '#53bdeb';
                            let tickGrey = '#8696a0';
                            let tickStyle = `font-size: 16px; margin-left: 4px; vertical-align: bottom; line-height: 1;`;

                            if(isMsgInternal) {
                                ticks = `<i class="bi bi-lock-fill" style="color: ${tickGrey}; font-size: 12px; margin-left: 4px; vertical-align: baseline;"></i>`;
                            } else if(msg.delivery_status === 'read') {
                                ticks = `<i class="bi bi-check2-all" style="color: ${tickBlue}; ${tickStyle}"></i>`;
                            } else if(msg.delivery_status === 'delivered') {
                                ticks = `<i class="bi bi-check2-all" style="color: ${tickGrey}; ${tickStyle}"></i>`;
                            } else {
                                ticks = `<i class="bi bi-check2" style="color: ${tickGrey}; ${tickStyle}"></i>`;
                            }
                        }

                        let mediaUrl = msg.media_url || '';
                        let mediaHtml = '';
                        
                        if (mediaUrl) {
                            if(msg.mime_type && msg.mime_type.includes('video')) {
                                mediaHtml = `<div class="mb-1"><video controls style="max-width: 100%; max-height: 250px; border-radius: 6px;"><source src="${mediaUrl}" type="${msg.mime_type}"></video></div>`;
                            } else if(msg.mime_type && msg.mime_type.includes('audio')) {
                                mediaHtml = `<div class="mb-1"><audio controls style="max-width: 250px;"><source src="${mediaUrl}" type="${msg.mime_type}"></audio></div>`;
                            } else if(msg.mime_type && (msg.mime_type.includes('pdf') || msg.mime_type.includes('document'))) {
                                mediaHtml = `<div class="mb-1"><a href="${mediaUrl}" target="_blank" class="btn btn-sm btn-light border w-100"><i class="bi bi-file-earmark-arrow-down"></i> Download Document</a></div>`;
                            } else {
                                mediaHtml = `<div class="mb-1"><img src="${mediaUrl}" onclick="openImagePopup('${mediaUrl}')" class="attachment-preview" style="max-width: 100%; max-height: 250px; border-radius: 6px; display: block; object-fit: cover;"></div>`;
                            }
                        }

                        const quotedHtml = crmQuoteMarkup(msg, messagesByWaId);
                        // Ad creative belongs to the FIRST incoming message only.
                        // Existing message text, reply reference and sender logic remain unchanged.
                        const leadAdName = String(currentChatData?.meta_ad_name || '').trim();
                        const firstAdHtml = !isSent && String(msg.id) === firstInboundMessageId && leadAdName && leadAdName !== 'null'
                            ? '<div class="crm-first-ad-creative"><span class="crm-first-ad-creative-label">Ad clicked · Original creative</span><span class="crm-ad-media-slot" data-crm-first-ad="1">Loading ad preview…</span></div>'
                            : '';
                        const waMessageAttr = crmQuoteEscape(msg.wa_message_id || '');
                        msgContainer.insertAdjacentHTML('beforeend', `
                            <div class="msg-wrapper ${wrapperClass}" data-wa-message-id="${waMessageAttr}">
                                <div class="msg-bubble ${bubbleClass}" title="${hoverText}">
                                    ${quotedHtml}
                                    ${mediaHtml}
                                    ${firstAdHtml}
                                    <span class="msg-text">${rawText}</span>
                                    <span class="msg-time">${timeStr} ${ticks}</span>
                                </div>
                            </div>
                        `);
                    });
                }
                
                // Load this ad preview separately; chat rendering never waits for Meta.
                crmAdMediaFirstLeadMessage(convoId, currentChatData?.meta_ad_name || '');
                setTimeout(() => {
                    msgContainer.scrollTop = msgContainer.scrollHeight;
                }, 80);
                
                if (lastCustomerDateString) {
                    convoCustomerDates[convoId] = lastCustomerDateString;
                }
                
                check24HourWindow(lastCustomerDateString);
                updateCustomerJourney(lastCustomerDateString, currentChatData?.current_agent);
            }
        });
}

window.sendMessage = function() {
    let input = document.getElementById('msgInput');
    if(!input) return;
    
    let text = input.value.trim();
    if((!text && selectedFilesArray.length === 0) || !activeConvoId) return;

    let isTemp = 0;
    let tempName = '';
    let tempLang = 'en_US'; 

    let tempMatch = text.match(/^\[Template:\s*(.+?)\]$/i);
    if (tempMatch) {
        isTemp = 1;
        tempName = tempMatch[1].trim(); 
        
        if (!cachedTemplates) {
            let loc = localStorage.getItem('wa_templates_cache');
            if(loc) cachedTemplates = JSON.parse(loc);
        }

        if (cachedTemplates) {
            let foundTemp = cachedTemplates.find(t => t.name === tempName);
            if(foundTemp) tempLang = foundTemp.language;
        }
    }

    // Always inspect the approved template and fill required IMAGE/VIDEO header
    // before sending. Never submit a raw [Template:name] without components.
    if (isTemp && !isInternalNote) {
        const idx = Array.isArray(cachedTemplates) ? cachedTemplates.findIndex(t => t.name === tempName && t.language === tempLang) : -1;
        if (idx >= 0) crmTemplateOpenFromChat(idx);
        else alert('Template not cached. Open WA Templates and click Sync first.');
        return;
    }

    if (isWindowClosed && !isTemp && !isInternalNote) {
        alert("The 24-hour window is closed. Click input area to use '//' for a template message.");
        return;
    }

    let payloads = [];

    if (selectedFilesArray.length > 0) {
        selectedFilesArray.forEach((file, index) => {
            payloads.push({
                conversation_id: activeConvoId, 
                message: (index === 0) ? text : '', // Text caption only on the first image
                is_internal: isInternalNote ? 1 : 0,
                attachment_base64: file.data,
                is_template: 0,
                template_name: '',
                template_language: ''
            });
        });
    } else {
        payloads.push({
            conversation_id: activeConvoId, 
            message: text,
            is_internal: isInternalNote ? 1 : 0,
            attachment_base64: null,
            is_template: isTemp,
            template_name: tempName,
            template_language: tempLang 
        });
    }

    input.value = '';
    input.style.height = 'auto';
    document.getElementById('slashCommands').style.display = 'none';
    removeAttachment();

    async function sendAll() {
        for(let payload of payloads) {
            try {
                let r = await fetch(`${baseUrl}inbox/send_message`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                let data = await r.json();
                if(data.status === 'error') {
                    alert("⚠️ Failed to Send: \n\n" + (data.message || 'Meta API blocked the message. Please check number verification.'));
                }
            } catch(err) {
                console.error("Send message error:", err);
            }
        }
        currentMessagesHash = ''; 
        fetchMessages(activeConvoId);
        currentChatListHash = '';
        fetchChatList(); 
        if(isInternalNote) toggleInternalNote();
    }
    
    sendAll();
}

// Lead Profile-compatible Inbox Notes & Tasks. Existing send/chat/ads code untouched.
// Reads Note rows from inbox/get_lead_notes; writes through existing Lead Profile endpoints.
let inboxCrmToolsLead = null;
let inboxCrmCurrentTab = 'notes';
let inboxCrmNoteSaving = false;
let inboxCrmTaskSaving = false;
let inboxCrmRequestVersion = 0;
let inboxCrmNotesRequestSeq = 0;
let inboxCrmTasksRequestSeq = 0;

function inboxCrmOpenLead(leadId) {
    inboxCrmToolsLead = String(leadId || '');
    ++inboxCrmRequestVersion;
    inboxCrmCurrentTab = 'notes';
    const note = document.getElementById('inboxCrmNoteInput');
    const title = document.getElementById('inboxCrmTaskTitle');
    const time = document.getElementById('inboxCrmTaskTime');
    if (note) note.value = '';
    if (title) title.value = '';
    if (time) time.value = '';
    const noteStatus = document.getElementById('inboxCrmNoteStatus');
    const taskStatus = document.getElementById('inboxCrmTaskStatus');
    if (noteStatus) noteStatus.textContent = '';
    if (taskStatus) taskStatus.textContent = '';
    inboxCrmSwitchTab('notes');
}
function inboxCrmSameLead(lead) {
    return !!lead && String(inboxCrmToolsLead) === String(lead) && String(activeLeadId) === String(lead);
}
function inboxCrmStatus(id, message) {
    const el = document.getElementById(id);
    if (el) el.textContent = message;
}
window.inboxCrmSwitchTab = function(tab) {
    if (tab !== 'notes' && tab !== 'tasks') return;
    inboxCrmCurrentTab = tab;
    const notesTab = document.getElementById('inboxCrmNotesTab');
    const tasksTab = document.getElementById('inboxCrmTasksTab');
    const notesPanel = document.getElementById('inboxCrmNotesPanel');
    const tasksPanel = document.getElementById('inboxCrmTasksPanel');
    if (!notesTab || !tasksTab || !notesPanel || !tasksPanel) return;
    notesTab.classList.toggle('active', tab === 'notes');
    tasksTab.classList.toggle('active', tab === 'tasks');
    notesTab.setAttribute('aria-selected', String(tab === 'notes'));
    tasksTab.setAttribute('aria-selected', String(tab === 'tasks'));
    notesPanel.hidden = tab !== 'notes';
    tasksPanel.hidden = tab !== 'tasks';
    if (!inboxCrmToolsLead) return;
    if (tab === 'notes') inboxCrmLoadNotes(inboxCrmToolsLead);
    else inboxCrmLoadTasks(inboxCrmToolsLead);
};
function inboxCrmDisplayTimestamp(value) {
    if (!value) return '';
    const date = safeParseDate(String(value)); // DB UTC; same company-wide timezone as Inbox.
    return Number.isFinite(date.getTime()) && date.getTime() > 0
        ? crmDisplayDate(date) + ' ' + crmDisplayTime(date) : '';
}
// Same due_date storage semantics as Lead Profile: datetime-local is a company-local wall time.
function inboxCrmWallTimeLabel(value) {
    if (!value) return '-';
    const text = String(value).trim().replace(' ', 'T');
    const offsetAware = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(text);
    const date = new Date(offsetAware ? text : text + 'Z');
    if (Number.isNaN(date.getTime())) return '-';
    return new Intl.DateTimeFormat('en-IN', {
        timeZone: offsetAware ? crmTimezone : 'UTC', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit', hour12: true
    }).format(date);
}
window.inboxCrmQuickReminder = function(hours) {
    const input = document.getElementById('inboxCrmTaskTime');
    if (!input) return;
    const date = new Date(Date.now() + Number(hours) * 3600000);
    const parts = new Intl.DateTimeFormat('en-GB', {
        timeZone: crmTimezone, year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
    }).formatToParts(date);
    const val = type => (parts.find(p => p.type === type) || {}).value || '';
    input.value = `${val('year')}-${val('month')}-${val('day')}T${val('hour')}:${val('minute')}`;
};
function inboxCrmMessageItem(text, css) {
    const el = document.createElement('div');
    el.className = css;
    el.textContent = text;
    return el;
}
async function inboxCrmLoadNotes(leadId) {
    if (!inboxCrmSameLead(leadId)) return;
    const list = document.getElementById('inboxCrmNotesList');
    if (!list) return;
    const version = inboxCrmRequestVersion;
    const requestSeq = ++inboxCrmNotesRequestSeq;
    list.replaceChildren(inboxCrmMessageItem('Loading notes...', 'inbox-crm-tool-empty'));
    try {
        const res = await fetch(`${baseUrl}inbox/get_lead_notes?lead_id=${encodeURIComponent(leadId)}`, {
            credentials: 'same-origin', cache: 'no-store', headers: {Accept:'application/json'}
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const json = await res.json();
        if (json.status !== 'success' || !Array.isArray(json.data)) throw new Error('Invalid notes response');
        if (!inboxCrmSameLead(leadId) || version !== inboxCrmRequestVersion || requestSeq !== inboxCrmNotesRequestSeq) return;
        list.replaceChildren();
        if (!json.data.length) {
            list.append(inboxCrmMessageItem('No notes yet', 'inbox-crm-tool-empty'));
            return;
        }
        for (const n of json.data) {
            const item = document.createElement('div');
            item.className = 'inbox-crm-note-item';
            const body = document.createElement('div');
            body.textContent = String(n.note_text || '');
            const meta = document.createElement('span');
            meta.className = 'inbox-crm-tool-meta';
            meta.textContent = [n.created_by || '', inboxCrmDisplayTimestamp(n.created_at)].filter(Boolean).join(' · ');
            item.append(body, meta);
            list.append(item);
        }
    } catch (e) {
        if (inboxCrmSameLead(leadId) && version === inboxCrmRequestVersion && requestSeq === inboxCrmNotesRequestSeq)
            list.replaceChildren(inboxCrmMessageItem('Unable to load notes. Reopen Notes to retry.', 'inbox-crm-tool-empty'));
    }
}
window.inboxCrmSaveNote = async function(event) {
    if (event) event.preventDefault();
    if (inboxCrmNoteSaving) return;
    const leadId = String(inboxCrmToolsLead || '');
    const input = document.getElementById('inboxCrmNoteInput');
    const button = document.getElementById('inboxCrmSaveNoteBtn');
    const note = input ? input.value.trim() : '';
    if (!inboxCrmSameLead(leadId) || !note) return;
    inboxCrmNoteSaving = true;
    if (button) button.disabled = true;
    inboxCrmStatus('inboxCrmNoteStatus', 'Saving note...');
    try {
        const form = new FormData();
        form.append('lead_id', leadId);
        form.append('note', note);
        // Same endpoint & SQL as the Lead Profile Save Note button.
        const response = await fetch(`${baseUrl}leadprofile/add_note`, {
            method:'POST', credentials:'same-origin', body: form, redirect:'follow'
        });
        if (!response.ok) throw new Error('HTTP ' + response.status);
        if (inboxCrmSameLead(leadId)) {
            if (input && input.value.trim() === note) input.value = '';
            inboxCrmStatus('inboxCrmNoteStatus', 'Note submitted.');
            await inboxCrmLoadNotes(leadId);
        }
    } catch(e) {
        if (inboxCrmSameLead(leadId)) inboxCrmStatus('inboxCrmNoteStatus', 'Note could not be confirmed. Check Lead Profile before trying again.');
    } finally {
        inboxCrmNoteSaving = false;
        if (button) button.disabled = false;
    }
};
async function inboxCrmLoadTasks(leadId) {
    if (!inboxCrmSameLead(leadId)) return;
    const list = document.getElementById('inboxCrmTaskList');
    if (!list) return;
    const version = inboxCrmRequestVersion;
    const requestSeq = ++inboxCrmTasksRequestSeq;
    list.replaceChildren(inboxCrmMessageItem('Loading tasks...', 'inbox-crm-tool-empty'));
    try {
        const res = await fetch(`${baseUrl}leadprofile/get_tasks/${encodeURIComponent(leadId)}`, {
            credentials:'same-origin', cache:'no-store', headers:{Accept:'application/json'}
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if (data.status !== 'success' || !Array.isArray(data.data)) throw new Error('Invalid tasks response');
        if (!inboxCrmSameLead(leadId) || version !== inboxCrmRequestVersion || requestSeq !== inboxCrmTasksRequestSeq) return;
        list.replaceChildren();
        if (!data.data.length) {
            list.append(inboxCrmMessageItem('No pending tasks', 'inbox-crm-tool-empty'));
            return;
        }
        for (const task of data.data) {
            const item = document.createElement('li');
            item.className = 'inbox-crm-task-item';
            const text = document.createElement('div');
            const title = document.createElement('strong');
            title.textContent = String(task.task_title || 'Reminder');
            const time = document.createElement('span');
            time.className = 'inbox-crm-tool-meta';
            time.textContent = inboxCrmWallTimeLabel(task.due_date);
            text.append(title,time);
            const done = document.createElement('button');
            done.type = 'button';
            done.title = 'Mark as done';
            done.setAttribute('aria-label', 'Complete task');
            done.innerHTML = '<i class="bi bi-check-circle-fill" aria-hidden="true"></i>';
            done.addEventListener('click', () => inboxCrmCompleteTask(leadId, task.id, done));
            item.append(text,done);
            list.append(item);
        }
    } catch(e) {
        if (inboxCrmSameLead(leadId) && version === inboxCrmRequestVersion && requestSeq === inboxCrmTasksRequestSeq)
            list.replaceChildren(inboxCrmMessageItem('Unable to load tasks. Reopen Tasks to retry.', 'inbox-crm-tool-empty'));
    }
}
window.inboxCrmSaveTask = async function(event) {
    if (event) event.preventDefault();
    if (inboxCrmTaskSaving) return;
    const leadId = String(inboxCrmToolsLead || '');
    const titleInput = document.getElementById('inboxCrmTaskTitle');
    const dateInput = document.getElementById('inboxCrmTaskTime');
    const button = document.getElementById('inboxCrmSaveTaskBtn');
    const title = titleInput ? titleInput.value.trim() : '';
    const dueDate = dateInput ? dateInput.value : '';
    if (!inboxCrmSameLead(leadId) || !title || !dueDate) return;
    inboxCrmTaskSaving = true;
    if (button) button.disabled = true;
    inboxCrmStatus('inboxCrmTaskStatus', 'Setting reminder...');
    try {
        // Same endpoint sends the same lead_tasks, lead_notes and notifications as Lead Profile.
        const res = await fetch(`${baseUrl}leadprofile/add_task`, {
            method:'POST', credentials:'same-origin',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({lead_id:leadId,title:title,due_date:dueDate})
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if (data.status !== 'success') throw new Error(data.message || 'Unable to set reminder');
        if (inboxCrmSameLead(leadId)) {
            if (titleInput && titleInput.value.trim() === title) titleInput.value = '';
            if (dateInput && dateInput.value === dueDate) dateInput.value = '';
            inboxCrmStatus('inboxCrmTaskStatus', 'Reminder saved.');
            await inboxCrmLoadTasks(leadId);
        }
    } catch(e) {
        if (inboxCrmSameLead(leadId)) inboxCrmStatus('inboxCrmTaskStatus', 'Reminder not saved: ' + e.message);
    } finally {
        inboxCrmTaskSaving = false;
        if (button) button.disabled = false;
    }
};
async function inboxCrmCompleteTask(leadId, taskId, button) {
    if (!inboxCrmSameLead(leadId) || !taskId) return;
    button.disabled = true;
    inboxCrmStatus('inboxCrmTaskStatus', 'Completing task...');
    try {
        const res = await fetch(`${baseUrl}leadprofile/complete_task`, {
            method:'POST', credentials:'same-origin',
            headers:{'Content-Type':'application/json'}, body:JSON.stringify({task_id:taskId})
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if (data.status !== 'success') throw new Error('Task not completed');
        if (inboxCrmSameLead(leadId)) {
            inboxCrmStatus('inboxCrmTaskStatus', 'Task completed.');
            await inboxCrmLoadTasks(leadId);
        }
    } catch (e) {
        if (inboxCrmSameLead(leadId)) inboxCrmStatus('inboxCrmTaskStatus', 'Could not complete task.');
    } finally {
        button.disabled = false;
    }
}
// When returning from Lead Profile, show the newest shared notes/tasks without changing chat polling.
document.addEventListener('visibilitychange', function() {
    if (!document.hidden && inboxCrmToolsLead && inboxCrmSameLead(inboxCrmToolsLead)) {
        if (inboxCrmCurrentTab === 'notes') inboxCrmLoadNotes(inboxCrmToolsLead);
        else inboxCrmLoadTasks(inboxCrmToolsLead);
    }
});

function initAppState() {
    fetchGlobalTags(); 
    fetchMacros();
    fetchLiveTemplates(); 
    fetchMetaAds();

    let initialMode = APP_CONFIG.appMode; 
    appMode = ''; 
    switchAppMode(null, initialMode, true);

    const mobileBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if(mobileBtn && sidebar && overlay) {
        mobileBtn.addEventListener('click', function() {
            sidebar.classList.add('show');
            overlay.classList.add('show');
        });

        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        });
        
        document.querySelectorAll('.sidebar .nav-link').forEach(link => {
            link.addEventListener('click', () => {
                sidebar.classList.remove('show');
                overlay.classList.remove('show');
            });
        });
    }
}

document.addEventListener("DOMContentLoaded", function() {
    initAppState();
});

// ===============================================
// GLOBAL OUTSIDE CLICK LISTENER TO CLOSE POPUPS
// ===============================================
document.addEventListener('click', function(e) {
    let emojiPicker = document.getElementById('emojiPicker');
    let slashCommands = document.getElementById('slashCommands');
    
    if (emojiPicker && emojiPicker.style.display === 'grid') {
        if (!emojiPicker.contains(e.target) && !e.target.classList.contains('bi-emoji-smile')) {
            emojiPicker.style.display = 'none';
        }
    }

    if (slashCommands && slashCommands.style.display === 'block') {
        if (!slashCommands.contains(e.target) && e.target.id !== 'msgInput') {
            slashCommands.style.display = 'none';
        }
    }
});

// ===============================================
// CONTINUOUS SILENT BACKGROUND ENGINE (SINGLE-TAB LOCK)
// ===============================================
let lastNotifId = 0;
let lastSoundPlayedAt = 0;
let audioCtx = null;

function playAiryChimeSound() {
    let now = Date.now();
    if (now - lastSoundPlayedAt < 4000) return;
    lastSoundPlayedAt = now;

    let sound = document.getElementById('notifSound');
    if (sound) {
        sound.volume = 0.6;
        sound.currentTime = 0;
        sound.play().catch(e => {});
    }
}

function showSingleTabNotification(title, message, targetUrl, notifId) {
    if (!("Notification" in window)) return;

    let globalLockKey = 'crm_notif_fired_' + notifId;
    if (localStorage.getItem(globalLockKey)) return;
    localStorage.setItem(globalLockKey, Date.now().toString());

    setTimeout(() => { localStorage.removeItem(globalLockKey); }, 60000);

    if (Notification.permission === "granted") {
        try {
            let n = new Notification(title, {
                body: message,
                icon: `${baseUrl}favicon.png`,
                tag: 'crm-unique-' + notifId
            });
            n.onclick = function(e) {
                e.preventDefault();
                window.focus();
                if (targetUrl) window.location.href = targetUrl;
            };
        } catch(e) {}
    } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                showSingleTabNotification(title, message, targetUrl, notifId);
            }
        });
    }
}

setInterval(() => {
    if(appMode !== 'macros' && appMode !== 'tags' && appMode !== 'templates' && appMode !== 'meta_ads' && appMode !== 'broadcasts') {
        fetchChatList();
        if (activeConvoId) {
            fetchMessages(activeConvoId);
        }

        fetch(`${baseUrl}settings/get_user_alerts?last_id=${lastNotifId}`)
            .then(r => r.json())
            .then(data => {
                if (data.sync_id !== undefined) {
                    lastNotifId = data.sync_id;
                    return;
                }
                
                if (data.notifications && data.notifications.length > 0) {
                    let shouldPlaySound = false;

                    data.notifications.forEach(n => {
                        let nId = parseInt(n.id);
                        lastNotifId = Math.max(lastNotifId, nId);
                        shouldPlaySound = true;
                        showSingleTabNotification(n.title, n.message, n.url || `${baseUrl}inbox/live_chat`, nId);
                    });

                    if (shouldPlaySound) {
                        playAiryChimeSound();
                    }
                }
            })
            .catch(e => {});
    }
}, 3000);

if ("Notification" in window && Notification.permission !== "granted" && Notification.permission !== "denied") {
    Notification.requestPermission();
}

// ==========================================
// QUICK REPLIES (MACROS) ENGINE
// ==========================================
let macroModalInstance = null;
let macroSelectedBase64 = null;
let macroRemoveImage = 0;
let macroExistingUrl = null;

function fetchMacros() {
    fetch(`${baseUrl}inbox/get_macros`)
    .then(r => r.json())
    .then(data => {
        if(data.status === 'success') {
            cannedResponses = data.data.map(m => ({ 
                id: m.id, 
                cmd: m.shortcut, 
                text: m.message,
                media_url: m.media_url,
                agent_name: m.agent_name
            }));
            renderMacrosTable();
        }
    });
}

window.openMacroModal = function(id = null, shortcut = '', message = '', media_url = null) {
    if(!macroModalInstance) macroModalInstance = new bootstrap.Modal(document.getElementById('macroModal'));
    document.getElementById('macroId').value = id || '';
    document.getElementById('macroShortcut').value = shortcut;
    document.getElementById('macroMessage').value = message;
    document.getElementById('macroModalTitle').innerHTML = id ? '<i class="bi bi-pencil-square text-primary me-2"></i> Edit Quick Reply' : '<i class="bi bi-plus-circle text-success me-2"></i> Add Quick Reply';
    
    macroSelectedBase64 = null;
    macroRemoveImage = 0;
    macroExistingUrl = media_url;
    document.getElementById('macroImageInput').value = '';
    
    if (media_url) {
        document.getElementById('macroImagePreview').src = media_url;
        document.getElementById('macroImagePreviewContainer').style.display = 'block';
    } else {
        document.getElementById('macroImagePreviewContainer').style.display = 'none';
    }

    macroModalInstance.show();
}

window.editMacro = function(id) {
    let m = cannedResponses.find(x => x.id == id);
    if(m) openMacroModal(m.id, m.cmd, m.text, m.media_url);
}

window.handleMacroImage = function(e) {
    let file = e.target.files[0];
    if(!file) return;
    let reader = new FileReader();
    reader.onload = function(event) {
        macroSelectedBase64 = event.target.result;
        macroRemoveImage = 0;
        document.getElementById('macroImagePreview').src = macroSelectedBase64;
        document.getElementById('macroImagePreviewContainer').style.display = 'block';
    };
    reader.readAsDataURL(file);
}

window.removeMacroImage = function() {
    macroSelectedBase64 = null;
    macroRemoveImage = 1;
    macroExistingUrl = null;
    document.getElementById('macroImageInput').value = '';
    document.getElementById('macroImagePreviewContainer').style.display = 'none';
}

window.saveMacro = function() {
    let id = document.getElementById('macroId').value;
    let shortcut = document.getElementById('macroShortcut').value.trim();
    let message = document.getElementById('macroMessage').value.trim();
    
    if(!shortcut || !message) return alert("Shortcut and Full Message are required!");
    
    let payload = {
        id: id,
        shortcut: shortcut,
        message: message,
        attachment_base64: macroSelectedBase64,
        remove_image: macroRemoveImage,
        media_url: macroExistingUrl
    };

    fetch(`${baseUrl}inbox/save_macro`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    }).then(r=>r.json()).then(res => {
        if(res.status === 'success') {
            macroModalInstance.hide();
            fetchMacros();
        }
    });
}

window.deleteMacro = function(id) {
    if(!confirm("Are you sure you want to delete this Quick Reply?")) return;
    fetch(`${baseUrl}inbox/delete_macro`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id})
    }).then(r=>r.json()).then(res => {
        if(res.status === 'success') fetchMacros();
    });
}

function renderMacrosTable() {
    let tbody = document.getElementById('macrosTableBody');
    if(!tbody) return;
    
    if(cannedResponses.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-5"><i class="bi bi-lightning fs-2 d-block mb-2 text-warning"></i> No Quick Replies found.<br>Click 'Add New Reply' to create your first shortcut.</td></tr>`;
        return;
    }
    
    tbody.innerHTML = cannedResponses.map((m, index) => {
        let mediaBadge = m.media_url ? `<span class="badge bg-light text-primary border border-primary border-opacity-25 ms-2"><i class="bi bi-image"></i> Image Attached</span>` : '';
        let creatorName = m.agent_name || 'Admin';

        return `
        <tr>
            <td class="ps-4 fw-bold text-muted">${index + 1}</td>
            <td class="fw-bold text-primary" style="font-size: 14px;">${m.cmd}</td>
            <td style="font-size: 13px; color: #555; white-space: pre-wrap;">${m.text.length > 80 ? m.text.substring(0,80)+'...' : m.text} ${mediaBadge}</td>
            <td style="font-size: 13px; color: #555;"><i class="bi bi-person-circle text-secondary me-1"></i> ${creatorName}</td>
            <td class="text-end pe-4">
                <button class="btn btn-sm btn-light border me-1 text-primary shadow-sm" onclick="editMacro('${m.id}')"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-danger shadow-sm" onclick="deleteMacro('${m.id}')"><i class="bi bi-trash"></i></button>
            </td>
        </tr>
    `}).join('');
}

// ==========================================
// TAGS MANAGER ENGINE
// ==========================================
let tagModalInstance = null;

window.fetchGlobalTags = function() {
    fetch(`${baseUrl}inbox/get_global_tags`)
    .then(r => r.json())
    .then(data => {
        if(data.status === 'success') {
            globalTagsList = data.data;
            renderTagsTable();
            updateTagDropdown();
        }
    });
}

window.openTagModal = function(id = null, name = '') {
    if(!tagModalInstance) tagModalInstance = new bootstrap.Modal(document.getElementById('tagModal'));
    document.getElementById('tagId').value = id || '';
    document.getElementById('tagName').value = name;
    document.getElementById('tagModalTitle').innerHTML = id ? '<i class="bi bi-pencil-square text-primary me-2"></i> Edit Tag' : '<i class="bi bi-plus-circle text-success me-2"></i> Add Tag';
    tagModalInstance.show();
}

window.editGlobalTag = function(id) {
    let t = globalTagsList.find(x => x.id == id);
    if(t) openTagModal(t.id, t.name);
}

window.saveGlobalTag = function() {
    let id = document.getElementById('tagId').value;
    let name = document.getElementById('tagName').value.trim();
    
    if(!name) return alert("Tag Name is required!");
    
    fetch(`${baseUrl}inbox/save_global_tag`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id, name})
    }).then(r=>r.json()).then(res => {
        if(res.status === 'success') {
            tagModalInstance.hide();
            fetchGlobalTags();
        }
    });
}

window.deleteGlobalTag = function(id) {
    if(!confirm("Are you sure you want to delete this Tag from the database? (Note: It won't remove it from existing leads)")) return;
    fetch(`${baseUrl}inbox/delete_global_tag`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id})
    }).then(r=>r.json()).then(res => {
        if(res.status === 'success') fetchGlobalTags();
    });
}

function renderTagsTable() {
    let tbody = document.getElementById('tagsTableBody');
    if(!tbody) return;
    
    if(globalTagsList.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center text-muted py-5"><i class="bi bi-tags fs-2 d-block mb-2 text-primary"></i> No Tags found.<br>Click 'Add New Tag' to create one.</td></tr>`;
        return;
    }
    
    tbody.innerHTML = globalTagsList.map((t, index) => {
        let creatorName = t.created_by_name || 'Admin';
        return `
        <tr>
            <td class="ps-4 fw-bold text-muted">${index + 1}</td>
            <td class="fw-bold" style="font-size: 14px; color: #333;">${t.name}</td>
            <td style="font-size: 13px; color: #555;"><i class="bi bi-person-circle text-secondary me-1"></i> ${creatorName}</td>
            <td class="text-end pe-4">
                <button class="btn btn-sm btn-light border me-1 text-primary shadow-sm" onclick="editGlobalTag('${t.id}')"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-danger shadow-sm" onclick="deleteGlobalTag('${t.id}')"><i class="bi bi-trash"></i></button>
            </td>
        </tr>
    `}).join('');
}

// ==========================================
// TEMPLATES MANAGER ENGINE
// ==========================================
window.forceSyncTemplates = function() {
    let btn = document.querySelector('button[onclick="forceSyncTemplates()"]');
    if(btn) btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span> Syncing...`;
    
    fetch(`${baseUrl}inbox/get_templates`)
    .then(r => r.json())
    .then(json => {
        if (json.data && json.data.length > 0) {
            cachedTemplates = json.data;
            localStorage.setItem('wa_templates_cache', JSON.stringify(json.data)); 
            renderTemplatesTable();
            alert("Templates Synced Successfully!");
        } else {
            alert("Failed to sync templates. Check Meta API configurations.");
        }
        if(btn) btn.innerHTML = `<i class="bi bi-arrow-repeat me-1"></i> Sync`;
    }).catch(err => {
        alert("Error syncing templates!");
        if(btn) btn.innerHTML = `<i class="bi bi-arrow-repeat me-1"></i> Sync`;
    });
}

// Individual template popup uses Meta's actual component definitions (not guesses).
let crmTemplateSelected = null;
let crmTemplateBusy = false;
function crmTemplateEscape(text) {
    return String(text == null ? '' : text).replace(/[&<>"']/g,
      ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
window.renderTemplatesTable = function() {
    const tbody = document.getElementById('templatesTableBody');
    if (!tbody) return;
    if (!Array.isArray(cachedTemplates) || !cachedTemplates.length) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-5">No Templates Synced. Click Sync to fetch Meta-approved templates.</td></tr>`;
        return;
    }
    tbody.innerHTML = cachedTemplates.map((t,index) => {
        const status = String(t.status || 'UNKNOWN');
        const klass = status === 'APPROVED' ? 'bg-success' : (status === 'PENDING' ? 'bg-warning text-dark' : 'bg-secondary');
        return `<tr>
            <td class="ps-4"><button type="button" class="crm-template-open" onclick="crmTemplateOpen(${index})" title="View and send this template">${crmTemplateEscape(t.name)}</button></td>
            <td>${crmTemplateEscape(t.language)}</td><td>${crmTemplateEscape(t.category)}</td>
            <td><span class="badge ${klass}">${crmTemplateEscape(status)}</span></td>
            <td class="text-end pe-4"><button type="button" class="btn btn-sm btn-outline-primary" onclick="crmTemplateOpen(${index})">View / Send</button></td>
        </tr>`;
    }).join('');
};
function crmTemplateState(text, kind='') {
    const el = document.getElementById('crmTemplateSendStatus');
    if (!el) return;
    el.className = 'crm-template-status' + (kind ? ' is-' + kind : '');
    el.textContent = text;
}
function crmTemplateUniqueVars(text) {
    return [...new Set([...String(text||'').matchAll(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g)].map(m=>m[1]))];
}
function crmTemplateNewInput(container, label, kind, key, type='text', placeholder='') {
    const wrapper = document.createElement('div');
    const id = 'crmTemplateVar' + container.children.length;
    const labelEl = document.createElement('label'); labelEl.htmlFor=id; labelEl.textContent=label;
    const input = document.createElement('input'); input.id=id; input.type=type;
    input.className='form-control'; input.required=true; input.maxLength=2048;
    input.placeholder=placeholder; input.dataset.kind=kind; input.dataset.key=String(key);
    wrapper.append(labelEl,input); container.append(wrapper);
    return input;
}
function crmTemplateRender(t) {
    const preview = document.getElementById('crmTemplatePreview');
    const fields = document.getElementById('crmTemplateVariableFields');
    preview.replaceChildren(); fields.replaceChildren();
    let unsupported = '';
    const section = (heading,text) => {
        const h=document.createElement('h6'); h.textContent=heading;
        const pre=document.createElement('pre'); pre.textContent=text || '(empty)';
        preview.append(h,pre);
    };
    for (const comp of (Array.isArray(t.components) ? t.components : [])) {
        const type=String(comp.type||'').toUpperCase();
        if (type==='HEADER') {
            const format=String(comp.format||'TEXT').toUpperCase();
            section('Header · '+format, format==='TEXT' ? comp.text : 'Media header required: '+format);
            if (format==='TEXT') crmTemplateUniqueVars(comp.text).forEach(key=>crmTemplateNewInput(fields,'Header variable {{'+key+'}}','header_text',key));
            else if (format==='IMAGE') {
                const picker=crmTemplateNewInput(fields,'IMAGE header · Choose JPG/PNG from computer','header_image_file','file','file');
                picker.required=false; picker.accept='image/jpeg,image/png';
                const urlField=crmTemplateNewInput(fields,'OR IMAGE header · Full public HTTPS image URL','header_media_url','url','url','https://your-site.com/photo.jpg');
                urlField.required=false;
                scpkAddGalleryChooseButton(fields,'IMAGE');
            }
            else if (format==='VIDEO') {
                const urlField=crmTemplateNewInput(fields,'VIDEO header · Public HTTPS URL (or choose gallery)','header_media_url','url','url','https://');
                urlField.required=false;
                scpkAddGalleryChooseButton(fields,'VIDEO');
            }
            else if (format==='DOCUMENT') crmTemplateNewInput(fields,format+' header · Public HTTPS URL','header_media_url','url','url','https://');
            else unsupported='Unsupported header format: '+format;
        } else if (type==='BODY') {
            section('Body',comp.text);
            crmTemplateUniqueVars(comp.text).forEach(key=>crmTemplateNewInput(fields,'Body variable {{'+key+'}}','body',key));
        } else if (type==='FOOTER') section('Footer',comp.text);
        else if (type==='BUTTONS') {
            const h=document.createElement('h6'); h.textContent='Buttons'; preview.append(h);
            const buttons=document.createElement('div'); buttons.className='crm-template-buttons';
            (comp.buttons||[]).forEach((b,index)=>{
                const s=document.createElement('span'); s.textContent=b.text||b.type||'Button'; buttons.append(s);
                const kind=String(b.type||'').toUpperCase();
                if(kind==='URL' && /\{\{\s*1\s*\}\}/.test(String(b.url||''))) {
                    crmTemplateNewInput(fields,'Button '+(index+1)+' · URL variable {{1}}','button_url',index);
                } else if(!['URL','QUICK_REPLY','PHONE_NUMBER','COPY_CODE'].includes(kind)) unsupported='Unsupported button: '+kind;
            });
            preview.append(buttons);
        } else unsupported='Advanced component '+type+' needs custom configuration';
    }
    const button=document.getElementById('crmTemplateSendButton');
    button.disabled=(t.status!=='APPROVED') || !!unsupported;
    crmTemplateState(unsupported || (t.status!=='APPROVED'?'Only approved templates can be sent.':'Review the approved content, enter variables and recipient, then send.'), unsupported?'error':'');
}
window.crmTemplateOpen = async function(index) {
    const t=Array.isArray(cachedTemplates) ? cachedTemplates[index] : null;
    if(!t) return;
    crmTemplateSelected=t;
    window.scpkSelectedTemplateMedia=null;
    document.getElementById('crmTemplateDetailTitle').textContent=t.name||'Template';
    document.getElementById('crmTemplateMetaInfo').textContent=[t.language,t.category,t.status].filter(Boolean).join(' · ');
    document.getElementById('crmTemplatePhone').value='';
    crmTemplateRender(t);
    bootstrap.Modal.getOrCreateInstance(document.getElementById('crmTemplateDetailModal')).show();
    // Refresh from Meta so an old localStorage cache cannot cause wrong parameters.
    crmTemplateState('Checking the current approved template format with Meta…');
    try {
        const resp=await fetch(baseUrl+'inbox/get_templates',{credentials:'same-origin',cache:'no-store'});
        const data=await resp.json();
        const fresh=(data.data||[]).find(x=>x.name===t.name && x.language===t.language);
        if(!fresh) throw new Error('Template not found in live Meta response');
        if (crmTemplateSelected!==t) return;
        crmTemplateSelected=fresh;
        cachedTemplates=data.data;
        localStorage.setItem('wa_templates_cache',JSON.stringify(data.data));
        crmTemplateRender(fresh);
    } catch(e) {
        if(crmTemplateSelected!==t) return;
        document.getElementById('crmTemplateSendButton').disabled=true;
        crmTemplateState('Live Meta template could not be refreshed; sending disabled until Sync works.','error');
    }
};
// Chat // selection reuses the same approved-template preview, not a blind send.
window.crmTemplateOpenFromChat = function(index) {
    if (!activeConvoId) { alert('Select a customer chat first.'); return; }
    const digits = (document.getElementById('infoPhone')?.textContent || '').replace(/\D/g, '');
    const input = document.getElementById('msgInput');
    if (input) { input.value=''; const slash=document.getElementById('slashCommands'); if(slash) slash.style.display='none'; }
    crmTemplateOpen(index);
    document.getElementById('crmTemplatePhone').value=digits;
};

window.crmTemplateSend = async function(event) {
    if(event && typeof event.preventDefault==='function') event.preventDefault();
    if(crmTemplateBusy || !crmTemplateSelected || crmTemplateSelected.status!=='APPROVED') return;
    const phone=document.getElementById('crmTemplatePhone').value.replace(/\D/g,'');
    if(phone.length<10 || phone.length>15) {crmTemplateState('Enter a valid customer WhatsApp number.','error');return;}
    const values={body:{},header_text:{},button_url:{}};
    const galleryMedia=window.scpkSelectedTemplateMedia || null;
    let headerImageFile=null;
    let imageHeaderPresent=false;
    for(const el of document.querySelectorAll('#crmTemplateVariableFields input')) {
        if(el.dataset.kind==='header_image_file') {
            imageHeaderPresent=true;
            headerImageFile=(el.files && el.files[0]) || null;
            continue;
        }
        const value=el.value.trim();
        if(el.dataset.kind==='header_media_url') {
            if(!value) {
                if(imageHeaderPresent || galleryMedia) continue; // Library or local image replaces URL.
                el.focus();crmTemplateState('Fill the required public HTTPS media URL.','error');return;
            }
            let valid=false;
            try { const parsed=new URL(value); valid=parsed.protocol==='https:' && !!parsed.hostname && parsed.hostname.includes('.'); }
            catch(e) { valid=false; }
            if(!valid) {el.focus();crmTemplateState('Enter the full public HTTPS media URL, not just https://.','error');return;}
            values.header_media_url=value;
        } else {
            if(!value) {el.focus();crmTemplateState('Fill every required variable.','error');return;}
            values[el.dataset.kind][el.dataset.key]=value;
        }
    }
    if(galleryMedia && (headerImageFile || values.header_media_url)) {
        crmTemplateState('Use ONLY one: media gallery, local image upload, or HTTPS URL.','error');return;
    }
    if(imageHeaderPresent) {
        if(headerImageFile && values.header_media_url) {
            crmTemplateState('Use either a JPG/PNG file OR an HTTPS image URL, not both.','error');return;
        }
        if(!headerImageFile && !values.header_media_url && !galleryMedia) {
            crmTemplateState('Choose a JPG/PNG image, or enter its full public HTTPS URL.','error');return;
        }
        if(headerImageFile && (!['image/jpeg','image/png'].includes(headerImageFile.type) ||
            headerImageFile.size<1 || headerImageFile.size>5*1024*1024)) {
            crmTemplateState('Choose a JPG/PNG image under 5 MB.','error');return;
        }
    }
    const button=document.getElementById('crmTemplateSendButton');
    crmTemplateBusy=true;button.disabled=true;
    crmTemplateState('Finding the customer CRM chat…');
    try {
        const find=await fetch(baseUrl+'inbox/template_recipient?phone='+encodeURIComponent(phone),{credentials:'same-origin',cache:'no-store'});
        const recipient=await find.json();
        if(recipient.status!=='success' || !recipient.conversation_id) throw new Error(recipient.message||'CRM chat not found');
        // This deliberate confirmation avoids an unintended send when the number was mistyped.
        if(!window.confirm('Send approved template "'+crmTemplateSelected.name+'" to '+recipient.lead_name+' ('+phone+')?')) {
            crmTemplateState('Cancelled. No template was sent.'); return;
        }
        if(galleryMedia) {
            crmTemplateState('Preparing selected gallery media for Meta…');
            const prepare=new FormData();
            prepare.append('media_id',galleryMedia.id);
            prepare.append('template_name',crmTemplateSelected.name);
            prepare.append('template_language',crmTemplateSelected.language);
            const r=await fetch(baseUrl+'inbox/template_media_prepare',{method:'POST',credentials:'same-origin',headers:{'X-SCPK-CSRF':APP_CONFIG.scpkActionToken},body:prepare});
            const d=await r.json();
            if(d.status!=='success' || !/^[0-9]{5,64}$/.test(String(d.media_id||''))) throw new Error(d.message||'Gallery media could not be prepared');
            values.header_media_id=String(d.media_id);
        }
        if(headerImageFile) {
            crmTemplateState('Uploading JPG/PNG image to Meta…');
            const uploadBody=new FormData();
            uploadBody.append('header_media',headerImageFile,headerImageFile.name);
            uploadBody.append('template_name',crmTemplateSelected.name);
            uploadBody.append('template_language',crmTemplateSelected.language);
            const uploadResp=await fetch(baseUrl+'inbox/template_header_media_upload',{
                method:'POST',credentials:'same-origin',body:uploadBody
            });
            const uploadResult=await uploadResp.json();
            if(uploadResult.status!=='success' || !/^[0-9]{5,64}$/.test(String(uploadResult.media_id||''))) {
                throw new Error(uploadResult.message||'Image upload to Meta failed; template was not sent.');
            }
            values.header_media_id=String(uploadResult.media_id);
        }
        crmTemplateState('Sending template to Meta…');
        const response=await fetch(baseUrl+'inbox/send_message',{
            method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({conversation_id:recipient.conversation_id,
                message:'[Template: '+crmTemplateSelected.name+']',is_template:1,
                template_name:crmTemplateSelected.name,template_language:crmTemplateSelected.language,
                template_values:values,template_media_library_id:galleryMedia?.id||'',is_internal:0})
        });
        const result=await response.json();
        if(result.status!=='success') throw new Error(result.message||'Meta did not confirm acceptance');
        crmTemplateState('Meta accepted this message. Delivery/read status will update separately.','success');
        // Refresh this same chat so the approved template body and selected
        // gallery media appear as a normal outgoing message.
        if (activeConvoId && String(activeConvoId) === String(recipient.conversation_id)) {
            currentMessagesHash='';fetchMessages(activeConvoId);
        }
    } catch(e) {
        crmTemplateState(e.message||'Send not confirmed. Check customer chat before retrying.','error');
    } finally {crmTemplateBusy=false;button.disabled=false;}
};

// ==========================================
// NEW META ADS MANAGER ENGINE
// ==========================================
window.fetchMetaAds = function() {
    fetch(`${baseUrl}inbox/get_meta_ads`)
    .then(r => r.json())
    .then(json => {
        if (json.status === 'success') {
            cachedMetaAds = json.data;
            renderMetaAdsTable();
        }
    });
}

window.forceSyncMetaAds = function() {
    let btn = document.querySelector('button[onclick="forceSyncMetaAds()"]');
    if(btn) btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span> Syncing...`;
    
    fetch(`${baseUrl}inbox/sync_meta_ads`)
    .then(r => r.json())
    .then(json => {
        if (json.status === 'success') {
            alert(json.message);
            fetchMetaAds();
        } else {
            alert("Sync Failed: " + (json.message || "Check settings."));
        }
        if(btn) btn.innerHTML = `<i class="bi bi-arrow-repeat me-1"></i> Sync Ads from Meta`;
    }).catch(err => {
        alert("Network error during sync.");
        if(btn) btn.innerHTML = `<i class="bi bi-arrow-repeat me-1"></i> Sync Ads from Meta`;
    });
}

window.renderMetaAdsTable = function() {
    let tbody = document.getElementById('metaAdsTableBody');
    if(!tbody) return;
    
    if(!cachedMetaAds || cachedMetaAds.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-5"><i class="bi bi-megaphone fs-2 d-block mb-2 text-primary"></i> No Ads Found.<br>Click 'Sync Ads from Meta' to fetch active Click-to-WhatsApp ads.</td></tr>`;
        return;
    }
    
    tbody.innerHTML = cachedMetaAds.map(ad => {
        let statusBadge = '';
        if(ad.status === 'ACTIVE') statusBadge = '<span class="badge bg-success">Active</span>';
        else if(ad.status === 'PAUSED') statusBadge = '<span class="badge bg-warning text-dark">Paused</span>';
        else statusBadge = `<span class="badge bg-secondary">${ad.status}</span>`;
        
        return `
            <tr>
                <td class="ps-4"><span class="crm-ad-media-slot" data-crm-ad-media-id="${crmQuoteEscape(ad.ad_id)}"><small class="text-muted">Loading…</small></span></td>
                <td class="fw-bold text-dark" style="font-size: 13px;">${ad.ad_id}</td>
                <td style="font-size: 13px; color: #555;">${ad.campaign_name}</td>
                <td style="font-size: 13px; color: #555;">${ad.ad_name}</td>
                <td class="text-end pe-4">${statusBadge}</td>
            </tr>
        `;
    }).join('');
    crmAdMediaObserveTable();
}

// Meta ad previews: read-only Meta API endpoint, no changes to WhatsApp sending.
const crmAdMediaCache = new Map();
const crmAdMediaInFlight = new Map();
let crmAdMediaObserver = null;
function crmAdMediaRequest(key, value) {
    const id = key + ':' + value;
    if (crmAdMediaCache.has(id)) return Promise.resolve(crmAdMediaCache.get(id));
    if (crmAdMediaInFlight.has(id)) return crmAdMediaInFlight.get(id);
    const params = new URLSearchParams({[key]: value});
    const p = fetch(`${baseUrl}inbox/get_meta_ad_media?${params}`, {credentials:'same-origin'})
        .then(r => r.ok ? r.json() : {status:'unavailable',message:'Media lookup HTTP ' + r.status})
        .catch(() => ({status:'unavailable', message:'Creative preview not available'}))
        .then(data => {
            if (data && data.status === 'success') {
                crmAdMediaCache.set(id, data);
                if (data.ad_id) crmAdMediaCache.set('ad_id:' + data.ad_id, data);
            } else {
                crmAdMediaCache.set(id, data || {status:'unavailable'});
            }
            return data;
        }).finally(() => crmAdMediaInFlight.delete(id));
    crmAdMediaInFlight.set(id,p);
    return p;
}
function crmAdMediaSlotFill(slot, media, isFirstMessage=false) {
    if (!slot || !slot.isConnected) return;
    slot.replaceChildren();
    if (!media || media.status !== 'success' || !media.thumbnail_url && !media.video_url) {
        const info = document.createElement('span');
        info.className = 'crm-ad-media-unavailable';
        info.textContent = isFirstMessage ? 'Ad creative preview unavailable' : 'Preview unavailable';
        info.title = media && media.message || 'Meta media access unavailable';
        slot.appendChild(info);
        return;
    }
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'crm-ad-open';
    button.setAttribute('aria-label', media.playable ? 'Play original Meta ad video' : 'View original Meta ad image');
    const image = document.createElement('img');
    image.alt = 'Meta ad creative thumbnail';
    image.loading = 'lazy';
    image.referrerPolicy = 'no-referrer';
    if (media.thumbnail_url) image.src = media.thumbnail_url;
    else { image.style.display = 'none'; button.style.minWidth = '105px'; button.style.minHeight = '75px'; }
    image.onerror = () => { image.style.display = 'none'; button.title = 'Thumbnail unavailable'; };
    button.appendChild(image);
    if (media.kind === 'video') {
        const overlay = document.createElement('span');
        overlay.className = 'crm-ad-play-icon';
        overlay.innerHTML = '<i class="bi bi-play-fill"></i>';
        button.appendChild(overlay);
        if (!media.playable) button.title = 'Meta has not allowed video playback. Thumbnail only.';
    }
    button.addEventListener('click', () => crmAdMediaOpen(media));
    slot.appendChild(button);
}
function crmAdMediaOpen(media) {
    const modalElement = document.getElementById('crmAdMediaModal');
    const body = document.getElementById('crmAdMediaModalBody');
    if (!modalElement || !body || !window.bootstrap) return;
    body.replaceChildren();
    const title = document.getElementById('crmAdMediaTitle');
    if (title) title.textContent = media.kind === 'video' ? 'Meta Ad Video' : 'Meta Ad Image';
    const instance = window.bootstrap.Modal.getOrCreateInstance(modalElement);
    // A late API reply must never put an iframe back after popup is closed.
    const requestNumber = String((Number(modalElement.dataset.crmPreviewRequest || '0') + 1));
    modalElement.dataset.crmPreviewRequest = requestNumber;
    if (modalElement.dataset.crmVideoCleanup !== '1') {
        modalElement.dataset.crmVideoCleanup = '1';
        modalElement.addEventListener('hidden.bs.modal', () => {
            modalElement.dataset.crmPreviewRequest = String(Number(modalElement.dataset.crmPreviewRequest || '0') + 1);
            const v = body.querySelector('video');
            if (v) { v.pause(); v.removeAttribute('src'); v.load(); }
            // Also stops Meta's iframe playback immediately.
            body.replaceChildren();
        });
    }
    instance.show();
    if (media.video_url && media.kind === 'video') {
        // Original path stays unchanged when Meta provided a direct MP4.
        const video = document.createElement('video');
        video.controls = true;
        video.autoplay = true;
        video.playsInline = true;
        video.preload = 'metadata';
        video.referrerPolicy = 'no-referrer';
        video.src = media.video_url;
        if (media.thumbnail_url) video.poster = media.thumbnail_url;
        video.addEventListener('error', () => {
            const info = document.createElement('p');
            info.className = 'text-danger small mt-2';
            info.textContent = 'Direct Meta video URL expired or playback is restricted. Close and reopen to retry.';
            body.appendChild(info);
        });
        body.appendChild(video);
        return;
    }
    if (media.kind !== 'video') {
        // Existing image-ad behavior stays unchanged.
        if (media.thumbnail_url) {
            const image = document.createElement('img');
            image.src = media.thumbnail_url;
            image.alt = 'Meta Ad Creative';
            body.appendChild(image);
        } else {
            const info = document.createElement('p');
            info.textContent = 'Media preview unavailable';
            body.appendChild(info);
        }
        return;
    }

    // No MP4 source: request an official Meta ad preview ONLY on click.
    // This is often available even when /{video_id}?fields=source is not.
    const loading = document.createElement('p');
    loading.className = 'text-secondary small py-3';
    loading.textContent = 'Loading original Meta ad preview…';
    body.appendChild(loading);
    const params = new URLSearchParams({ad_id: String(media.ad_id), preview: '1'});
    fetch(`${baseUrl}inbox/get_meta_ad_media?${params.toString()}`, {credentials:'same-origin'})
        .then(async r => r.ok ? r.json() : {status:'unavailable',message:`Preview HTTP ${r.status}`})
        .then(preview => {
            if (modalElement.dataset.crmPreviewRequest !== requestNumber || !modalElement.classList.contains('show')) return;
            body.replaceChildren();
            let safePreview = '';
            if (preview && preview.status === 'success' && typeof preview.preview_url === 'string') {
                try {
                    const url = new URL(preview.preview_url);
                    if (url.protocol === 'https:' &&
                        ['www.facebook.com','facebook.com','business.facebook.com'].includes(url.hostname) &&
                        url.pathname === '/ads/api/preview_iframe.php') safePreview = url.href;
                } catch (_) {}
            }
            if (safePreview) {
                const iframe = document.createElement('iframe');
                iframe.title = 'Original Meta ad preview';
                iframe.src = safePreview;
                iframe.allow = 'autoplay; encrypted-media; fullscreen; picture-in-picture';
                iframe.allowFullscreen = true;
                iframe.referrerPolicy = 'strict-origin-when-cross-origin';
                iframe.style.cssText = 'display:block;width:100%;height:min(68dvh,620px);min-height:340px;border:0;border-radius:8px;background:#fff;';
                body.appendChild(iframe);
                const external = document.createElement('a');
                external.href = safePreview;
                external.target = '_blank';
                external.rel = 'noopener noreferrer';
                external.className = 'btn btn-sm btn-outline-primary mt-3';
                external.textContent = 'Open original Meta preview in new tab';
                body.appendChild(external);
                const note = document.createElement('p');
                note.className = 'text-muted small mt-2 mb-0';
                note.textContent = 'If embedded playback requires Meta login or is blocked by the browser, use the new-tab option.';
                body.appendChild(note);
                return;
            }
            // Do not pretend thumbnail is a playable video.
            if (media.thumbnail_url) {
                const image = document.createElement('img');
                image.src = media.thumbnail_url;
                image.alt = 'Meta video thumbnail';
                body.appendChild(image);
            }
            const message = document.createElement('p');
            message.className = 'text-muted small mt-2';
            message.textContent = (preview && preview.message) || 'Meta did not provide a video source or ad preview. Check Page/video asset access.';
            body.appendChild(message);
        })
        .catch(() => {
            if (modalElement.dataset.crmPreviewRequest !== requestNumber || !modalElement.classList.contains('show')) return;
            loading.textContent = 'Unable to load Meta ad preview. Check the CRM Network response and Meta access.';
        });
}
function crmAdMediaObserveTable() {
    if (crmAdMediaObserver) crmAdMediaObserver.disconnect();
    const slots = Array.from(document.querySelectorAll('#metaAdsTableBody [data-crm-ad-media-id]'));
    const load = slot => {
        if (slot.dataset.crmLoading === '1') return;
        slot.dataset.crmLoading = '1';
        const adId = slot.dataset.crmAdMediaId;
        crmAdMediaRequest('ad_id', adId).then(data => crmAdMediaSlotFill(slot, data));
    };
    if ('IntersectionObserver' in window) {
        crmAdMediaObserver = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                crmAdMediaObserver.unobserve(entry.target);
                load(entry.target);
            });
        }, {root: document.querySelector('#metaAdsManagerArea .manager-scroll-body'), rootMargin:'250px 0px'});
        slots.forEach(el => crmAdMediaObserver.observe(el));
    } else {
        slots.forEach(load);
    }
}
function crmAdMediaFirstLeadMessage(convoId, adName) {
    if (!adName || adName === 'null') return;
    const firstSlot = document.querySelector('#messageContainer [data-crm-first-ad]');
    if (!firstSlot) return;
    crmAdMediaRequest('ad_name', adName).then(media => {
        if (String(activeConvoId) !== String(convoId)) return;
        if (!firstSlot.isConnected) return;
        crmAdMediaSlotFill(firstSlot, media, true);
    });
}
