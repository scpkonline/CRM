/* SCPK Broadcast Campaigns — opt-in-only, admin-confirmed batch sender. */
let scpkBroadcastMedia = null;
let scpkBroadcastSending = false;
function scpkBroadcastStatus(text,kind='secondary') {
    const el=document.getElementById('scpkBroadcastStatus');if(!el)return;
    el.textContent=text;el.className='alert alert-'+kind+' mt-3 small';
}
async function scpkBroadcastRequest(endpoint,body=null) {
    const options={credentials:'same-origin',cache:'no-store'};
    if(body!==null){options.method='POST';options.headers={'Content-Type':'application/json','X-SCPK-CSRF':APP_CONFIG.scpkActionToken};options.body=JSON.stringify(body);}
    const response=await fetch(baseUrl+'broadcast/'+endpoint,options);
    let data;
    try{data=await response.json();}catch(e){throw new Error('Broadcast service unavailable or login expired');}
    if(data.status!=='success')throw new Error(data.message||'Broadcast request failed');
    return data;
}
window.scpkBroadcastTemplateChanged=function() {
    const select=document.getElementById('scpkCampaignTemplate');
    const current=select.options[select.selectedIndex];
    const kind=current?.dataset.mediaKind||'';
    const selectedTemplate=(Array.isArray(cachedTemplates)?cachedTemplates:[]).find(t=>t.name+'|'+t.language===select.value);
    const body=(selectedTemplate?.components||[]).filter(c=>['HEADER','BODY','FOOTER'].includes(String(c.type).toUpperCase()))
       .map(c=>String(c.format||'').toUpperCase()==='TEXT' || !c.format ? String(c.text||'') : '[Header: '+c.format+']').filter(Boolean).join('\n\n');
    const preview=document.getElementById('scpkCampaignTemplatePreview');
    if(preview)preview.textContent=body||'Select a template to preview approved content.';
    const label=document.getElementById('scpkCampaignMediaLabel');
    if(scpkBroadcastMedia && kind && !scpkBroadcastMedia.mime.startsWith(kind+'/'))scpkBroadcastMedia=null;
    if(!kind)scpkBroadcastMedia=null;
    label.textContent=kind ? 'Required '+kind.toUpperCase()+' header — '+(scpkBroadcastMedia?.name||'not selected') : 'No media header required';
};
window.scpkBroadcastChooseMedia=function() {
    const select=document.getElementById('scpkCampaignTemplate');
    const kind=select.options[select.selectedIndex]?.dataset.mediaKind||'';
    if(!kind){scpkBroadcastStatus('Select a Marketing template with an IMAGE or VIDEO header first.','warning');return;}
    scpkMediaLibraryOpen('broadcast',kind.toUpperCase());
};
window.scpkBroadcastGallerySelected=function(item) {
    scpkBroadcastMedia=item;
    document.getElementById('scpkCampaignMediaLabel').textContent='Selected: '+item.name;
};
window.scpkBroadcastPopulateTemplates=function() {
    const select=document.getElementById('scpkCampaignTemplate');if(!select)return;
    select.replaceChildren();
    const available=(Array.isArray(cachedTemplates)?cachedTemplates:[]).filter(t=>t.status==='APPROVED'&&String(t.category||'').toUpperCase()==='MARKETING');
    const start=document.createElement('option');start.value='';start.textContent=available.length?'Select Marketing template':'No approved Marketing templates. Create and approve one in Meta.';
    select.appendChild(start);
    for(const t of available){
        const option=document.createElement('option');option.value=t.name+'|'+t.language;
        option.textContent=t.name+' ('+t.language+')';
        const header=(t.components||[]).find(c=>String(c.type).toUpperCase()==='HEADER');
        const fmt=String(header?.format||'').toUpperCase();
        option.dataset.mediaKind=['IMAGE','VIDEO'].includes(fmt)?fmt.toLowerCase():'';
        // Server performs authoritative template validation; UI labels are advisory.
        select.appendChild(option);
    }
    scpkBroadcastTemplateChanged();
}
window.scpkBroadcastRefresh=async function() {
    scpkBroadcastPopulateTemplates();
    const tbody=document.getElementById('scpkCampaignRows');if(!tbody)return;
    tbody.replaceChildren();
    try {
        const data=await scpkBroadcastRequest('list_campaigns');
        for(const c of data.data){
            const tr=document.createElement('tr');
            const a=document.createElement('td');const b=document.createElement('td');
            const progress=document.createElement('td');const controls=document.createElement('td');
            a.textContent=c.name;b.textContent=c.template_name+' ('+c.template_language+')';
            progress.textContent='Status '+c.status+' · '+c.accepted+'/'+c.total+' accepted · '+c.pending+' pending · '+c.issues+' issues';
            if(['draft','active'].includes(c.status)&&Number(c.pending)>0){
                const send=document.createElement('button');send.className='btn btn-primary btn-sm mb-1';
                send.textContent='Send next 2';send.type='button';
                send.onclick=()=>scpkBroadcastSendBatch(c.id,c.name,c.pending);
                const pause=document.createElement('button');pause.className='btn btn-outline-danger btn-sm ms-1 mb-1';
                pause.textContent='Pause';pause.type='button';pause.onclick=()=>scpkBroadcastPause(c.id);
                controls.append(send,pause);
            }else{controls.textContent='—';}
            tr.append(a,b,progress,controls);tbody.append(tr);
        }
        if(!data.data.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=4;td.textContent='No campaigns. Create a reviewed draft first.';tr.append(td);tbody.append(tr);}
        scpkBroadcastStatus('Campaigns loaded. No messages are sent just by opening this page.');
    }catch(e){scpkBroadcastStatus(e.message,'danger');}
};
window.scpkBroadcastSaveConsent=async function(e) {
    e.preventDefault();
    const phone=document.getElementById('scpkConsentPhone').value;
    const source=document.getElementById('scpkConsentSource').value;
    const evidence=document.getElementById('scpkConsentEvidence').value.trim();
    if(!window.confirm('Confirm this customer actually opted in to SCPK marketing WhatsApp messages and you have the referenced evidence?'))return;
    try{const r=await scpkBroadcastRequest('record_optin',{phone,source,evidence});scpkBroadcastStatus('Consent recorded for '+r.lead_name+'.','success');}
    catch(e){scpkBroadcastStatus(e.message,'danger');}
};
window.scpkBroadcastRevokeConsent=async function() {
    const phone=document.getElementById('scpkConsentPhone').value.trim();
    if(!phone){scpkBroadcastStatus('Enter phone to opt out.','warning');return;}
    if(!window.confirm('Mark marketing consent OPTED OUT for this CRM customer?'))return;
    try{await scpkBroadcastRequest('revoke_optin',{phone});scpkBroadcastStatus('Marketing opt-out saved.','success');}
    catch(e){scpkBroadcastStatus(e.message,'danger');}
};
window.scpkBroadcastCreate=async function(e) {
    e.preventDefault();
    const choice=document.getElementById('scpkCampaignTemplate').value;
    if(!choice||!choice.includes('|')){scpkBroadcastStatus('Select an approved Marketing template.','warning');return;}
    const [template_name,template_language]=choice.split('|');
    const name=document.getElementById('scpkCampaignName').value.trim();
    const phones=document.getElementById('scpkCampaignPhones').value;
    const media_id=scpkBroadcastMedia?.id||'';
    const selected=document.getElementById('scpkCampaignTemplate');
    const kind=selected.options[selected.selectedIndex]?.dataset.mediaKind||'';
    if(kind&&!media_id){scpkBroadcastStatus('Select required campaign header media from the gallery.','warning');return;}
    if(!window.confirm('Create a DRAFT campaign only? This does NOT send messages.'))return;
    try{
        const data=await scpkBroadcastRequest('create_campaign',{name,phones,template_name,template_language,media_id});
        scpkBroadcastStatus('Draft #'+data.campaign_id+' created: '+data.eligible+' eligible. Skipped: '+(data.skipped||[]).join('; '),'success');
        await scpkBroadcastRefresh();
    }catch(e){scpkBroadcastStatus(e.message,'danger');}
};
window.scpkBroadcastSendBatch=async function(id,name,pending) {
    if(scpkBroadcastSending)return;
    if(!window.confirm('Send approved MARKETING template in campaign "'+name+'" to the NEXT maximum 2 eligible, opted-in recipients? This is a real paid WhatsApp API action.'))return;
    scpkBroadcastSending=true;scpkBroadcastStatus('Sending selected batch (max 2)…','warning');
    try{
        const result=await scpkBroadcastRequest('send_batch',{campaign_id:id,confirm:'SEND_APPROVED_MARKETING'});
        const summary=result.results.map(x=>x.last4+': '+x.status+(x.code?' ('+x.code+')':'')).join('; ');
        scpkBroadcastStatus('Batch finished. '+summary+'; remaining pending: '+result.pending+'. Meta accepted ≠ delivered.','success');
        await scpkBroadcastRefresh();
    }catch(e){scpkBroadcastStatus('Stopped: '+e.message+' — check campaign status before retrying.','danger');}
    finally{scpkBroadcastSending=false;}
};
window.scpkBroadcastPause=async function(id) {
    if(!window.confirm('Pause campaign '+id+'? No pending recipients will be sent while paused.'))return;
    try{await scpkBroadcastRequest('pause_campaign',{campaign_id:id});await scpkBroadcastRefresh();}
    catch(e){scpkBroadcastStatus(e.message,'danger');}
};

/* =====================================================================
   SCPK Campaign Builder v2 — additive UI adapter. Legacy opt-in, media gallery,
   template and two-at-a-time sender remain in this file unchanged above.
   ===================================================================== */
const scpkWizard = {
    id:0,step:1,media:null,csvPhones:[],status:'draft',
    testAccepted:false,prepared:false,saving:null,autoSaveTimer:null,autoRun:false,
    options:null,loading:false
};
function scpkWizardStatus(message,type='secondary'){
    const el=document.getElementById('scpkBroadcastStatus');if(!el)return;
    el.className='alert alert-'+type+' small';el.textContent=message;
}
function scpkWizardShow(step){
    scpkWizard.step=Math.min(6,Math.max(1,Number(step)||1));
    const editor=document.getElementById('scpkWizardEditor');
    const overview=document.getElementById('scpkCampaignOverview');
    if(!editor)return;
    editor.hidden=false;if(overview)overview.hidden=true;
    document.querySelectorAll('#scpkWizardEditor [data-step-panel]').forEach(el=>{
        el.hidden=Number(el.dataset.stepPanel)!==scpkWizard.step;
    });
    document.querySelectorAll('#scpkWizardSteps button').forEach(btn=>{
        btn.classList.toggle('active',Number(btn.dataset.step)===scpkWizard.step);
        btn.setAttribute('aria-current',Number(btn.dataset.step)===scpkWizard.step?'step':'false');
    });
    const header=document.getElementById('scpkWizardHeading');
    if(header)header.textContent=(scpkWizard.id?'Campaign #'+scpkWizard.id:'New campaign')+' · Step '+scpkWizard.step+' of 6';
    if(scpkWizard.step===5)scpkWizardUpdateReview();
    if(scpkWizard.step===6 && scpkWizard.id)scpkWizardAnalytics();
}
async function scpkWizardOverview(){
    scpkWizard.autoRun=false;
    clearTimeout(scpkWizard.autoSaveTimer);
    if(scpkWizard.status==='draft' && (document.getElementById('scpkWizardName')?.value.trim()||'').length>=3){
        try{await scpkWizardSave();}catch(e){scpkWizardStatus('Draft could not be saved: '+e.message,'danger');return;}
    }
    const e=document.getElementById('scpkWizardEditor');if(e)e.hidden=true;
    const o=document.getElementById('scpkCampaignOverview');if(o)o.hidden=false;
    scpkBroadcastRefresh();
}
function scpkWizardNew(){
    scpkWizard.autoRun=false;
    clearTimeout(scpkWizard.autoSaveTimer);
    Object.assign(scpkWizard,{id:0,step:1,media:null,csvPhones:[],status:'draft',testAccepted:false,prepared:false});
    for(const id of ['scpkWizardName','scpkWizardTestNumber','scpkWizardEstimatedRate']){
        const e=document.getElementById(id);if(e)e.value='';
    }
    const mediaLabel=document.getElementById('scpkCampaignMediaLabel');
    if(mediaLabel)mediaLabel.textContent='No media header required';
    for(const id of ['scpkWizardTag','scpkWizardStage','scpkWizardStatusFilter','scpkWizardTemperature']){
        const e=document.getElementById(id);if(e)e.value='';
    }
    const agent=document.getElementById('scpkWizardAgent');if(agent)agent.value='0';
    const ra=document.querySelector('input[name="scpkAudienceSource"][value="filters"]');if(ra)ra.checked=true;
    scpkWizardAudienceSource();
    const template=document.getElementById('scpkCampaignTemplate');if(template)template.value='';
    const label=document.getElementById('scpkWizardSavedLabel');if(label)label.textContent='Not saved yet';
    for(const id of ['scpkWizardAudienceCount','scpkWizardTestStatus','scpkWizardCSVStatus']){
        const e=document.getElementById(id);if(e)e.textContent='';
    }
    const tbody=document.getElementById('scpkWizardAudiencePreview');if(tbody)tbody.replaceChildren();
    scpkBroadcastTemplateChanged(true);scpkWizardShow(1);
    scpkWizardStatus('New campaign draft. Enter a name and choose Save & Next. Nothing is sent automatically.');
}
function scpkWizardAudienceSource(){
    const val=document.querySelector('input[name="scpkAudienceSource"]:checked')?.value||'filters';
    const panel=document.getElementById('scpkWizardCSVPanel');if(panel)panel.hidden=val!=='csv';
}
function scpkWizardParseCSV(text){
    // RFC4180-style parsing for escaped quotes, quoted commas and newlines.
    const rows=[];let row=[],cell='',quoted=false;
    text=String(text||'').replace(/^\uFEFF/,'');
    for(let i=0;i<text.length;i++){
        const ch=text[i];
        if(ch==='"'){
            if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;
        } else if(ch===','&&!quoted){row.push(cell.trim());cell='';}
        else if((ch==='\n'||ch==='\r')&&!quoted){
            row.push(cell.trim());if(row.some(x=>x!==''))rows.push(row);
            row=[];cell='';if(ch==='\r'&&text[i+1]==='\n')i++;
        } else cell+=ch;
    }
    if(quoted)throw new Error('Invalid CSV: unmatched quote');
    row.push(cell.trim());if(row.some(x=>x!==''))rows.push(row);
    return rows;
}
async function scpkWizardCSVFileChanged(event){
    const file=event.target.files?.[0];if(!file)return;
    const box=document.getElementById('scpkWizardCSVStatus');
    if(file.size>2000000){box.textContent='CSV file too large (max 2 MB)';return;}
    try{
        const rows=scpkWizardParseCSV(await file.text());
        if(!rows.length)throw new Error('CSV is empty');
        const headings=rows[0].map(s=>s.toLowerCase().trim().replace(/[\s-]/g,'_'));
        let idx=headings.findIndex(h=>['whatsapp_number','phone','mobile','number','wa_number','whatsapp','phone_number'].includes(h));
        const hasHeader=idx>=0;
        if(idx<0)idx=0;
        const vals=(hasHeader?rows.slice(1):rows).map(r=>String(r[idx]||'').replace(/[^0-9]/g,''));
        if(vals.length>2000)throw new Error('Maximum 2,000 CSV rows per campaign');
        const phones=Array.from(new Set(vals.filter(Boolean)));
        const invalid=phones.filter(n=>n.length<11||n.length>15);
        if(invalid.length)throw new Error(invalid.length+' number(s) missing international country code; fix the CSV before importing');
        if(!phones.length)throw new Error('No phone numbers found in CSV');
        scpkWizard.csvPhones=phones;
        box.textContent=phones.length+' unique international numbers read locally. Only opted-in CRM matches can be prepared.';
        scpkWizardQueueAutosave();
    }catch(e){scpkWizard.csvPhones=[];box.textContent=e.message;scpkWizardStatus(e.message,'danger');}
}
function scpkWizardAudienceValues(){
    return {
        source:document.querySelector('input[name="scpkAudienceSource"]:checked')?.value||'filters',
        phones:scpkWizard.csvPhones,
        tag:document.getElementById('scpkWizardTag')?.value||'',
        stage:document.getElementById('scpkWizardStage')?.value||'',
        status:document.getElementById('scpkWizardStatusFilter')?.value||'',
        temperature:document.getElementById('scpkWizardTemperature')?.value||'',
        agent_id:Number(document.getElementById('scpkWizardAgent')?.value||0)
    };
}
function scpkWizardSelectedTemplate(){
    const value=document.getElementById('scpkCampaignTemplate')?.value||'';
    if(!value.includes('|'))return {template_name:'',template_language:''};
    const [template_name,template_language]=value.split('|');
    return {template_name,template_language};
}
function scpkWizardSavePayload(step){
    return {
        campaign_id:scpkWizard.id,name:document.getElementById('scpkWizardName')?.value.trim()||'',
        step:step||scpkWizard.step,audience:scpkWizardAudienceValues(),
        ...scpkWizardSelectedTemplate(),media_id:scpkWizard.media?.id||'',
        estimated_unit_rate:document.getElementById('scpkWizardEstimatedRate')?.value||null
    };
}
async function scpkWizardSave(step){
    if(scpkWizard.status!=='draft')return true;
    const name=document.getElementById('scpkWizardName')?.value.trim()||'';
    if(name.length<3||name.length>120)throw new Error('Campaign name must have 3–120 characters');
    if(scpkWizard.saving)await scpkWizard.saving;
    const p=scpkBroadcastRequest('wizard_save',scpkWizardSavePayload(step));
    scpkWizard.saving=p;
    try{
        const r=await p;scpkWizard.id=r.campaign_id;scpkWizard.prepared=Number(r.pending)>0;
        const label=document.getElementById('scpkWizardSavedLabel');
        if(label)label.textContent='Saved draft #'+scpkWizard.id;
        return true;
    }finally{if(scpkWizard.saving===p)scpkWizard.saving=null;}
}
function scpkWizardQueueAutosave(){
    clearTimeout(scpkWizard.autoSaveTimer);
    if(scpkWizard.status!=='draft')return;
    scpkWizard.autoSaveTimer=setTimeout(async()=>{
        try{if((document.getElementById('scpkWizardName')?.value.trim()||'').length>=3)await scpkWizardSave();}
        catch(e){scpkWizardStatus('Auto-save: '+e.message,'warning');}
    },1100);
}
async function scpkWizardSaveClick(){
    clearTimeout(scpkWizard.autoSaveTimer);
    try{await scpkWizardSave();scpkWizardStatus('Draft saved. No WhatsApp messages were sent.','success');}
    catch(e){scpkWizardStatus(e.message,'danger');}
}
async function scpkWizardGoto(step){
    if(scpkWizard.step===5 && Number(step)!==5)scpkWizard.autoRun=false;
    clearTimeout(scpkWizard.autoSaveTimer);
    try{if(scpkWizard.status==='draft')await scpkWizardSave(Number(step));scpkWizardShow(Number(step));}
    catch(e){scpkWizardStatus('Could not save current step: '+e.message,'danger');}
}
async function scpkWizardNext(){
    try{
        if(scpkWizard.step===2){
            const a=scpkWizardAudienceValues();
            if(a.source==='csv'&&!a.phones.length)throw new Error('Choose a CSV file before proceeding');
            const r=await scpkBroadcastRequest('wizard_preview',{audience:a});
            if(!r.eligible)throw new Error('No verified opted-in contacts match the selected audience');
        }
        if(scpkWizard.step===3){
            const t=scpkWizardSelectedTemplate();
            if(!t.template_name)throw new Error('Choose an approved Marketing template');
            const kind=document.querySelector('#scpkCampaignTemplate option:checked')?.dataset.mediaKind||'';
            if(kind&&!scpkWizard.media?.id)throw new Error('Select the required '+kind+' gallery media');
        }
        if(scpkWizard.step===4 && !scpkWizard.testAccepted){
            const a=await scpkBroadcastRequest('wizard_analytics?id='+scpkWizard.id);
            if(Number(a.data.test?.accepted||0)<1)throw new Error('Send one accepted test template before final campaign');
        }
        await scpkWizardGoto(Math.min(6,scpkWizard.step+1));
    }catch(e){scpkWizardStatus(e.message,'warning');}
}
function scpkWizardPrev(){scpkWizardGoto(Math.max(1,scpkWizard.step-1));}
async function scpkWizardPreviewAudience(){
    const a=scpkWizardAudienceValues();
    if(a.source==='csv'&&!a.phones.length){scpkWizardStatus('Select a CSV file first','warning');return;}
    try{
        const r=await scpkBroadcastRequest('wizard_preview',{audience:a});
        document.getElementById('scpkWizardAudienceCount').textContent=r.eligible+' eligible customers';
        const tbody=document.getElementById('scpkWizardAudiencePreview');tbody.replaceChildren();
        for(const p of r.sample){
            const tr=document.createElement('tr');
            for(const field of ['name','number','stage','status']){
                const td=document.createElement('td');td.textContent=p[field]||'—';tr.appendChild(td);
            }
            tbody.appendChild(tr);
        }
        scpkWizardStatus('Audience preview: '+r.eligible+' opted-in CRM contacts. No messages sent.','success');
    }catch(e){scpkWizardStatus(e.message,'danger');}
}
function scpkWizardFillSelect(id,values,placeholder){
    const sel=document.getElementById(id);if(!sel)return;
    const old=sel.value;sel.replaceChildren();const empty=document.createElement('option');
    empty.value=id==='scpkWizardAgent'?'0':'';empty.textContent=placeholder;sel.appendChild(empty);
    for(const v of values||[]){
        const opt=document.createElement('option');
        opt.value=typeof v==='object'?String(v.id):String(v);
        opt.textContent=typeof v==='object'?String(v.full_name):String(v);
        sel.appendChild(opt);
    }
    if(Array.from(sel.options).some(o=>o.value===old))sel.value=old;
}
async function scpkWizardLoadOptions(){
    try{
        const r=await scpkBroadcastRequest('wizard_options');
        scpkWizard.options=r.data;
        scpkWizardFillSelect('scpkWizardTag',r.data.tags,'All tags');
        scpkWizardFillSelect('scpkWizardStage',r.data.stages,'All stages');
        scpkWizardFillSelect('scpkWizardStatusFilter',r.data.statuses,'All statuses');
        scpkWizardFillSelect('scpkWizardTemperature',r.data.temperatures,'All temperatures');
        scpkWizardFillSelect('scpkWizardAgent',r.data.agents,'All agents');
        const temp=document.getElementById('scpkWizardTemperature');
        temp.disabled=!r.data.temperature_field;
        document.getElementById('scpkWizardTempHint').textContent=r.data.temperature_field?'CRM field: '+r.data.temperature_field:'Temperature field not found in current leads schema';
    }catch(e){scpkWizardStatus('Cannot load CRM audience filters: '+e.message,'danger');}
}
function scpkWizardTemplatePreview(t){
    if(!t)return 'Select an approved Marketing template.';
    return (t.components||[]).filter(c=>['HEADER','BODY','FOOTER'].includes(String(c.type).toUpperCase()))
      .map(c=>(['IMAGE','VIDEO'].includes(String(c.format||'').toUpperCase())?'['+c.format+' header]':String(c.text||'')))
      .filter(Boolean).join('\n\n');
}
window.scpkBroadcastPopulateTemplates=function(){
    const select=document.getElementById('scpkCampaignTemplate');if(!select)return;
    const previous=select.value;
    const source=Array.isArray(cachedTemplates)?cachedTemplates:[];
    const allowed=source.filter(t=>t.status==='APPROVED'&&String(t.category||'').toUpperCase()==='MARKETING');
    select.replaceChildren();
    const init=document.createElement('option');init.value='';
    init.textContent=allowed.length?'Choose approved Marketing template':'No approved Marketing templates. Create one in Meta.';
    select.appendChild(init);
    for(const t of allowed){
        const o=document.createElement('option');o.value=t.name+'|'+t.language;o.textContent=t.name+' ('+t.language+')';
        const head=(t.components||[]).find(c=>String(c.type).toUpperCase()==='HEADER');
        const fmt=String(head?.format||'').toUpperCase();o.dataset.mediaKind=['IMAGE','VIDEO'].includes(fmt)?fmt.toLowerCase():'';
        select.appendChild(o);
    }
    if(Array.from(select.options).some(o=>o.value===previous))select.value=previous;
    scpkBroadcastTemplateChanged(true);
};
window.scpkBroadcastTemplateChanged=function(silent=false){
    const sel=document.getElementById('scpkCampaignTemplate');if(!sel)return;
    const kind=sel.options[sel.selectedIndex]?.dataset.mediaKind||'';
    const t=(Array.isArray(cachedTemplates)?cachedTemplates:[]).find(t=>t.name+'|'+t.language===sel.value);
    document.getElementById('scpkCampaignTemplatePreview').textContent=scpkWizardTemplatePreview(t);
    if(!kind || (scpkWizard.media&&!scpkWizard.media.mime.startsWith(kind+'/')))scpkWizard.media=null;
    const label=document.getElementById('scpkCampaignMediaLabel');
    if(label)label.textContent=kind?'Required '+kind.toUpperCase()+' header · '+(scpkWizard.media?.name||'No media selected'):'No media header required';
    if(!silent){scpkWizard.testAccepted=false;scpkWizardQueueAutosave();}
};
window.scpkBroadcastChooseMedia=function(){
    const sel=document.getElementById('scpkCampaignTemplate');
    const kind=sel?.options[sel.selectedIndex]?.dataset.mediaKind||'';
    if(!kind){scpkWizardStatus('Select an approved Marketing IMAGE or VIDEO header template first.','warning');return;}
    if(typeof scpkMediaLibraryOpen!=='function'){scpkWizardStatus('Gallery JS not loaded.','danger');return;}
    scpkMediaLibraryOpen('broadcast',kind.toUpperCase());
};
window.scpkBroadcastGallerySelected=function(item){
    scpkWizard.media={id:item.id,name:item.name,mime:item.mime};
    scpkWizard.testAccepted=false;
    const label=document.getElementById('scpkCampaignMediaLabel');
    if(label)label.textContent='Selected: '+item.name;
    scpkWizardQueueAutosave();
};
async function scpkWizardOpen(id){
    clearTimeout(scpkWizard.autoSaveTimer);
    try{
        const r=await scpkBroadcastRequest('wizard_load?id='+encodeURIComponent(id));
        const d=r.data;Object.assign(scpkWizard,{id:d.campaign_id,status:d.status,
            csvPhones:d.audience?.phones||[],media:d.media_id?{id:d.media_id,name:'Saved gallery media',mime:''}:null,
            prepared:false,testAccepted:false});
        document.getElementById('scpkWizardName').value=d.name||'';
        document.getElementById('scpkWizardEstimatedRate').value=d.estimated_unit_rate??'';
        const source=d.audience?.source||'filters';
        const radio=document.querySelector('input[name="scpkAudienceSource"][value="'+source+'"]');if(radio)radio.checked=true;
        scpkWizardAudienceSource();
        document.getElementById('scpkWizardCSVStatus').textContent=(d.audience?.phones||[]).length+' CSV numbers restored from saved draft';
        for(const [id,key] of [['scpkWizardTag','tag'],['scpkWizardStage','stage'],['scpkWizardStatusFilter','status'],['scpkWizardTemperature','temperature']]){
            const sel=document.getElementById(id);if(sel)sel.value=d.audience?.[key]||'';
        }
        document.getElementById('scpkWizardAgent').value=String(d.audience?.agent_id||0);
        scpkBroadcastPopulateTemplates();
        const t=document.getElementById('scpkCampaignTemplate');
        t.value=d.template_name?(d.template_name+'|'+d.template_language):'';
        scpkBroadcastTemplateChanged(true);
        if(d.media_id){
            const kind=t.options[t.selectedIndex]?.dataset.mediaKind||'';
            scpkWizard.media={id:d.media_id,name:'Saved gallery media',mime:kind+'/saved'};
        }
        if(scpkWizard.media){
            const label=document.getElementById('scpkCampaignMediaLabel');
            if(label)label.textContent='Saved gallery selection: '+d.media_id+' (server verifies file on send)';
        }
        const a=await scpkBroadcastRequest('wizard_analytics?id='+id);
        scpkWizard.testAccepted=Number(a.data.test?.accepted||0)>0;
        scpkWizard.prepared=Number(a.data.counts?.total||0)>0;
        scpkWizardShow(d.status==='draft'?d.step:6);
        scpkWizardStatus('Campaign #'+id+' restored from database. '+(scpkWizard.prepared?'Prepared recipients: '+a.data.counts.total+'.':'Draft not yet prepared.'),'success');
        return true;
    }catch(e){scpkWizardStatus('Cannot reopen draft: '+e.message,'danger');return false;}
}
async function scpkWizardSendTest(){
    if(!scpkWizard.id){scpkWizardStatus('Save draft before testing','warning');return;}
    if(!window.confirm('Send ONE REAL approved marketing template to this opted-in test number? It may incur a Meta charge.'))return;
    try{
        await scpkWizardSave(4);
        const phone=document.getElementById('scpkWizardTestNumber').value;
        const r=await scpkBroadcastRequest('wizard_test',{campaign_id:scpkWizard.id,phone,confirm:'SEND_SINGLE_TEST'});
        scpkWizard.testAccepted=r.test_status==='accepted';
        document.getElementById('scpkWizardTestStatus').textContent=r.message+(r.code?' Code: '+r.code:'');
        scpkWizardStatus(r.message,r.test_status==='accepted'?'success':'warning');
    }catch(e){scpkWizardStatus('Test error: '+e.message,'danger');}
}
function scpkWizardUpdateReview(){
    const audience=scpkWizardAudienceValues();const template=scpkWizardSelectedTemplate();
    document.getElementById('scpkWizardReview').textContent=
      'Campaign: '+(document.getElementById('scpkWizardName').value||'—')+'\n'+
      'Audience source: '+audience.source+(audience.source==='csv'?' ('+audience.phones.length+' imported numbers)':'')+'\n'+
      'Template: '+(template.template_name||'—')+'\n'+
      'Media: '+(scpkWizard.media?.name||'None')+'\n'+
      'Test API accepted: '+(scpkWizard.testAccepted?'Yes':'Not yet')+'\n'+
      'Prepared: '+(scpkWizard.prepared?'Yes':'Not yet')+'\n'+
      'Final sends need an explicit click for each batch (maximum 2 contacts).';
}
async function scpkWizardPrepare(){
    if(!scpkWizard.id){scpkWizardStatus('Create draft first','warning');return;}
    if(!window.confirm('Freeze the CURRENT opted-in, filtered audience in a draft? No final messages are sent by this action.'))return;
    try{
        await scpkWizardSave(5);
        const r=await scpkBroadcastRequest('wizard_finalize',{campaign_id:scpkWizard.id,confirm:'PREPARE_REVIEWED_AUDIENCE'});
        scpkWizard.prepared=true;scpkWizardStatus('Prepared '+r.eligible+' eligible recipients as pending. No final messages sent.','success');
        scpkWizardUpdateReview();
    }catch(e){scpkWizardStatus(e.message,'danger');}
}
async function scpkWizardSendOnce(){
    const r=await scpkBroadcastRequest('send_batch',{campaign_id:scpkWizard.id,confirm:'SEND_APPROVED_MARKETING'});
    if(r.pending===0)scpkWizard.status='completed';else scpkWizard.status='active';
    scpkWizardStatus('Batch: '+r.results.map(x=>x.last4+'='+x.status).join(', ')+'. Remaining: '+r.pending+'. Accepted ≠ delivered.','success');
    return r;
}
async function scpkWizardSendBatch(){
    if(!scpkWizard.id||!scpkWizard.prepared){scpkWizardStatus('Prepare the audience first.','warning');return;}
    if(scpkBroadcastSending||scpkWizard.autoRun)return;
    if(!window.confirm('SEND a real approved Marketing template to the NEXT 2 eligible recipients now? This may incur WhatsApp charges.'))return;
    scpkBroadcastSending=true;const btn=document.getElementById('scpkWizardSendBtn');if(btn)btn.disabled=true;
    try{await scpkWizardSendOnce();await scpkWizardAnalytics();}
    catch(e){scpkWizardStatus('Send halted: '+e.message+'. Inspect analytics before retrying.','danger');}
    finally{scpkBroadcastSending=false;if(btn)btn.disabled=false;}
}
function scpkWizardStopRun(){
    scpkWizard.autoRun=false;
    scpkWizardStatus('Stopping controlled sends after any in-flight batch. Progress is saved in MySQL.','warning');
}
async function scpkWizardStartRun(){
    if(!scpkWizard.id||!scpkWizard.prepared){scpkWizardStatus('Prepare the audience and finish test first.','warning');return;}
    if(scpkWizard.autoRun||scpkBroadcastSending)return;
    if(!window.confirm('START REAL paid WhatsApp MARKETING sends for up to 40 opted-in contacts (20 batches of 2) WHILE THIS TAB STAYS OPEN? You can stop after the current batch.'))return;
    scpkWizard.autoRun=true;scpkBroadcastSending=true;
    const btn=document.getElementById('scpkWizardAutoSendBtn');if(btn)btn.disabled=true;
    try {
        let total=0;
        for(let i=0;i<20&&scpkWizard.autoRun;i++){
            if(document.hidden||appMode!=='broadcasts'||scpkWizard.status==='paused')break;
            const r=await scpkWizardSendOnce();
            total+=r.results.length;
            if(!r.results.length||Number(r.pending)===0)break;
            // Stop on any rejected/unconfirmed recipient. Never run through systemic errors.
            if(r.results.some(x=>x.status!=='accepted')){
                scpkWizardStatus('Stopped after '+total+' attempts: some recipients were not accepted. Inspect analytics.','warning');break;
            }
        }
        await scpkWizardAnalytics();
        scpkWizardStatus('Controlled sending stopped. Processed up to '+total+' recipients this session. Pending contacts stay saved.','success');
    }catch(e){scpkWizardStatus('Sending stopped: '+e.message+'. Check statuses before retry.','danger');}
    finally{scpkWizard.autoRun=false;scpkBroadcastSending=false;if(btn)btn.disabled=false;}
}
async function scpkWizardPause(){
    scpkWizard.autoRun=false;
    if(!scpkWizard.id||!window.confirm('Pause pending sends in this campaign?'))return;
    try{await scpkBroadcastRequest('pause_campaign',{campaign_id:scpkWizard.id});scpkWizard.status='paused';scpkWizardStatus('Campaign paused. Existing history remains saved.','success');}
    catch(e){scpkWizardStatus(e.message,'danger');}
}
async function scpkWizardResume(){
    if(!scpkWizard.id||!window.confirm('Resume saved pending campaign? No messages will be sent until you click Send next 2.'))return;
    try{await scpkBroadcastRequest('wizard_resume',{campaign_id:scpkWizard.id,confirm:'RESUME_PAUSED'});scpkWizard.status='active';scpkWizardStatus('Resumed. Click Send next 2 to continue.','success');}
    catch(e){scpkWizardStatus(e.message,'danger');}
}
async function scpkWizardAnalytics(){
    if(!scpkWizard.id)return;
    try{
        const r=await scpkBroadcastRequest('wizard_analytics?id='+scpkWizard.id);
        const x=r.data;const m=document.getElementById('scpkWizardMetrics');if(!m)return;
        m.replaceChildren();
        for(const [label,value] of [
          ['Audience',x.counts.total],['Meta accepted',x.counts.accepted],
          ['Delivered',x.counts.delivered],['Read',x.counts.read],
          ['Pending',x.counts.pending],['Failed',x.counts.failed],
          ['Unconfirmed',x.counts.unconfirmed],
          ['Estimated spend',x.estimated_cost_inr===null?'Not set':'₹'+x.estimated_cost_inr.toFixed(2)]
        ]){
            const tile=document.createElement('div');tile.className='scpk-wizard-metric';
            const val=document.createElement('strong');val.textContent=String(value);
            const cap=document.createElement('span');cap.textContent=label;
            tile.append(val,cap);m.append(tile);
        }
        const rateInput=document.getElementById('scpkWizardEstimatedRate');
        if(rateInput && document.activeElement!==rateInput)rateInput.value=x.estimated_unit_rate??'';
        scpkWizard.testAccepted=Number(x.test?.accepted||0)>0;
        scpkWizard.prepared=Number(x.counts.total)>0;
        scpkWizard.status=x.campaign_status;
    }catch(e){scpkWizardStatus('Analytics unavailable: '+e.message,'danger');}
}

async function scpkWizardSaveRate(){
    if(!scpkWizard.id){scpkWizardStatus('Save the campaign first','warning');return;}
    try{
        const rate=document.getElementById('scpkWizardEstimatedRate').value;
        await scpkBroadcastRequest('wizard_rate',{campaign_id:scpkWizard.id,estimated_unit_rate:rate});
        scpkWizardStatus('Estimated cost rate saved (not a Meta invoice).','success');
        await scpkWizardAnalytics();
    }catch(e){scpkWizardStatus('Could not save estimate: '+e.message,'danger');}
}

window.scpkBroadcastRefresh=async function(){
    const tbody=document.getElementById('scpkCampaignRows');if(!tbody)return;
    try{
        if(!scpkWizard.options)await scpkWizardLoadOptions();
        if(typeof fetchLiveTemplates==='function')await fetchLiveTemplates();
        scpkBroadcastPopulateTemplates();
        const r=await scpkBroadcastRequest('list_campaigns');tbody.replaceChildren();
        for(const c of r.data){
            const tr=document.createElement('tr');
            for(const v of [c.name,c.template_name||'Not selected',c.status,
                 String(c.accepted)+'/'+c.total]){
                const td=document.createElement('td');td.textContent=String(v);tr.appendChild(td);
            }
            const td=document.createElement('td');
            const continueButton=document.createElement('button');continueButton.type='button';
            continueButton.className='btn btn-outline-primary btn-sm me-1 mb-1';continueButton.textContent='Continue';
            continueButton.addEventListener('click',()=>scpkWizardOpen(c.id));
            const analytics=document.createElement('button');analytics.type='button';
            analytics.className='btn btn-outline-secondary btn-sm mb-1';analytics.textContent='Analytics';
            analytics.addEventListener('click',async()=>{
                const ok=await scpkWizardOpen(c.id);
                if(ok)scpkWizardShow(6);
                else {
                    // Analytics of campaigns created before the Wizard migration.
                    scpkWizard.id=Number(c.id);scpkWizard.status=c.status;
                    scpkWizardShow(6);
                }
            });
            td.append(continueButton,analytics);tr.append(td);tbody.append(tr);
        }
        if(!r.data.length){const tr=document.createElement('tr'),td=document.createElement('td');
            td.colSpan=5;td.textContent='No campaigns saved. Click + New campaign.';tr.append(td);tbody.append(tr);}
        scpkWizardStatus('Campaign list loaded. Opening this page does not send WhatsApp messages.','secondary');
    }catch(e){scpkWizardStatus('Cannot load campaigns: '+e.message,'danger');}
};
// No change to existing consent endpoints, new listener only saves wizard inputs.
document.addEventListener('DOMContentLoaded',()=>{
    const root=document.getElementById('scpkWizardEditor');if(!root)return;
    root.addEventListener('input',e=>{
        if(e.target.matches('input,select,textarea') && !e.target.matches('#scpkWizardCsvInput,#scpkWizardTestNumber'))scpkWizardQueueAutosave();
    });
    root.addEventListener('change',e=>{
        if(e.target.matches('input,select') && !e.target.matches('#scpkWizardCsvInput,#scpkWizardTestNumber'))scpkWizardQueueAutosave();
    });
});

window.addEventListener('pagehide',()=>{scpkWizard.autoRun=false;});
