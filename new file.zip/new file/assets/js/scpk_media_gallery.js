/* SCPK authenticated media library: isolated from existing Inbox behavior. */
let scpkGalleryItems = [];
let scpkGalleryMode = 'manage';
let scpkGalleryExpected = '';
let scpkGallerySelected = null;
window.scpkSelectedTemplateMedia = null;

window.scpkAddGalleryChooseButton = function(container, expected) {
    const wrap = document.createElement('div'); wrap.className = 'mb-2';
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'scpk-gallery-choose';
    button.innerHTML = '<i class="bi bi-images"></i> Choose from Media Library / Upload';
    const status = document.createElement('div'); status.className = 'scpk-gallery-picked';
    status.id = 'scpkTemplateSelectedMediaLabel'; status.style.display = 'none';
    button.addEventListener('click', () => scpkMediaLibraryOpen('header', expected));
    wrap.append(button, status); container.appendChild(wrap);
    const selected = window.scpkSelectedTemplateMedia;
    if (selected) scpkGalleryShowPicked(selected);
};

function scpkGalleryShowPicked(item) {
    const label = document.getElementById('scpkTemplateSelectedMediaLabel');
    if (label) {
        label.textContent = item ? 'Selected: ' + item.name + ' (' + item.mime + ')' : '';
        label.style.display = item ? 'block' : 'none';
    }
}

window.scpkMediaLibraryOpen = async function(mode='manage',expected='') {
    scpkGalleryMode = mode; scpkGalleryExpected = expected;
    scpkGallerySelected = null;
    const overlay = document.getElementById('scpkGalleryOverlay');
    if (!overlay) return;
    overlay.hidden = false;
    document.getElementById('scpkGalleryHint').textContent =
        mode === 'header' ? 'Choose ' + expected + ' media for the approved template' :
        mode === 'broadcast' ? 'Choose a campaign template header image/video' :
        'Upload images or videos for reuse in WhatsApp templates';
    document.getElementById('scpkGalleryFilter').value = expected === 'IMAGE' ? 'image' : expected === 'VIDEO' ? 'video' : 'all';
    document.getElementById('scpkGallerySelection').textContent = 'No media selected';
    document.getElementById('scpkGalleryUseBtn').style.display = mode === 'manage' ? 'none' : '';
    document.getElementById('scpkGalleryUseBtn').disabled = true;
    document.getElementById('scpkGallerySearch').value = '';
    await scpkMediaLibraryLoad();
    document.getElementById('scpkGallerySearch').focus();
};
window.scpkMediaLibraryClose = function() {
    const overlay = document.getElementById('scpkGalleryOverlay');
    if (overlay) overlay.hidden = true;
};
window.scpkMediaLibraryLoad = async function() {
    const label = document.getElementById('scpkGalleryMessage');
    label.textContent = 'Loading secure media gallery…';
    try {
        const resp = await fetch(baseUrl + 'inbox/template_media_library', {credentials:'same-origin',cache:'no-store'});
        const data = await resp.json();
        if (data.status !== 'success' || !Array.isArray(data.data)) throw new Error(data.message || 'Gallery could not be loaded');
        scpkGalleryItems = data.data;
        label.textContent = scpkGalleryItems.length + ' saved media files (private, company-specific).';
        scpkMediaLibraryRender();
    } catch(e) {
        label.textContent = e.message || 'Media gallery unavailable';
    }
};
window.scpkMediaLibraryRender = function() {
    const grid = document.getElementById('scpkGalleryGrid'); if (!grid) return;
    grid.replaceChildren();
    const search = document.getElementById('scpkGallerySearch').value.toLowerCase();
    const kind = document.getElementById('scpkGalleryFilter').value;
    const filtered = scpkGalleryItems.filter(item =>
        (kind === 'all' || item.mime.startsWith(kind + '/')) &&
        (!scpkGalleryExpected || item.mime.startsWith(scpkGalleryExpected.toLowerCase() + '/')) &&
        String(item.name || '').toLowerCase().includes(search));
    if (!filtered.length) {
        const empty=document.createElement('div'); empty.textContent='No matching media. Upload JPG/PNG or MP4 above.';
        empty.className='text-muted small p-3';grid.appendChild(empty);return;
    }
    for (const item of filtered) {
        const tile=document.createElement('div'); tile.role='button'; tile.tabIndex=0; tile.className='scpk-gallery-tile';
        if (scpkGallerySelected && scpkGallerySelected.id === item.id) tile.classList.add('is-selected');
        let preview;
        if (item.mime.startsWith('video/')) {
            preview=document.createElement('video'); preview.preload='metadata';preview.muted=true;
            preview.playsInline=true; preview.controls=true;
        } else {
            preview=document.createElement('img');preview.alt=item.name;preview.loading='lazy';
        }
        // Server returns a same-origin, authenticated URL; validate to prevent external media injection.
        const url = new URL(String(item.preview_url || ''), window.location.href);
        if (url.origin !== window.location.origin || !url.pathname.includes('/inbox/template_media_preview')) continue;
        preview.src=url.href;
        const name=document.createElement('strong');name.textContent=item.name;
        const size=document.createElement('small');size.textContent=item.mime.split('/')[1].toUpperCase()+' · '+Math.ceil(item.size/1024)+' KB';
        tile.append(preview,name,size);
        const select = () => {
            scpkGallerySelected=item;
            document.getElementById('scpkGallerySelection').textContent = 'Selected: '+item.name;
            document.getElementById('scpkGalleryUseBtn').disabled = false;
            scpkMediaLibraryRender();
        };
        tile.addEventListener('click', e => { if(e.target.tagName!=='VIDEO') select(); });
        tile.addEventListener('keydown', e => {
            if(e.key==='Enter' || e.key===' '){e.preventDefault();select();}
        });
        grid.appendChild(tile);
    }
};
window.scpkMediaLibraryUpload = async function() {
    const input=document.getElementById('scpkGalleryUploadInput');
    const file=input && input.files && input.files[0];
    const status=document.getElementById('scpkGalleryMessage');
    if (!file) {status.textContent='Choose a JPG/PNG or MP4 to upload.';return;}
    const max=file.type==='video/mp4'?16*1024*1024:5*1024*1024;
    if (!['image/jpeg','image/png','video/mp4'].includes(file.type)||file.size<1||file.size>max) {
        status.textContent='Allowed: JPG/PNG up to 5MB; MP4 up to 16MB.';return;
    }
    const btn=document.getElementById('scpkGalleryUploadBtn');btn.disabled=true;
    status.textContent='Uploading securely to CRM media library…';
    try {
        const body=new FormData();body.append('media',file,file.name);
        const resp=await fetch(baseUrl+'inbox/template_media_upload',{method:'POST',credentials:'same-origin',headers:{'X-SCPK-CSRF':APP_CONFIG.scpkActionToken},body});
        const data=await resp.json();
        if(data.status!=='success')throw new Error(data.message||'Upload failed');
        input.value='';await scpkMediaLibraryLoad();
        status.textContent='Saved in private gallery. Select it below to use in a template.';
    } catch(e){status.textContent=e.message||'Upload failed';}
    finally{btn.disabled=false;}
};
window.scpkMediaLibraryUseSelected = function() {
    if(!scpkGallerySelected)return;
    if(scpkGalleryMode==='header'){
        window.scpkSelectedTemplateMedia={id:scpkGallerySelected.id,name:scpkGallerySelected.name,mime:scpkGallerySelected.mime};
        scpkGalleryShowPicked(window.scpkSelectedTemplateMedia);
    } else if(scpkGalleryMode==='broadcast') {
        if(typeof scpkBroadcastGallerySelected==='function') scpkBroadcastGallerySelected(scpkGallerySelected);
    }
    scpkMediaLibraryClose();
};
document.addEventListener('keydown', e=>{
    if(e.key==='Escape' && document.getElementById('scpkGalleryOverlay')?.hidden===false){
        e.stopPropagation();scpkMediaLibraryClose();
    }
});
